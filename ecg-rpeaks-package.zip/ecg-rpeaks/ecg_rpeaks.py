#!/usr/bin/env python3
"""ecg_rpeaks -- R peak detection, manual review, and accuracy comparison.

This is the production tool the diagnostic programme (v1-v10) was built to
specify.  Every default in DEFAULTS and in the species profiles below is a
measured result, not a guess, and each one carries the evidence that set it.

  band 20-45 Hz        v4 band sweep: 20-45 / 25-55 / 30-60 are identical to
                       four decimals -- a wide plateau.  The cliff is between
                       8-20 Hz (tmplQ 0.583) and 10-30 Hz (0.958).
  refractory 350 ms    v10, 19/19 files.  The 500 ms value used for most of
                       this project was BINDING: 29-71% of short intervals sat
                       against it, and dropping to 350 ms recovered beats in
                       every single file (median +0.8%, max +5.8%) and moved
                       the fleet mean rate +2.32 bpm.
  chunk 60 s           neurokit's Pan-Tompkins updates SPKI only inside the
                       accept branch and nests its searchback there too, so one
                       gross artifact raises the threshold floor (0.25 * SPKI)
                       above every real beat permanently.  Measured on part015:
                       SPKI frozen 25 windows, threshold 12x above every beat
                       for 26 minutes.  Chunking bounds the loss to about half
                       a chunk: 600 s -> 0.916 coverage, 120 s -> 0.984,
                       60 s -> 1.002.
  lead by tmplQ        NOT by SQI.  Across 19 files SQI ranked lead 2 highest
                       in 17 while lead 1 had the better morphology in 17.  SQI
                       measures the noise floor, not whether the QRS is
                       separable from the dissociated P wave.
  no PCA fusion        lost to the best single lead in 18/19 files.
  clustering +-40 ms   +-100 ms fragmented ONE morphology into eight clusters
                       under AV dissociation, as the P wave marched through the
                       window at random phase.
  rate = beats/time    NOT 60/medianRR.  With 20-30% of beats in short/long
                       couplets the median and mode both sit on the LONG
                       interval and read up to 10.1% low.  (An earlier rule in
                       this project said the opposite; it was derived from a
                       DROPOUT case and was wrong for couplets.)

The rhythm these defaults are tuned for: AV dissociation with a pacemaker, so
the atrial and ventricular rates are independent.  Roughly 20-30% of beats
arrive early and RESET the ventricular timer rather than being followed by a
compensatory pause.  Those early beats are REAL -- they carry 0.87-1.18x normal
QRS amplitude (a P-wave false positive runs 0.1-0.3x), and suppressing them
lowers the measured rate below the modal rate, which only happens if a genuine
interval is being merged away.

Text output only: no matplotlib, no images, no network.  Read-only on the data.

Usage
-----
  detect   run detection, write a peak file          -> this is (a)
  show     ASCII display of signal + detected peaks  -> inspect (a)
  review   write an editable file with suggestions   -> you edit this
  compare  score an edited file against detection    -> (a) vs (b)
  report   QC and rate summary for one or many files

  python3 ecg_rpeaks.py detect  --input "$HOME/EDF_output/*.edf" --outdir peaks/
  python3 ecg_rpeaks.py show    --input FILE.edf --peaks peaks/FILE.peaks.csv \
                                --start 300 --seconds 6
  python3 ecg_rpeaks.py review  --input FILE.edf --peaks peaks/FILE.peaks.csv \
                                --out review.csv
  # ... edit review.csv by hand (set keep=0 to reject, keep=1 to accept a
  #     suggestion, or add your own rows) ...
  python3 ecg_rpeaks.py compare --input FILE.edf --auto peaks/FILE.peaks.csv \
                                --manual review.csv
"""

import argparse
import bisect
import csv
import datetime
import glob
import hashlib
import os
import re
# stdlib -- no new dependency.  All four Ponemah sidecars (.PnmMarks,
# .PnmResults, .PnmExp, .PnmExpLog) are SQLite databases, and one of them very
# likely holds Ponemah's OWN per-beat detections.
import sqlite3
# Only the selftest writes binary; everything that READS it uses
# int.from_bytes / np.frombuffer, which carry their width and endianness at the
# call site where a reader has to be able to check them.
import struct
import sys
import traceback
import zipfile

import numpy as np
from scipy.signal import butter, filtfilt, detrend

try:
    import neurokit2 as nk
except ImportError:
    sys.exit("neurokit2 not importable -- run this where the detection env lives")

_VERSION_BASE = "ecg_rpeaks/1.1"


def _self_hash():
    """Hash of this source file, shown in every banner.

    Output that cannot identify the code that produced it is a trap: three
    separate runs of a stale copy were read as current ones, because the
    version string alone did not change between builds.

    The hash is taken over LINE-ENDING-NORMALISED bytes.  A first attempt hashed
    the raw file and was defeated immediately: copying the file from Linux to a
    Mac rewrote the line endings, so the same code reported a different build
    and the tag could not be compared against the delivered value at all.
    Normalising means the tag identifies the CODE, not the transfer.
    """
    try:
        with open(os.path.abspath(__file__), "rb") as f:
            raw = f.read()
        norm = raw.replace(b"\r\n", b"\n").replace(b"\r", b"\n").rstrip(b"\n")
        return hashlib.sha1(norm).hexdigest()[:8]
    except Exception:                                        # noqa: BLE001
        return "unknown"


VERSION = "%s build %s" % (_VERSION_BASE, _self_hash())


# =========================================================== species profiles

class Species:
    """Everything that depends on the animal, in one object.

    The pig profile is measured.  The rat profile is a STARTING POINT and is
    marked unvalidated: no rat data has been seen by this project.  Nothing
    outside this class should hardcode an animal-specific number.
    """

    def __init__(self, name, fs_expected, hr_plausible, refractory_ms, band,
                 snap_ms, match_tol_ms, cluster_half_ms, beat_half_ms,
                 qrs_width_ms, validated, amp_floor_frac=0.25,
                 no_signal_frac=0.15, saturated_frac=7.0):
        self.name = name
        self.fs_expected = fs_expected
        self.hr_plausible = hr_plausible          # (min_bpm, max_bpm)
        self.refractory_ms = refractory_ms
        self.band = band
        self.snap_ms = snap_ms
        self.match_tol_ms = match_tol_ms          # (a) vs (b) matching window
        self.cluster_half_ms = cluster_half_ms
        self.beat_half_ms = beat_half_ms
        self.qrs_width_ms = qrs_width_ms
        self.validated = validated
        # A detection whose deflection is this small a fraction of the median
        # QRS cannot be a beat.  Measured basis (v9 [5]): real beats, including
        # the early RESET beats, ran 0.87-1.18x the normal amplitude, while
        # P-wave false positives ran 0.1-0.3x.  0.25 sits below every real beat
        # ever measured here and at the top of the artifact band.
        self.amp_floor_frac = amp_floor_frac
        # A 2 s window whose peak-to-peak is this small a fraction of the median
        # QRS contains no signal at all.  MEASURED over 17 files, 244,800
        # windows, by the `spans` command:
        #     lowest value on any dropout-free file   0.445  (part007, t=207 s)
        #     top of the flat population in a dropout ~0.10  (part010)
        #     everything between: 2 windows, both edge ramps
        # 0.15 sits 3.0x under the clean floor and 1.5x over the dropout top.
        # It is deliberately NOT the geometric midpoint (0.21): the two errors
        # are not equally bad.  Cutting too high excises real beats and real
        # time and corrupts the rate SILENTLY; cutting too low leaves a second
        # or two of dropout in the denominator, which is a small bias that the
        # gap machinery still reports.  So the margin is spent on the side that
        # fails quietly.
        self.no_signal_frac = no_signal_frac
        # Above this the amplifier is railing.  Also measured: clean controls
        # reach 0 s only at >=7, and they legitimately carry ~15 s each of 3x
        # transients that the pipeline handles perfectly.
        #
        # PURELY ADVISORY: it reports, it does not act.  It discards no beats
        # and no time, because part010 would lose 60.5 s containing real beats
        # (RR 1034, 1006, 986) to remove a handful of false positives.  An
        # earlier draft of this comment said saturation would also suppress the
        # refill; it does not, and the reasoning is worth keeping.  The refill
        # only enters a span where detection ALREADY failed, so suppressing it
        # there can only subtract recoveries -- and part006's 51 recovered
        # beats sit next to exactly this kind of transient.  The junk that the
        # refill does generate on saturated artifact is already caught, by
        # measurement: part010's floor% rose 0.1 -> 1.3 when the refill landed,
        # which is the amplitude floor removing those detections.  Adding a
        # second, unmeasured suppressor to redo work the floor is observed to
        # be doing would risk a verified gain for no demonstrated benefit.
        #
        # Saturation is uncorrelated with dropout: 5 of 17 files exceed 10x and
        # only one of those has a dropout.
        self.saturated_frac = saturated_frac


PIG = Species("pig", 500.0, (40.0, 200.0), 350.0, (20.0, 45.0), 80.0, 80.0,
              40.0, 100.0, 14.0, validated=True)

# Rat: HR 300-500 bpm means RR 120-200 ms, so every window scales down roughly
# with the QRS width.  UNVALIDATED -- see the neurokit caveat in detect_nk().
RAT = Species("rat", 1000.0, (200.0, 600.0), 60.0, (25.0, 100.0), 15.0, 15.0,
              8.0, 25.0, 5.0, validated=False)

SPECIES = {"pig": PIG, "rat": RAT}

# clip_k = 3.0 is bounded on BOTH sides by measurement, not by taste:
#   lower bound  k >= 2.83  (the largest measured k_min_safe across files;
#                            below it the clip starts cutting real QRS)
#   upper bound  k <= 3     (k=4 still left part015 with a 20.7 s gap;
#                            k=3 reduced it to 2.0 s)
# See clip_artifacts() for the derivation and `clipsweep` for the experiment.
DEFAULTS = dict(chunk_s=60.0, lead_in_s=15.0, clip_k=3.0, window_s=60.0,
                corr=0.85, kmax=8, min_frac=0.01, qc_min=0.90,
                nosig_win_s=2.0, nosig_step_s=0.25, nosig_min_s=2.0)

# Long recordings are analysed in SEGMENTS of this many minutes (report,
# trend, view --segment; 0 = never).  One hour because that is what the EDF
# exports of the same recordings already are: P10 as 19 hourly EDFs and P10
# as one 18.6 h .PnmWav should give the same kind of table, row for row.
# Each segment is analysed as if it were its own file -- its own lead choice,
# its own detection thresholds, its own no-signal and empty-gap measurement
# -- which is also what bounds memory: only one segment is ever decoded.
SEGMENT_MIN_DEFAULT = 60.0

# One sentence, used by the text report and its HTML page, so a reader does not
# add the three removal columns together.  They overlap by design: Ponemah's
# bad intervals arrive as blanked samples, which also measure as no-signal.
REMOVED_OVERLAP_NOTE = ("no-signal, marked and empty seconds can overlap (Ponemah's bad "
                        "intervals are blanked, so they also read as no-signal); "
                        "overlapping time is removed once, so they do not add up.")
# A file is only split when it is longer than one segment by MORE than this
# fraction of a segment, and a trailing remainder no longer than it is folded
# into the last segment.  Without it an hourly EDF that runs 60.02 min would
# become a 60-minute segment plus a 1 s one, and the 1 s segment would carry
# SHORT_RECORD and a meaningless rate.  5% of 60 min is 3 min.
SEGMENT_TOL_FRAC = 0.05

# Flags that are worth SAYING but do not mean "do not believe this file".
# Without this distinction the only way to report a borderline condition is to
# condemn the file, which trains you to ignore the flags column.
#
# NO_SIGNAL is advisory ON PURPOSE, and it is the one entry here that deserves
# an argument.  A flag answers exactly one question -- "can I believe the
# number in the bpm column?" -- and once a no-signal span has been excised the
# answer is yes: the beats inside it are dropped from the numerator, its
# duration is dropped from the denominator, and the interval bridging it is
# dropped from the gap statistics.  Condemning the file anyway would leave
# part010 exactly where it started and would mean this whole mechanism bought
# nothing.  What is NOT knowable is what the heart did during the dead time,
# and the tool makes no claim about that.
ADVISORY_FLAGS = frozenset(["CLIP_BELOW_KMIN", "SATURATED", "NO_SIGNAL"])


def is_advisory(flag):
    """True if `flag` is worth saying but does not disqualify the file.

    A plain set lookup is not enough any more.  Some flags carry their measured
    value in the name -- `AMP_FLOOR_0.99%` -- precisely so that the printed
    label cannot disagree with the verdict that produced it, and an exact-match
    set can never contain those.  Getting this wrong is silent in the worst
    way: trustworthy is RECOMPUTED from the flag list at the end of analyse(),
    so a flag the set does not recognise quietly disqualifies the file no
    matter what the code that appended it intended.
    """
    if flag in ADVISORY_FLAGS:
        return True
    # Amplitude floor below the major cut: reported, not disqualifying.  The
    # MAJOR variant shares the prefix and must NOT be caught here.
    if flag.startswith("AMP_FLOOR_") and not flag.startswith("AMP_FLOOR_MAJOR"):
        return True
    # Same shape, same trap, for time the exporter marked as missing.  A file
    # with a second of marked data is still a usable file; the excision has
    # already removed that second from both the beats and the duration, so the
    # rate it reports is correct for the time that remains.
    if flag.startswith("MARKED_") and not flag.startswith("MARKED_MAJOR"):
        return True
    return False


# How many samples must land in a percentile's TAIL before that percentile is
# a percentile rather than a synonym for the maximum.
#
# Not arbitrary, and not a style preference -- this is the guard on a real
# defect that survived several sessions of review.  A 0.178 s ASCII sample
# (89 samples, under one cardiac cycle) reported `p99/A = 1.11` against a
# fleet range of 0.46-0.48, and that 1.11 was carried forward as a genuine
# morphology anomaly worth investigating.  It was not.  The 99th percentile
# of 89 samples sits at index 88.1: it IS the maximum.  A ratio of max to
# beat amplitude is ~1 by construction and says nothing about the animal.
#
# The statistic is built on the assumption that a QRS is RARE -- a 14 ms
# complex at ~65 bpm occupies ~1.5% of samples, so p99 lands partway up the
# complex and the ratio carries information.  That assumption needs enough
# samples for the top 1% to be a population rather than a single point.
PERCENTILE_TAIL_MIN = 10.0
# And the denominator A is a MEDIAN over beats, which needs beats.
PERCENTILE_BEATS_MIN = 10


def percentile_support(n_samples, n_beats, pct=99.0,
                       tail_min=PERCENTILE_TAIL_MIN,
                       beats_min=PERCENTILE_BEATS_MIN):
    """Can a p-th percentile / median-amplitude ratio be believed here?

    Pure, so it can be asserted against directly.  Returns a dict rather than
    a bool because the CALLER has to be able to say why it refused -- a blank
    column with no reason is how the original defect hid: the reader (which
    did warn, correctly, that 89 rows were read against a header claiming
    10,800,001) was honest, and the summary table that printed p99/A next to
    it was not.  The warning existed; it just never reached the number it
    invalidated.

    `tail_n` is the expected number of samples above the percentile.  At
    pct=99 and tail_min=10 this asks for 1,000 samples, which is 2 s at
    500 Hz -- no real recording is anywhere near it, and the 0.178 s sample
    that caused this fails by more than an order of magnitude.
    """
    n_samples = int(n_samples or 0)
    n_beats = int(n_beats or 0)
    tail_n = n_samples * (1.0 - float(pct) / 100.0)
    why = ""
    if tail_n < tail_min:
        why = ("p%g of %d sample(s) has %.1f sample(s) above it -- that is "
               "the maximum, not a percentile" % (pct, n_samples, tail_n))
    elif n_beats < beats_min:
        why = ("the amplitude it is divided by is a median over %d beat(s)"
               % n_beats)
    return dict(ok=not why, tail_n=tail_n, n_samples=n_samples,
                n_beats=n_beats, pct=float(pct), why=why)


# Beyond this fraction of the record, excision stops being a repair and starts
# being a cover-up, so NO_SIGNAL_MAJOR is raised instead and disqualifies.
#
# THIS NUMBER IS NOT MEASURED, unlike every other threshold in this file, and
# it is written here rather than in Species so that it cannot be mistaken for
# one that is.  The corpus contains exactly one file with a dropout and it sits
# at 0.44% of its record, so the data can bound this from below and cannot
# distinguish 5% from 20%.  What IS measured is that 0.44% is safe to excise.
# 10% is a guard against an unexamined future file, placed where "most of the
# record survived" stops being a fair description.  Replace it with a measured
# value as soon as a second dropout file exists.
NO_SIGNAL_MAJOR_FRAC = 0.10

# Amplitude-floor reporting bands.  These replace a single `> 1%` cliff that
# was demonstrably too sharp for the quantity it was judging.
#
# The failure was concrete.  Excising part010's dead time moved its floor%
# from 1.31 to 0.99 -- a 0.32pp change, well inside what a denominator edit can
# do -- and that silently flipped the file from untrustworthy to trustworthy,
# taking the fleet from 16/17 to 17/17.  A verdict that turns on 0.01pp is a
# rounding coin-flip wearing the costume of a finding.  Worse, the label was
# formatted `%.0f%%`, so 1.01% and 1.49% both printed "AMP_FLOOR_1%" while
# 0.99% printed nothing: the label could not express the distinction the
# decision was turning on, which is how the flip went unnoticed.
#
# Two edges instead of one, and they answer different questions:
#
#   below NOTE   say nothing.  A healthy record loses ~0 here -- real beats sit
#                at 0.87-1.18x the median QRS -- so anything above the noise
#                floor is worth reporting.
#   NOTE..MAJOR  report the measured value, ADVISORY.  The floor did its job:
#                it removed sub-QRS deflections the detector should not have
#                emitted.  That is information about the record, not grounds to
#                disbelieve the rate, because the offending detections are gone
#                from the numerator by the time the rate is computed.
#   above MAJOR  disqualifying.  At this share the detector was not finding
#                beats, it was finding something else, and what survived the
#                floor is no longer a safe basis for a rate.
#
# NOTE = 0.5% is bounded by measurement: the clean files sit at ~0 and part010
# sits near 1%, so the corpus separates those two populations and 0.5% is
# between them.  MAJOR = 5% is NOT measured -- no file in the corpus is
# anywhere near it -- and carries the same warning as NO_SIGNAL_MAJOR_FRAC
# above: it is a guard against an unexamined future file, not a finding.
#
# The property that matters, and that [13] asserts: part010 at 1.31% and at
# 0.99% now receive the SAME verdict.  Excising dead time is not allowed to
# change whether you believe the amplitude floor's report about a file.
AMP_FLOOR_NOTE_FRAC = 0.005
AMP_FLOOR_MAJOR_FRAC = 0.05


# ==================================================================== readers

# A recording start is needed to place a file on a wall clock, which is what
# `trend` bins against.  There are two independent sources and they are treated
# as two WITNESSES rather than as a primary and a fallback: each is parsed, and
# a disagreement is reported instead of resolved.  Both fail in ways that look
# like success -- an exporter that never set the header leaves a plausible
# placeholder date, and a filename convention can be changed by whoever renames
# the files -- so a silent preference for either one would put a whole night of
# heart-rate trend on the wrong hour with nothing to show for it.

_NAME_TS = re.compile(r"(?:^|[^0-9])(\d{8})[_-](\d{6})(?:[^0-9]|$)")
# Ponemah native files write the same stamp with NO separator:
#   `08062023 P10.P10.20230806195959.PnmWav`
# Fourteen bare digits are a weaker claim than a separated pair -- a serial
# number or a subject id of the right length would match the shape -- so this
# form is additionally required to parse to a plausible RECORDING year.  That
# is a filter on the value, not a guess about it: a 14-digit run that is not a
# date will almost never land between 1990 and 2100 with a valid month and day.
_NAME_TS14 = re.compile(r"(?:^|[^0-9])(\d{8})(\d{6})(?:[^0-9]|$)")
_NAME_YEAR_RANGE = (1990, 2100)


def _parse_edf_start(date_s, time_s):
    """EDF header start as a datetime, or None if it is unusable.

    The two-digit year follows the EDF clipping rule: 85-99 means 19xx and
    00-84 means 20xx.  `01.01.85` is the canonical "not set" placeholder and is
    rejected rather than believed, because a 1985 timestamp on a 2023 recording
    would sort and bin perfectly happily.
    """
    try:
        d = date_s.replace("-", ".").replace("/", ".").split(".")
        t = time_s.replace("-", ".").replace(":", ".").split(".")
        if len(d) != 3 or len(t) != 3:
            return None
        dd, mm, yy = (int(x) for x in d)
        hh, mi, ss = (int(x) for x in t)
        year = 1900 + yy if yy >= 85 else 2000 + yy
        if (dd, mm, year) == (1, 1, 1985):
            return None
        return datetime.datetime(year, mm, dd, hh, mi, ss)
    except (ValueError, TypeError):
        return None


def _parse_name_start(path):
    """`..._20230806_195959.edf` as a datetime, or None.

    Also accepts the unseparated `.20230806195959.` form that Ponemah native
    files use.  That second form is only believed if it yields a plausible
    recording year -- see _NAME_TS14.
    """
    base = os.path.basename(path)
    m = _NAME_TS.search(base)
    if m:
        try:
            return datetime.datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S")
        except ValueError:
            return None
    m = _NAME_TS14.search(base)
    if not m:
        return None
    try:
        dt = datetime.datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S")
    except ValueError:
        return None
    lo, hi = _NAME_YEAR_RANGE
    return dt if lo <= dt.year <= hi else None


def record_start(path, edf=None):
    """(datetime or None, source, note) for where this file sits on the clock.

    Agreement to within a second is required to call the answer confirmed.  If
    only one witness exists the answer is used but labelled, so the trend header
    can say which files are placed on evidence and which on a single source.
    """
    ext = os.path.splitext(path)[1].lower()
    hdr = getattr(edf, "start_dt", None)
    # Which reader owns this file?  Extension first, then content -- the same
    # order load_signals() uses, and for the same reason.  Keeping these two in
    # step matters more than it looks: if a file LOADS by content sniffing but
    # is placed by extension only, it reads fine and then silently has no
    # timestamp, so `trend` drops it and the record simply goes missing from
    # the chart with no error anywhere.
    kind = None
    if ext in (".edf", ".bdf", ".rec"):
        kind = "edf"
    elif ext in _ASCII_EXTS:
        kind = "ascii"
    elif ext not in (".wav", ".wave") and ext not in PNMWAV_EXTS:
        kind, _ = _sniff_format(path)
    if hdr is None and kind == "edf":
        try:
            hdr = MiniEDF(path).start_dt
        except Exception:                                    # noqa: BLE001
            hdr = None
    elif hdr is None and kind == "ascii":
        # An ASCII export states its start time in the header and carries no
        # timestamp in the filename, so this is usually the ONLY witness --
        # which is exactly why it is labelled as single-sourced below rather
        # than reported as confirmed.
        try:
            hdr = ascii_describe(path).get("start")
        except Exception:                                    # noqa: BLE001
            hdr = None
    name = _parse_name_start(path)
    if hdr and name:
        skew = abs((hdr - name).total_seconds())
        if skew <= 1.0:
            return hdr, "header+name", ""
        return (name, "name (DISAGREES with header)",
                "header says %s, filename says %s, %.0f s apart"
                % (hdr.isoformat(sep=" "), name.isoformat(sep=" "), skew))
    if hdr:
        return hdr, "header only", ""
    if name:
        return name, "filename only", ""
    return None, "none", "no usable timestamp in header or filename"


# ------------------------------------------------------------ .NET tick clock
#
# Every timestamp in the Ponemah sidecars is a .NET DateTime tick: 100 ns since
# 0001-01-01.  Nothing in the file says so, so it was CHECKED rather than
# assumed, and it is worth writing down how, because a wrong time unit is the
# kind of error that produces plausible numbers forever.
#
# On 08062023 P10, Cycle.CycleTime spans
#     638269487992540000 .. 638270159078000000
# Read as 100 ns ticks those are 2023-08-06 19:59:59.254 and 2023-08-07
# 14:38:27.800, a span of 67108.546 s.  Two independent facts agree:
#
#   * The waveform file beside it is named ...P10.20230806195959.PnmWav.  The
#     decoded start matches that stamp to the second, and the filename was
#     written by a different part of the system than the database.
#   * The payload arithmetic on that .PnmWav -- 3 channels, int16, 500 Hz,
#     derived with no reference to this database at all -- gave 67109 s.  The
#     two durations agree to 0.5 s over 18.6 hours, a relative error of 7e-6.
#
# A wrong tick unit is wrong by a FACTOR (10, 1000, 10^7), never by 7e-6.  The
# unit is settled.  The remaining uncertainty is the timezone, which .NET ticks
# do not carry: these are wall-clock times in whatever zone the acquisition PC
# was set to, and this tool never converts them, only subtracts them.
NET_TICKS_PER_S = 10000000
NET_EPOCH = datetime.datetime(1, 1, 1)


def ticks_to_dt(t):
    """A .NET tick count as a datetime.  Returns None rather than raising."""
    try:
        return NET_EPOCH + datetime.timedelta(microseconds=float(t) / 10.0)
    except (TypeError, ValueError, OverflowError):
        return None


def ticks_to_s(t, t0):
    """Seconds from `t0`, as a float.  Subtraction only -- no epoch, no zone.

    Elapsed time is the one thing the tick values give up without any
    assumption at all: whatever the epoch and whatever the timezone, a
    difference of ticks is a difference of seconds.  Everything this tool does
    with beat times is a difference, so this is the function that matters and
    `ticks_to_dt` is only for display.
    """
    return (np.asarray(t, dtype=np.int64) - np.int64(t0)) / float(NET_TICKS_PER_S)


class MiniEDF:
    """EDF reader.  Deliberately minimal and dependency-free."""

    def __init__(self, path):
        self.path = path
        with open(path, "rb") as f:
            h = f.read(256)
            if len(h) < 256:
                raise ValueError("%s: too short to be EDF" % path)
            g = lambda a, b: h[a:b].decode("ascii", "ignore").strip()
            # Bytes 168-184 are the recording start, dd.mm.yy then hh.mm.ss.
            # Parsed but NOT trusted on its own -- see record_start().  Many
            # exporters leave it at a placeholder, and the two-digit year needs
            # the EDF clipping rule (85-99 -> 19xx, 00-84 -> 20xx) which silently
            # produces a date a century out if applied wrongly.
            self.start_raw = (g(168, 176), g(176, 184))
            self.start_dt = _parse_edf_start(*self.start_raw)
            try:
                self.header_bytes = int(g(184, 192))
                self.num_records = int(g(236, 244))
                self.rec_duration = float(g(244, 252))
                self.ns = int(g(252, 256))
            except ValueError as e:
                raise ValueError("%s: unreadable EDF header (%s)" % (path, e))
            raw = f.read(self.header_bytes - 256)
        ns = self.ns

        def blk(off, w):
            return [raw[off + i * w: off + (i + 1) * w].decode("ascii", "ignore").strip()
                    for i in range(ns)]

        o = 0
        self.labels = blk(o, 16); o += ns * 16
        o += ns * 80                                   # transducer
        self.units = blk(o, 8); o += ns * 8
        self.pmin = [float(x) for x in blk(o, 8)]; o += ns * 8
        self.pmax = [float(x) for x in blk(o, 8)]; o += ns * 8
        self.dmin = [float(x) for x in blk(o, 8)]; o += ns * 8
        self.dmax = [float(x) for x in blk(o, 8)]; o += ns * 8
        o += ns * 80                                   # prefiltering
        self.spr = [int(x) for x in blk(o, 8)]
        self.total_spr = sum(self.spr)
        self.offsets, acc = [], 0
        for nn in self.spr:
            self.offsets.append(acc); acc += nn
        self.scale = [((self.pmax[i] - self.pmin[i]) / (self.dmax[i] - self.dmin[i]))
                      if (self.dmax[i] - self.dmin[i]) else 1.0 for i in range(ns)]
        self.fs = [s / self.rec_duration if self.rec_duration > 0 else float(s)
                   for s in self.spr]

    def read(self, idxs, max_records=None):
        nrec = self.num_records if max_records is None else min(self.num_records, max_records)
        with open(self.path, "rb") as f:
            f.seek(self.header_bytes)
            raw = np.fromfile(f, dtype="<i2", count=nrec * self.total_spr)
        nrec = len(raw) // self.total_spr
        if nrec == 0:
            raise ValueError("%s: no complete data records" % self.path)
        raw = raw[: nrec * self.total_spr].reshape(nrec, self.total_spr)
        cols = []
        for i in idxs:
            ch = raw[:, self.offsets[i]: self.offsets[i] + self.spr[i]].ravel().astype(np.float64)
            cols.append(self.pmin[i] + (ch - self.dmin[i]) * self.scale[i])
        return np.column_stack(cols)


SKIP_LABELS = ("annotation", "batt", "temp", "act", "acc", "gyro", "status", "imped")


# ------------------------------------------------------------------ RIFF WAVE
#
# "Ponemah waveform file" may well BE a RIFF/WAVE file -- several acquisition
# systems export waveforms that way.  Unlike the native Ponemah container, RIFF
# is a published, self-describing format: the header states the sample format,
# channel count and rate, so reading it is implementation, not guesswork.  That
# is the whole reason this is written and read_ponemah() below still is not.
#
# The one thing a WAV does NOT carry is a physical scale.  Integer PCM is
# normalised to [-1, 1) and float PCM is passed through unchanged, and the
# result is labelled as stored units, not mV.  Inventing a mV scale would be
# exactly the class of error this file exists to avoid.  It costs nothing here:
# every amplitude decision in the pipeline (the floor, the no-signal range test)
# is expressed as a RATIO to the median QRS, so it is scale-invariant.

def _u32(b, i):
    return int.from_bytes(b[i:i + 4], "little", signed=False)


def _u16(b, i):
    return int.from_bytes(b[i:i + 2], "little", signed=False)


def wav_describe(path):
    """Parse a RIFF/WAVE header.  Returns a dict, or raises ValueError.

    Walks the chunk list rather than assuming `fmt ` and `data` sit at fixed
    offsets, because they routinely do not -- LIST/INFO and fact chunks get
    written between them.
    """
    fsz = os.path.getsize(path)
    with open(path, "rb") as f:
        head = f.read(12)
        if len(head) < 12 or head[:4] != b"RIFF" or head[8:12] != b"WAVE":
            raise ValueError("not a RIFF/WAVE file")
        fmt, data, chunks = None, None, []
        while True:
            hdr = f.read(8)
            if len(hdr) < 8:
                break
            cid, sz = hdr[:4], _u32(hdr, 4)
            pos = f.tell()
            # A streaming writer that never went back to patch the size leaves
            # 0xFFFFFFFF or similar here.  Clamp rather than trusting it.
            sz = min(sz, max(0, fsz - pos))
            chunks.append((cid.decode("ascii", "replace"), pos, sz))
            if cid == b"fmt " and sz >= 16:
                b = f.read(min(sz, 40))
                af, nch, sr, bits = _u16(b, 0), _u16(b, 2), _u32(b, 4), _u16(b, 14)
                # WAVE_FORMAT_EXTENSIBLE hides the real format in a GUID whose
                # first two bytes are the format tag.
                if af == 0xFFFE and len(b) >= 26:
                    af = _u16(b, 24)
                fmt = dict(audio_format=af, nch=nch, fs=float(sr), bits=bits)
            elif cid == b"data":
                data = (pos, sz)
            f.seek(pos + sz + (sz & 1))     # chunks are word-aligned
    if fmt is None:
        raise ValueError("RIFF/WAVE file has no fmt chunk")
    if data is None:
        raise ValueError("RIFF/WAVE file has no data chunk")
    return dict(fmt=fmt, data=data, chunks=chunks, size=fsz)


def read_wav(path, minutes=0.0):
    """RIFF/WAVE -> (cols, fs, labels, duration_s), amplitudes in STORED units."""
    info = wav_describe(path)
    fmt, (off, sz) = info["fmt"], info["data"]
    af, nch, fs, bits = (fmt["audio_format"], fmt["nch"], fmt["fs"], fmt["bits"])
    if nch < 1 or fs <= 0:
        raise ValueError("%s: implausible fmt chunk (%d ch, %g Hz)" % (path, nch, fs))
    wid = bits // 8
    frames = sz // (wid * nch) if wid and nch else 0
    if frames == 0:
        raise ValueError("%s: data chunk holds no complete frames" % path)
    if minutes and minutes > 0:
        frames = min(frames, int(round(minutes * 60.0 * fs)))
    n = frames * nch

    with open(path, "rb") as f:
        f.seek(off)
        if af == 1 and bits == 24:
            # No numpy dtype for 24-bit.  Assemble little-endian signed from
            # bytes and sign-extend via the top byte.
            b = np.frombuffer(f.read(n * 3), dtype=np.uint8)
            b = b[: (len(b) // 3) * 3].reshape(-1, 3).astype(np.int32)
            flat = (b[:, 0] | (b[:, 1] << 8) | (b[:, 2] << 16)).astype(np.int32)
            flat = np.where(flat >= 1 << 23, flat - (1 << 24), flat)
            flat = flat.astype(np.float64) / float(1 << 23)
        else:
            if af == 1 and bits == 8:
                dt, scale, bias = np.dtype("u1"), 1.0 / 128.0, 128.0
            elif af == 1 and bits == 16:
                dt, scale, bias = np.dtype("<i2"), 1.0 / 32768.0, 0.0
            elif af == 1 and bits == 32:
                dt, scale, bias = np.dtype("<i4"), 1.0 / 2147483648.0, 0.0
            elif af == 3 and bits == 32:
                dt, scale, bias = np.dtype("<f4"), 1.0, 0.0
            elif af == 3 and bits == 64:
                dt, scale, bias = np.dtype("<f8"), 1.0, 0.0
            else:
                raise ValueError(
                    "%s: unsupported WAVE encoding (format tag %d, %d-bit).\n"
                    "  Supported: PCM 8/16/24/32-bit and IEEE float 32/64-bit.\n"
                    "  Run `probe` on this file and send the output."
                    % (path, af, bits))
            flat = np.frombuffer(f.read(n * dt.itemsize), dtype=dt).astype(np.float64)
            flat = (flat - bias) * scale

    frames = len(flat) // nch
    cols = flat[: frames * nch].reshape(frames, nch)
    labels = ["CH%d" % (i + 1) for i in range(nch)]
    return cols, float(fs), labels, frames / float(fs)


# ============================================================== ASCII exports
#
# The Ponemah ASCII export is self-describing, which makes it the opposite of
# the binary case: the header states every channel's identity, units and rate,
# so nothing has to be inferred.  Three things in it are traps, and all three
# are silent if got wrong.
#
# 1. CHANNELS DO NOT SHARE A RATE.  A real header reads:
#        # Col 2:1265277 - P21, ECG,      ECG,  mV,      Sample Rate: 500.00
#        # Col 5:1265277 - P21, Temperat, TEMP, Celsius, Sample Rate:  10.00
#        # Col 6:1265277 - P21, Activity, ACT,  Counts,  Sample Rate:   1.00
#    Every row still carries all six fields, so the 10 Hz and 1 Hz channels are
#    FORWARD-FILLED -- the same value repeats 50 and 500 times.  A reader that
#    returns all five numeric columns hands lead selection a near-constant
#    temperature trace as a candidate ECG lead.  Only columns whose declared
#    rate matches the ECG rate are returned.
#
# 2. "12:00:00.000 AM" IS MIDNIGHT.  Parsing the hour as 24-hour instead of
#    %I with %p puts the record at noon: a 12-hour error that sorts, bins and
#    plots perfectly happily, and would place a night recording in daylight.
#
# 3. THE FILE IS ENORMOUS.  Six hours at 500 Hz is 10.8 million rows, roughly
#    650 MB of text.  Parsing 10.8M datetimes in Python would dominate the
#    runtime for no benefit, so the timestamp column is skipped in bulk and
#    used only to VERIFY the declared rate on the first few dozen rows.
#
# The column-label row disagrees with the `# Col` block in real exports -- it
# calls temperature and activity "Input" -- so the `# Col` lines are treated as
# authoritative and the label row is kept only for reporting.

_ASCII_EXTS = (".txt", ".csv", ".asc", ".ascii", ".tsv", ".dat")

# US month/day ordering, because these files write their own dates US-style
# ("Monday, January 27, 2025" in the creation line).  A d/m/Y fallback is
# deliberately NOT tried: for 3/4/2024 both readings succeed and differ by a
# month, so a silent guess is worse than the ambiguity being reported.
_ASCII_TIME_FORMATS = (
    "%m/%d/%Y %I:%M:%S.%f %p",
    "%m/%d/%Y %I:%M:%S %p",
    "%m/%d/%Y %H:%M:%S.%f",
    "%m/%d/%Y %H:%M:%S",
    "%Y-%m-%d %H:%M:%S.%f",
    "%Y-%m-%d %H:%M:%S",
    "%Y/%m/%d %H:%M:%S.%f",
)


def _parse_ascii_time(s):
    """(datetime or None, ambiguous) for one export timestamp.

    `ambiguous` marks a date whose first two components are both <= 12, so
    month/day order cannot be settled from the value alone.
    """
    s = s.strip()
    for fmt in _ASCII_TIME_FORMATS:
        try:
            t = datetime.datetime.strptime(s, fmt)
        except ValueError:
            continue
        amb = False
        m = re.match(r"\s*(\d{1,2})[/-](\d{1,2})[/-]\d{4}", s)
        if m and int(m.group(1)) <= 12 and int(m.group(2)) <= 12:
            amb = True
        return t, amb
    return None, False


def _ascii_is_data(line):
    """True if this line is a data row rather than header or labels.

    Keys on the SECOND field being numeric.  The label row's second field is
    `1265277 - P21:ECG`, which is not, so the two cannot be confused.
    """
    parts = line.split(",")
    if len(parts) < 2:
        return False
    try:
        float(parts[1])
        return True
    except ValueError:
        return False


def ascii_describe(path, max_header=400):
    """Read the export header.  Returns a dict; raises ValueError if unusable."""
    meta = dict(path=path, start=None, end=None, cols=[], data_offset=None,
                labels=[], ambiguous=False, notes=[])
    with open(path, "r", errors="replace") as f:
        pos = f.tell()
        line = f.readline()
        n = 0
        while line and n < max_header:
            n += 1
            s = line.strip()
            if s.startswith("#"):
                m = re.match(r"#\s*Col\s+(\d+)\s*:(.*)$", s)
                if m:
                    idx, rest = int(m.group(1)), m.group(2)
                    parts = [p.strip() for p in rest.split(",")]
                    rm = re.search(r"Sample\s*Rate\s*:\s*([0-9.eE+-]+)", rest)
                    meta["cols"].append(dict(
                        index=idx,
                        subject=parts[0] if parts else "",
                        name=parts[1] if len(parts) > 1 else "",
                        kind=parts[2] if len(parts) > 2 else "",
                        units=parts[3] if len(parts) > 3 else "",
                        fs=float(rm.group(1)) if rm else float("nan")))
                else:
                    tm = re.search(r"Time of (first|last) sample\s*:\s*(.+?)\s*$",
                                   s, re.I)
                    if tm:
                        t, amb = _parse_ascii_time(tm.group(2))
                        meta["first" if tm.group(1).lower() == "first"
                             else "last"] = t
                        meta["start" if tm.group(1).lower() == "first"
                             else "end"] = t
                        meta["ambiguous"] = meta["ambiguous"] or amb
            elif s and _ascii_is_data(s):
                meta["data_offset"] = pos
                break
            elif s:
                meta["labels"] = [p.strip() for p in s.split(",")]
            pos = f.tell()
            line = f.readline()
    if meta["data_offset"] is None:
        raise ValueError(
            "%s: no data rows found in the first %d lines.\n"
            "  This does not look like a Ponemah ASCII export.  Run\n"
            "      python3 ecg_rpeaks.py probe --input %s\n"
            "  and send the output." % (path, max_header, path))
    return meta


def ascii_rate_from_timestamps(path, data_offset, k=64):
    """Sampling rate implied by the first k timestamps, or nan.

    An independent witness to the declared rate.  They are compared rather than
    one being preferred: if the header says 500 Hz and the timestamps say 250,
    something is wrong with the file and picking either silently would bake the
    error into every result downstream.
    """
    ts = []
    with open(path, "r", errors="replace") as f:
        f.seek(data_offset)
        for _ in range(k):
            line = f.readline()
            if not line:
                break
            t, _ = _parse_ascii_time(line.split(",", 1)[0])
            if t is not None:
                ts.append(t)
    if len(ts) < 3:
        return float("nan")
    d = sorted((ts[i + 1] - ts[i]).total_seconds() for i in range(len(ts) - 1))
    med = d[len(d) // 2]
    return 1.0 / med if med > 0 else float("nan")


# A numeric field holds only these.  Anything else in it -- 'x', 'NA', '***',
# a stray letter -- means the exporter had no number to write there.
_ASCII_NUMERIC_CHARS = "0123456789eE+-. \t\r\n"
_ASCII_DIRTY = re.compile(r"[^0-9eE+\-.,\s]")
# A whole field, following a comma, containing at least one non-numeric char.
# The lookbehind is what protects column 0: the timestamp "3/22/2024 12:00:00
# AM" is full of slashes and letters and must be left exactly as it is, and it
# is the only field that does not follow a comma.
_ASCII_MARK = re.compile(r"(?<=,)[^,\r\n]*[^0-9eE+\-.,\s][^,\r\n]*")
# An empty field.  ",," is missing data too, and np.loadtxt rejects it just as
# loudly as it rejects 'x'.
_ASCII_EMPTY = re.compile(r"(?<=,)(?=[,\r\n])|(?<=,)$")


def _ascii_clean_lines(f, seen, cap=16):
    """Yield lines with non-numeric data fields rewritten to 'nan'.

    A generator rather than a whole-file substitution because these exports
    run to hundreds of megabytes -- P21's six hours at 500 Hz is about ten
    million rows -- and `--minutes 5` should not have to read all of it.
    np.loadtxt consumes an iterable of strings and stops at max_rows, so
    cleaning stays lazy.

    `seen` accumulates {token: count} so the caller can report what was
    actually in the file rather than asserting what it expected.  Only the
    first `cap` distinct tokens are tracked; a file with more than sixteen
    different markers has something wrong with it that a longer list will not
    illuminate.

    The fast path matters: almost every line is clean, so each one costs a
    single C-level regex search that starts AFTER the timestamp column.
    """
    for line in f:
        i = line.find(",")
        if i >= 0 and (_ASCII_DIRTY.search(line, i + 1) or ",," in line):
            def _note(m):
                tok = m.group(0).strip()
                if tok in seen:
                    seen[tok] += 1
                elif len(seen) < cap:
                    seen[tok] = 1
                return " nan"
            line = _ASCII_MARK.sub(_note, line)
            line = _ASCII_EMPTY.sub(" nan", line)
        yield line


def read_ascii(path, minutes=0.0):
    """Ponemah ASCII export -> (cols, fs, labels, duration_s)."""
    meta = ascii_describe(path)
    cols = meta["cols"]

    if cols:
        rates = [c["fs"] for c in cols if np.isfinite(c["fs"]) and c["fs"] > 0]
        if not rates:
            raise ValueError("%s: header declares no usable sample rate" % path)
        # The ECG channels are the ones the header calls ECG.  If it names none,
        # fall back to the fastest channels -- a waveform is always sampled
        # faster than the housekeeping channels beside it -- and say so.
        want = [c for c in cols
                if "ecg" in (c["name"] + " " + c["kind"]).lower()
                and not any(k in (c["name"] + " " + c["kind"]).lower()
                            for k in SKIP_LABELS)]
        if not want:
            top = max(rates)
            want = [c for c in cols if c["fs"] == top]
            meta["notes"].append(
                "header names no ECG channel; using the %d fastest channel(s)"
                " at %g Hz" % (len(want), top))
        fs = want[0]["fs"]
        if any(abs(c["fs"] - fs) > 1e-9 for c in want):
            raise ValueError("%s: ECG channels declare different rates: %s"
                             % (path, [c["fs"] for c in want]))
        usecols = [c["index"] - 1 for c in want]
        labels = ["%s%d" % (c["name"] or "CH", i + 1) for i, c in enumerate(want)]
    else:
        # No `# Col` block.  Take every numeric column after the first and get
        # the rate from the timestamps.  Reported, because the channel identity
        # is then a guess rather than a reading.
        with open(path, "r", errors="replace") as f:
            f.seek(meta["data_offset"])
            ncol = len(f.readline().split(","))
        usecols = list(range(1, ncol))
        fs = ascii_rate_from_timestamps(path, meta["data_offset"])
        labels = ["CH%d" % i for i in range(1, ncol)]
        meta["notes"].append("no '# Col' header; channel identity is assumed")
        if not np.isfinite(fs):
            raise ValueError("%s: no '# Col' header and the timestamps do not "
                             "give a rate" % path)

    # Cross-check the declared rate against the clock.  Disagreement is
    # reported, not resolved -- see ascii_rate_from_timestamps().
    fs_ts = ascii_rate_from_timestamps(path, meta["data_offset"])
    if np.isfinite(fs_ts) and abs(fs_ts - fs) > 0.01 * fs:
        meta["notes"].append(
            "header says %g Hz but the timestamps imply %.4f Hz" % (fs, fs_ts))

    max_rows = int(round(minutes * 60.0 * fs)) if minutes and minutes > 0 else None
    with open(path, "r", errors="replace") as f:
        f.seek(meta["data_offset"])
        seen = {}
        arr = np.loadtxt(_ascii_clean_lines(f, seen), delimiter=",",
                         usecols=usecols, ndmin=2, max_rows=max_rows)
    if arr.size == 0:
        raise ValueError("%s: no data rows parsed" % path)
    arr = np.asarray(arr, dtype=np.float64)

    # What did the exporter refuse to give us a number for?
    #
    # Ponemah writes a marker -- 'x' in P21's export -- where it has no valid
    # sample.  The old reader handed the whole field to np.loadtxt, which
    # raised, so one marked sample 86 s into a six-hour recording aborted the
    # entire file.  That is the worst possible response: the data either side
    # of the mark is perfectly good, and the mark is the exporter telling us
    # precisely which stretch NOT to trust -- better evidence than any
    # amplitude heuristic could ever produce.
    #
    # They become NaN, and NaN is load-bearing from here on: analyse() turns
    # runs of it into excised spans, so marked time leaves both the beat count
    # and the duration.  Nothing downstream has to know the marker's spelling.
    #
    # What the marker MEANS is not decoded.  'x' might be "sensor detached",
    # "out of range" or "operator excluded"; those would matter for a writeup
    # and none of them change the handling, which is simply that a
    # non-number is not a measurement.
    if seen:
        toks = ", ".join("%s x%d" % (t, n)
                         for t, n in sorted(seen.items(), key=lambda kv: -kv[1]))
        meta["notes"].append("non-numeric marker(s) in the data, read as "
                             "missing: %s" % toks)
    nan_n = np.isnan(arr).sum(axis=0)
    if nan_n.any():
        per = ", ".join("%s %d (%.2f%%, %.1f s)"
                        % (labels[i], int(nan_n[i]),
                           100.0 * nan_n[i] / float(len(arr)), nan_n[i] / fs)
                        for i in range(len(labels)) if nan_n[i])
        meta["notes"].append("missing samples per channel: %s" % per)
        if int(nan_n.min()) == 0:
            # Worth saying plainly: a mark in one channel is not a mark in all
            # of them, and lead selection can simply prefer a clean lead.
            meta["notes"].append(
                "at least one channel has no missing samples, so the gap is "
                "per-channel rather than a whole-record dropout")

    # Row count against the header's own first/last timestamps.  This catches a
    # truncated or concatenated export, which nothing else here would notice.
    if meta.get("start") and meta.get("end") and max_rows is None:
        want_n = (meta["end"] - meta["start"]).total_seconds() * fs + 1.0
        if want_n > 0 and abs(len(arr) - want_n) > max(2.0, 0.001 * want_n):
            meta["notes"].append(
                "header spans %s..%s = %.0f rows at %g Hz, but %d were read"
                % (meta["start"], meta["end"], want_n, fs, len(arr)))

    for note in meta["notes"]:
        print("  ** %s: %s" % (os.path.basename(path), note), file=sys.stderr)
    return arr, float(fs), labels, arr.shape[0] / float(fs)


# --------------------------------------------- Ponemah native container (TLV)
#
# This is READ FROM THE FILE, not guessed.  The first 64 bytes of a real
# `.PnmWav` (P10, 2023-08-06) are:
#
#   af 55 55 aa                                     magic
#   88 13 | 08 00 00 00 | a4 00 00 00 00 00 00 00   tag 5000, len 8,  = 164
#   8a 13 | 04 00 00 00 | 02 00 00 00               tag 5002, len 4,  = 2
#   b2 13 | 15 00 00 00 | "Eastern Standard Time"   tag 5042, len 21
#   b4 13 | 08 00 00 00 | 01 ...                    tag 5044, len 8,  = 1
#
# Four records chain head-to-tail, and the third one's declared length (0x15 =
# 21) lands exactly on the end of a 21-character string.  A wrong structural
# hypothesis does not survive four consecutive records and does not land a
# length on a string boundary by luck, so the framing -- uint16 tag, uint32
# length, value[length], little-endian -- is established rather than assumed.
#
# What is NOT established is what any tag MEANS.  164, 2 and 1 are values whose
# significance is unknown, and this code says so rather than captioning them
# "sample rate" or "channel count" because those would be plausible.  A wrong
# caption here is worse than no caption: it propagates into a reader.
#
# The walk's real job is to find where metadata ends.  The chain is followed
# until a record is malformed -- a length running past the buffer, or one too
# large to be metadata -- and that stopping point is the first candidate for
# the start of the sample payload.

PNMWAV_MAGIC = b"\xaf\x55\x55\xaa"
PNMWAV_EXTS = (".pnmwav", ".pnm", ".ponemah", ".exp")

# The tags whose meaning is ESTABLISHED, and how.
#
# `probe` used to say flatly that tag numbers are not decoded, which was true
# when written and is the right default: naming a tag on a hunch is how a
# reader acquires a bug that only shows up on someone else's file.  These
# twelve are named because two independent routes agree on each, and the route
# is recorded next to the name so a future reader can re-check rather than
# trust.
#
#   "measured"  -- this tool derived it from the bytes with no outside help:
#                  5015 by byte share (99.0% of the file in fixed-size
#                  records), 5045 by elimination (declared before the first
#                  data block AND splitting the payload into integer ratios).
#   "ep_pipeline" -- independently named in the reference implementation found
#                  in the P10 data directory, as hex: 0x1397=5015,
#                  0x13B5=5045, 0x1395=5013, 0x1396=5014, 0x13B1=5041,
#                  0x13B2=5042.  Written by someone with documentation this
#                  project does not have.
#   "agrees with filename" -- the decoded value matches the recording stamp in
#                  the filename to within 2 s, which no wrong epoch does.
#   "consistent calibration" -- the four range tags produce a gain of
#                  28/64511 = 4.34035e-4 mV/count, identical across all three
#                  channels, with the raw range stopping short of full scale
#                  (-32256..32255, not -32768..32767) the way a real ADC does.
#
# Deliberately ABSENT: 5000, 5001, 5002-5008, 5010, 5016, 5018, 5020, 5022,
# 5023, 5024, 5034, 5035, 5043, 5044.  Several have obvious-looking values.
# None has a second witness, so none is named.
PNMWAV_TAG_NAMES = {
    5013: ("start time", "ep_pipeline; agrees with filename"),
    5014: ("end time", "ep_pipeline"),
    5015: ("sample block", "measured: 99.0% of bytes; ep_pipeline"),
    5025: ("raw range lo", "consistent calibration"),
    5026: ("raw range hi", "consistent calibration"),
    5029: ("engineering range lo", "consistent calibration"),
    5030: ("engineering range hi", "consistent calibration"),
    5038: ("recording start", "agrees with filename"),
    5039: ("recording end", "spans 67109 s, matches the Cycle table"),
    5041: ("subject", "ep_pipeline"),
    5042: ("timezone", "ep_pipeline"),
    5045: ("channel id", "measured: integer byte ratios; ep_pipeline"),
}

# No metadata record plausibly exceeds 64 MB.  A declared length above this is
# read as "the chain has ended and these bytes are something else", which is
# the outcome that matters: it stops the walk at the payload instead of
# consuming the file.
_PNMWAV_MAX_VALUE = 1 << 26
_PNMWAV_HDR = 6                                   # uint16 tag + uint32 length


def _pnmwav_chain(read, size, start=4, limit=20000, keep_max=None,
                  whole=True):
    """Walk a tag/length/value chain.  The one implementation, two callers.

    `read(off, n)` returns bytes; `size` is how far it is legal to read.
    `whole` says whether `size` is the END OF THE FILE or merely the end of
    the bytes the caller happened to load -- and that distinction is the whole
    reason this function exists in this form.  See the `how` codes below.

    Returns (records, stop_offset, why, how) where `how` is one of:

      "eof"        the chain consumed every byte.  There is NO payload after
                   it, and a caller that prints "payload follows" is lying.
      "oversize"   a length too large to be metadata.  A real boundary: the
                   chain has ended and those bytes are something else.
      "malformed"  a record runs past the end.  A real boundary IF `whole`,
                   and otherwise only a statement about the caller's buffer.
      "short"      same, but `whole` was False -- the chain was NOT shown to
                   end here; there were simply no more bytes to look at.
      "limit"      the record cap was hit.  Also not an ending.

    Only "oversize", and "malformed" with `whole`, are evidence about the
    file.  The other three are evidence about how hard we looked, and
    conflating the two is exactly the bug that made a 1 MiB read report a
    195 MB payload that was not there.
    """
    recs, off, n = [], int(start), int(size)
    while len(recs) < limit:
        if off + _PNMWAV_HDR > n:
            if whole:
                return recs, off, ("the chain consumed the file exactly -- no "
                                   "bytes remain after the last record"), "eof"
            return recs, off, ("ran out of the %d bytes read -- the chain was "
                               "NOT shown to end here" % n), "short"
        hdr = read(off, _PNMWAV_HDR)
        if len(hdr) < _PNMWAV_HDR:
            return recs, off, "the read came up short", "short"
        tag = int.from_bytes(hdr[:2], "little")
        ln = int.from_bytes(hdr[2:6], "little")
        if ln > _PNMWAV_MAX_VALUE:
            return recs, off, ("tag %d declares a %d-byte value, too large to "
                               "be metadata" % (tag, ln)), "oversize"
        if off + _PNMWAV_HDR + ln > n:
            rem = n - off - _PNMWAV_HDR
            if whole:
                return recs, off, ("tag %d declares %d bytes but only %d "
                                   "remain in the FILE" % (tag, ln, rem)), \
                                  "malformed"
            return recs, off, ("tag %d declares %d bytes but only %d were "
                               "read -- read further to see whether the chain "
                               "continues" % (tag, ln, rem)), "short"
        # Bulk values are located, not loaded.  A 16 KB data block repeated ten
        # thousand times would be 200 MB of `bytes` objects for no benefit; the
        # offset is enough to go and get it later, and `verify` does exactly
        # that.
        if keep_max is not None and ln > keep_max:
            val = None
        else:
            val = bytes(read(off + _PNMWAV_HDR, ln))
        recs.append(dict(offset=off, tag=tag, length=ln, value=val,
                         value_offset=off + _PNMWAV_HDR))
        off += _PNMWAV_HDR + ln
    return recs, off, ("stopped after %d records -- the cap, not the end of "
                       "the chain" % limit), "limit"


def pnmwav_records(buf, start=4, limit=20000):
    """Walk the chain inside an in-memory buffer.

    Returns (records, stop_offset, why).  `whole=False`: a buffer is by
    definition a partial view, so running off its end is never reported as the
    chain having ended.
    """
    n = len(buf)
    recs, stop, why, _ = _pnmwav_chain(
        lambda o, k: buf[o:o + k], n, start=start, limit=limit, whole=False)
    return recs, stop, why


def pnmwav_walk_file(path, start=4, limit=5000000, keep_max=4096):
    """Walk the chain across an ENTIRE file, keeping only small values.

    This is the version that tells the truth about where metadata stops.  The
    earlier code read a fixed 1 MiB and walked that, so on a 197 MB recording
    the walk hit the edge of its own buffer at byte 1034556 and reported the
    remaining 195 MB as "payload".  It was not payload; the chain carried on.
    The arithmetic that gives it away is exact: 1034556 + 6 + 14014 = 1048576.

    Reads are sequential and buffered, and large values are skipped rather
    than copied, so the cost is one pass of seeks over the file.
    """
    size = os.path.getsize(path)
    with open(path, "rb", buffering=1 << 20) as f:
        def read(off, n):
            if f.tell() != off:
                f.seek(off)
            return f.read(n)
        return (size,) + _pnmwav_chain(read, size, start=start, limit=limit,
                                       keep_max=keep_max, whole=True)


def pnmwav_census(recs):
    """Per-tag totals: how many, how many bytes, which lengths.

    A chain of half a million records cannot be read record by record, but it
    does not need to be.  One line per tag says what the file is made of, and
    a tag holding 95% of the bytes in fixed-size values is a data block --
    which is a structural fact worth far more than any single record's value.
    """
    by = {}
    for r in recs:
        t = by.setdefault(r["tag"], dict(tag=r["tag"], count=0, bytes=0,
                                         lengths=set(), first=r["offset"],
                                         last=r["offset"]))
        t["count"] += 1
        t["bytes"] += r["length"]
        t["last"] = r["offset"]
        if len(t["lengths"]) < 8:
            t["lengths"].add(r["length"])
    out = sorted(by.values(), key=lambda d: -d["bytes"])
    for d in out:
        d["lengths"] = sorted(d["lengths"])
    return out


def pnmwav_bulk_tag(recs, size, min_share=0.25, min_count=4):
    """The tag whose values hold the bulk of the file, if any.

    Returns (tag, spans, total) or (None, [], 0).  `spans` are (file_offset,
    length) pairs in chain order -- everything a reader needs to treat the
    scattered values as one continuous stream.
    """
    if not recs or size <= 0:
        return None, [], 0
    for d in pnmwav_census(recs):
        if d["count"] >= min_count and d["bytes"] >= min_share * size:
            spans = [(r["value_offset"], r["length"])
                     for r in recs if r["tag"] == d["tag"]]
            return d["tag"], spans, d["bytes"]
    return None, [], 0


def _integer_ratio_error(sizes):
    """How far a set of byte counts is from being integer multiples of each other.

    This is the test that separates a channel id from a sequence number, and it
    needs nothing from outside the file.  Channels are sampled at rates that are
    integer multiples of one another -- 500, 10 and 1 Hz on this rig -- and they
    all run for the same wall-clock duration, so their payload sizes land on
    exact integer ratios.  P10 divides as 67109000 : 1342180 : 134218 = 500 : 10
    : 1, to the byte.  A tag that merely correlates with position splits the
    payload into whatever sizes happen to fall out, and the ratios are ragged.

    Returns the worst relative error, so lower is better and 0.0 is exact.
    """
    sizes = [s for s in sizes if s > 0]
    if len(sizes) < 2:
        return 1.0
    m = float(min(sizes))
    worst = 0.0
    for s in sizes:
        r = s / m
        worst = max(worst, abs(r - round(r)) / r)
    return worst


def pnmwav_channel_tag(recs, bulk_tag, max_groups=16, max_ratio_err=0.001):
    """Discover which tag carries the CHANNEL ID, by elimination.

    Two weaker versions of this were wrong before it settled here, and both
    failures are worth keeping in view.

    The first hand-picked three candidates on the reasoning that a channel tag
    should appear exactly once per data block.  That excluded the tag that
    actually carries it: 5045 appears about twice per block, and a reader that
    tracks the most recent value does not care how often it repeats.

    The second tried every tag and kept those whose groups had integer byte
    ratios -- channels share a duration, so their sizes land on their rate
    ratios, 500 : 10 : 1 to the byte on P10.  That is true but not
    discriminating: any tag whose groups happen to be multiples of a common
    block size passes it too, and a decoy that changed value every third block
    beat 5045 outright.

    What actually separates them is that a container which multiplexes has to
    DECLARE its channels.  The descriptor chain in the header names each one
    before a single sample appears, so the values a channel tag takes over the
    data must be values the header already introduced.  A sequence number, a
    segment id or a block timestamp never appears there.  That is the primary
    test here; the ratio check is kept as a secondary filter because a tag can
    be declared and still not be the axis the payload is split on.

    Returns (tag, groups, table) where `groups` maps channel id -> list of
    (file_offset, length) spans in chain order, and `table` is every tag that
    was considered, for printing.  (None, {}, table) if nothing qualifies --
    which is the right answer for a container that is not multiplexed.
    """
    if bulk_tag is None:
        return None, {}, []
    last = {}
    header = {}
    acc = {}
    blown = set()
    seen_data = False
    for r in recs:
        t = r["tag"]
        if t == bulk_tag:
            seen_data = True
            span = (r["value_offset"], r["length"])
            for k, v in last.items():
                if k in blown:
                    continue
                g = acc.setdefault(k, {})
                if v not in g and len(g) >= max_groups:
                    # Too many groups to be a channel id.  Drop the whole
                    # accumulation rather than carry a saturated bucket: a
                    # partial grouping would score well on the ratio test by
                    # accident.
                    blown.add(k)
                    acc.pop(k, None)
                    continue
                g.setdefault(v, []).append(span)
            continue
        val = r.get("value")
        if val and 1 <= len(val) <= 8:
            u = int.from_bytes(val, "little", signed=False)
            last[t] = u
            if not seen_data:
                header.setdefault(t, set()).add(u)

    table = []
    ranked = []
    for t in sorted(set(list(acc) + list(blown))):
        if t in blown:
            table.append(dict(tag=t, groups=None, err=None,
                              why="too many groups"))
            continue
        g = acc[t]
        if len(g) < 2:
            table.append(dict(tag=t, groups=len(g), err=None,
                              why="constant -- partitions nothing"))
            continue
        declared = header.get(t, set())
        if not declared:
            table.append(dict(tag=t, groups=len(g), err=None,
                              why="never declared in the header"))
            continue
        undeclared = set(g) - declared
        if undeclared:
            table.append(dict(tag=t, groups=len(g), err=None,
                              why="%d value(s) never declared: %s"
                                  % (len(undeclared),
                                     sorted(undeclared)[:4])))
            continue
        sizes = [sum(ln for _o, ln in spans) for spans in g.values()]
        err = _integer_ratio_error(sizes)
        if err > max_ratio_err:
            table.append(dict(tag=t, groups=len(g), err=err,
                              why="declared, but ragged ratios -- the payload"
                                  " is not split on this axis"))
            continue
        table.append(dict(tag=t, groups=len(g), err=err, why="CHANNEL ID"))
        ranked.append((err, -len(g), t))
    if not ranked:
        return None, {}, table
    ranked.sort()
    best = ranked[0][2]
    return best, acc[best], table



def pnmwav_descriptors(recs, id_tag, bulk_tag,
                       raw_lo_tag=5025, raw_hi_tag=5026,
                       eng_lo_tag=5029, eng_hi_tag=5030):
    """Per-channel calibration, read from the header's descriptor chain.

    The container states a raw range and an engineering range for each channel.
    Their ratio is the counts-to-units gain, and it is the one number a reader
    cannot obtain from correlation alone -- `verify` matches shape, and shape is
    scale-invariant, so a gain error is completely silent there.

    Do NOT take these from a whole-file scan.  Every descriptor is parsed before
    the first data block, so a "last value seen at each block" view reports the
    LAST descriptor's numbers for every channel and they look identical.  That
    is an artefact of the scan order, not a fact about the rig, and a 10 Hz
    temperature channel certainly does not share the ECG's +/-14.0 range.  This
    walks the header only, opening a new descriptor at each `id_tag`.

    Returns {channel_id: dict(raw_lo, raw_hi, eng_lo, eng_hi, gain, offset)}.
    Channels whose descriptor is incomplete are returned with gain=None rather
    than a guessed 1.0: a silently wrong scale is worse than a missing one.
    """
    want = {raw_lo_tag: "raw_lo", raw_hi_tag: "raw_hi",
            eng_lo_tag: "eng_lo", eng_hi_tag: "eng_hi"}
    out, cur = {}, None
    for r in recs:
        if r["tag"] == bulk_tag:
            break                       # descriptors are all ahead of the data
        val = r.get("value")
        if val is None:
            continue
        if r["tag"] == id_tag and 1 <= len(val) <= 8:
            cur = out.setdefault(
                int.from_bytes(val, "little", signed=False),
                dict(raw_lo=None, raw_hi=None, eng_lo=None, eng_hi=None))
        elif cur is not None and r["tag"] in want:
            key = want[r["tag"]]
            if key.startswith("eng") and len(val) == 4:
                cur[key] = float(np.frombuffer(val, dtype="<f4", count=1)[0])
            elif len(val) in (1, 2, 4, 8):
                cur[key] = int.from_bytes(val, "little", signed=True)
    for ch, d in out.items():
        lo, hi, elo, ehi = d["raw_lo"], d["raw_hi"], d["eng_lo"], d["eng_hi"]
        if None in (lo, hi, elo, ehi) or hi == lo:
            d["gain"] = d["offset"] = None
        else:
            d["gain"] = (ehi - elo) / float(hi - lo)
            d["offset"] = elo - d["gain"] * lo
    return out




def _plausible_dt(dt):
    lo, hi = _NAME_YEAR_RANGE
    return dt is not None and lo <= dt.year <= hi


def _as_filetime(u):
    """Windows FILETIME (100 ns ticks since 1601-01-01) as a datetime, or None."""
    try:
        return (datetime.datetime(1601, 1, 1)
                + datetime.timedelta(microseconds=u / 10.0))
    except (OverflowError, ValueError, OSError):
        return None


def _as_oledate(f):
    """OLE automation date (days since 1899-12-30) as a datetime, or None."""
    try:
        return datetime.datetime(1899, 12, 30) + datetime.timedelta(days=float(f))
    except (OverflowError, ValueError, OSError):
        return None


def _as_dotnet(u):
    """.NET DateTime ticks (100 ns since 0001-01-01) as a datetime, or None.

    Worth having a name for, because it is the epoch this vendor actually
    uses: in P10's container an 8-byte record decodes under it to
    2023-08-06 19:59:59, which is the recording's filename timestamp to the
    second, and a second such record sits 67109 s later -- the length of the
    EDF corpus exported from the same recording (67110 s) to within one
    sample interval.  Two independent agreements is not a coincidence.

    It stays a CONDITIONAL rendering all the same.  The agreement is what
    promotes it, and `pnmwav_clocks` is what checks the agreement; the epoch
    on its own proves nothing.
    """
    try:
        return (datetime.datetime(1, 1, 1)
                + datetime.timedelta(microseconds=u / 10.0))
    except (OverflowError, ValueError, OSError):
        return None


# The epochs a fixed-width integer might be counting from, tried in turn.
_EPOCHS = (("FILETIME", 8, _as_filetime),
           (".NET ticks", 8, _as_dotnet))


def pnmwav_render(val):
    """A readable rendering of one record value, plus any date it could be.

    Numeric renderings are labelled with their width and signedness.  Date
    interpretations are offered ONLY when they land in a plausible recording
    year, and are always phrased as conditionals -- "if FILETIME: ..." -- since
    the same 8 bytes are simultaneously a valid integer, a valid float and a
    valid timestamp, and nothing in the record says which was intended.
    """
    txt = val.rstrip(b"\x00")
    if len(txt) >= 2 and all(32 <= c < 127 for c in txt):
        return '"%s"' % txt.decode("ascii")
    if len(val) in (1, 2, 4, 8):
        u = int.from_bytes(val, "little", signed=False)
        s = int.from_bytes(val, "little", signed=True)
        out = "%d" % u if u == s else "%d (unsigned) / %d (signed)" % (u, s)
        extras = []
        if len(val) == 8:
            f = float(np.frombuffer(val, dtype="<f8", count=1)[0])
            if np.isfinite(f) and (f == 0.0 or 1e-6 < abs(f) < 1e12):
                extras.append("as f64 %.6g" % f)
                d = _as_oledate(f)
                if _plausible_dt(d):
                    extras.append("if OLE date: %s" % d.isoformat(sep=" "))
            d = _as_filetime(u)
            if _plausible_dt(d):
                extras.append("if FILETIME: %s" % d.isoformat(sep=" "))
            d = _as_dotnet(u)
            if _plausible_dt(d):
                extras.append("if .NET ticks: %s" % d.isoformat(sep=" "))
        if len(val) == 4:
            f = float(np.frombuffer(val, dtype="<f4", count=1)[0])
            if np.isfinite(f) and (f == 0.0 or 1e-6 < abs(f) < 1e12):
                extras.append("as f32 %.6g" % f)
            try:
                d = datetime.datetime(1970, 1, 1) + datetime.timedelta(seconds=u)
                if _plausible_dt(d):
                    extras.append("if unix time: %s" % d.isoformat(sep=" "))
            except (OverflowError, ValueError, OSError):
                pass
        return out + ("   [%s]" % ", ".join(extras) if extras else "")
    head = " ".join("%02x" % c for c in val[:16])
    return "%d bytes: %s%s" % (len(val), head, " ..." if len(val) > 16 else "")


def pnmwav_clocks(recs, want_dt=None, tol_s=2.0):
    """Which records could be timestamps, and which one AGREES with the clock.

    Every 8-byte value is simultaneously a plausible integer and a plausible
    timestamp under several epochs, so a lone "this could be a date" is worth
    almost nothing.  What is worth something is agreement with a clock we
    already trust -- the filename, or an export's header.  When a candidate
    lands within `tol_s` of `want_dt` it is marked `agrees`, and that is the
    only circumstance under which this project will act on a decoded date.

    Returns a list of dicts sorted earliest first.
    """
    out = []
    for r in recs:
        v = r.get("value")
        if not v or len(v) != 8:
            continue
        u = int.from_bytes(v, "little", signed=False)
        for name, _w, fn in _EPOCHS:
            d = fn(u)
            if not _plausible_dt(d):
                continue
            agrees = (want_dt is not None
                      and abs((d - want_dt).total_seconds()) <= tol_s)
            out.append(dict(offset=r["offset"], tag=r["tag"], epoch=name,
                            dt=d, agrees=agrees, raw=u))
    out.sort(key=lambda d: d["dt"])
    return out


def pnmwav_start_ticks(recs, want_dt=None, tol_s=2.0):
    """The recording's START, in .NET ticks, read from the container itself.

    Needed because the .PnmWav and its .PnmMarks sidecar do NOT share an
    origin.  Sample zero of the waveform is the start of the RECORDING; the
    sidecar's Cycle and BadDataMark times are .NET ticks whose natural
    reference in this tool has been the FIRST BEAT, which on P10 arrives
    0.254 s later.  Placing a bad-data interval on the waveform with the wrong
    one of those slides every interval by a quarter of a second.

    That error is small enough to survive review and large enough to matter:
    it puts the edge of each of 344 intervals a quarter-second off, which
    either leaks bad samples in or excises good ones, once per interval.

    The same agreement rule as `pnmwav_clocks` applies, and for the same
    reason -- an 8-byte integer is a plausible date under several epochs, so a
    decode alone is worth nothing.  Only a candidate that matches a clock we
    already trust (the filename stamp) is returned.  Returns None when nothing
    agrees, and the caller must then say what it fell back to.
    """
    best = None
    for c in pnmwav_clocks(recs, want_dt=want_dt, tol_s=tol_s):
        if c["epoch"] != ".NET ticks" or not c["agrees"]:
            continue
        if best is None or c["raw"] < best:
            best = int(c["raw"])
    return best


def pnmwav_describe(path, limit=5000000):
    """Walk a native Ponemah file's chain, end to end.  Never raises.

    `ok` is False with a `why` if the magic does not match, so callers can use
    this as a test as well as a reader.

    This used to read a fixed 1 MiB and walk that.  On P10's 197 MB recording
    the walk therefore stopped at byte 1034556 -- the edge of its own buffer,
    not a feature of the file -- and every caller downstream treated the
    remaining 195 MB as sample payload.  `verify` then searched those bytes for
    a signal, found r = -0.32, and reported NO MATCH.  The layout was never the
    problem; the boundary was invented.

    `how` distinguishes an ending from a stopping point, and `data_offset` is
    None unless the chain genuinely ended with bytes left over.
    """
    try:
        size, recs, stop, why, how = pnmwav_walk_file(path, limit=limit)
    except OSError as e:
        # An unreadable file is not a format question.  Reporting it here keeps
        # the promise callers rely on -- that this never raises -- and keeps
        # read_ponemah's single failure mode (NotImplementedError) intact.
        return dict(ok=False, size=0, records=[], data_offset=None, how="error",
                    truncated=False, head=b"", census=[], bulk_tag=None,
                    bulk_spans=[], bulk_bytes=0, why="cannot read it (%s)" % e)
    try:
        with open(path, "rb") as f:
            head = f.read(64)
    except OSError:
        head = b""
    if not head.startswith(PNMWAV_MAGIC):
        return dict(ok=False, size=size, records=[], data_offset=None,
                    truncated=False, head=head, census=[], bulk_tag=None,
                    bulk_spans=[], bulk_bytes=0, how="nomagic",
                    why="magic is %s, expected %s"
                        % (" ".join("%02x" % c for c in head[:4]),
                           " ".join("%02x" % c for c in PNMWAV_MAGIC)))
    # A trailing payload exists only if the chain STOPPED on the file's own
    # evidence.  "eof" means there is nothing after it; "limit" means we gave
    # up early and have no idea.  Saying None here is what stops a caller
    # inventing a 195 MB payload out of our own impatience.
    trailing = stop if how in ("oversize", "malformed") else None
    tag, spans, nbulk = pnmwav_bulk_tag(recs, size)
    return dict(ok=True, size=size, records=recs, data_offset=trailing,
                stop=stop, how=how, why=why, head=head,
                truncated=(how == "limit"), census=pnmwav_census(recs),
                bulk_tag=tag, bulk_spans=spans, bulk_bytes=nbulk)


def pnmwav_payload_options(nbytes, fs, want_s=None, max_ch=12,
                           itemsizes=(1, 2, 4, 8)):
    """Which frame strides divide `nbytes` exactly, and what each implies.

    Grouped by STRIDE, not by (width, channels), because duration arithmetic
    cannot tell those apart: 2-byte samples in 3 channels and 1-byte samples in
    6 channels both give a 6-byte frame and therefore exactly the same frame
    count and the same duration.  An earlier version returned them as separate
    ranked options, which let a stable sort quietly promote one of two
    indistinguishable hypotheses to "the answer".  Listing the splits together
    puts the ambiguity on the page where it belongs -- resolving it needs
    `verify`, not arithmetic.

    Divisibility is weak evidence on its own -- a 2-byte stride divides almost
    anything -- so when `want_s` is supplied (a duration known from elsewhere,
    such as the matching exports) the strides are ranked by how close their
    implied duration comes to it.
    """
    groups = {}
    for it in itemsizes:
        for nch in range(1, max_ch + 1):
            stride = it * nch
            if nbytes % stride:
                continue
            g = groups.setdefault(stride, dict(stride=stride,
                                               nsamp=nbytes // stride,
                                               splits=[]))
            g["splits"].append((it, nch))
    out = []
    for stride in sorted(groups):
        g = groups[stride]
        g["dur_s"] = g["nsamp"] / float(fs) if fs > 0 else float("nan")
        g["err_s"] = abs(g["dur_s"] - want_s) if want_s else float("nan")
        out.append(g)
    if want_s:
        out.sort(key=lambda d: d["err_s"])
    return out


def _pnmwav_sidecar_info(path, ch_ids, origin_ticks=None):
    """Look for a .PnmMarks sidecar beside `path` for sample rate & bad spans.

    Returns (fs, source_str, bad_spans_s, origin_note).

    `bad_spans_s` is measured from `origin_ticks` -- which must be SAMPLE
    ZERO of the waveform, not the sidecar's first beat.  The two differ by
    0.254 s on P10 and using the wrong one slides all 344 intervals by that
    much.  When `origin_ticks` is None the first beat is used instead and
    `origin_note` says so, because a quarter-second error that announces
    itself is a different thing from one that does not.
    """
    folder = os.path.dirname(os.path.abspath(path))
    try:
        cands = sorted(f for f in os.listdir(folder)
                       if f.lower().endswith(".pnmmarks"))
    except OSError:
        cands = []
    for fn in cands:
        m = read_marks(os.path.join(folder, fn))
        if not m.get("ok"):
            continue
        t0 = m.get("t0")
        if origin_ticks is not None:
            origin = int(origin_ticks)
            note = "recording start read from the container"
        else:
            origin = t0
            note = ("first beat in the sidecar -- the container did not state"
                    " a start that agreed with the filename, so intervals may"
                    " sit up to one beat interval early")
        bad_spans_s = []
        if origin is not None and m.get("bad"):
            merged = merge_tick_spans([(a, b) for _s, a, b in m["bad"]])
            bad_spans_s = [((a - origin) / float(NET_TICKS_PER_S),
                            (b - origin) / float(NET_TICKS_PER_S))
                           for a, b in merged]
        by_sub = {c.get("SubjectChannelId"): c.get("fs")
                  for c in m.get("contexts", []) if c.get("fs")}
        rates = [by_sub[c] for c in ch_ids if c in by_sub]
        fs = float(rates[0]) if rates else 500.0
        src = (".PnmMarks (%s)" % fn if rates
               else "assumed 500 Hz (.PnmMarks %s had no rate for %s)"
                    % (fn, ch_ids))
        return fs, src, bad_spans_s, note
    return (500.0, "assumed 500 Hz (no .PnmMarks sidecar beside file)", [],
            "no sidecar")


def _pnmwav_plan(path, minutes=0.0, quiet=False):
    """Everything needed to decode a multiplexed .PnmWav, without the samples.

    Returns (describe_dict, plan) where plan is None when the container has
    no channel partition (read_ponemah then refuses with evidence).  Split
    out of read_ponemah so a long recording can be read one SEGMENT at a
    time (_SegReader) with exactly the channel choice, per-channel gains,
    sampling rate, recording origin and BadDataMark intervals the whole-file
    reader uses -- two readers that each worked these out for themselves
    would be two chances to disagree about where a bad interval sits.

    plan keys: chs, labels, spans (per channel), takes (payload bytes to read
    per channel, honouring --minutes), gains (None = unscaled), fs, fs_src,
    bad_spans_s (seconds from sample zero), n (samples per channel).
    """
    d = pnmwav_describe(path)
    if not d["ok"]:
        raise NotImplementedError(
            "%s: not a recognised Ponemah container (%s).\n"
            "  Run:  python3 ecg_rpeaks.py probe --input %s"
            % (os.path.basename(path), d["why"], path))
    recs = d["records"]
    if d.get("bulk_tag") is not None:
        demux_tag, demux_groups, _ = pnmwav_channel_tag(recs, d["bulk_tag"])
        if demux_groups:
            descs = pnmwav_descriptors(recs, demux_tag, d["bulk_tag"])
            totals = {ch: sum(L for _o, L in spans)
                      for ch, spans in demux_groups.items()}
            big = max(totals.values()) if totals else 0
            # Full-rate channels all share the maximum byte count (within 5%);
            # slow derived/housekeeping channels (1-10 Hz) are orders of
            # magnitude smaller.
            ecg_chs = sorted(ch for ch, nb in totals.items()
                             if big > 0 and nb >= 0.95 * big)
            if ecg_chs:
                # Sample zero is the start of the RECORDING.  The sidecar's
                # intervals are ticks against an absolute clock.  Ask the
                # container where it thinks it started, and only believe it if
                # it agrees with the filename stamp -- see pnmwav_start_ticks.
                _name_dt, _, _ = record_start(path)
                _origin = pnmwav_start_ticks(recs, want_dt=_name_dt)
                fs, fs_src, bad_spans_s, origin_note = _pnmwav_sidecar_info(
                    path, ecg_chs, origin_ticks=_origin)
                if bad_spans_s and _origin is None and not quiet:
                    print("  ** %s: bad-data intervals placed against the %s"
                          % (os.path.basename(path), origin_note),
                          file=sys.stderr)
                want_samp = (int(np.ceil(minutes * 60.0 * fs))
                             if minutes and minutes > 0 else None)
                takes, gains = {}, {}
                for ch in ecg_chs:
                    nbytes = totals[ch]
                    takes[ch] = (min(nbytes, want_samp * 2)
                                 if want_samp is not None else nbytes)
                    gain = (descs.get(ch) or {}).get("gain")
                    gains[ch] = (float(gain) if gain is not None
                                 and np.isfinite(gain) and gain != 0 else None)
                return d, dict(
                    chs=ecg_chs, labels=["ECG_ch%d" % ch for ch in ecg_chs],
                    spans={ch: demux_groups[ch] for ch in ecg_chs},
                    takes=takes, gains=gains, fs=fs, fs_src=fs_src,
                    bad_spans_s=bad_spans_s,
                    origin_warning=(
                        "  ** %s: bad-data intervals placed against the %s"
                        % (os.path.basename(path), origin_note)
                        if bad_spans_s and _origin is None else ""),
                    n=min(takes.values()) // 2)
    return d, None


def read_ponemah(path, minutes=0.0):
    """Read native Ponemah (.PnmWav) waveform files.

    When the container is block-framed and declares its channel partition (tag
    5045 on Ponemah native files, verified at r = 1.000 against simultaneous
    EDF exports across all three ECG leads), every piece needed to decode the
    waveform is present in the file itself:

      * sample blocks   tag 5015, 16-bit signed little-endian (<i2)
      * channel split   tag 5045 (demultiplexed per channel via pnmwav_channel_tag)
      * counts -> mV    per-channel engineering/raw range in pnmwav_descriptors
      * sampling rate   ChannelContextInfo.TicksPerSample in the .PnmMarks
                        sidecar (or 500 Hz if no sidecar sits beside the file)
      * bad intervals   BadDataMark in the .PnmMarks sidecar, marked as NaN so
                        downstream `fill_missing` / `mark_spans` excises them
                        identically to exporter 'x' markers

    Full-rate channels (those carrying the maximum sample count in the
    container, e.g. the three 500 Hz ECG leads on P10) are selected and
    returned as an (N, C) float64 array scaled to engineering units (mV).

    If a container does NOT carry a channel-id partition (e.g. a trailing raw
    blob or single-stream container where width and channel count cannot be
    separated without an external reference), this function still refuses with
    the diagnostic NotImplementedError pointing to `verify`.
    """
    d, plan = _pnmwav_plan(path, minutes)
    recs = d["records"]
    if plan is not None:
        fs, bad_spans_s = plan["fs"], plan["bad_spans_s"]
        cols, labels = [], []
        for ch in plan["chs"]:
            src = BlockSource(path, plan["spans"][ch])
            buf = src.read_at(0, plan["takes"][ch])
            arr = np.frombuffer(buf, dtype="<i2").astype(np.float64)
            gain = plan["gains"][ch]
            if gain is not None:
                arr = arr * gain
            cols.append(arr)
            labels.append("ECG_ch%d" % ch)
        nmin = min(len(a) for a in cols)
        if nmin == 0:
            raise ValueError("%s: multiplexed channels contain 0 samples"
                             % path)
        mat = np.column_stack([a[:nmin] for a in cols])
        _detrend_cols(mat)
        for start_s, end_s in bad_spans_s:
            s0 = max(0, int(np.floor(start_s * fs)))
            s1 = min(nmin, int(np.ceil(end_s * fs)))
            if s1 > s0:
                mat[s0:s1, :] = np.nan
        return mat, fs, labels, mat.shape[0] / fs

    # Container has no demultiplexed channel partition -- refuse with evidence.
    if d.get("bulk_tag") is not None:
        where = ("  payload   framed: %d record(s) of tag %d hold %d bytes "
                 "(%.1f MB)\n"
                 % (len(d["bulk_spans"]), d["bulk_tag"], d["bulk_bytes"],
                    d["bulk_bytes"] / 1048576.0))
    elif d.get("data_offset"):
        where = ("  payload   trailing: starts at byte %d, %d bytes (%.1f MB)\n"
                 % (d["data_offset"], d["size"] - d["data_offset"],
                    (d["size"] - d["data_offset"]) / 1048576.0))
    else:
        where = ("  payload   NOT LOCATED -- the chain %s\n" % d["why"])
    raise NotImplementedError(
        "%s: the container header reads, but the SAMPLE LAYOUT is not known "
        "yet.\n"
        "  header    %d metadata record(s), tags %s\n"
        "%s"
        "  missing   sample width, channel count, channel order, mV scale\n"
        "\n"
        "  These are not guessable: a wrong width or channel count still\n"
        "  produces a signal with peaks and a plausible heart rate.  Resolve\n"
        "  them against an EDF export of the same recording, which this\n"
        "  project already has:\n"
        "\n"
        "      python3 ecg_rpeaks.py verify --raw %s \\\n"
        "          --against '~/EDF_output/*.edf'\n"
        % (os.path.basename(path), len(recs),
           ", ".join(str(r["tag"]) for r in recs[:8]) + (" ..." if len(recs) > 8 else ""),
           where, path))


def _sniff_format(path, nbytes=1 << 16):
    """Identify a file by its CONTENT.  Returns (kind, why) or (None, why).

    Extensions are a convention, not a fact, and this project has already met
    four spellings of the same two formats: `.txt`, `.asc`, `.ascii` for the
    Ponemah text export and `.PnmWav` for the native one.  Refusing a readable
    file because of its suffix is a self-inflicted failure -- the bytes were
    right there.

    Only claims something is readable on POSITIVE evidence: container magic, or
    a body that is overwhelmingly printable.  An unrecognised binary returns
    None, because guessing a layout is the error this whole project exists to
    avoid, and `probe` is the tool for that case.
    """
    try:
        with open(path, "rb") as f:
            head = f.read(nbytes)
    except OSError as e:
        return None, "cannot read it (%s)" % e
    if not head:
        return None, "the file is empty"
    if head.startswith(PNMWAV_MAGIC):
        return "pnmwav", "it starts with the Ponemah native container magic"
    if head[:4] == b"RIFF" and head[8:12] == b"WAVE":
        return "wav", "it starts with RIFF/WAVE"
    if head[:8] == b"0       ":
        return "edf", "it starts with the EDF version field"
    printable = sum(1 for c in head if 32 <= c < 127 or c in (9, 10, 13))
    frac = printable / float(len(head))
    if frac > 0.95:
        return "ascii", "%.0f%% of the first %d bytes are printable text" % (
            100.0 * frac, len(head))
    return None, ("no container magic matched and only %.0f%% of the bytes are "
                  "printable, so it is neither a known container nor text"
                  % (100.0 * frac))


def _detrend_cols(cols):
    """Remove a linear baseline from each column, IN PLACE, tolerating NaN.

    scipy.signal.detrend refuses an array containing NaN -- it calls lstsq
    with check_finite, which raises.  That mattered the moment a reader
    started producing NaN for marked samples: the load aborted before the
    excision machinery ever saw the file, so the careful downstream handling
    of missing data was unreachable, and the user got a stack trace naming
    scipy rather than anything about their recording.

    The baseline is fitted on the FINITE samples only and subtracted from the
    whole column.  Missing stays missing: filling belongs to fill_missing,
    which is paired with the mask that excises what it filled.  Silently
    interpolating here would lose that pairing, and the marked time would be
    counted as real signal.
    """
    for j in range(cols.shape[1]):
        col = cols[:, j]
        good = np.isfinite(col)
        ngood = int(good.sum())
        if ngood == len(col):
            cols[:, j] = detrend(col)
        elif ngood >= 2:
            idx = np.arange(len(col), dtype=float)
            slope, intercept = np.polyfit(idx[good], col[good], 1)
            cols[:, j] = col - (slope * idx + intercept)
        # Fewer than two finite samples: there is no line to fit, and the
        # column is excised in full downstream regardless.


def load_signals(path, minutes=0.0):
    """Dispatch on extension, then on content.  (cols, fs, labels, duration_s)."""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".edf", ".bdf", ".rec"):
        kind = "edf"
    elif ext in (".wav", ".wave"):
        kind = "wav"
    elif ext in _ASCII_EXTS:
        kind = "ascii"
    elif ext in PNMWAV_EXTS:
        kind = "pnmwav"
    else:
        # Unknown suffix: ask the bytes instead of refusing.
        kind, why = _sniff_format(path)
        if kind is None:
            raise ValueError(
                "%s: unrecognised extension %r, and the content does not\n"
                "  identify it either -- %s.\n"
                "  Known suffixes: .edf/.bdf/.rec, .wav, ASCII exports\n"
                "  %s, and Ponemah native %s.\n"
                "  Run:  python3 ecg_rpeaks.py probe --input %s\n"
                "  and send the output -- it reports what the file actually is\n"
                "  and tests candidate layouts against signal properties, which\n"
                "  is what a reader has to be written from."
                % (path, ext, why, "/".join(_ASCII_EXTS),
                   "/".join(PNMWAV_EXTS), path))
        # Say so, every time.  A file that reads for a reason the user did not
        # state is a file whose reader they cannot check, and if the sniff is
        # ever wrong this line is the only clue to why the numbers are strange.
        print("  ** %s: extension %r is not one I know, but %s, so it is being"
              " read as %s"
              % (os.path.basename(path), ext, why, kind), file=sys.stderr)

    if kind == "edf":
        edf = MiniEDF(path)
        valid = [i for i in range(edf.ns)
                 if not any(k in edf.labels[i].lower() for k in SKIP_LABELS)]
        if not valid:
            raise ValueError("%s: no usable signal channels" % path)
        ecg = [i for i in valid if "ecg" in edf.labels[i].lower()] or valid[:3]
        fs = float(edf.fs[ecg[0]])
        if fs <= 0:
            raise ValueError("%s: nonsensical sampling rate %r" % (path, fs))
        maxrec = (None if minutes <= 0
                  else int(np.ceil(minutes * 60.0 / edf.rec_duration)))
        cols = edf.read(ecg, max_records=maxrec)
        _detrend_cols(cols)
        return cols, fs, [edf.labels[i] for i in ecg], cols.shape[0] / fs
    if kind == "wav":
        cols, fs, labels, dur = read_wav(path, minutes)
        # Same baseline treatment the EDF path gets.  A waveform export often
        # carries a larger DC offset than an EDF, not less.
        _detrend_cols(cols)
        return cols, fs, labels, dur
    if kind == "ascii":
        cols, fs, labels, dur = read_ascii(path, minutes)
        _detrend_cols(cols)
        return cols, fs, labels, dur
    return read_ponemah(path, minutes)


# ======================================================== unknown-format probe
#
# The problem this solves: a binary layout guessed wrong does not fail loudly.
# It yields numbers, a plot, a heart rate -- all wrong, none obviously so.  The
# only safe way to write a reader for an unseen format is to make the file
# testify about itself, so `probe` reports what can be OBSERVED and then tests
# candidate interpretations against properties that a misparse cannot fake.
#
# The discriminator is oversampling.  A physiological signal sampled at 500 Hz
# is smooth on the scale of one sample: consecutive samples differ by far less
# than the signal's range, so autocorrelation at short lag is high.  Bytes read
# at the wrong width, endianness or offset produce a series with essentially no
# sample-to-sample correlation.
#
# How high is "high" depends on the record, and the honest number is lower than
# it first appears.  Clean bandlimited ECG reaches ~0.99, but a noisy trace --
# flat baseline, narrow QRS, white noise between beats -- measures only 0.34 on
# the selftest fixture.  What matters is not the absolute value but the RATIO:
# the same bytes read wrongly score 0.01.
#
# So the cut is 0.15, which is 34x the noise floor and 2x below the hardest
# real signal measured.  A round 0.5 was the first choice and was wrong: it
# would have rejected the selftest fixture, a genuine ECG, as "not a waveform".
# Smoothness alone is only a screen; probe_rate() below is what actually
# confirms, and the verdict text says "probably" either way.
#
# Interleaving falls out of the same measurement for free.  If N channels are
# interleaved, consecutive samples come from DIFFERENT channels, so correlation
# peaks at lag N rather than lag 1.  The lag of the peak is the channel count.

_MAGICS = [
    (b"RIFF", "RIFF container (bytes 8-12 say which kind; WAVE is readable now)"),
    (b"\x89HDF", "HDF5"),
    (b"PK\x03\x04", "ZIP container (some exports are zipped)"),
    (b"\x1f\x8b", "gzip"),
    (b"SQLite format 3", "SQLite database"),
    (b"\xd0\xcf\x11\xe0", "OLE2 / Compound File (old MS container)"),
    (b"<?xml", "XML text"),
    (b"\x93NUMPY", "NumPy .npy"),
    (b"\x89PNG\r\n\x1a\n", "PNG image"),
    (b"%PDF", "PDF"),
    (b"0       ", "EDF / EDF+ (version field is '0' padded to 8)"),
]


def zip_describe(path, limit=40):
    """List an archive's entries, and name the sheets if it is an xlsx.

    Worth having because `.xlsx` is a ZIP of XML and the standard library can
    open it -- no new dependency, which matters for a tool that has to run on
    the user's laptop beside the data.  A Ponemah spreadsheet export is a
    strong candidate for DERIVED results (per-interval heart rate and the
    like), and those are the one thing this project cannot produce for itself:
    an independent second opinion to check `trend` against.

    Returns a dict; never raises.  Reports only what the archive SAYS it
    contains -- names, sizes, sheet titles.  Reading the numbers out is a
    separate job and should not be guessed at from a listing.
    """
    out = dict(ok=False, entries=[], sheets=[], kind="zip", why="")
    try:
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
            out["entries"] = [(i.filename, i.file_size)
                              for i in z.infolist()[:limit]]
            out["n_entries"] = len(names)
            out["ok"] = True
            if "xl/workbook.xml" in names:
                out["kind"] = "xlsx"
                # Sheet names live in workbook.xml as name="..." attributes.
                # A regex rather than an XML parse: the file is tiny, the
                # attribute is unambiguous, and this cannot fail in a way that
                # matters -- a missed name costs a line of output.
                try:
                    xml = z.read("xl/workbook.xml").decode("utf-8", "replace")
                    out["sheets"] = re.findall(r'<sheet[^>]*name="([^"]+)"', xml)
                except (KeyError, OSError):
                    pass
            elif any(n.startswith("word/") for n in names):
                out["kind"] = "docx"
    except (zipfile.BadZipFile, OSError) as e:
        out["why"] = str(e)
    return out


# Column names that have meant "a point in time" in the sidecars seen so far.
# Used only to decide which columns are worth showing a min/max for; a wrong
# guess costs one line of output and is visible in that line.
_TIME_NAMEISH = ("time", "ticks", "stamp", "date", "start", "end", "logtime")


def _sqlite_uri_path(path):
    """Make a path safe to drop into a `file:...?mode=ro` SQLite URI.

    Only the characters SQLite's URI parser treats specially need escaping.  A
    full urllib quote would also escape the spaces that are all over these
    filenames ("08062023 P10.PnmMarks") -- legal, but it makes the URI
    unreadable in an error message, and error messages are most of what this
    ever appears in.
    """
    return str(path).replace("?", "%3f").replace("#", "%23")


def sqlite_describe(path, sample=0):
    """List what a SQLite file contains, without modifying it in any way.

    All four Ponemah sidecars are SQLite, and `probe` was already printing
    "SQLite database" and then running the waveform search over B-tree pages
    anyway -- which is how a 122 KB event log got called "very likely correct"
    as a biosignal layout.  Recognising the container has to mean something.

    Opened `mode=ro&immutable=1`.  Read-only is the obvious half; `immutable`
    is the half that matters, because without it SQLite may create `-wal` and
    `-shm` files beside the database, and this tool is pointed at the user's
    only copy of an experiment.  It must leave the directory byte-identical.

    `sample` > 0 also pulls that many rows from each table.  Off by default: a
    listing is cheap and safe to run on anything, and 26 MB of beat times is
    not something to print by accident.

    Returns a dict; never raises.
    """
    out = dict(ok=False, tables=[], why="", npages=0, page_size=0)
    uri = "file:%s?mode=ro&immutable=1" % _sqlite_uri_path(path)
    try:
        con = sqlite3.connect(uri, uri=True)
    except sqlite3.Error as e:
        out["why"] = str(e)
        return out
    try:
        cur = con.cursor()
        try:
            out["page_size"] = int(cur.execute("PRAGMA page_size").fetchone()[0])
            out["npages"] = int(cur.execute("PRAGMA page_count").fetchone()[0])
        except (sqlite3.Error, TypeError, IndexError):
            pass
        try:
            names = [r[0] for r in cur.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
                " ORDER BY name").fetchall()]
        except sqlite3.Error as e:
            out["why"] = str(e)
            return out
        for nm in names:
            t = dict(name=nm, cols=[], nrow=None, rows=[], spans={}, why="")
            # Identifiers cannot be bound as parameters, and these names come
            # from sqlite_master rather than from the user, so quoting is the
            # right tool: double any quote character and wrap.
            q = '"%s"' % nm.replace('"', '""')
            try:
                t["cols"] = [(r[1], r[2]) for r in
                             cur.execute("PRAGMA table_info(%s)" % q).fetchall()]
                t["nrow"] = int(cur.execute(
                    "SELECT COUNT(*) FROM %s" % q).fetchone()[0])
            except (sqlite3.Error, TypeError, IndexError) as e:
                t["why"] = str(e)
                out["tables"].append(t)
                continue
            # Ranges for anything time-shaped.  A min and a max turn "LogTime
            # LONG" into a statement about how long the recording is and what
            # the clock's units are, which is exactly what a reader must know
            # and exactly what the container never says outright.
            for cn, ct in t["cols"]:
                if not any(k in cn.lower() for k in _TIME_NAMEISH):
                    continue
                if not any(k in (ct or "").upper()
                           for k in ("INT", "LONG", "REAL", "NUM", "FLOAT")):
                    continue
                cq = cn.replace('"', '""')
                try:
                    lo, hi = cur.execute(
                        'SELECT MIN("%s"), MAX("%s") FROM %s' % (cq, cq, q)
                    ).fetchone()
                except (sqlite3.Error, TypeError):
                    continue
                if lo is not None:
                    t["spans"][cn] = (lo, hi)
            if sample > 0 and t["nrow"]:
                try:
                    t["rows"] = cur.execute(
                        "SELECT * FROM %s LIMIT %d" % (q, int(sample))
                    ).fetchall()
                except sqlite3.Error:
                    pass
            out["tables"].append(t)
        out["ok"] = True
    finally:
        con.close()
    return out


def _sq_cols(tables, name):
    """Column names of `name`, or [] if the table is absent."""
    t = tables.get(name)
    return [c for c, _ty in (t or {}).get("cols", [])]


def read_marks(path):
    """Read Ponemah's OWN beat detections and bad-data intervals.

    This is the file that changes what the project can measure.  Until now
    there were two things no amount of work on the waveform could supply:

      * goal (b), "reasonable R peak suggestions ... to estimate the
        accuracy".  `Cycle` is a per-beat table -- 407,376 rows on P10 --
        written by the acquisition system.  That is a second opinion on every
        beat, for free, with nothing marked by hand.
      * the intervals to exclude.  `BadDataMark(StartTime, EndTime)` is the
        acquisition system's own statement of which stretches are unusable.
        This tool INFERS bad stretches (nosig_s) and reads the exporter's 'x'
        markers (mark_s); this is the third and most authoritative source, and
        it is the one the user asked for first.

    Note what is NOT read: `Cycle.Marks` is a BLOB whose layout is unknown, and
    nothing here guesses at it.  `CycleTime` alone is the beat time, and the
    beat time is what is needed.  A blob decoded on a hunch would be worse than
    no blob at all, because its output would look like data.

    Every table is treated as optional and every column is checked for before
    it is selected: this schema has been seen on exactly one file.

    Returns a dict; never raises on a malformed or unexpected database.
    """
    out = dict(ok=False, why="", path=path, contexts=[], bad=[],
               t0=None, t1=None, created=None, span_s=0.0, tables={})
    desc = sqlite_describe(path)
    if not desc["ok"]:
        out["why"] = desc["why"] or "not a readable SQLite database"
        return out
    tables = {t["name"]: t for t in desc["tables"]}
    out["tables"] = {k: v["nrow"] for k, v in tables.items()}
    cyc_cols = _sq_cols(tables, "Cycle")
    if not cyc_cols:
        out["why"] = ("no Cycle table; this database has %s"
                      % (", ".join(sorted(tables)) or "no tables"))
        return out
    if "CycleTime" not in cyc_cols:
        out["why"] = ("Cycle has no CycleTime column (found %s)"
                      % ", ".join(cyc_cols))
        return out
    has_ctx = "ChannelContextId" in cyc_cols

    con = sqlite3.connect("file:%s?mode=ro&immutable=1" % _sqlite_uri_path(path),
                          uri=True)
    try:
        cur = con.cursor()
        # ---- the beats
        sel = ("SELECT ChannelContextId, CycleTime FROM Cycle"
               if has_ctx else "SELECT 0, CycleTime FROM Cycle")
        try:
            rows = cur.execute(sel).fetchall()
        except sqlite3.Error as e:
            out["why"] = "could not read Cycle: %s" % e
            return out
        if not rows:
            out["why"] = "Cycle is empty"
            return out
        arr = np.asarray(rows, dtype=np.int64)
        ctx_ids, times = arr[:, 0], arr[:, 1]
        out["t0"] = int(times.min())
        out["t1"] = int(times.max())
        out["span_s"] = (out["t1"] - out["t0"]) / float(NET_TICKS_PER_S)

        # ---- what each context IS.  Reported verbatim; the only derived
        # value is the rate, and TicksPerSample states it outright.
        info = {}
        ici_cols = _sq_cols(tables, "ChannelContextInfo")
        if "ChannelContextId" in ici_cols:
            try:
                for r in cur.execute("SELECT * FROM ChannelContextInfo"):
                    d = dict(zip(ici_cols, r))
                    tps = d.get("TicksPerSample")
                    d["fs"] = (float(NET_TICKS_PER_S) / float(tps)
                               if tps else None)
                    info[int(d["ChannelContextId"])] = d
            except (sqlite3.Error, TypeError, ValueError):
                pass

        for cid in sorted(set(int(c) for c in ctx_ids)):
            t = np.sort(times[ctx_ids == cid])
            d = dict(info.get(cid) or {})
            d["ctx"] = cid
            d["n"] = int(t.size)
            d["t0"], d["t1"] = int(t[0]), int(t[-1])
            d["span_s"] = (d["t1"] - d["t0"]) / float(NET_TICKS_PER_S)
            d["times"] = t
            # Mean rate is count over span.  Median RR is the robust one: a
            # single long dropout moves the mean and leaves the median alone,
            # and the difference between them is itself the dropout signal.
            d["bpm_mean"] = (60.0 * (d["n"] - 1) / d["span_s"]
                             if d["span_s"] > 0 and d["n"] > 1 else float("nan"))
            rr = np.diff(t) / float(NET_TICKS_PER_S)
            d["rr"] = rr
            d["bpm_modal"] = (60.0 / float(np.median(rr))
                              if rr.size and np.median(rr) > 0 else float("nan"))
            out["contexts"].append(d)

        # ---- the bad-data intervals
        bad_cols = _sq_cols(tables, "BadDataMark")
        if "StartTime" in bad_cols and "EndTime" in bad_cols:
            has_sub = "SubjectChannelId" in bad_cols
            sel = ("SELECT SubjectChannelId, StartTime, EndTime FROM BadDataMark"
                   if has_sub else "SELECT 0, StartTime, EndTime FROM BadDataMark")
            try:
                out["bad"] = [tuple(int(x) for x in r)
                              for r in cur.execute(sel)
                              if r[1] is not None and r[2] is not None]
            except (sqlite3.Error, TypeError, ValueError) as e:
                out["why"] = "BadDataMark present but unreadable: %s" % e

        mdi_cols = _sq_cols(tables, "MarkDatabaseInfo")
        if "CreateDate" in mdi_cols:
            try:
                out["created"] = int(cur.execute(
                    "SELECT CreateDate FROM MarkDatabaseInfo").fetchone()[0])
            except (sqlite3.Error, TypeError, ValueError, IndexError):
                pass
        out["ok"] = True
    finally:
        con.close()
    return out


def merge_tick_spans(spans):
    """Merge overlapping (start, end) tick intervals.  Returns a sorted list.

    Overlapping marks are not hypothetical: 383 of them over 18 hours, written
    by an operator and by an algorithm, will overlap.  Summing the raw
    durations would then over-count the excluded time -- the same mistake the
    no-signal span code had to fix, and the same fix.
    """
    if not spans:
        return []
    s = sorted((int(a), int(b)) for a, b in spans if b >= a)
    merged = [list(s[0])]
    for a, b in s[1:]:
        if a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return [(a, b) for a, b in merged]


def merge_spans_s(spans):
    """Merge overlapping (start, end) intervals given in SECONDS.

    Deliberately separate from merge_tick_spans, which casts to int because
    ticks are integers.  Running second-valued spans through that would
    truncate every edge to a whole second -- at 500 Hz that is up to 500
    samples of silent misplacement per edge, in a code path whose entire job
    is to place edges correctly.

    Merging is not just tidiness here.  Downstream the membership test finds
    the LAST span starting at or before a beat; with (0, 100) and (50, 60)
    left unmerged, a beat at 80 is tested against (50, 60), found outside, and
    kept -- even though (0, 100) covers it.  Merged input makes that test
    exact rather than usually-right.
    """
    if not spans:
        return []
    s = sorted((float(a), float(b)) for a, b in spans if b >= a)
    merged = [list(s[0])]
    for a, b in s[1:]:
        if a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return [(a, b) for a, b in merged]


def beats_in_spans(times, spans):
    """How many of `times` fall inside any of the merged `spans`.

    The number that decides how to USE both tables.  If Ponemah's own beat list
    already excludes its own bad intervals, the Cycle table is pre-cleaned and
    can be compared against directly.  If it does not, the marks are advisory
    and the beats inside them are the ones to distrust -- in which case the
    exclusion has to be applied by whoever reads the file, which is this tool.

    Either answer is useful.  Assuming either one is not.
    """
    if not len(times) or not spans:
        return 0
    starts = np.array([a for a, _ in spans], dtype=np.int64)
    ends = np.array([b for _, b in spans], dtype=np.int64)
    t = np.asarray(times, dtype=np.int64)
    # Index of the last span starting at or before each beat.
    i = np.searchsorted(starts, t, side="right") - 1
    ok = i >= 0
    return int(np.count_nonzero(ok & (t <= ends[np.clip(i, 0, None)])))


_PROBE_DTYPES = ["<i2", ">i2", "<i4", ">i4", "<f4", ">f4", "<f8", ">f8"]
# Offsets worth trying: zero, the usual round header sizes, and the canonical
# WAV data offset.  A detected text-header length is appended to this at runtime.
_PROBE_OFFSETS = [0, 16, 24, 32, 44, 48, 64, 96, 128, 256, 512, 768, 1024, 2048, 4096]

# Below this peak correlation, decline to call it a waveform.  Derived above.
PROBE_WAVEFORM_CUT = 0.15
# Two candidates whose scores differ by less than this are not distinguishable
# by the data, so the ordering between them is noise.  See the sort below.
PROBE_TIE = 0.02


def _autocorr(x, k):
    """Normalised autocorrelation of x at lag k, or 0.0 if undefined.

    Runs under errstate(ignore) because the probe feeds this deliberately
    misinterpreted bytes: NaN, inf and overflow are the expected result of a
    wrong hypothesis, not a fault.  Letting numpy warn would print dozens of
    RuntimeWarnings into the user's terminal on every probe of a real file --
    and a tool that cries wolf on its normal path is one whose warnings stop
    being read.  A non-finite result is mapped to 0.0, which scores the
    hypothesis as "no correlation", which is exactly what it deserves.
    """
    if k <= 0 or len(x) <= k + 2:
        return 0.0
    with np.errstate(all="ignore"):
        a, b = x[:-k], x[k:]
        a = a - a.mean()
        b = b - b.mean()
        d = float(np.sqrt(float((a * a).sum()) * float((b * b).sum())))
        r = float((a * b).sum() / d) if d > 0 else 0.0
    return r if np.isfinite(r) else 0.0


def probe_layouts(buf, extra_offsets=(), max_samples=60000, max_lag=8):
    """Rank (dtype, offset) readings of `buf` by sample-to-sample smoothness.

    Returns dicts sorted best-first.  `nch_hint` is the lag at which
    correlation peaks, which for interleaved data is the channel count.
    """
    offsets = sorted(set(list(_PROBE_OFFSETS) + [int(o) for o in extra_offsets]))
    out = []
    for name in _PROBE_DTYPES:
        dt = np.dtype(name)
        for off in offsets:
            if off % dt.itemsize:            # unaligned: np.frombuffer refuses
                continue
            avail = (len(buf) - off) // dt.itemsize
            if avail < 2000:                 # too little to conclude anything
                continue
            n = int(min(avail, max_samples))
            try:
                # Reading bytes as the WRONG float type is the point of this
                # loop, and it legitimately produces NaN, inf and overflow.
                # Those are measurements here, not faults, so numpy is told
                # to stay quiet rather than printing a warning per candidate.
                with np.errstate(all="ignore"):
                    x = np.frombuffer(buf, dtype=dt, count=n,
                                      offset=off).astype(np.float64)
                    ffrac = float(np.isfinite(x).mean())
            except (ValueError, TypeError):
                continue
            # Float dtypes read off the wrong boundary generate NaN/inf en
            # masse.  That is itself evidence, so it is recorded, not hidden.
            if ffrac < 0.99:
                out.append(dict(dtype=name, offset=off, finite=ffrac,
                                acs=[0.0] * max_lag, score=0.0, nch_hint=0,
                                rng=(float("nan"), float("nan"))))
                continue
            with np.errstate(all="ignore"):
                sd = float(x.std())
            if not np.isfinite(sd) or sd <= 0:
                continue
            acs = [_autocorr(x, k) for k in range(1, max_lag + 1)]
            best = int(np.argmax(acs))
            out.append(dict(dtype=name, offset=off, finite=ffrac, acs=acs,
                            score=float(acs[best]), nch_hint=best + 1,
                            rng=(float(x.min()), float(x.max()))))
    # Sort by score, but treat near-ties as ties and prefer the EARLIEST
    # offset among them.  In a headerless buffer every offset that is a
    # multiple of the item size is an equally valid place to start, so the
    # ranking between them is decided by noise -- and reporting "data starts
    # at 4096" for a file with no header would send a reader author hunting
    # for a header that does not exist.  Where a real header IS present, its
    # bytes are not smooth, so the score itself separates the offsets and
    # this tie-break never engages.
    out.sort(key=lambda d: (-int(d["score"] / PROBE_TIE), d["offset"]))
    return out


def probe_rate(x, fs, hr_lo=40.0, hr_hi=250.0):
    """Strongest periodicity within a heart-rate band: (bpm, correlation).

    The confirmatory test, and much harder to fake than smoothness.  An
    interpretation that is wrong but still smooth -- reading the high half of a
    32-bit word, say -- will not show a sharp autocorrelation peak at a
    physiological interval.  Smooth AND periodic at 40-250 bpm is close to
    conclusive; smooth alone is only suggestive.
    """
    lo = max(2, int(round(fs * 60.0 / hr_hi)))
    hi = min(int(round(fs * 60.0 / hr_lo)), (len(x) // 2) - 1)
    if hi <= lo:
        return float("nan"), 0.0
    lags = np.arange(lo, hi + 1)
    if len(lags) > 400:                      # keep the sweep cheap
        lags = np.unique(np.linspace(lo, hi, 400).astype(int))
    best_lag, best_ac = 0, -2.0
    for k in lags:
        a = _autocorr(x, int(k))
        if a > best_ac:
            best_ac, best_lag = a, int(k)
    # How big is "big"?  Scanning many lags for the largest correlation finds
    # something even in noise, and how much depends on the series length and
    # the number of lags tried -- so a fixed cut is meaningless.  For white
    # noise the expected largest |r| over nl lags of n samples is about
    # sqrt(2 ln(nl) / n).  Reporting the peak as a MULTIPLE of that makes the
    # claim scale-free and checkable.
    #
    # This matters concretely: a fixed 0.30 cut was tried first and rejected a
    # peak of 0.211 that was the exactly correct rate and 12x chance.
    chance = float(np.sqrt(2.0 * np.log(max(2, len(lags))) / max(1, len(x))))
    return ((60.0 * fs / best_lag if best_lag else float("nan")),
            best_ac, chance)


def probe_text(buf, minlen=6, limit=25):
    """Printable-ASCII runs -- where a vendor usually names its own format."""
    runs, cur, start = [], [], 0
    for i, c in enumerate(buf):
        if 32 <= c < 127:
            if not cur:
                start = i
            cur.append(c)
        else:
            if len(cur) >= minlen:
                runs.append((start, bytes(cur).decode("ascii")))
            cur = []
    if len(cur) >= minlen:
        runs.append((start, bytes(cur).decode("ascii")))
    return runs[:limit]


# ==================================== verifying a binary layout against truth
#
# `probe` above scores a layout by whether it LOOKS like a signal.  That is the
# best available test when nothing else is known, and it is weak: the real
# .PnmWav probe returned a confident verdict for a big-endian reading of a
# little-endian file, because misread bytes can be smooth and can be periodic.
#
# This section replaces the judgement call with a measurement, using a fact
# specific to this project: the EDF corpus was EXPORTED FROM the Ponemah file.
# `08062023 P10.P10.20230806195959.PnmWav` and
# `P10_seg01_part001_20230806_195959.edf` carry the same timestamp, and the
# EDFs are the decoded form of the same samples.  So the decoded answer is
# already on disk, and a candidate layout does not need to be judged -- it can
# be checked.  The layout that reproduces the export is correct; everything
# else correlates at essentially zero.
#
# Why correlation rather than equality: the export may have been scaled,
# offset, inverted, filtered or reordered on its way out of Ponemah.  Any of
# those defeats a byte-equality test while leaving correlation near 1.  The fit
# afterwards recovers the scale and offset, which is exactly the mV calibration
# a reader needs and which the container never states.
#
# The second thing this buys is a CONTIGUITY test.  Matching the first minute
# proves the layout at one point.  Matching an EDF from ten hours later, at the
# byte offset predicted by elapsed time alone, proves that the payload is one
# unbroken interleaved block with no per-block headers -- the failure mode that
# would otherwise appear as a slow drift and be discovered only after someone
# trusted a night of heart rates.

VERIFY_DTYPES = ("<i2", ">i2", "<i4", ">i4", "<f4", "<f8")
# At or above this, the candidate reproduces the reference and the layout is
# settled.  Real recordings of the same samples correlate at ~1.0; the margin
# below 1 is for export-side filtering, not for doubt.
VERIFY_MATCH = 0.99
# Below this the two are not the same signal.  Between the two is the
# uncomfortable middle, which is reported as unresolved rather than rounded to
# a verdict -- a 0.8 here would most likely mean the right dtype with the wrong
# channel count, which is worth saying out loud rather than accepting.
#
# MEASURED, and the margin is thinner than it looks: the report harness matches
# the container against an UNRELATED recording, and that scores 0.399 -- not
# because the layout is nearly right but because both synthetic records carry
# the same slow baseline oscillation, and correlation notices it.  Two real
# recordings of different animals share less, so 0.399 is a pessimistic floor.
# Even so, only 0.1 separates the worst false positive seen from this cut, so
# treat a result in the 0.4-0.6 band as unresolved in practice regardless of
# which side of the line it lands.
VERIFY_REJECT = 0.50


def _lin_detrend(v):
    """Remove a least-squares line.  Cheap, and applied to BOTH sides.

    load_signals() detrends every reference channel on the way in.  Leaving the
    raw side untreated would compare a detrended signal against a drifting one
    and lose a few points of correlation on nothing but baseline wander -- and
    a few points is the whole margin between "confirmed" and "partial".
    """
    v = np.asarray(v, dtype=np.float64)
    n = len(v)
    if n < 3:
        return v - (v.mean() if n else 0.0)
    t = np.arange(n, dtype=np.float64)
    tc = t - t.mean()
    with np.errstate(all="ignore"):
        den = float((tc * tc).sum())
        vm = float(v.mean())
        slope = float((tc * (v - vm)).sum()) / den if den > 0 else 0.0
        out = v - (vm + slope * tc)
    return out if np.isfinite(out).all() else v - vm



def _xcorr_best(a, b, max_lag=0):
    """(r, lag) for the shift of `a` against `b` maximising |correlation|.

    The sign of r is kept and reported: a lead can be stored inverted relative
    to how it was exported, which is a polarity convention rather than a
    mismatch, and silently taking the absolute value would hide it.

    Normalisation uses the full-length norms rather than per-overlap ones, so a
    match at nonzero lag is very slightly understated.  That is the safe
    direction -- it can only make a true match look worse, never a false one
    look better.
    """
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    n = int(min(len(a), len(b)))
    if n < 64:
        return 0.0, 0
    a, b = a[:n], b[:n]
    with np.errstate(all="ignore"):
        a = a - a.mean()
        b = b - b.mean()
        na = float(np.sqrt(float((a * a).sum())))
        nb = float(np.sqrt(float((b * b).sum())))
    if not (np.isfinite(na) and np.isfinite(nb) and na > 0 and nb > 0):
        return 0.0, 0
    max_lag = int(max(0, min(max_lag, n - 1)))
    if max_lag == 0:
        r = float((a * b).sum() / (na * nb))
        return (r if np.isfinite(r) else 0.0), 0
    nf = 1
    while nf < 2 * n:
        nf <<= 1
    with np.errstate(all="ignore"):
        c = np.fft.irfft(np.fft.rfft(a, nf) * np.conj(np.fft.rfft(b, nf)), nf)
        c = c / (na * nb)
    vals = np.concatenate([c[:max_lag + 1], c[nf - max_lag:]])
    lags = np.concatenate([np.arange(0, max_lag + 1), np.arange(-max_lag, 0)])
    vals = np.where(np.isfinite(vals), vals, 0.0)
    k = int(np.argmax(np.abs(vals)))
    return float(vals[k]), int(lags[k])


class FileSource(object):
    """The whole file, as bytes at their own offsets.  The obvious case."""

    framed = False

    def __init__(self, path):
        self.path = path
        self.nbytes = os.path.getsize(path)
        self.label = "file"

    def read_at(self, off, n):
        if off < 0 or n <= 0:
            return b""
        with open(self.path, "rb") as f:
            f.seek(int(off))
            return f.read(int(n))

    def where(self, off):
        """Describe a logical offset in terms a person can check."""
        return "byte %d" % off


class BlockSource(object):
    """The values of one repeated tag, concatenated into one logical stream.

    A container that stores samples in framed blocks -- 16 KB of data behind
    every tag/length header -- has no contiguous payload at all, so a layout
    search over raw file offsets is searching bytes that are interrupted every
    few thousand samples by six bytes of header.  That is enough to destroy
    any correlation, which is what NO MATCH at r = -0.32 looks like.

    This presents the block VALUES as one run, so the same search works
    unchanged.  `skip` drops a fixed prefix from each block, for the common
    case where a block carries its own small preamble (a timestamp, a
    sequence number) before the samples.  Zero is tried first and is the only
    value that needs no justification.
    """

    framed = True

    def __init__(self, path, spans, skip=0):
        self.path = path
        self.skip = int(skip)
        self.spans = [(int(o) + self.skip, int(L) - self.skip)
                      for o, L in spans if int(L) - self.skip > 0]
        self.starts, tot = [], 0
        for _o, L in self.spans:
            self.starts.append(tot)
            tot += L
        self.nbytes = tot
        self.label = ("%d block(s), %d byte(s) of payload%s"
                      % (len(self.spans), tot,
                         ", skipping %d per block" % self.skip if self.skip
                         else ""))

    def read_at(self, off, n):
        if off < 0 or n <= 0 or off >= self.nbytes:
            return b""
        out, want = [], int(n)
        i = bisect.bisect_right(self.starts, int(off)) - 1
        pos = int(off)
        with open(self.path, "rb") as f:
            while want > 0 and 0 <= i < len(self.spans):
                fo, L = self.spans[i]
                within = pos - self.starts[i]
                take = min(want, L - within)
                if take > 0:
                    f.seek(fo + within)
                    chunk = f.read(take)
                    if not chunk:
                        break
                    out.append(chunk)
                    want -= len(chunk)
                    pos += len(chunk)
                    if len(chunk) < take:
                        break
                i += 1
        return b"".join(out)

    def where(self, off):
        if off < 0 or off >= self.nbytes:
            return "offset %d (outside the payload)" % off
        i = bisect.bisect_right(self.starts, int(off)) - 1
        fo, _L = self.spans[i]
        within = int(off) - self.starts[i]
        return ("payload byte %d = block %d + %d, file byte %d"
                % (off, i, within, fo + within))


def _as_source(src):
    """Accept a path or a source object, so old callers keep working."""
    return FileSource(src) if isinstance(src, str) else src


def raw_window(src, byte_off, dtype, nch, nsamp):
    """Read nsamp frames of nch interleaved `dtype` samples from `byte_off`.

    `src` is a path or a byte source, so the same search runs over a flat file
    and over a block-framed payload without knowing which it has.

    Returns an (n, nch) array or None if the read is too short or the bytes do
    not decode finitely -- which is the normal outcome for a wrong float dtype
    and is treated as evidence against the hypothesis, not as an error.
    """
    src = _as_source(src)
    dt = np.dtype(dtype)
    stride = dt.itemsize * int(nch)
    if byte_off < 0 or stride <= 0 or nsamp <= 0:
        return None
    try:
        raw = src.read_at(int(byte_off), int(nsamp) * stride)
    except OSError:
        return None
    nfull = len(raw) // stride
    if nfull < 64:
        return None
    with np.errstate(all="ignore"):
        x = np.frombuffer(raw, dtype=dt, count=nfull * int(nch)).astype(np.float64)
    x = x.reshape(nfull, int(nch))
    if not bool(np.isfinite(x).all()):
        return None
    return x


def verify_layouts(raw_path, ref, base_offsets, fs, dtypes=VERIFY_DTYPES,
                   max_nch=8, seconds=10.0, max_lag_s=1.0, top=10):
    """Rank readings of `raw_path` by how well they reproduce `ref`.

    `ref` is an (n, k) array of reference channels, already sampled at `fs`.
    Every (base offset, dtype, channel count) is decoded and every decoded
    channel is correlated against every reference channel.

    There is deliberately NO channel-phase loop.  An earlier version had one,
    on the reasoning that a payload starting a sample or two off the reported
    offset would leave the interleave rotated.  It does -- but a rotated read
    contains exactly the same samples under permuted channel indices, so it
    matches just as well, and the loop generated aliases of the winner that
    were indistinguishable from it (0.9999 against 0.9999) rather than rival
    hypotheses.

    The consequence is worth stating plainly, because it limits what this can
    conclude: the first-sample offset is only ever pinned down MODULO THE FRAME
    STRIDE.  Reading one sample earlier or later is the same recording with the
    channels relabelled.  What removes the remaining ambiguity is the channel
    mapping, which is reported alongside the offset for exactly that reason.
    """
    nsamp = int(seconds * fs)
    max_lag = int(max_lag_s * fs)
    out = []
    for base in base_offsets:
        for name in dtypes:
            for nch in range(1, max_nch + 1):
                off = int(base)
                x = raw_window(raw_path, off, name, nch, nsamp + max_lag + 8)
                if x is None:
                    continue
                for j in range(nch):
                    col = _lin_detrend(x[:, j])
                    with np.errstate(all="ignore"):
                        sd = float(col.std())
                    if not np.isfinite(sd) or sd <= 0:
                        continue
                    for i in range(ref.shape[1]):
                        r, lag = _xcorr_best(col, ref[:, i], max_lag)
                        out.append(dict(base=int(base), dtype=name, nch=nch,
                                        offset=off, raw_ch=j, ref_ch=i, r=r,
                                        lag=lag))
    out.sort(key=lambda d: -abs(d["r"]))
    # One row per structural hypothesis.  Without this the table is filled by
    # the same winning layout matched against each reference channel in turn,
    # which looks like corroboration and is not.
    seen, uniq = set(), []
    for d in out:
        key = (d["base"], d["dtype"], d["nch"], d["raw_ch"])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(d)
        if len(uniq) >= top:
            break
    return uniq


def verify_fit(raw_path, layout, ref_col, fs, byte_off, seconds=10.0,
               max_lag_s=1.0):
    """Match one layout at one byte offset against one reference channel.

    Returns a dict with the correlation, the lag, and the least-squares gain
    and offset that map raw counts onto the reference's units.  The gain is the
    calibration the container does not state; it is reported rather than
    applied, because one fit on one window is a measurement, not a constant.
    """
    dt = np.dtype(layout["dtype"])
    nsamp = int(seconds * fs)
    max_lag = int(max_lag_s * fs)
    x = raw_window(raw_path, byte_off, layout["dtype"], layout["nch"],
                   nsamp + max_lag + 8)
    if x is None:
        return dict(ok=False, why="could not read %d frames at byte %d"
                                  % (nsamp, byte_off), r=0.0)
    raw_col = x[:, layout["raw_ch"]]
    # Detrend over the span that is actually COMPARED, not over everything
    # read.  The read is deliberately longer -- nsamp + max_lag + 8 -- so the
    # gain fit has tail to align into, but `_xcorr_best` truncates both sides
    # to the shorter one, so fitting the baseline over the full read leaves a
    # residual tilt across the compared region.  On P10 channel 2 that alone
    # cost 0.012: the direct per-channel match measured 1.000 and this path
    # reported 0.988, which is exactly the margin between CONFIRMED and
    # PARTIAL.  A preprocessing detail decided the verdict.
    ncmp = int(min(len(raw_col), len(ref_col))) or len(raw_col)
    col = _lin_detrend(raw_col[:ncmp])
    r, lag = _xcorr_best(col, ref_col, max_lag)
    # The gain fit needs the tail, so it works on the whole column detrended
    # over its own span.  Shape is settled by `r` above; this only sets scale.
    col = _lin_detrend(raw_col)
    # Align and fit on the overlap.  A positive lag means the raw window starts
    # EARLIER than the reference, so the raw side is advanced to meet it.
    a = col[lag:] if lag >= 0 else col
    b = ref_col if lag >= 0 else ref_col[-lag:]
    m = int(min(len(a), len(b), nsamp))
    if m < 64:
        return dict(ok=False, why="overlap too short after a %d-sample lag" % lag,
                    r=r, lag=lag)
    a, b = a[:m], b[:m]
    with np.errstate(all="ignore"):
        va = float(a.var())
        gain = float(((a - a.mean()) * (b - b.mean())).sum()
                     / ((a - a.mean()) ** 2).sum()) if va > 0 else float("nan")
        icept = float(b.mean() - gain * a.mean()) if np.isfinite(gain) else float("nan")
        resid = b - (gain * a + icept) if np.isfinite(gain) else b
        rms = float(np.sqrt(float((resid ** 2).mean())))
        span = float(b.max() - b.min())
    return dict(ok=True, r=r, lag=lag, gain=gain, intercept=icept, rms=rms,
                rms_frac=(rms / span if span > 0 else float("nan")), n=m)


def verify_verdict(rabs, ch_r=None, match=None):
    """Decide what `verify` should say, given BOTH of its measurements.

    There are two independent measurements on a multiplexed container and they
    do not have to agree:

      * `ch_r` -- the direct match.  Each channel is demultiplexed, read as its
        own stream, and correlated against each exported lead.  It answers "is
        this stream that lead", and it is the cleaner question because nothing
        about the width or the frame stride has to be guessed.
      * `rabs` -- the re-derivation.  The layout search starts over on the
        winning stream and rediscovers the sample width, the channel count and
        the payload offset without being told.  Agreement is corroboration.

    Quoting only the second one is what produced this, verbatim, on P10:

        ch  ...  refCh       r
         2  ...      0    1.000
         3  ...      1    1.000
         4  ...      2    1.000
        VERDICT: PARTIAL -- r = 0.988 ... Do not write a reader yet.

    Three channels at unity and a closing line telling the reader to stop.  A
    verdict that contradicts the evidence printed six lines above it teaches
    the reader to skip the verdict, which is worse than having none.

    So: a confirmed direct match settles the layout.  A weaker re-derivation
    after it is reported as what it is -- a second pass that did not reach the
    same number -- and never as grounds to withdraw the first.

    Returns (level, lines) where level is "confirmed" or "partial".  The
    below-chance case never reaches here -- cmd_verify prints NO MATCH first.
    """
    match = VERIFY_MATCH if match is None else match
    direct = ch_r is not None and abs(ch_r) >= match
    derived = rabs >= match
    lines = []

    if not derived and not direct:
        lines.append("VERDICT: PARTIAL -- r = %.3f, which is well above chance"
                     " but short of" % rabs)
        lines.append("the %.2f needed to call the layout settled.  A value here"
                     " usually means" % match)
        lines.append("the sample width is right and the channel count is not,"
                     " so the")
        lines.append("interleave drifts across the window.  Do not write a"
                     " reader yet.")
        if ch_r is not None:
            lines.append("")
            lines.append("The direct per-channel match reached only %.3f, so"
                         " both passes" % abs(ch_r))
            lines.append("agree that something is unresolved.")
        return "partial", lines

    if direct and not derived:
        lines.append("VERDICT: LAYOUT CONFIRMED -- r = %.4f, from the direct"
                     " per-channel" % abs(ch_r))
        lines.append("match against a known-good export.")
        lines.append("")
        lines.append("The independent re-derivation below reached %.3f rather"
                     " than %.2f." % (rabs, match))
        lines.append("That gap is a property of the second pass, not of the")
        lines.append("layout: it searches widths and offsets over a window it")
        lines.append("has to guess the extent of, while the direct match reads")
        lines.append("one demultiplexed stream whose extent the container")
        lines.append("states.  The direct number is the one to quote.")
        return "confirmed", lines

    lines.append("VERDICT: LAYOUT CONFIRMED -- r = %.4f against a known-good"
                 " export." % rabs)
    if direct:
        lines.append("The direct per-channel match agrees at %.4f -- two"
                     " passes, one" % abs(ch_r))
        lines.append("told the channel split and one told nothing, same"
                     " answer.")
    elif ch_r is not None:
        # The re-derivation is the stronger of the two.  Say so plainly rather
        # than quietly dropping the weaker number.
        lines.append("The direct per-channel match reached %.3f, below the"
                     " %.2f bar;" % (abs(ch_r), match))
        lines.append("the layout search is the stronger evidence here.")
    return "confirmed", lines


def probe_verdict(best, bpm, rac, chance, fs_hint, hr_lo=40.0, hr_hi=250.0,
                  container_endian=None):
    """Turn the probe's measurements into a verdict, with its own caveats.

    Split out of cmd_probe so it can be tested, which is how three separate
    overstatements in the original text were found -- all of them on a real
    file, all of them reading as confident:

      * A best period pinned to the EDGE of the search band is not a peak, it
        is the search running out of room.  The real .PnmWav reported
        "250.0 bpm", which is exactly hr_hi, and the old text called that
        confirmation.
      * An integer reading that spans the FULL representable range is what
        arbitrary bytes look like.  Real recordings leave headroom.
      * A big-endian winner inside a little-endian container contradicts the
        container.  The .PnmWav header is unambiguously little-endian, and the
        old verdict still promoted a big-endian reading to "very likely
        correct".

    Returns (level, lines) where level is "confirmed", "unresolved" or
    "rejected".
    """
    ratio = (rac / chance) if chance > 0 else 0.0
    caveats = []

    edge = (np.isfinite(bpm)
            and (abs(bpm - hr_hi) <= 0.01 * hr_hi or abs(bpm - hr_lo) <= 0.01 * hr_lo))
    if edge:
        caveats.append(
            "the best period sits at the EDGE of the %g-%g bpm search band, so "
            "it is where the search stopped, not a peak it found"
            % (hr_lo, hr_hi))

    lo, hi = best.get("rng", (float("nan"), float("nan")))
    dt = np.dtype(best["dtype"])
    if dt.kind == "i" and np.isfinite(lo) and np.isfinite(hi):
        full_lo = -(2 ** (8 * dt.itemsize - 1))
        full_hi = 2 ** (8 * dt.itemsize - 1) - 1
        if lo <= full_lo and hi >= full_hi:
            caveats.append(
                "the values span the full %d-bit range exactly (%d..%d), which "
                "is what arbitrary bytes do; a real recording leaves headroom"
                % (8 * dt.itemsize, full_lo, full_hi))

    if container_endian and dt.byteorder in (">", "<"):
        cand = "big" if dt.byteorder == ">" else "little"
        if cand != container_endian:
            caveats.append(
                "this is a %s-endian reading, but the container's own header is "
                "%s-endian -- a file does not usually switch endianness between "
                "its header and its payload"
                % (cand, container_endian))

    if best["score"] < PROBE_WAVEFORM_CUT:
        return "rejected", [
            "VERDICT: no interpretation looks like a sampled waveform.",
            "The payload here is probably compressed, encrypted, or is",
            "an index rather than samples -- or the real data begins at",
            "an offset not in the tried set.  Send this output."]

    if ratio >= 5.0 and not caveats:
        return "confirmed", [
            "VERDICT: consistent with an oversampled biosignal, and",
            "periodic in the heart-rate band at %.0fx the level chance" % ratio,
            "would produce.  This layout is very likely correct.",
            "NOTE the %g Hz above was ASSUMED, not" % fs_hint,
            "read: if the true rate differs, the bpm scales with it,",
            "so confirm the rate before trusting that number."]

    lines = ["VERDICT: NOT RESOLVED -- smooth, so plausibly the right sample",
             "width, but the evidence does not settle the layout:"]
    if ratio < 5.0:
        lines.append("  * best periodicity is only %.1fx chance, which fits a slow"
                     % ratio)
        lines.append("    channel first in the interleave, a wrong channel count,")
        lines.append("    or a stretch with no signal.")
    for c in caveats:
        wrapped, cur = [], "  * "
        for word in c.split():
            if len(cur) + len(word) + 1 > 72:
                wrapped.append(cur)
                cur = "    " + word
            else:
                cur += ("" if cur.endswith("* ") else " ") + word
        wrapped.append(cur)
        lines += wrapped
    lines += [
        "",
        "Do not write a reader on this.  If an EDF (or other) export of the",
        "SAME recording exists, the layout can be settled outright:",
        "    python3 ecg_rpeaks.py verify --raw FILE --against 'EXPORTS/*.edf'",
        "which decodes the binary and checks it against the export instead of",
        "judging how signal-like it looks."]
    return "unresolved", lines



# ========================================================= signal / detection

def bp(x, fs, lo, hi, order=2):
    nyq = 0.5 * fs
    lo = max(lo, 0.05) / nyq
    hi = min(hi, nyq * 0.95) / nyq
    if hi <= lo:
        return np.zeros_like(x)
    b, a = butter(order, [lo, hi], btype="band")
    return filtfilt(b, a, x)


def enforce_refractory(sig, peaks, fs, ms):
    """Keep the larger of any two peaks closer than ms apart."""
    peaks = [int(p) for p in peaks]
    if not peaks:
        return np.array([], dtype=int)
    out, lim = [peaks[0]], ms / 1000.0 * fs
    for p in peaks[1:]:
        if (p - out[-1]) < lim:
            if abs(sig[p]) > abs(sig[out[-1]]):
                out[-1] = p
        else:
            out.append(p)
    return np.asarray(out, dtype=int)


def snap_to_extremum(sig, peaks, fs, win_ms):
    pad = int(round(win_ms / 1000.0 * fs))
    out = []
    for p in peaks:
        s = max(0, int(p) - pad); e = min(len(sig), int(p) + pad + 1)
        seg = sig[s:e]
        out.append(s + int(np.argmax(np.abs(seg - np.median(seg)))) if len(seg) else int(p))
    return np.asarray(out, dtype=int)


def clip_artifacts(x, k):
    """Limit gross artifacts before detection.

    WHY THE CONSTANT MATTERS, and why 8.0 was wrong.

    neurokit accepts a peak when it exceeds 0.25 * SPKI, where SPKI is an EWMA
    of ACCEPTED peak heights that is never lowered by a rejection.  Clipping at
    level C caps SPKI, so it caps the acceptance floor at 0.25 * C.

    Be careful with that sentence -- an earlier version of this comment got it
    backwards.  C is only an UPPER BOUND on SPKI, not its value.  On clean
    signal SPKI settles at the beat amplitude A and the floor sits at ~0.25 A
    whatever k is; that is why dropping k from 8 to 2 changed a clean file by
    0 beats and another by 1.  The clip binds in exactly one situation: an
    artifact taller than a beat drives SPKI up, the floor rises above A, and
    every subsequent beat in the chunk is rejected.  k = 8 permits SPKI to
    reach ~8 * p99, i.e. several times A, which is that failure.

    The LOWER bound on k is the opposite hazard: the clip must stay above the
    largest genuine beat, else real QRS complexes are flattened.

        C = k * p99(|x|)  >  1.18 * A        (1.18 A = largest real beat, v9)
        k  >  1.18 / (p99/A)

    p99/A is MEASURED per file and printed by `report` and `clipsweep`.  On this
    fleet it is 0.42-0.50, giving k_min 2.35-2.83.  The old figure of ~0.6 in
    this comment was a guess, and it was wrong in the UNSAFE direction by ~1.4x.

    k = 3.0 is the window those two bounds leave: above every measured k_min,
    and low enough that part015's 20.7 s gap at k=4 fell to 2.0 s at k=3.

    This is not a tuning preference.  It predicted the failure seen on real
    data: six of seven long gaps ended within 0.6 s of a 60 s chunk boundary,
    which is the ratchet releasing when the next chunk resets SPKI.

    Clipping affects ONLY the detection signal.  Morphology, amplitude and the
    template all run off `wide`, which is never clipped.
    """
    if k <= 0:
        return x, 0.0
    c = clip_level(x, k)
    if not np.isfinite(c):
        return x, 0.0
    return np.clip(x, -c, c), float(np.mean(np.abs(x) > c))


def clip_level(x, k):
    """The level clip_artifacts() clips at, or nan if it would not clip.

    Extracted so that refill_gaps() can ask where the clip sits without
    restating the formula.  Two copies of this expression would eventually
    disagree, and the failure would be silent: the refill would look for
    artifacts at a level the clipper never used.
    """
    if k <= 0:
        return float("nan")
    c = k * float(np.percentile(np.abs(x), 99.0))
    return c if np.isfinite(c) and c > 0 else float("nan")


def detect_nk(det_sig, fs, refr_ms):
    """One neurokit Pan-Tompkins call.

    CAVEAT for fast species.  neurokit hardcodes its minimum peak distance at
    0.3 * sampling_rate and does not forward **kwargs, so it physically cannot
    return a rate above 200 bpm.  A rat at 300-500 bpm is therefore impossible
    to detect with the stock call.  The workaround is to lie to it about the
    sampling rate so that 0.3 * sr_virtual equals the refractory period we
    actually want, in samples.

    That lie is not free.  ecg_peaks(method="pantompkins") does NOT filter:
    it takes the signal as given (the 5-15 Hz band-pass lives in ecg_clean,
    which this tool never calls; our own band-pass is applied before this).
    What it does is differentiate, square, integrate over int(0.12 * sr),
    blank the first int(0.2 * sr) samples, and run its adaptive-threshold
    peak search with a 0.3 * sr peak distance and a 0.25 * sr searchback
    distance (third_party/py/neurokit2/ecg/ecg_findpeaks.py).  Every one of
    those windows scales with sr_virtual, so a smaller sr also shortens the
    integration window and the searchback limit.  It is applied ONLY when the
    requested refractory is shorter than neurokit's own floor, which never
    happens for pig at 350 ms.  For rat this path is UNVALIDATED -- no rat
    data has been seen -- so it warns once.
    """
    fsi = int(round(fs))
    refr_samples = refr_ms / 1000.0 * fs
    sr_arg = fsi
    if refr_samples < 0.3 * fs:                  # our floor is tighter than theirs
        sr_arg = max(1, int(round(refr_samples / 0.3)))
        if not getattr(detect_nk, "_warned", False):
            print("  NOTE: requested refractory %.0f ms is below neurokit's hardcoded\n"
                  "        0.3*fs floor, so the detector is being called with a virtual\n"
                  "        sampling rate of %d Hz (real %d Hz).  This also shortens\n"
                  "        neurokit's 120 ms integration window and its searchback\n"
                  "        limit.  UNVALIDATED -- verify against\n"
                  "        hand-marked beats before trusting these results."
                  % (refr_ms, sr_arg, fsi), file=sys.stderr)
            detect_nk._warned = True
    try:
        _, info = nk.ecg_peaks(det_sig, sampling_rate=sr_arg, method="pantompkins")
    except Exception:                                        # noqa: BLE001
        return np.array([], dtype=int)
    pk = np.asarray(info["ECG_R_Peaks"], dtype=int)
    pk = pk[(pk > 0) & (pk < len(det_sig))]
    return enforce_refractory(det_sig, pk, fs, refr_ms)


def detect_chunked(det_sig, fs, chunk_s, refr_ms, lead_s=15.0, grid0=0):
    """Detect in bounded chunks.

    neurokit's _ecg_findpeaks_peakdetect updates SPKI only inside the accept
    branch, and nests its searchback inside that same branch, so the threshold
    floor (0.25 * SPKI) is a one-way ratchet: one gross artifact lifts it above
    every real beat and nothing can bring it back down.  Chunking confines the
    damage to the chunk that contains the artifact.  Each chunk gets a lead-in
    so the detector's thresholds are warm before its scoring region begins.

    `grid0` is the sample the chunk grid is anchored to.  0 for a whole file.
    A SEGMENT of a long recording arrives with DEFAULTS["lead_in_s"] of the
    previous segment in front of it, and its grid must start at the segment,
    not at the front of that lead-in: otherwise every chunk boundary would
    move by 15 s relative to an unsegmented run, and GAP_ENDS_ON_CHUNK_EDGE
    would be measured against a grid the detector never used.
    """
    n = len(det_sig)
    cs, lead = int(chunk_s * fs), int(lead_s * fs)
    g0 = int(grid0)
    out, k = [], (-((g0 + cs - 1) // cs) if g0 > 0 and cs > 0 else 0)
    while g0 + k * cs < n:
        core_s, core_e = max(0, g0 + k * cs), min(n, g0 + k * cs + cs)
        seg_s = max(0, core_s - lead)
        seg = det_sig[seg_s:core_e]
        if len(seg) > int(3 * fs):
            for p in detect_nk(seg, fs, refr_ms):
                g = seg_s + int(p)
                if core_s <= g < core_e:
                    out.append(g)
        k += 1
    out = np.unique(np.asarray(out, dtype=int)) if out else np.array([], dtype=int)
    return enforce_refractory(det_sig, out, fs, refr_ms)


def _first_artifact_end(det_sig, a, b, thr, fs, join_s=0.2):
    """Index just past the FIRST artifact burst inside [a, b), else a.

    An artifact is a sample the clipper had to flatten, so `thr` is the clip
    level and equality identifies it exactly.  Samples separated by less than
    `join_s` count as one burst, so a ringing artifact is not mistaken for
    several.

    The FIRST burst, not the last.  Restarting after the last one would refuse
    to recover anything whenever a second artifact lands late in the gap, even
    though the long clean stretch before it is perfectly detectable.  Taking the
    first burst recovers that stretch; whatever the second artifact suppresses
    is a shorter gap, which the next round handles.
    """
    if not np.isfinite(thr) or thr <= 0 or b <= a:
        return a
    hit = np.nonzero(np.abs(det_sig[a:b]) >= thr * (1.0 - 1e-9))[0]
    if not len(hit):
        return a
    join = max(1, int(round(join_s * fs)))
    end = hit[0]
    for h in hit[1:]:
        if h - end > join:
            break
        end = h
    return a + int(end) + 1


def refill_gaps(det_sig, peaks, fs, refr_ms, thr, gap_mult=3.0, max_rounds=3,
                min_seg_s=5.0, skip_spans=None):
    """Re-detect inside long gaps, restarting just after the artifact.

    WHY THIS EXISTS, and why the obvious alternative does not work.

    neurokit's SPKI is an EWMA of ACCEPTED peak heights, so a rejection never
    lowers it.  One artifact taller than a beat lifts the acceptance floor
    (0.25 * SPKI) above every real beat, and nothing inside that chunk can bring
    it back down -- searchback is nested inside the accept branch, so it cannot
    run either.  The threshold only recovers when the next chunk re-initialises
    it.  Every such gap therefore runs from the artifact to the next chunk
    boundary, which is why six of seven long gaps on the pig fleet ended within
    0.6 s of a 60 s grid line.

    The tempting fix is to detect on two grids offset by half a chunk and union
    the results.  It does not work.  Pass one loses [t_a, B1) and pass two loses
    [t_a, B2); both lose the span STARTING AT THE ARTIFACT, so the union still
    loses [t_a, min(B1, B2)).  That merely halves the worst case and leaves the
    gap ending on one of the two grids.

    What actually fixes it is to stop letting an arbitrary grid decide where the
    threshold resets.  The artifact is the thing that poisoned it, and a gap's
    start is where the artifact is, so restart detection immediately AFTER the
    artifact and take only what lands inside the gap.

    This is also self-diagnosing, which matters for files that may be genuinely
    damaged: if a gap refills, it was the ratchet; if it stays empty after being
    handed a clean restart, there was nothing there to find.

    skip_spans, if given, are (start_s, end_s) stretches where measurement has
    already established there is no signal, and no beat may be placed inside
    one.  The self-diagnosis above is the reason this is needed.  Handed a
    clean restart inside a dropout the refill mostly finds nothing, which is
    the right answer -- but "mostly" is not "never": the detector still fires
    on the recovery transient at the far edge, and those detections arrive
    with short RR intervals that look like couplets rather than like junk.
    Refusing by construction is stronger than relying on the amplitude floor
    to catch them afterwards, because here the evidence is not statistical:
    the window is flat, so a beat placed in it was invented by definition.

    Only gaps are re-run, so the cost is proportional to how broken the file is.
    Returns (peaks, n_added, n_rounds, n_spans).
    """
    peaks = np.unique(np.asarray(peaks, dtype=int))
    n = len(det_sig)
    if len(peaks) < 3 or n <= 0:
        return peaks, 0, 0, 0
    min_seg = int(round(min_seg_s * fs))
    total_added, spans, rounds = 0, 0, 0
    for rounds in range(1, int(max_rounds) + 1):
        rr = np.diff(peaks)
        if not len(rr):
            break
        m = float(np.median(rr))
        if not np.isfinite(m) or m <= 0:
            break
        limit = gap_mult * m
        # Head and tail count: a poisoned first chunk leaves no peaks at all at
        # the start of the file, and that is a gap like any other.
        edges = ([(0, int(peaks[0]))]
                 + [(int(peaks[i]), int(peaks[i + 1]))
                    for i in range(len(peaks) - 1)]
                 + [(int(peaks[-1]), n)])
        added = []
        for a, b in edges:
            if b - a < limit:
                continue
            s = _first_artifact_end(det_sig, a, b, thr, fs)
            if b - s < int(round(0.5 * m)):
                continue                  # artifact fills the gap: nothing to find
            # Give the detector enough signal to initialise its thresholds, but
            # only ACCEPT what falls strictly inside the gap.  Extending forward
            # only is deliberate: extending backward would feed the artifact
            # back in and re-poison the very threshold this restart exists to
            # reset.
            e = min(n, max(b, s + min_seg))
            if e - s < int(3 * fs):
                continue
            # If measurement says the entire searchable stretch is dead, do not
            # call the detector at all.  This is an optimisation, not the
            # safeguard -- the safeguard is the per-candidate test below, which
            # also covers the case where a gap only PARTLY overlaps a span.
            if skip_spans and _span_covers(s, e, skip_spans, fs):
                continue
            spans += 1
            for p in detect_nk(det_sig[s:e], fs, refr_ms):
                g = s + int(p)
                if a < g < b:
                    added.append(g)
        if added and skip_spans:
            arr = np.asarray(added, dtype=np.int64)
            added = list(arr[~in_any_span(arr, skip_spans, fs)])
        if not added:
            break
        before = len(peaks)
        peaks = enforce_refractory(
            det_sig,
            np.unique(np.concatenate([peaks, np.asarray(added, dtype=int)])),
            fs, refr_ms)
        gained = len(peaks) - before
        total_added += max(0, gained)
        if gained <= 0:
            break
    return peaks, total_added, rounds, spans


# ================================================================== morphology

def extract_beats(wide, anchors, fs, half_ms):
    pre = post = int(round(half_ms / 1000.0 * fs))
    segs, keep = [], []
    for i, p in enumerate(anchors):
        s, e = int(p) - pre, int(p) + post
        if s < 0 or e > len(wide):
            continue
        segs.append(wide[s:e] - np.median(wide[s:e]))
        keep.append(i)
    if not segs:
        return np.zeros((0, 2 * pre)), np.array([], dtype=int), pre
    return np.vstack(segs), np.asarray(keep, dtype=int), pre


def cluster_beats(segs, thr=0.85, kmax=8, min_frac=0.01, seed=0):
    """Greedy correlation clustering.  Cluster 0 is dominant; orphans are -1.

    Two invariants that were bugs in an earlier revision:
      1. labels[i] indexes templates, by construction and asserted.  Taking the
         label from a loop counter while appending templates conditionally made
         the two drift apart and silently dropped clusters.
      2. Seeds are chosen by POPULARITY, not amplitude.  Amplitude seeding picks
         the largest artifact in the record first, every time.
    """
    n = len(segs)
    labels = np.full(n, -1, dtype=int)
    if n < 20:
        return labels, []
    X = segs - segs.mean(axis=1, keepdims=True)
    X /= (np.linalg.norm(X, axis=1, keepdims=True) + 1e-12)
    minsz = max(20, int(round(min_frac * n)))
    rng = np.random.default_rng(seed)
    free = np.ones(n, bool)
    found, guard = [], 0
    while len(found) < kmax and guard < 64:
        guard += 1
        idx = np.where(free)[0]
        if len(idx) < minsz:
            break
        cand = idx if len(idx) <= 300 else rng.choice(idx, 300, replace=False)
        pop = (X[cand] @ X[idx].T > thr).sum(axis=1)
        if int(pop.max()) < minsz:
            break
        s = int(cand[int(np.argmax(pop))])
        tmpl = X[s].copy()
        members = free & ((X @ tmpl) > thr)
        for _ in range(3):
            if int(members.sum()) < 3:
                break
            t = X[members].mean(axis=0)
            t /= (np.linalg.norm(t) + 1e-12)
            m2 = free & ((X @ t) > thr)
            if int(m2.sum()) < 3:
                break
            tmpl, members = t, m2
        if int(members.sum()) < minsz:
            free[s] = False
            continue
        found.append((members.copy(), tmpl))
        free &= ~members
    found.sort(key=lambda mt: -int(mt[0].sum()))
    templates = []
    for k, (mask, tmpl) in enumerate(found):
        labels[mask] = k
        templates.append(tmpl)
    assert labels.max(initial=-1) == len(templates) - 1, "label/template desync"
    return labels, templates


def template_quality(wide, anchors, fs, half_ms):
    """Fraction of beats correlating > 0.8 with a template built from the
    above-median-amplitude beats.  This is the lead-selection statistic."""
    pre = post = int(round(half_ms / 1000.0 * fs))
    segs, amps = [], []
    for p in anchors:
        s, e = int(p) - pre, int(p) + post
        if s < 0 or e > len(wide):
            continue
        seg = wide[s:e] - np.median(wide[s:e])
        segs.append(seg); amps.append(abs(float(seg[pre])))
    if len(segs) < 8:
        return float("nan"), float("nan")
    segs, amps = np.vstack(segs), np.asarray(amps)
    tmpl = np.median(segs[amps >= np.median(amps)], axis=0)
    tn = tmpl - tmpl.mean()
    tden = np.sqrt((tn ** 2).sum())
    if tden <= 0:
        return float("nan"), float(np.median(amps))
    sn = segs - segs.mean(axis=1, keepdims=True)
    sden = np.sqrt((sn ** 2).sum(axis=1))
    return (float(np.mean(((sn @ tn) / (sden * tden + 1e-12)) > 0.8)),
            float(np.median(amps)))


# ===================================================== rhythm, rate, integrity

def robust_baseline_rr(rr, tol=0.15, iters=10, min_sel=10):
    """Modal RR, resistant to a heavy load of short/long couplets.

    `view` re-implements this in JavaScript to recompute empty gaps from an
    edited beat list, and is handed tol/iters/min_sel from EMPTY_BASE_* so
    the two cannot drift apart silently.  Change it here, change it there.
    """
    M = float(np.median(rr))
    for _ in range(iters):
        sel = np.abs(rr / M - 1.0) < tol
        if int(sel.sum()) < min_sel:
            break
        M2 = float(np.median(rr[sel]))
        if abs(M2 - M) < 1e-7:
            M = M2
            break
        M = M2
    return M


def classify_rhythm(anchors, fs, short_frac=0.85):
    """Per-beat RR context against a contamination-resistant baseline.

    a = RR_before / baseline, b = RR_after / baseline, s = a + b
      s ~ 1.0   the beat split one interval        -> likely false positive
      s ~ 2.0   compensatory pause                 -> timer NOT disturbed (PVC)
      s ~ 1 + a next event one baseline after it   -> the timer RESET
    """
    n = len(anchors)
    cls = np.zeros(n, dtype=int)
    if n < 25:
        return cls, float("nan"), np.array([])
    rr = np.diff(anchors) / fs
    M = robust_baseline_rr(rr)
    for i in range(1, n - 1):
        a, b = rr[i - 1] / M, rr[i] / M
        if a >= short_frac:
            continue
        s = a + b
        cls[i] = 1 if s < 1.15 else 2 if s < 1.85 else 3 if s <= 2.15 else 4
    return cls, M, rr


CLS_NAME = {0: "normal", 1: "SPLIT", 2: "RESET", 3: "COMPENS", 4: "other"}


def beat_amplitudes(wide, anchors, fs, profile):
    """Per-beat peak-to-peak deflection, over a QRS-width window each.

    Factored out of amplitude_floor so that the floor and the NO_SIGNAL span
    detector share ONE definition of how tall a beat is.  They were about to
    have two, and two definitions of the same quantity drift: the floor would
    reject beats by one scale while the span detector called a stretch silent
    by another, and the disagreement would show up as unexplained beat counts
    rather than as an obvious error.
    """
    if not len(anchors):
        return np.zeros(0)
    half = max(2, int(round(profile.qrs_width_ms / 1000.0 * fs)))
    lo = np.maximum(anchors - half, 0)
    hi = np.minimum(anchors + half + 1, len(wide))
    return np.array([np.ptp(wide[a:b]) if b > a else 0.0
                     for a, b in zip(lo, hi)])


def median_qrs_amp(wide, anchors, fs, profile):
    """The record's own QRS scale A, or nan if it cannot be established.

    Everything downstream is expressed as a RATIO to this, so no threshold in
    this tool carries absolute units or assumes an electrode gain.
    """
    amp = beat_amplitudes(wide, anchors, fs, profile)
    if not len(amp):
        return float("nan")
    med = float(np.median(amp))
    return med if np.isfinite(med) and med > 0 else float("nan")


def windowed_range(wide, fs, win_s=2.0, step_s=0.25):
    """Peak-to-peak of `wide` in a sliding window, sampled every step_s.

    The window must be LONGER than the longest plausible RR interval.  A
    0.5 s window that happens to land in diastole is flat and is not a
    dropout; at 62 bpm the RR is about 1 s, so 2 s is the shortest window
    that a normal pause between beats cannot fool.  The price is that spans
    shorter than the window cannot be resolved, which is acceptable here --
    the span this was built for is 16 s.

    Measured on `wide`, never on the detection signal: `det` has already been
    through clip_artifacts, so saturation has been deliberately flattened out
    of it and it literally cannot show one of the two things being looked for.

    Returns (range_at_each_step, time_of_each_step).
    """
    from scipy.ndimage import maximum_filter1d, minimum_filter1d
    wide = np.asarray(wide, float)
    n = len(wide)
    win_n = max(3, int(round(win_s * fs)))
    step_n = max(1, int(round(step_s * fs)))
    if n < win_n:
        return np.zeros(0), np.zeros(0)
    hi = maximum_filter1d(wide, size=win_n, mode="nearest")
    lo = minimum_filter1d(wide, size=win_n, mode="nearest")
    rng = (hi - lo)[::step_n]
    t = np.arange(len(rng)) * (step_n / float(fs))
    return rng, t


def mask_to_spans(mask, fs):
    """Contiguous True runs of a per-SAMPLE mask, as (start_s, end_s).

    Distinct from spans_from_mask, which works on the coarse window grid that
    windowed_range produces.  A mark from the recording system is known
    exactly, per sample, and rounding it onto a 0.25 s grid would both blur
    its edges and impose a minimum length on something that has none.

    There is deliberately NO minimum length here.  spans_from_mask discards
    short runs because an isolated window over an amplitude threshold is
    noise rather than an event -- an inference about a measurement.  A marker
    is not an inference; the exporter is stating that it has no valid sample.
    One marked sample is one sample that must not be counted.
    """
    m = np.asarray(mask, bool)
    if not m.any():
        return []
    d = np.diff(np.concatenate(([0], m.astype(np.int8), [0])))
    return [(float(s) / fs, float(e) / fs)
            for s, e in zip(np.where(d == 1)[0], np.where(d == -1)[0])]


def fill_missing(cols):
    """Linearly interpolate across NaN.  Returns (filled_copy, nan_mask).

    This is NOT a repair, and the filled values are never counted: analyse()
    turns the same mask into excised spans, so every sample this touches
    leaves both the numerator and the denominator.  It exists because of what
    NaN does to an IIR filter -- filtfilt propagates a single NaN across the
    ENTIRE trace in both directions, so one marked sample 86 s into a
    six-hour recording would silently return six hours of NaN, no beats, and
    a heart rate of zero.  A crash would be far kinder than that, and getting
    neither is the point.

    Linear interpolation rather than zero-fill: a jump to zero is a step
    edge, and a step edge through a 5-40 Hz bandpass rings like a QRS on both
    sides of the gap.  That would manufacture beats immediately OUTSIDE the
    excised span, where they would be counted.  Interpolation puts a straight
    line across the gap, which the detector ignores.  Edge runs clamp to the
    nearest real value, for the same reason.
    """
    a = np.asarray(cols, float)
    bad = np.isnan(a)
    if not bad.any():
        return a, bad
    out = a.copy()
    idx = np.arange(a.shape[0], dtype=float)
    for j in range(a.shape[1]):
        m = bad[:, j]
        if not m.any():
            continue
        good = ~m
        if not good.any():
            # Nothing to interpolate from.  Zero is as good as anything, and
            # the column is excised in full anyway.
            out[:, j] = 0.0
            continue
        out[m, j] = np.interp(idx[m], idx[good], a[good, j])
    return out, bad


def spans_from_mask(mask, t, step_s, min_s):
    """Contiguous true runs of `mask` as (start_s, end_s), at least min_s long.

    min_s exists because an isolated window over threshold is noise, not an
    event.  Runs shorter than it are discarded rather than reported.
    """
    out = []
    m = np.asarray(mask, bool)
    if not len(m) or not len(t):
        return out
    d = np.diff(np.concatenate(([0], m.astype(np.int8), [0])))
    for s, e in zip(np.where(d == 1)[0], np.where(d == -1)[0]):
        a = float(t[min(s, len(t) - 1)])
        b = float(t[min(e - 1, len(t) - 1)]) + step_s
        if b - a >= min_s:
            out.append((a, b))
    return out


def merge_spans(spans):
    """Union of possibly overlapping spans, sorted and disjoint.

    total_span_s assumes disjointness, and spans_from_mask guarantees it
    WITHIN one list.  It is not true ACROSS lists: a stretch the exporter
    marked missing is very likely also flat enough for the no-signal detector
    to find, so the two lists overlap almost by definition.  Adding their
    durations would subtract that overlap from the denominator twice, which
    inflates the reported rate -- silently, and in the one column everyone
    reads.
    """
    out = []
    for a, b in sorted((float(a), float(b)) for a, b in (spans or [])):
        if b <= a:
            continue
        if out and a <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return out


def total_span_s(spans):
    """Seconds covered by a span list.  Assumes the spans are disjoint, which
    spans_from_mask guarantees by construction and merge_spans restores after
    two lists are combined."""
    return float(sum(b - a for a, b in (spans or [])))


def in_any_span(samples, spans_s, fs):
    """Boolean mask: which samples fall inside any (start_s, end_s) span.

    One definition, shared by the refill (which must not place a beat inside a
    span) and the anchor filter (which must not keep one).  Two call sites
    reimplementing the same interval test would eventually disagree about a
    boundary, and the symptom would be a beat count that does not reconcile
    with the excised duration -- which is precisely the failure this whole
    mechanism is supposed to make impossible.

    Half-open [start, end) so that adjacent spans cannot both claim a sample.
    """
    s = np.asarray(samples, dtype=np.int64)
    m = np.zeros(len(s), dtype=bool)
    for a, b in (spans_s or []):
        m |= (s >= int(round(a * fs))) & (s < int(round(b * fs)))
    return m


def _span_covers(lo_n, hi_n, spans_s, fs):
    """Is the whole sample range [lo_n, hi_n) inside a SINGLE span?

    Single, not the union.  Testing against the union would need interval
    merging, and the only caller uses this to skip work it is entitled to do
    anyway -- a false negative costs one wasted detector call, whose output is
    then filtered by in_any_span regardless.  A false POSITIVE would skip a
    live region, so the conservative direction is the cheap one here.
    """
    for a, b in (spans_s or []):
        if lo_n >= int(round(a * fs)) and hi_n <= int(round(b * fs)):
            return True
    return False


def rr_bridges_span(anchors, fs, spans_s):
    """Boolean mask over RR intervals: which ones cross an excised span.

    Without this, excision makes the gap statistics WORSE rather than better.
    Removing the beats inside a 16 s hole leaves the two surviving beats on
    either side separated by 16 s, so maxGap jumps to ~19x and LONG_GAP fires
    on a file whose dead time has just been accounted for and removed.  The
    flag would be describing time that is no longer in the denominator.

    An interval that bridges an excised span is not evidence of a missed beat;
    it is the span, seen from the beat list.  So it is dropped from the
    interval statistics, and what remains describes gaps in ANALYSABLE time,
    which is the only kind the reported rate is computed over.

    Overlap, not containment: an interval that merely clips the edge of a span
    still carries the span's duration and would still distort the maximum.
    """
    n = max(0, len(anchors) - 1)
    if n == 0 or not spans_s:
        return np.zeros(n, dtype=bool)
    a0 = np.asarray(anchors[:-1], dtype=float) / float(fs)
    a1 = np.asarray(anchors[1:], dtype=float) / float(fs)
    m = np.zeros(n, dtype=bool)
    for s, e in spans_s:
        m |= (a0 < e) & (a1 > s)
    return m


# ---------------------------------------------------------- empty gaps
#
# The DEFAULT since this build: a stretch with no beat in it, longer than the
# refill's own threshold (--refill-gap-mult, 3x baseline RR by default), that
# neither the no-signal detector nor the exporter already removed, is excised
# as EMPTY -- its time leaves the rate's denominator.  `--keep-empty` restores
# the old reading, in which such a stretch is a real pause and its seconds
# stay in.
#
# Why the refill's multiplier.  The refill has ALREADY re-detected inside every
# gap this long, from a clean restart just after the artifact.  A gap that
# survives that is one where the detector, handed its best chance, found
# nothing; the choice left is only whether its time counts.  Using the same
# multiplier means "a gap the refill gave up on" and "a gap that is excised"
# are essentially one set.  (Not exactly: the refill measures in MEDIAN RR
# of the raw detections, this in baseline RR of the final beats, and on a
# couplet-loaded record the median sits below the baseline -- so this
# threshold is, if anything, slightly LONGER, the conservative side.)
#
# Baseline RR, not the median, is the unit, because under couplets the median
# drifts with the short-interval load; robust_baseline_rr is what the rhythm
# classes and the modal rate already use.  Its constants are handed to `view`
# (EMPTY_BASE_*) so the page recomputes the SAME spans from an edited list.
EMPTY_BASE_TOL = 0.15
EMPTY_BASE_ITERS = 10
EMPTY_BASE_MIN_SEL = 10
# Fewer beats than this and there is no baseline worth the name; the same
# floor as TOO_FEW_BEATS in rate_and_integrity.
EMPTY_MIN_BEATS = 25


def _in_spans_mask(t, spans):
    """Boolean mask: which of the sorted-or-not times `t` lie in [a, b] of the
    merged, sorted `spans`.  searchsorted, so an 18-hour list costs nothing."""
    t = np.asarray(t, dtype=float)
    if not len(spans) or not len(t):
        return np.zeros(len(t), dtype=bool)
    st = np.array([a for a, _ in spans], dtype=float)
    en = np.array([b for _, b in spans], dtype=float)
    i = np.searchsorted(st, t, side="right") - 1
    return (i >= 0) & (t <= en[np.clip(i, 0, None)])


def compare_empty_spans(auto_s, man_s, fn_idx, fs, win_s, base_spans, gap_mult):
    """Empty gaps for `compare`, from the UNION of (a) and (b).  No printing.

    A stretch is empty only if NEITHER list has a beat in it.  If (b) has
    beats inside a gap of (a), that gap is (a)'s miss -- FNs to be scored --
    and excising it would take those FNs' time out of the denominator while
    leaving (b)'s beats in its numerator: (b) would read fast and (a)'s
    misses would be hidden.  So: (a)'s beats plus (b)'s UNMATCHED beats (a
    matched pair is one heartbeat; counting it twice would put near-zero
    intervals into the baseline), on (a)'s clock, cut to the window, minus
    anything inside no-signal/marked time -- exactly what analyse() hands
    empty_gap_spans -- and then the same rule and constants.

    Returns (spans, baseline_rr_s, n_union).  By construction no beat of
    either list lies strictly inside a span: every (a) beat and every
    unmatched (b) beat is in the union, and a matched (b) beat sits within
    the matching tolerance of an (a) beat, far less than the M/2 margin.
    compare verifies that rather than trusting it.
    """
    auto_s = np.asarray(auto_s, dtype=float)
    man_s = np.asarray(man_s, dtype=float)
    fn_idx = np.asarray(sorted(fn_idx), dtype=int)
    extra = man_s[fn_idx] if len(fn_idx) else np.zeros(0)
    uni = np.sort(np.concatenate([auto_s, extra]))
    uni = uni[(uni >= 0.0) & (uni <= float(win_s))]
    base = merge_spans(base_spans or [])
    uni = uni[~_in_spans_mask(uni, base)]
    samp = np.unique(np.round(uni * float(fs)).astype(np.int64))
    spans, M = empty_gap_spans(samp, fs, float(win_s), base, gap_mult)
    return spans, M, int(len(samp))


def subtract_spans(lo, hi, spans):
    """[lo, hi) minus the (merged, sorted) `spans`, as a list of pieces."""
    out, cur = [], float(lo)
    for a, b in spans:
        if b <= cur:
            continue
        if a >= hi:
            break
        if a > cur:
            out.append((cur, min(a, hi)))
        cur = max(cur, b)
        if cur >= hi:
            break
    if cur < hi:
        out.append((cur, float(hi)))
    return [(a, b) for a, b in out if b > a]


def empty_gap_spans(anchors, fs, dur, excluded, gap_mult):
    """Beatless stretches to excise as EMPTY: (spans_s, baseline_rr_s).

    A gap counts when its LIVE length -- the interval minus whatever part of
    it is already excised as no-signal or marked -- exceeds gap_mult * M,
    with M the baseline RR.  Measuring the live length is what keeps a gap
    that merely bridges a no-signal span from being excised twice.

    What is excised is the gap's INTERIOR, (t_i + M/2, t_{i+1} - M/2): ONE
    normal interval, split half at each end, stays in the denominator.  That
    is the interval the two bounding beats actually account for -- each beat
    "owns" half an RR either side of it -- so cutting from beat to beat would
    remove time the numerator has a beat for and read HIGH by one interval
    per gap, while cutting nothing reads LOW by the whole pause.  With the
    interior rule a gap of exactly k baseline intervals leaves exactly one
    counted, which is what a detector that simply stopped hearing the heart
    for (k-1) beats should leave.

    The head (0 to first beat) and tail (last beat to `dur`) follow the same
    rule with one bounding beat, so they keep M/2 -- the half interval that
    beat owns.

    Pieces already covered by `excluded` are subtracted, so the result is
    DISJOINT from it by construction and the categories never double count:
    empty_s + (no-signal U marked) is exactly the excised total.

    Returns ([], M) when there are too few beats for a baseline.  No beat
    ever lies inside an empty span -- the spans are the insides of gaps
    between consecutive beats -- so the numerator needs no change.
    """
    a = np.sort(np.asarray(anchors, dtype=np.int64))
    if len(a) < EMPTY_MIN_BEATS or dur <= 0:
        return [], float("nan")
    rr = np.diff(a).astype(float) / float(fs)
    if not len(rr):
        return [], float("nan")
    M = robust_baseline_rr(rr, tol=EMPTY_BASE_TOL, iters=EMPTY_BASE_ITERS,
                           min_sel=EMPTY_BASE_MIN_SEL)
    if not np.isfinite(M) or M <= 0:
        return [], M
    limit = float(gap_mult) * M
    ex = merge_spans(excluded)
    t = a.astype(float) / float(fs)
    edges = ([(0.0, float(t[0]), "head")]
             + [(float(t[i]), float(t[i + 1]), "mid") for i in range(len(t) - 1)]
             + [(float(t[-1]), float(dur), "tail")])
    out = []
    for g0, g1, kind in edges:
        if g1 - g0 <= limit:
            continue
        live = (g1 - g0) - sum(_overlap(g0, g1, s, e) for s, e in ex)
        if live <= limit:
            continue
        lo = g0 if kind == "head" else g0 + 0.5 * M
        hi = g1 if kind == "tail" else g1 - 0.5 * M
        if hi > lo:
            out.extend(subtract_spans(lo, hi, ex))
    return merge_spans(out), M


# ---------------------------------------------------------- wall-clock bins

# Naive datetimes are converted against a fixed epoch rather than through
# datetime.timestamp(), which would apply the local timezone.  These recordings
# run overnight, and a DST boundary inside one would either duplicate or delete
# an hour of trend.  Everything here is therefore one consistent clock with no
# zone attached: the bin labels and the bin edges come from the same arithmetic,
# so they cannot disagree even if the true zone is unknown.
_EPOCH = datetime.datetime(1970, 1, 1)


def to_epoch(dt):
    return (dt - _EPOCH).total_seconds()


def from_epoch(ep):
    return _EPOCH + datetime.timedelta(seconds=float(ep))


def _overlap(a0, a1, b0, b1):
    return max(0.0, min(a1, b1) - max(b0, a0))


def bin_record(acc, start_epoch, dur, beats_epoch, excluded_epoch, bin_s):
    """Fold one file into the shared bin table, keyed by absolute time.

    Bins are aligned to wall-clock multiples of bin_s, NOT to the start of each
    file.  Two reasons, and the second is the one that bites.  A physiologist
    asks what the rate was at 03:00-03:05, not what it was 187 minutes into
    file 4.  And file-relative bins only line up across files while every file
    is exactly the same length -- part019 is 38.5 minutes, so the moment it
    joins the set every later bin would be offset from every earlier one and
    the trend would silently smear.

    Each bin accumulates three things, and the third is what makes the second
    honest:
      beats  detections falling in the bin, AFTER excision
      live   seconds of ANALYSABLE recording in the bin
      span   seconds of recording in the bin, dead or not
    bpm is beats/live, so the per-bin rate uses exactly the same estimator and
    exactly the same denominator discipline as the whole-file rate.  live/span
    is the coverage, which is how a bin that is mostly dropout announces itself
    instead of just reading low.
    """
    if dur <= 0:
        return
    i0 = int(np.floor(start_epoch / bin_s))
    i1 = int(np.floor((start_epoch + dur - 1e-9) / bin_s))
    for i in range(i0, i1 + 1):
        b0, b1 = i * bin_s, (i + 1) * bin_s
        span = _overlap(start_epoch, start_epoch + dur, b0, b1)
        if span <= 0:
            continue
        dead = sum(_overlap(s, e, b0, b1) for s, e in (excluded_epoch or []))
        rec = acc.setdefault(i, dict(beats=0, live=0.0, span=0.0))
        rec["span"] += span
        rec["live"] += max(0.0, span - dead)
    if len(beats_epoch):
        idx = np.floor(np.asarray(beats_epoch, dtype=float) / bin_s).astype(np.int64)
        for i, c in zip(*np.unique(idx, return_counts=True)):
            rec = acc.setdefault(int(i), dict(beats=0, live=0.0, span=0.0))
            rec["beats"] += int(c)


def bins_to_rows(acc, bin_s, min_cov):
    """Sorted bin table with a bpm and a verdict per bin.

    Bins between the first and last are FILLED IN as empty rather than omitted.
    A missing hour -- part009 is held out of the fit set, so there is one -- must
    appear as a hole in the trend.  Omitting it would close the gap and draw a
    continuous line across an hour that was never measured, which is the single
    most misleading thing a trend plot can do.
    """
    if not acc:
        return []
    rows = []
    for i in range(min(acc), max(acc) + 1):
        d = acc.get(i)
        live = d["live"] if d else 0.0
        span = d["span"] if d else 0.0
        beats = d["beats"] if d else 0
        cov = live / bin_s if bin_s > 0 else 0.0
        bpm = (60.0 * beats / live) if live > 0 else float("nan")
        rows.append(dict(i=i, t0=i * bin_s, beats=beats, live=live, span=span,
                         cov=cov, bpm=bpm,
                         ok=bool(live > 0 and cov >= min_cov),
                         empty=bool(span <= 0)))
    return rows


def ascii_trend(rows, bin_s, height=15, width=108):
    """Time series of bin bpm, panelled, with ONE y-scale across all panels.

    The shared scale is not cosmetic.  Per-panel autoscaling was how a real bug
    survived here before: a window holding fourteen normal beats rendered as a
    flat line because a neighbouring artifact owned its scale.  Panels that do
    not share a scale cannot be compared by eye, and comparing them by eye is
    the entire purpose of a trend.

    Glyphs distinguish the three states a bin can be in, because they mean
    different things and merging them would hide the difference:
      *  measured, coverage at or above the floor
      ?  measured, but over less than the required coverage -- read with care
      (blank column, 'x' on the axis)  no recording at all in this bin
    """
    vals = [r["bpm"] for r in rows if r["ok"] and np.isfinite(r["bpm"])]
    if not vals:
        return ["  no bin has enough coverage to plot"]
    lo, hi = min(vals), max(vals)
    if hi - lo < 1e-6:
        lo, hi = lo - 1.0, hi + 1.0
    pad = 0.08 * (hi - lo)
    lo, hi = lo - pad, hi + pad
    out = []
    for p0 in range(0, len(rows), width):
        chunk = rows[p0:p0 + width]
        grid = [[" "] * len(chunk) for _ in range(height)]
        axis = ["-"] * len(chunk)
        for c, r in enumerate(chunk):
            if r["empty"]:
                axis[c] = "x"
                continue
            if not np.isfinite(r["bpm"]):
                axis[c] = "x"
                continue
            frac = (r["bpm"] - lo) / (hi - lo)
            row = int(round((1.0 - frac) * (height - 1)))
            row = max(0, min(height - 1, row))
            grid[row][c] = "*" if r["ok"] else "?"
        for k in range(height):
            y = hi - (hi - lo) * k / float(height - 1)
            out.append("  %7.1f |%s" % (y, "".join(grid[k])))
        out.append("          +%s" % "".join(axis))
        t_a = from_epoch(chunk[0]["t0"])
        t_b = from_epoch(chunk[-1]["t0"] + bin_s)
        lab_a = t_a.strftime("%m-%d %H:%M")
        lab_b = t_b.strftime("%m-%d %H:%M")
        mid = max(0, len(chunk) - len(lab_a) - len(lab_b))
        out.append("           %s%s%s" % (lab_a, " " * mid, lab_b))
        out.append("")
    return out


def amplitude_floor(wide, anchors, fs, profile):
    """Drop detections whose deflection is too small to be a QRS.

    Pan-Tompkins thresholds adapt to the local signal, so in a segment with no
    signal at all the threshold collapses and the detector will happily emit
    beats from numerical residue.  neurokit 0.2.12 does exactly this: on a
    synthetic record whose 80-140 s span is set to literal 0.0, it returned 179
    beats where 145 exist -- 34 beats invented out of zeros.  The 145 is ground
    truth from the generator, not another library's output; no claim is made
    here about which neurokit versions are affected, only that at least one is
    and the tool cannot control which one is installed.  So it defends itself.

    The cut is relative to the record's own median QRS, so it carries no
    absolute units and no assumption about electrode gain.  Returns the
    surviving anchors and the fraction removed.
    """
    if not len(anchors):
        return anchors, 0.0
    amp = beat_amplitudes(wide, anchors, fs, profile)
    med = float(np.median(amp))
    if not np.isfinite(med) or med <= 0:
        return anchors, 0.0
    ok = amp >= profile.amp_floor_frac * med
    return anchors[ok], 1.0 - float(np.mean(ok))


def rate_and_integrity(anchors, fs, dur, profile, excluded=None):
    """Report the rate, and refuse to trust it when the record says not to.

    beats/duration is the only estimator that is not biased by couplets, but it
    is the truth only if detection is COMPLETE, and it cannot tell you that it
    is.  Two independent completeness checks:

      gaps      intervals beyond 1.8x baseline are where a missed beat hides.
      coherence if the measured rate sits BELOW the modal rate, the record is
                self-contradictory: short beats are the only thing that can
                push the mean rate above the mode, so a rate below the mode
                means beats are missing rather than early.  This is what
                part010 looks like (rate 8% under modal, 26 gaps, maxGap 66x)
                and it is a reliable dropout detector.

    The coherence test deliberately does NOT also require the short population
    to be small.  It used to, and that was backwards: a large short population
    pushes the mean rate UP, so observing a below-modal rate anyway means the
    missing-beat deficit had to be even larger to overcome it.  Requiring
    short_pct < 5% therefore silenced the flag exactly when the evidence was
    strongest.  It was also redundant -- a couplet-loaded record has a rate
    ABOVE its mode, so it never reaches this test.  Found by selftest [6] on
    neurokit 0.2.12, whose phantom detections inside a dropout raised the short
    population past the conjunct and hid a 60 s hole.

    `dur` is ANALYSABLE duration and `excluded` are the spans already removed
    from it.  The two arguments are a matched pair and must be derived from one
    another: `dur` must already have had `excluded` subtracted, and `anchors`
    must already have had the beats inside `excluded` removed.  Getting that
    wrong does not raise -- it silently returns a rate that is wrong by the
    ratio of the two, which is exactly the class of error this function exists
    to prevent.  selftest [11] asserts the invariant on a record whose correct
    rate is known by construction.  Pass excluded=None for the unexcised case,
    which is then identical to the original behaviour.
    """
    out = dict(n=len(anchors), bpm=float("nan"), modal_bpm=float("nan"),
               modal_rr_ms=float("nan"), short_pct=float("nan"),
               max_gap=float("nan"), max_gap_at=float("nan"), n_gaps=0,
               gap_time_pct=float("nan"), n_bridging=0, trustworthy=False,
               flags=[])
    if len(anchors) < 25:
        out["flags"].append("TOO_FEW_BEATS")
        return out
    cls, M, rr = classify_rhythm(anchors, fs)
    out["bpm"] = 60.0 * len(anchors) / dur
    out["modal_rr_ms"] = M * 1000.0
    out["modal_bpm"] = 60.0 / M
    # Intervals that merely bridge an excised span describe time that is no
    # longer in the denominator, so they are not evidence about the part of the
    # record being reported on.  classify_rhythm above is left to see all of
    # them on purpose: its baseline is robust to a handful of outliers, and
    # giving it a different beat list than the clustering upstream received
    # would be a second, quieter inconsistency.
    live = ~rr_bridges_span(anchors, fs, excluded)
    if not live.any():
        live = np.ones(len(rr), dtype=bool)
    rr_live = rr[live]
    idx_live = np.where(live)[0]
    short = rr_live < 0.85 * M
    out["short_pct"] = 100.0 * float(np.mean(short))
    gaps = rr_live > 1.8 * M
    out["max_gap"] = float(np.max(rr_live)) / M
    # Where the worst gap starts, in seconds.  A flagged file is only useful if
    # you can go and look at the place that caused the flag.  The index has to
    # be mapped back through idx_live: argmax over the filtered array indexes
    # the filtered array, and using it on `anchors` directly would point at the
    # wrong beat whenever anything was excluded.
    out["max_gap_at"] = float(anchors[idx_live[int(np.argmax(rr_live))]]) / fs
    out["n_gaps"] = int(gaps.sum())
    out["gap_time_pct"] = (100.0 * float(np.sum(rr_live[gaps])) / dur
                           if gaps.any() else 0.0)
    out["n_bridging"] = int(np.sum(~live))

    lo, hi = profile.hr_plausible
    if not (lo <= out["bpm"] <= hi):
        out["flags"].append("RATE_IMPLAUSIBLE")
    # the coherence check described above
    if out["bpm"] < out["modal_bpm"] * 0.98:
        out["flags"].append("DROPOUT_SUSPECTED")
    if out["gap_time_pct"] > 2.0:
        out["flags"].append("GAP_TIME_>2%")
    if out["max_gap"] > 10.0:
        out["flags"].append("LONG_GAP")
    out["trustworthy"] = not out["flags"]
    return out


def qc_windows(labels, anchors, keep, fs, nsamp, window_s, qc_min):
    """PERMISSIVE gating: a beat counts if it matches ANY tight cluster, and a
    window is accepted if at least qc_min of its beats do.

    Permissive rather than strict because under AV dissociation a single
    morphology legitimately fragments into several clusters.  Strict gating
    (dominant cluster only) threw away a third to two-thirds of good data;
    permissive keeps a median of 90% across the fleet.
    """
    wn = int(round(window_s * fs))
    nwin = max(1, int(nsamp // wn))
    keep_pos = anchors[keep] if len(keep) else np.array([], dtype=int)
    ok = labels >= 0
    accepted, rows = [], []
    for k in range(nwin):
        s, e = k * wn, (k + 1) * wn
        m = (keep_pos >= s) & (keep_pos < e)
        nb = int(m.sum())
        if nb < 8:
            rows.append((k, nb, float("nan"), False)); continue
        rrw = np.diff(keep_pos[m]) / fs
        if len(rrw) < 5:
            rows.append((k, nb, float("nan"), False)); continue
        frac = float(np.mean(ok[m]))
        good = frac >= qc_min
        rows.append((k, nb, frac, good))
        if good:
            accepted.append(60.0 / float(np.mean(rrw)))
    pct = 100.0 * sum(1 for r in rows if r[3]) / nwin if nwin else float("nan")
    gated = float(np.mean(accepted)) if accepted else float("nan")
    gated_sd = float(np.std(accepted)) if accepted else float("nan")
    return dict(n_windows=nwin, accept_pct=pct, gated_bpm=gated,
                gated_sd=gated_sd, rows=rows)


# =================================================================== analysis

class Result:
    pass


def analyse(path, args, profile, loaded=None, core=None):
    """Analyse one file -- or, with `loaded` and `core`, one SEGMENT of one.

    `loaded` is load_signals()'s (cols, fs, labels, duration_s) when the
    caller already has the samples.  `core` = (a, b) sample indices into
    those cols: the stretch to report.  Everything outside it is lead-in and
    lead-out -- detection runs over it so the filters and the detector's
    thresholds are settled at the segment edges, and then every beat, span
    and duration is cut back to [a, b) before anything is counted.  A beat
    belongs to exactly one segment (half-open intervals), so the segments
    of a record add up to the record with nothing lost or counted twice.
    """
    if loaded is not None:
        cols, fs, ch_names, dur = loaded
    else:
        cols, fs, ch_names, dur = load_signals(path, args.minutes)
    grid0 = int(core[0]) if core is not None else 0
    if profile.fs_expected and abs(fs - profile.fs_expected) > 1.0:
        print("  NOTE: %s is %.1f Hz but the %s profile expects %.0f Hz."
              % (os.path.basename(path), fs, profile.name, profile.fs_expected),
              file=sys.stderr)

    # Samples the recording system declined to give a number for.  This must
    # happen BEFORE anything filters, correlates or detects: filtfilt spreads a
    # single NaN over the entire record in both directions, so leaving one in
    # would turn a six-hour file into six hours of nothing without raising.
    #
    # The mask is kept, not discarded.  It becomes excised spans further down,
    # on exactly the footing as a measured no-signal span -- with the
    # difference that this one is not inferred, and so is never subject to a
    # minimum length or a threshold.
    cols, missing = fill_missing(cols)
    miss_frac = missing.mean(axis=0) if missing.size else np.zeros(cols.shape[1])

    band = args.band if args.band else profile.band
    refr = args.refractory if args.refractory else profile.refractory_ms
    clip_k = getattr(args, "clip_k", DEFAULTS["clip_k"])
    chunk_s = getattr(args, "chunk", DEFAULTS["chunk_s"])

    # ---- lead selection on the WHOLE record, by tmplQ (never by SQI)
    lead_q = {}
    if args.lead is not None and args.lead >= 0:
        chosen = min(args.lead, cols.shape[1] - 1)
    else:
        for j in range(cols.shape[1]):
            w = bp(cols[:, j], fs, 0.7, min(240.0, 0.45 * fs))
            d, _ = clip_artifacts(bp(cols[:, j], fs, band[0], band[1]), clip_k)
            pk = detect_chunked(d, fs, chunk_s, refr,
                                DEFAULTS["lead_in_s"], grid0=grid0)
            a = np.unique(snap_to_extremum(w, pk, fs, profile.snap_ms))
            a, _ = amplitude_floor(w, a, fs, profile)
            q, _ = (template_quality(w, a, fs, profile.beat_half_ms)
                    if len(a) >= 50 else (float("nan"), 0.0))
            q = q if np.isfinite(q) else -1.0
            # A lead that is largely interpolated cannot be scored on its
            # morphology -- the template would be fitted partly to a straight
            # line we drew ourselves.  Penalising by the marked fraction keeps
            # the comparison between leads honest without hard-excluding a
            # lead that is merely slightly marked, and P21's export is exactly
            # this case: the mark is per-channel, so a clean lead exists.
            lead_q[j] = q - float(miss_frac[j])
        chosen = max(lead_q, key=lambda k: lead_q[k])

    x = cols[:, chosen]
    wide = bp(x, fs, 0.7, min(240.0, 0.45 * fs))
    det_raw = bp(x, fs, band[0], band[1])
    det, clip_frac = clip_artifacts(det_raw, clip_k)
    raw_peaks = detect_chunked(det, fs, chunk_s, refr,
                               DEFAULTS["lead_in_s"], grid0=grid0)

    # ---- what did the recording system itself mark as missing?
    #
    # Kept in its own list rather than folded into nosig_spans, even though
    # both end up excised the same way, because they are different KINDS of
    # claim and the report must not blur them.  nosig_s is this tool's
    # inference from an amplitude ratio, and could be wrong.  mark_s is the
    # exporter stating it had no sample -- not an inference at all.  A user
    # deciding whether to trust a night of heart rates needs to see which of
    # the two removed the time.
    #
    # Taken from the CHOSEN lead only.  The marks are per-channel in P21's
    # export, and excising lead 2's marked stretch from lead 1's rate would
    # discard good data for no reason.
    mark_spans = mask_to_spans(missing[:, chosen], fs) if missing.size else []
    mark_s = total_span_s(mark_spans)

    # ---- where is there no signal at all?
    #
    # Measured here, between the first detection pass and the refill, because
    # both neighbours need it: the refill must not reach into a dead span, and
    # everything downstream needs the beats and the duration removed together.
    #
    # It needs a QRS scale, which needs beats, so the first pass supplies them.
    # That pass is incomplete by construction -- recovering what it missed is
    # what the refill is for -- but the scale is a MEDIAN over thousands of
    # beats and the threshold sits 3x clear of the nearest measured signal, so
    # neither the missing beats nor the phantoms move it anywhere near the cut.
    # The alternative, measuring after the refill, cannot be done: it is the
    # refill that has to be told where not to go.
    #
    # Measured on `wide`, never on `det`: det has been through clip_artifacts,
    # so saturation has been deliberately flattened out of it and it cannot
    # show one of the two things being looked for.
    nosig_spans, sat_spans = [], []
    amp_a = float("nan")
    if getattr(args, "nosig", True):
        probe = np.unique(snap_to_extremum(wide, raw_peaks, fs, profile.snap_ms))
        probe, _ = amplitude_floor(wide, probe, fs, profile)
        amp_a = median_qrs_amp(wide, probe, fs, profile)
        if np.isfinite(amp_a):
            _rng, _t = windowed_range(wide, fs, DEFAULTS["nosig_win_s"],
                                      DEFAULTS["nosig_step_s"])
            if len(_rng):
                _ratio = _rng / amp_a
                nosig_spans = spans_from_mask(
                    _ratio < profile.no_signal_frac, _t,
                    DEFAULTS["nosig_step_s"], DEFAULTS["nosig_min_s"])
                sat_spans = spans_from_mask(
                    _ratio > profile.saturated_frac, _t,
                    DEFAULTS["nosig_step_s"], DEFAULTS["nosig_min_s"])
    nosig_s = total_span_s(nosig_spans)
    sat_s = total_span_s(sat_spans)

    # From here on the two are excised together.  Merging AFTER measuring each
    # keeps the reported numbers separable while giving the refill, the beat
    # drop and the denominator one list to respect -- three places that must
    # agree, and would not if each merged for itself.
    #
    # Marked time is excised unconditionally, including when --no-nosig is
    # given.  --no-nosig switches off an inference this tool makes; it is not
    # a licence to count samples the exporter said do not exist.
    excise_spans = merge_spans(nosig_spans + mark_spans)

    # Recover beats the SPKI ratchet suppressed.  This runs BEFORE the snap and
    # the amplitude floor so that refilled beats face exactly the same scrutiny
    # as every other beat -- a recovered beat that cannot clear the QRS floor
    # must not survive merely because it was recovered.
    n_pre_refill = len(raw_peaks)
    refill_rounds = refill_spans = 0
    refill_added = 0
    if getattr(args, "refill", True):
        raw_peaks, refill_added, refill_rounds, refill_spans = refill_gaps(
            det, raw_peaks, fs, refr, clip_level(det_raw, clip_k),
            gap_mult=getattr(args, "refill_gap_mult", 3.0),
            max_rounds=getattr(args, "refill_rounds", 3),
            skip_spans=excise_spans)
    anchors = np.unique(snap_to_extremum(wide, raw_peaks, fs, profile.snap_ms))
    # Reject anything too small to be a QRS before it reaches any statistic.
    # This must happen here, not at reporting time: a phantom beat corrupts the
    # rate, the modal RR, the rhythm classes and the QC windows alike.
    n_pre_floor = len(anchors)
    anchors_pre_floor = anchors
    anchors, floor_removed = amplitude_floor(wide, anchors, fs, profile)
    # Snapshot BEFORE the excision drop below.  Differencing against the final
    # `anchors` would call every excision-dropped beat a floor rejection, which
    # is the same conflation this block exists to undo.
    anchors_post_floor = anchors

    # ---- a SEGMENT: cut everything back to the core, here and only here.
    #
    # Detection, the refill, the snap and the amplitude floor above all ran
    # over lead-in + core + lead-out, so a beat at the segment edge was found
    # with warm thresholds and settled filters.  From here on only the core
    # exists: beats outside it are dropped (they belong to the neighbouring
    # segment, which finds them itself), the no-signal / saturated spans are
    # clipped to it, the marked spans are re-measured on it, and the duration
    # IS the core.  So the empty gaps, the rate, the QC windows and every flag
    # below describe this segment and nothing else, exactly as for a file.
    if core is not None:
        _a0, _a1 = int(core[0]), int(min(core[1], len(wide)))

        def _in_core(p):
            p = np.asarray(p)
            return p[(p >= _a0) & (p < _a1)] - _a0

        anchors = _in_core(anchors)
        anchors_pre_floor = _in_core(anchors_pre_floor)
        anchors_post_floor = anchors
        raw_peaks = _in_core(raw_peaks)
        n_pre_floor = len(anchors_pre_floor)
        floor_removed = ((n_pre_floor - len(anchors)) / float(n_pre_floor)
                         if n_pre_floor else 0.0)
        _t0c, _t1c = _a0 / float(fs), _a1 / float(fs)

        def _clip_sp(sp):
            return [(max(a, _t0c) - _t0c, min(b, _t1c) - _t0c)
                    for a, b in sp if b > _t0c and a < _t1c]

        nosig_spans, sat_spans = _clip_sp(nosig_spans), _clip_sp(sat_spans)
        nosig_s, sat_s = total_span_s(nosig_spans), total_span_s(sat_spans)
        wide, det, det_raw = wide[_a0:_a1], det[_a0:_a1], det_raw[_a0:_a1]
        if missing.size:
            missing = missing[_a0:_a1]
            miss_frac = (missing.mean(axis=0) if missing.size
                         else np.zeros(cols.shape[1]))
            mark_spans = mask_to_spans(missing[:, chosen], fs) if missing.size else []
        else:
            mark_spans = []
        mark_s = total_span_s(mark_spans)
        excise_spans = merge_spans(nosig_spans + mark_spans)
        dur = (_a1 - _a0) / float(fs)

    # Drop beats inside an excised span.  This is the numerator half of the
    # excision; `analysable_s` below is the denominator half, and the two MUST
    # move together.  Removing the duration alone inflates the rate; removing
    # the beats alone deflates it.  Neither failure raises anything -- the
    # report simply carries a wrong number in the column everyone reads -- so
    # selftest [11] checks the pair against a record whose rate is known.
    #
    # It runs after the floor rather than before so that the floor still sees
    # the record's full amplitude distribution.  Order is immaterial to the
    # result (the two filters are independent), but not to the diagnostics:
    # floor% is a statement about the detector's behaviour, and pre-filtering
    # its input by location would quietly change what that number means.
    nosig_dropped = 0
    if excise_spans and len(anchors):
        _drop = in_any_span(anchors, excise_spans, fs)
        nosig_dropped = int(_drop.sum())
        anchors = anchors[~_drop]

    # ---- floor% must describe the DETECTOR, not our own interpolation.
    #
    # The cut above is still taken over the whole record, so the median QRS it
    # measures against is the record's own and unaffected by location.  But the
    # number REPORTED has to answer a narrower question -- "was neurokit
    # emitting sub-QRS detections on signal we are actually using?" -- and
    # inside an excised span it cannot.  fill_missing bridges marked samples
    # with a straight line, so every detection landing there is sub-QRS BY
    # CONSTRUCTION: it is our interpolation being measured, not the detector.
    #
    # Found on P10's native .PnmWav the moment BadDataMark excision was wired
    # in: floor% jumped 0.67% -> 3.15% and raised AMP_FLOOR_3.15% on a file
    # whose analysable signal had not changed at all.  Those detections are
    # discarded twice over -- once by the floor, once by the excision -- so
    # counting them in the flag reports the bad interval a second time under a
    # name that points at the detector.  Both figures are kept: the restricted
    # one drives the flag, the raw one stays visible in the integrity dict.
    floor_removed_all = floor_removed
    floor_excised = 0
    if excise_spans and n_pre_floor:
        _pre_out = anchors_pre_floor[
            ~in_any_span(anchors_pre_floor, excise_spans, fs)]
        _rejected = anchors_pre_floor[
            ~np.isin(anchors_pre_floor, anchors_post_floor)]
        _rej_out = (_rejected[~in_any_span(_rejected, excise_spans, fs)]
                    if len(_rejected) else _rejected)
        floor_excised = len(_rejected) - len(_rej_out)
        floor_removed = (len(_rej_out) / float(len(_pre_out))
                         if len(_pre_out) else 0.0)

    # What is left to measure.  The span boundaries come from WINDOW CENTRES,
    # so a span understates the true hole by up to one window (2 s) at each
    # end.  That is the safe direction: up to 4 s of dead time stays in the
    # denominator and biases the rate slightly LOW, which the gap machinery
    # still sees and can still report.  Overstating would remove live time and
    # bias the rate HIGH with nothing left behind to notice it.
    #
    # Marked spans carry no such slack -- they are exact -- so the merged
    # total is subtracted rather than nosig_s alone.  Using nosig_s here while
    # dropping beats by excise_spans would remove marked beats from the
    # numerator and leave their seconds in the denominator: a rate biased low
    # by exactly the marked fraction, with nothing in the output to show it.
    excised_base_s = total_span_s(excise_spans)

    # ---- beatless gaps: the third excised category, EMPTY.
    #
    # Measured here, on the FINAL beat list -- after the refill has had its
    # chance, after the amplitude floor, after the no-signal/marked drop --
    # because a gap is only "empty" once everything that could have put a
    # beat in it has run.  See empty_gap_spans for the rule and the interior
    # cut.  ALWAYS measured, so a --keep-empty run can still say how much
    # time the default would have removed; APPLIED unless --keep-empty.
    keep_empty = bool(getattr(args, "keep_empty", False))
    empty_spans, empty_base_rr = empty_gap_spans(
        anchors, fs, dur, excise_spans,
        float(getattr(args, "refill_gap_mult", 3.0)))
    empty_s = total_span_s(empty_spans)
    excise_base_spans = excise_spans
    # Disjoint from excise_spans by construction, so this merge only sorts;
    # it is still a merge so the invariant does not rest on that alone.
    rate_spans = (excise_base_spans if keep_empty
                  else merge_spans(excise_base_spans + empty_spans))
    excised_s = total_span_s(rate_spans)
    analysable_s = max(1e-9, dur - excised_s)


    segs, keep, mid = extract_beats(wide, anchors, fs, profile.beat_half_ms)
    pre_c = max(4, min(int(round(profile.cluster_half_ms / 1000.0 * fs)), mid))
    if len(segs):
        csegs = segs[:, mid - pre_c: mid + pre_c]
        csegs = csegs - np.median(csegs, axis=1, keepdims=True)
    else:
        csegs = segs
    lab_kept, templates = cluster_beats(csegs, thr=DEFAULTS["corr"],
                                        kmax=DEFAULTS["kmax"],
                                        min_frac=DEFAULTS["min_frac"])
    labels = np.full(len(anchors), -1, dtype=int)
    if len(keep):
        labels[keep] = lab_kept

    cls, M, rr = classify_rhythm(anchors, fs)
    # The RATE divides by the fully excised duration.  The GAP statistics are
    # told only about no-signal and marked time.  An empty span is derived
    # FROM a gap, so letting rr_bridges_span drop the interval that bridges
    # it would be circular: every gap over the threshold would vanish from
    # maxGap, LONG_GAP and GAP_ENDS_ON_CHUNK_EDGE could never fire, and the
    # report would lose the one column that says "the detector went deaf
    # here" -- which is still true, and still worth looking at, whether or
    # not its seconds are counted.
    integ = rate_and_integrity(anchors, fs, analysable_s, profile,
                               excluded=excise_base_spans)
    integ["chunk_s"] = chunk_s
    integ["clip_k"] = clip_k
    integ["nosig_s"] = nosig_s
    integ["mark_s"] = mark_s
    integ["empty_s"] = empty_s
    integ["empty_applied_s"] = 0.0 if keep_empty else empty_s
    integ["n_empty"] = len(empty_spans)
    integ["keep_empty"] = keep_empty
    integ["empty_base_rr_s"] = empty_base_rr
    integ["excised_base_s"] = excised_base_s
    integ["excised_s"] = excised_s
    integ["mark_frac"] = float(miss_frac[chosen]) if missing.size else 0.0
    integ["sat_s"] = sat_s
    integ["analysable_s"] = analysable_s
    integ["nosig_dropped"] = nosig_dropped
    # Does the worst gap END on a chunk boundary?  The animal has no way of
    # knowing where this tool's chunk grid falls, so alignment means the gap
    # was MANUFACTURED by detection: the SPKI ratchet suppresses beats from an
    # artifact until the next chunk resets the threshold.  Such beats are
    # recoverable; a true acquisition dropout is not.  The distinction changes
    # what you should do about the file, so it gets its own flag.
    gap_end = integ.get("max_gap_at", float("nan"))
    if np.isfinite(gap_end) and np.isfinite(integ["max_gap"]):
        gap_end = gap_end + integ["max_gap"] * integ["modal_rr_ms"] / 1000.0
        edge_d = min(gap_end % chunk_s, chunk_s - (gap_end % chunk_s))
        integ["gap_end_edge_s"] = float(edge_d)
        if integ["max_gap"] > 10.0 and edge_d <= 1.5:
            integ["flags"].append("GAP_ENDS_ON_CHUNK_EDGE")
            integ["trustworthy"] = False
    else:
        integ["gap_end_edge_s"] = float("nan")
    # If the floor removed a meaningful share of detections, say so.  A healthy
    # record loses ~0: real beats sit at 0.87-1.18x the median QRS.  A nonzero
    # figure means the detector was emitting sub-QRS deflections, which is
    # information about the record (or the neurokit build), not housekeeping.
    #
    # Two edges, not one -- see AMP_FLOOR_NOTE_FRAC for why a single 1% cliff
    # was unsafe.  The label carries two decimals because the old `%.0f`
    # rendered 1.01% and 1.49% identically while giving them the same verdict
    # and 0.99% the opposite one; a label that cannot distinguish the cases the
    # decision distinguishes is how a silent flip survives review.
    if n_pre_floor and floor_removed > AMP_FLOOR_NOTE_FRAC:
        pct = 100.0 * floor_removed
        if floor_removed > AMP_FLOOR_MAJOR_FRAC:
            integ["flags"].append("AMP_FLOOR_MAJOR_%.2f%%" % pct)
            integ["trustworthy"] = False
        else:
            integ["flags"].append("AMP_FLOOR_%.2f%%" % pct)
    # Dead time, in two tiers.  See ADVISORY_FLAGS for why the ordinary case is
    # advisory and NO_SIGNAL_MAJOR_FRAC for why the major cut is the one number
    # in this file that is not measured.
    if nosig_s > 0:
        integ["flags"].append("NO_SIGNAL_MAJOR"
                              if nosig_s > NO_SIGNAL_MAJOR_FRAC * dur
                              else "NO_SIGNAL")
    # Time the EXPORTER disowned, on the same two tiers and for the same
    # reason.  A separate flag rather than reusing NO_SIGNAL: a reader seeing
    # NO_SIGNAL will go looking for a lead-off event in the trace, and on a
    # marked file there may be nothing to see -- the samples were removed
    # upstream and the gap is whatever the interpolation drew.  Sending
    # someone to inspect a straight line we drew ourselves wastes their time.
    #
    # The percentage is carried in the flag text, as AMP_FLOOR does, because
    # "MARKED" alone does not distinguish one bad second from half the file.
    if mark_s > 0:
        pct = 100.0 * mark_s / max(1e-9, dur)
        integ["flags"].append(
            ("MARKED_MAJOR_%.2f%%" % pct) if mark_s > NO_SIGNAL_MAJOR_FRAC * dur
            else ("MARKED_%.2f%%" % pct))
    # Saturation reports and does nothing else; see Species.saturated_frac.
    if sat_s > 0:
        integ["flags"].append("SATURATED")
    qc = qc_windows(lab_kept, anchors, keep, fs, len(wide),
                    DEFAULTS["window_s"], args.qc_min)
    tq, med_amp = template_quality(wide, anchors, fs, profile.beat_half_ms)
    amps = np.abs(segs[:, mid]) if len(segs) else np.array([])
    amp_full = np.full(len(anchors), np.nan)
    if len(keep):
        amp_full[keep] = amps

    r = Result()
    r.path, r.fs, r.dur, r.lead, r.lead_q = path, fs, dur, chosen, lead_q
    r.ch_names = ch_names
    r.anchors, r.labels, r.cls, r.amps = anchors, labels, cls, amp_full
    r.wide, r.det = wide, det
    r.band, r.refr, r.profile = band, refr, profile
    r.clip_frac, r.tmplq, r.med_amp = clip_frac, tq, med_amp
    r.floor_removed, r.n_pre_floor = floor_removed, n_pre_floor
    r.floor_removed_all, r.floor_excised = floor_removed_all, floor_excised
    r.refill_added, r.refill_rounds = refill_added, refill_rounds
    r.refill_spans, r.n_pre_refill = refill_spans, n_pre_refill
    r.refill_cfg = (bool(getattr(args, "refill", True)),
                    float(getattr(args, "refill_gap_mult", 3.0)),
                    int(getattr(args, "refill_rounds", 3)))
    r.nosig_spans, r.sat_spans = nosig_spans, sat_spans
    r.nosig_s, r.sat_s = nosig_s, sat_s
    r.mark_spans, r.mark_s = mark_spans, mark_s
    # excise_spans is what the RATE excised (no-signal U marked U empty
    # unless --keep-empty); excise_base_spans is no-signal U marked only.
    # Both are kept because `view` has to shade them differently and
    # recompute the empty part from an edited beat list.
    r.excise_spans, r.excised_s = rate_spans, excised_s
    r.excise_base_spans = excise_base_spans
    r.empty_spans, r.empty_s = empty_spans, empty_s
    r.empty_base_rr = empty_base_rr
    r.keep_empty = keep_empty
    r.empty_gap_mult = float(getattr(args, "refill_gap_mult", 3.0))
    r.missing = missing
    r.analysable_s, r.nosig_dropped = analysable_s, nosig_dropped
    r.amp_a = amp_a
    r.nosig_cfg = bool(getattr(args, "nosig", True))
    # NOTE: qc_windows above is deliberately NOT told about the spans.  Excluded
    # windows would have to be dropped from its denominator, and a 60 s window
    # holding 2 s of dead time is not obviously excludable, so the rule would
    # need a fraction -- another unmeasured number.  Leaving it alone means QC%
    # dips on a file with dead time, which is defensible: QC% is a data-quality
    # measure and dead time is poor quality.  gated_bpm is unaffected either
    # way, since it only averages windows it accepted.
    # p99/A on the UNCLIPPED detection signal, and the two clip thresholds it
    # implies.  These used to be an ESTIMATE (p99 ~ 0.6 A) that had never been
    # checked against data; measuring per file turns the choice of k from an
    # argument into a number.
    r.p99_over_a = float("nan")
    r.k_min_safe = float("nan")
    r.k_crit = float("nan")
    # Whether these three CAN be computed is a separate question from how, and
    # it is asked first.  Computing them and letting the reader judge was the
    # original behaviour, and the reader (me) judged wrong for several
    # sessions: 1.11 from 89 samples read as an anomaly when it was an
    # identity.  A statistic that cannot be supported is not reported at all.
    r.pct_support = percentile_support(len(det_raw), len(anchors))
    if len(anchors) and r.pct_support["ok"]:
        _h = max(2, int(round(profile.qrs_width_ms / 1000.0 * fs)))
        _lo = np.maximum(anchors - _h, 0)
        _hi = np.minimum(anchors + _h + 1, len(det_raw))
        _a = np.array([np.ptp(det_raw[i:j]) if j > i else 0.0
                       for i, j in zip(_lo, _hi)])
        _amed = float(np.median(_a))
        _p99 = float(np.percentile(np.abs(det_raw), 99.0))
        if _amed > 0 and np.isfinite(_p99):
            r.p99_over_a = _p99 / _amed
            # k_min_safe: below this the clip level C = k*p99 falls under the
            # TALLEST real beat (1.18x the median QRS, v9 [5]), so the biggest
            # complexes get their tops flattened.
            r.k_min_safe = 1.18 / (_p99 / _amed)
            # k_crit: below this C falls into the P-WAVE band (P-wave false
            # positives measured 0.1-0.3 A, v9 [5]).  Once C <= 0.3 A a beat
            # a P wave are clipped to the SAME level and become
            # indistinguishable.  This, not k_min_safe, is where detection
            # actually breaks.
            r.k_crit = 0.30 / (_p99 / _amed)
    elif not r.pct_support["ok"]:
        # Disqualifying, not advisory.  A record this short does not have a
        # weak p99/A -- it does not have a bpm, a modal rate or a QC figure
        # either, because none of them have anything to average over.  The
        # sample count goes IN the flag, following AMP_FLOOR_n.nn%, so the
        # label cannot drift from the measurement that produced it.
        integ["flags"].append("SHORT_RECORD_n=%d" % r.pct_support["n_samples"])

    r.integrity, r.qc, r.modal_rr = integ, qc, M
    # Two tiers, because one tier was wrong.  The first version of this check
    # condemned any file with clip_k < k_min_safe, and the selftest immediately
    # caught it crying wolf on a synthetic record it detected perfectly (240 of
    # 240 beats, 0.0 ms median offset).  The clipsweep on real data says the
    # same thing: at k=2, which is BELOW the measured k_min of 2.35-2.83,
    # part014 gained 0 beats and part012 gained 1, with tmplQ flat.  Grazing
    # the top of a QRS costs nothing -- the beat still towers over the floor.
    if np.isfinite(r.k_crit) and 0 < clip_k < r.k_crit:
        integ["flags"].append("CLIP_DESTROYS_QRS")
    elif np.isfinite(r.k_min_safe) and 0 < clip_k < r.k_min_safe:
        integ["flags"].append("CLIP_BELOW_KMIN")
    integ["trustworthy"] = not [f for f in integ["flags"]
                                if not is_advisory(f)]
    r.n_clusters = len(templates)
    r.qc_min = args.qc_min
    return r


def config_signature(r):
    """Describe the configuration that PRODUCED r.

    Reads only the Result, never live args.  An earlier version took qc_min
    from the caller's args while taking everything else from r, so passing a
    different namespace silently produced a signature for a run that never
    happened -- which defeats the entire point of a provenance check.

    Keyed on _VERSION_BASE, deliberately NOT on the per-build source hash that
    appears in the banners.  The signature exists to stop an edited review file
    being scored against a detection run with different PARAMETERS; invalidating
    hours of hand review because a comment was reworded would be a different and
    worse failure.  Anything that changes detection belongs in this list.

    chunk and clip are read from r.integrity, which records what the run
    actually used.  They were previously read from DEFAULTS, so `--chunk 30`
    and `--clip-k 8` produced a signature identical to a default run -- the
    exact class of bug this docstring already warns about one paragraph up.
    """
    ig = getattr(r, "integrity", {}) or {}
    rc = getattr(r, "refill_cfg", (True, 3.0, 3))
    s = "|".join(["%s" % _VERSION_BASE, r.profile.name, "%.1f" % r.fs,
                  "%d" % r.lead, "%.1f-%.1f" % (r.band[0], r.band[1]),
                  "%.0f" % r.refr,
                  "%.0f" % ig.get("chunk_s", DEFAULTS["chunk_s"]),
                  "%.2f" % ig.get("clip_k", DEFAULTS["clip_k"]),
                  "refill=%d,%.2f,%d" % (1 if rc[0] else 0, rc[1], rc[2]),
                  # The no-signal cut belongs here because it REMOVES beats.
                  # A review file edited against a run that excised a span,
                  # scored against a run that did not, would attribute the
                  # excised beats to the reviewer as deletions and report an
                  # accuracy that is an artifact of the mismatch.
                  "nosig=%d,%.3f" % (1 if getattr(r, "nosig_cfg", True) else 0,
                                     r.profile.no_signal_frac),
                  "%.0f" % r.profile.snap_ms, "%.2f" % r.qc_min,
                  "%.3f" % r.profile.amp_floor_frac])
    return s, hashlib.sha1(s.encode()).hexdigest()[:10]


# ================================================================= peak files

PEAK_FIELDS = ["time_s", "sample", "amp", "rhythm", "cluster", "qc", "source",
               "keep", "note"]


def write_peaks(path, r, review=False):
    """Write a peak file.  With review=True it also proposes INSERT candidates
    and pre-flags the beats most worth a human's attention."""
    cfg, sig = config_signature(r)
    wn = int(round(DEFAULTS["window_s"] * r.fs))
    win_ok = {k: ok for k, _, _, ok in r.qc["rows"]}

    rows = []
    for i, p in enumerate(r.anchors):
        w = int(p) // wn
        qc = bool(win_ok.get(w, False)) and r.labels[i] >= 0
        flag = []
        if r.labels[i] < 0:
            flag.append("orphan")
        if not win_ok.get(w, False):
            flag.append("win")
        if r.cls[i] == 1:
            flag.append("split?")        # s~1 is the false-positive signature
        elif r.cls[i] == 3:
            flag.append("pvc?")
        rows.append(dict(time_s="%.4f" % (p / r.fs), sample=int(p),
                         amp="%.5f" % (r.amps[i] if np.isfinite(r.amps[i]) else 0.0),
                         rhythm=CLS_NAME.get(int(r.cls[i]), "?"),
                         cluster=int(r.labels[i]), qc=int(qc), source="AUTO",
                         keep=1, note=";".join(flag)))

    n_sugg = 0
    if review and len(r.anchors) > 25 and np.isfinite(r.modal_rr):
        # Propose beats inside long gaps.  A gap of k baselines plausibly hides
        # k-1 beats; place them evenly and let the reviewer accept or reject.
        rr = np.diff(r.anchors) / r.fs
        for i, gap in enumerate(rr):
            k = int(round(gap / r.modal_rr))
            if k < 2 or gap <= 1.8 * r.modal_rr:
                continue
            k = min(k, 40)
            for j in range(1, k):
                t = (r.anchors[i] + j * gap * r.fs / k)
                rows.append(dict(time_s="%.4f" % (t / r.fs), sample=int(round(t)),
                                 amp="", rhythm="", cluster=-1, qc=0,
                                 source="SUGGEST", keep=0, note="gap%.1fx" % (gap / r.modal_rr)))
                n_sugg += 1

    rows.sort(key=lambda d: float(d["time_s"]))
    with open(path, "w", newline="") as f:
        f.write("# %s\n" % VERSION)
        f.write("# source_file: %s\n" % os.path.abspath(r.path))
        f.write("# species: %s\n" % r.profile.name)
        f.write("# fs_hz: %.4f\n" % r.fs)
        f.write("# duration_s: %.4f\n" % r.dur)
        _sg = getattr(r, "seg", None)
        if _sg:
            # A page or peak file for ONE SEGMENT of a long recording: its
            # clock starts at the segment, so say where that is.
            f.write("# segment: %s\n" % _sg["name"])
            f.write("# segment_offset_s: %.4f\n" % _sg["t0_s"])
            f.write("# segment_note: time_s and sample are counted from the "
                    "segment start, not the recording start\n")
        f.write("# lead: %d\n" % r.lead)
        f.write("# config: %s\n" % cfg)
        f.write("# config_sha1: %s\n" % sig)
        f.write("# n_auto: %d\n" % len(r.anchors))
        f.write("# n_suggested: %d\n" % n_sugg)
        if review:
            f.write("#\n")
            f.write("# HOW TO EDIT THIS FILE\n")
            f.write("#   keep=1  this beat counts        keep=0  this beat does not\n")
            f.write("#   AUTO rows start keep=1.  Set keep=0 to reject a detection.\n")
            f.write("#   SUGGEST rows start keep=0 and mark where a beat MIGHT be\n")
            f.write("#     missing (inside a gap).  Set keep=1 to accept one.\n")
            f.write("#   To add a beat of your own, append a row with source=MANUAL,\n")
            f.write("#     keep=1 and a time_s.  sample/amp/cluster may be left blank.\n")
            f.write("#   Do not edit the '# config_sha1' line: compare checks it so an\n")
            f.write("#     edited file cannot be scored against the wrong detection.\n")
            f.write("#   note column: orphan=odd morphology, win=window failed QC,\n")
            f.write("#     split?=interval-splitting shape (the false-positive\n")
            f.write("#     signature), pvc?=compensatory pause, gapNx=size of the gap\n")
            f.write("#     a suggestion sits in.\n")
        w = csv.DictWriter(f, fieldnames=PEAK_FIELDS)
        w.writeheader()
        for d in rows:
            w.writerow(d)
    return len(rows), n_sugg


def read_peaks(path):
    """Read a peak file, returning (kept_times_s, meta, all_rows)."""
    meta, lines = {}, []
    with open(path, "r", newline="") as f:
        for line in f:
            if line.startswith("#"):
                body = line[1:].strip()
                if ":" in body:
                    k, v = body.split(":", 1)
                    meta[k.strip()] = v.strip()
                continue
            lines.append(line)
    if not lines:
        raise ValueError("%s: no data rows" % path)
    rdr = csv.DictReader(lines)
    rows, times = [], []
    for i, d in enumerate(rdr, 2):
        rows.append(d)
        try:
            keep = int(float(d.get("keep", "1") or 1))
        except ValueError:
            raise ValueError("%s line %d: keep=%r is not a number" % (path, i, d.get("keep")))
        if not keep:
            continue
        t = d.get("time_s", "").strip()
        if not t:
            s = d.get("sample", "").strip()
            if not s:
                raise ValueError("%s line %d: row has neither time_s nor sample" % (path, i))
            fs = float(meta.get("fs_hz", "0") or 0)
            if fs <= 0:
                raise ValueError("%s line %d: sample given but fs_hz unknown" % (path, i))
            t = float(s) / fs
        times.append(float(t))
    times = np.sort(np.asarray(times, dtype=float))
    return times, meta, rows


# ==================================================================== display

def beat_scale(y, peak_idx, pad=1.4):
    """Display half-range built from BEAT height, not from the extrema.

    The renderer used to scale each panel to min/max of its own samples.  One
    artifact fifteen times taller than a QRS then pinned the range and every
    real beat collapsed onto the zero row.  That is not a cosmetic problem:
    a part006 panel carrying 14 beats at the file's modal RR rendered as a
    flat line, and the windows worth inspecting are precisely the ones with
    an artifact in them, so the display went blind exactly where it was
    needed.  It also failed in the opposite direction -- a silent stretch
    with nothing but noise had that noise stretched to full height and so
    looked like signal.

    Scale to the median height of the DETECTED beats instead.  Beats then
    fill the panel whatever the artifact does, the artifact announces itself
    by running off the top, and a genuinely silent stretch reads silent.

    Pass the peaks of the WHOLE shown window, not one panel: a shared scale
    is what lets a reader compare panels, and it is what stops a panel that
    happens to contain no beats from inventing its own reference.

    Returns (lo, hi) about the sample median.
    """
    y = np.asarray(y, float)
    fin = y[np.isfinite(y)]
    if not len(fin):
        return (-1.0, 1.0)
    base = float(np.median(fin))
    amp = None
    if peak_idx is not None and len(peak_idx):
        pk = np.asarray(peak_idx, dtype=int)
        pk = pk[(pk >= 0) & (pk < len(y))]
        if len(pk):
            h = np.abs(y[pk] - base)
            h = h[np.isfinite(h)]
            if len(h):
                amp = float(np.median(h))
    if amp is None or not np.isfinite(amp) or amp <= 0:
        # No beats anywhere in the window.  There is no beat to reference, so
        # fall back to a high percentile of |deviation| -- high enough to sit
        # above the noise, but a percentile rather than the max so that one
        # spike still cannot own the scale.  cmd_show says when this happened.
        dev = np.abs(fin - base)
        amp = float(np.percentile(dev, 99.0))
    if not np.isfinite(amp) or amp <= 0:
        amp = 1.0
    return (base - pad * amp, base + pad * amp)


def panel_resolution(seconds, width, fs, qrs_ms):
    """How much of a QRS fits in ONE column of a panel.  Nothing is plotted here.

    This exists because a `show` panel can be asked for a time span its own
    column count cannot represent, and until now it answered anyway.  At
    `--seconds 10` across 100 columns each column spans 100 ms against a
    14 ms porcine QRS: the beat is seven times narrower than the smallest
    thing the panel is able to draw.  What comes back is not a waveform, and
    the tool said nothing to that effect.

    The failure is not that the QRS vanishes -- the renderer decimates by
    range precisely so spikes survive.  It is subtler and worse.  Each column
    becomes an extreme-value statistic over `samp_per_col` samples, so the
    NOISE floor of the display rises with the decimation while the beat
    height stays where it is.  Decimate far enough and noise reaches beat
    height, the panel fills, and it still looks like a measurement.

    Three regimes, and the boundaries are geometry rather than taste:

      "morphology"  >= 3 columns per QRS.  Up, over and down land in
                    different columns, so the shape can be read.
      "peaks"       >= 1 column per QRS.  The beat owns a column of its own:
                    height is readable, shape is not.
      "envelope"    <  1 column per QRS.  The beat is narrower than a column.
                    Nothing here is a waveform; it is a min/max envelope, and
                    ascii_wave draws it as one.

    Returns the arithmetic plus the `--seconds` (and `--width`) that would
    reach the first two regimes.  It does NOT refuse: an envelope drawn as an
    envelope is an honest object, and the caller is told which one it holds.
    """
    seconds = float(seconds)
    width = max(1, int(width))
    fs = float(fs)
    qrs_ms = float(qrs_ms)
    ms_per_col = seconds * 1000.0 / width
    samp_per_col = seconds * fs / width
    cols_per_qrs = (qrs_ms / ms_per_col) if ms_per_col > 0 else float("inf")
    if cols_per_qrs >= 3.0:
        verdict = "morphology"
    elif cols_per_qrs >= 1.0:
        verdict = "peaks"
    else:
        verdict = "envelope"
    return dict(seconds=seconds, width=width, fs=fs, qrs_ms=qrs_ms,
                ms_per_col=ms_per_col, samp_per_col=samp_per_col,
                cols_per_qrs=cols_per_qrs, verdict=verdict,
                seconds_for_peaks=qrs_ms * width / 1000.0,
                seconds_for_morphology=qrs_ms * width / 3000.0,
                width_for_peaks=(int(np.ceil(seconds * 1000.0 / qrs_ms))
                                 if qrs_ms > 0 else 0))


def ascii_wave(y, t0, t1, marks_s=None, height=13, width=100, title="",
               yscale=None):
    """Plot y (already sliced) between t0 and t1 seconds, marking peaks.

    Each column is drawn as its min..max ENVELOPE -- a vertical bar from the
    lowest to the highest sample in that column -- not as a single point.

    The single point was the column extremum, chosen so a spike would survive
    decimation, and survive it does.  What did not survive is legibility.  A
    column holding 50 samples of noise has a maximum above the baseline and a
    minimum below it, and the extremum rule keeps whichever is larger in
    absolute value; neighbouring columns pick opposite sides for no reason
    but the noise, so the panel fills with dots scattered either side of the
    baseline.  That is how a quiet, slightly noisy stretch came back looking
    like dense signal.  The picture was not wrong about any single column and
    was entirely wrong as a whole.

    An envelope cannot fail that way.  Every bar spans its column's true
    range, so noise reads as a BAND with a flat top edge, a dropout reads as
    a flat line on the baseline, and a beat is a bar standing above the band
    -- which is the one comparison a reader is here to make.  Where a column
    holds only a sample or two the bar collapses to a point, so nothing is
    lost at high resolution.

    '*' marks the two ends of a bar and ':' fills between them, keeping the
    outline readable when the band is tall.  '#' replaces '*' at an end that
    ran off the scale.

    yscale is an explicit (lo, hi), normally built once per show window by
    beat_scale so every panel shares it.  Samples outside it are pinned to
    the edge row instead of being allowed to rescale the panel.
    """
    y = np.asarray(y, float)
    if len(y) < 2 or not np.any(np.isfinite(y)):
        print("  (no data)"); return
    cols = np.array_split(np.arange(len(y)), width)
    vmin = np.full(width, np.nan)
    vmax = np.full(width, np.nan)
    for i, c in enumerate(cols):
        if not len(c):
            continue
        seg = y[c]
        if not np.any(np.isfinite(seg)):
            continue
        vmin[i] = float(np.nanmin(seg))
        vmax[i] = float(np.nanmax(seg))
    if yscale is not None:
        lo, hi = float(yscale[0]), float(yscale[1])
    else:
        lo, hi = beat_scale(y, None)
    if not np.isfinite(lo) or not np.isfinite(hi) or hi - lo < 1e-12:
        hi, lo = lo + 1.0, lo - 1.0
    grid = [[" "] * width for _ in range(height)]
    zero_row = int(round((hi - 0.0) / (hi - lo) * (height - 1)))
    if 0 <= zero_row < height:
        grid[zero_row] = ["-"] * width

    def _row(v):
        return min(max(int(round((hi - v) / (hi - lo) * (height - 1))), 0),
                   height - 1)

    n_over = 0
    for c in range(width):
        if not np.isfinite(vmin[c]):
            continue
        hot, cold = vmax[c] > hi, vmin[c] < lo
        r_top = 0 if hot else _row(vmax[c])
        r_bot = height - 1 if cold else _row(vmin[c])
        if hot or cold:
            n_over += 1
        if r_top == r_bot:
            grid[r_top][c] = "#" if (hot or cold) else "*"
            continue
        for r in range(r_top + 1, r_bot):
            grid[r][c] = ":"
        grid[r_top][c] = "#" if hot else "*"
        grid[r_bot][c] = "#" if cold else "*"
    mark = [" "] * width
    if marks_s is not None and t1 > t0:
        for t in marks_s:
            # Data columns come from array_split into `width` bins, so sample i
            # lands in column int(i*width/N) -- i.e. the map uses width, not
            # width-1.  Using width-1 here drifted the caret up to a full column
            # left of its own beat by the end of a panel, which is a real error
            # when the panel is being read to decide whether a mark sits on a
            # QRS or on nothing.
            c = int((t - t0) / (t1 - t0) * width)
            if 0 <= c < width:
                mark[c] = "^"
    if title:
        print("  " + title)
    for row in grid:
        print("   |" + "".join(row))
    print("   +" + "-" * width)
    print("    " + "".join(mark))
    legend = "^ = R peak   bar '*..*' = column min..max"
    if n_over:
        legend += "   # = %d col(s) off scale" % n_over
    print("    %-*.2f%*.2f  seconds      %s"
          % (width // 2, t0, width - width // 2, t1, legend))


def filter_marks_by_source(rows, want):
    """Times of the peak-file rows whose source is in `want`, kept and timed.

    A separate function because `show` is the one command the selftest cannot
    call -- it needs a whole recording to render -- and this is the part of it
    with a decision in it.  Left inline it would have been the only new logic
    in the build with no check on it.

    `want` is a set of upper-case source names.  Rows with keep=0 are skipped
    even when their source matches: keep=0 means the row is present for the
    record, not for the display, and honouring it here keeps one meaning of
    keep across the whole tool.
    """
    out = []
    for row in rows or ():
        if (row.get("source") or "").strip().upper() not in want:
            continue
        try:
            if int(float(row.get("keep", "1") or 1)) == 0:
                continue
        except (TypeError, ValueError):
            continue
        t = (row.get("time_s") or "").strip()
        if not t:
            continue
        try:
            out.append(float(t))
        except ValueError:
            continue
    return np.sort(np.asarray(out, dtype=float))


def cmd_show(args):
    profile = SPECIES[args.species]
    files = expand_inputs(args.input)
    if not files:
        sys.exit("no input files matched %r" % (args.input,))
    path = files[0]
    r = analyse(path, args, profile)
    # Two peak sets, deliberately.
    #
    #   peaks_s  sets the DISPLAY SCALE
    #   marks_s  is what gets DRAWN
    #
    # They are usually the same list.  They must not be forced to be, because
    # the file this command is most useful on -- `compare --export-diff` --
    # holds three kinds of row, and the interesting ones are the disputed
    # handful.  Drawing only those is the point; scaling to only those would
    # build the panel's height reference out of whatever the dispute is
    # about, which on a false positive may well be a noise spike, and the
    # real beats beside it would then render as a flat line.  So the agreed
    # beats stay in the scale set even when they are not drawn.
    mark_src = None
    if getattr(args, "mark_source", None):
        mark_src = {s.strip().upper() for s in args.mark_source.split(",")
                    if s.strip()}
    if args.peaks:
        times, meta, rows = read_peaks(args.peaks)
        check_provenance(meta, r, fatal=False)
        peaks_s = times
        src = os.path.basename(args.peaks)
        if mark_src:
            marks_s = filter_marks_by_source(rows, mark_src)
            src += "  [drawing %s only: %d of %d]" % (
                ",".join(sorted(mark_src)), len(marks_s), len(peaks_s))
        else:
            marks_s = peaks_s
    else:
        peaks_s = r.anchors / r.fs
        marks_s = peaks_s
        src = "fresh detection"
        if mark_src:
            print("  ** --mark-source needs --peaks; it filters rows of a peak\n"
                  "     file by their source column and there is no file here.",
                  file=sys.stderr)

    print("=" * 108)
    print("%s | lead %d | %.0f Hz | %.0f s | %d beats | peaks from %s"
          % (os.path.basename(path), r.lead, r.fs, r.dur, len(peaks_s), src))
    print("=" * 108)

    t0 = args.start
    per = args.seconds
    n_panels = max(1, args.panels)
    # 40 columns is narrower than any terminal worth using; 400 is wider than
    # any terminal that will not wrap, and a wrapped panel is unreadable in a
    # different way from an unresolved one.
    width = min(400, max(40, int(getattr(args, "width", 100) or 100)))

    # WHAT THIS PANEL CAN AND CANNOT SHOW, before it shows anything.
    #
    # A panel is an image of `per` seconds in `width` columns, and that ratio
    # decides which questions it can answer.  Saying so costs three lines and
    # removes the one way this display can mislead: looking like a waveform
    # when it is an envelope.  See panel_resolution for the regimes.
    pr = panel_resolution(per, width, r.fs, profile.qrs_width_ms)
    print("  resolution     %.4g s over %d columns = %.4g ms and %.4g sample(s)"
          " per column" % (per, width, pr["ms_per_col"], pr["samp_per_col"]))
    print("                 a %.4g ms %s QRS spans %.2f column(s) -- %s"
          % (pr["qrs_ms"], profile.name, pr["cols_per_qrs"],
             {"morphology": "shape is readable",
              "peaks": "height is readable, shape is NOT",
              "envelope": "this is an ENVELOPE, not a waveform"}[pr["verdict"]]))
    if pr["verdict"] == "envelope":
        # Not an error and not refused.  Each bar spans its column's true
        # min..max, so the picture is honest -- a beat is a bar above the
        # band.  What it cannot do is show a beat's shape, and a reader who
        # wanted that has to be told, with the number that would give it.
        print("                 Bars are column min..max: a beat reads as a bar"
              " standing")
        print("                 above the noise band.  For beat SHAPE use"
              "  --seconds %.4g"
              % pr["seconds_for_morphology"])
        if pr["width_for_peaks"] <= 400:
            print("                 (or keep this span and widen to --width %d)"
                  % pr["width_for_peaks"])

    # ONE scale for every panel, built from beat height across the whole shown
    # window.  Per-panel min/max let a single artifact pin the range and flatten
    # every real beat beside it -- the failure that made a 14-beat part006 panel
    # look like a flat line.  A shared beat-referenced scale also makes panels
    # comparable, which is the whole point when the question is "is this stretch
    # silent, or is it merely being drawn next to something enormous".
    w0 = int(max(0.0, t0) * r.fs)
    w1 = min(len(r.wide), int((t0 + n_panels * per) * r.fs))
    yscale, scale_src, n_win_pk = None, "none", 0
    if w1 - w0 >= 10:
        win_pk = peaks_s[(peaks_s >= t0) & (peaks_s < t0 + n_panels * per)]
        n_win_pk = len(win_pk)
        idx = np.round(np.asarray(win_pk, float) * r.fs).astype(int) - w0
        yscale = beat_scale(r.wide[w0:w1], idx)
        scale_src = ("median of %d beat(s) in view" % n_win_pk if n_win_pk
                     else "p99 of |deviation| -- NO beats in view to scale to")
        print("  display scale  +/-%.4g about baseline  (%s)"
              % ((yscale[1] - yscale[0]) / 2.0, scale_src))
        if not n_win_pk:
            print("                 with no beat in view the scale is not beat-")
            print("                 referenced, so height here is NOT comparable")
            print("                 to a window that has beats.  Widen --seconds.")
    for k in range(n_panels):
        a, b = t0 + k * per, t0 + (k + 1) * per
        if a >= r.dur:
            break
        s, e = int(a * r.fs), min(len(r.wide), int(b * r.fs))
        if e - s < 10:
            break
        sel = marks_s[(marks_s >= a) & (marks_s < b)]
        print()
        ascii_wave(r.wide[s:e], a, b, marks_s=sel, yscale=yscale, width=width,
                   title="t = %.2f .. %.2f s   (%d %s)"
                         % (a, b, len(sel),
                            "marked" if mark_src else "peaks"))
        # Only print RR when the drawn set IS the beat train.  With a filter
        # on, consecutive marks are consecutive DISAGREEMENTS, and the gaps
        # between them are not cardiac intervals -- labelling them "RR" would
        # invite reading a 4-second dispute gap as a 15 bpm heart rate.
        if len(sel) > 1 and not mark_src:
            rr = np.diff(sel) * 1000.0
            print("    RR in panel (ms): " + " ".join("%.0f" % v for v in rr[:18])
                  + (" ..." if len(rr) > 18 else ""))
        elif len(sel) > 1:
            gap = np.diff(sel) * 1000.0
            print("    gap between marks (ms, NOT RR): "
                  + " ".join("%.0f" % v for v in gap[:12])
                  + (" ..." if len(gap) > 12 else ""))
    print()
    print_rate_block(r)


SPAN_BINS = [0.0, 0.02, 0.05, 0.10, 0.15, 0.20, 0.30, 0.50, 0.75, 1.00,
             1.50, 2.00, 3.00, 5.00, 7.00, 10.0, float("inf")]
FLAT_TRIALS = [0.05, 0.10, 0.15, 0.20, 0.30]
SAT_TRIALS = [3.0, 5.0, 7.0, 10.0]


def cmd_spans(args):
    """MEASURE the windowed-range distribution.  Decides nothing, changes nothing.

    Phase 1 of the NO_SIGNAL work, and deliberately inert.  The obvious move
    is to pick "flat means under 15% of a QRS" and start suppressing things.
    That is how p99/A came to be guessed at 0.6 in this project when it
    measures 0.42-0.50 -- wrong by 1.4x, in the direction that damages real
    beats.  A threshold that suppresses signal must be derived from the data
    it will be applied to.

    So this prints the distribution of (windowed range / median QRS
    amplitude) and what several candidate cuts WOULD select.  The expectation
    is bimodal: a population near 1.0 where there are beats, and, on a file
    with a dropout, a separate population near 0.  The cut belongs in the gap
    between them.  If there is no gap, there is no safe cut and this approach
    needs rethinking rather than tuning.

    Now that the cut derived from this command is WIRED IN, this command has to
    defend its own independence: it calls analyse(), and analyse() would
    otherwise excise the very spans being measured, then report a QRS scale and
    a range distribution computed over what survived.  The measurement would
    then be conditioned on its own conclusion, and re-running it could only
    ever confirm the current threshold.  So excision is forced off here.  This
    is not a preference -- it is the difference between a measurement and an
    echo.
    """
    profile = SPECIES[args.species]
    args.nosig = False
    files = expand_inputs(args.input)
    if not files:
        sys.exit("no input files matched %r" % (args.input,))
    print("=" * 132)
    print("%s  spans  |  %s profile  |  %d file(s)  |  window %.1f s, step %.2f s, "
          "min span %.1f s" % (VERSION, profile.name, len(files),
                               args.win, args.step, args.min_span))
    print("=" * 132)
    print("  MEASUREMENT ONLY -- no threshold is applied and no output of any")
    print("  other command changes because of this run.")
    print()
    # flat_s and sat_s are read from the PROFILE rather than written as
    # literals.  They were literals while the cut was being derived, which was
    # right then and is wrong now: with the cut adopted, a literal here would
    # let `spans` keep reporting 0.15 after someone changed no_signal_frac, and
    # the command you would reach for to check the threshold would be the one
    # command that could not see it had moved.
    print("  file                                        A     minR  minR_at"
          "      p1  flat_s@%.2f  sat_s@%.0f  sat10_s     maxR  maxR_at"
          % (profile.no_signal_frac, profile.saturated_frac))
    print("  " + "-" * 128)

    rows = []
    for path in files:
        name = os.path.basename(path)
        try:
            r = analyse(path, args, profile)
        except Exception as e:                               # noqa: BLE001
            if getattr(args, "traceback", False):
                raise
            print("  %-38s FAILED: %s" % (name[:38], e))
            continue
        amp_a = median_qrs_amp(r.wide, r.anchors, r.fs, profile)
        if not np.isfinite(amp_a):
            print("  %-38s no QRS scale (%d beats)" % (name[:38], len(r.anchors)))
            continue
        rng, t = windowed_range(r.wide, r.fs, args.win, args.step)
        if not len(rng):
            print("  %-38s shorter than one window" % name[:38])
            continue
        ratio = rng / amp_a
        i_lo, i_hi = int(np.argmin(ratio)), int(np.argmax(ratio))
        flat_s = sum(b - a for a, b in
                     spans_from_mask(ratio < profile.no_signal_frac, t,
                                     args.step, args.min_span))
        sat7 = sum(b - a for a, b in
                   spans_from_mask(ratio > profile.saturated_frac, t,
                                   args.step, args.min_span))
        sat10 = sum(b - a for a, b in
                    spans_from_mask(ratio > 10.0, t, args.step, args.min_span))
        row = dict(name=name, A=amp_a, minR=float(ratio[i_lo]),
                   minR_at=float(t[i_lo]), p1=float(np.percentile(ratio, 1.0)),
                   flat_s=flat_s, sat7=sat7, sat10=sat10,
                   maxR=float(ratio[i_hi]), maxR_at=float(t[i_hi]),
                   ratio=ratio, t=t, dur=r.dur, n=len(r.anchors))
        rows.append(row)
        print("  %-38s %8.5g %8.3f %8.1f %7.3f %8.1f %8.1f %8.1f %8.2f %8.1f"
              % (name[:38], row["A"], row["minR"], row["minR_at"], row["p1"],
                 flat_s, sat7, sat10, row["maxR"], row["maxR_at"]))

        if getattr(args, "hist", False):
            counts, _ = np.histogram(ratio, bins=SPAN_BINS)
            top = max(1, int(counts.max()))
            for i, c in enumerate(counts):
                lo_b, hi_b = SPAN_BINS[i], SPAN_BINS[i + 1]
                label = ("%5.2f - %5.2f" % (lo_b, hi_b) if np.isfinite(hi_b)
                         else "%5.2f +     " % lo_b)
                print("        %s  %8d  %6.2f   %s"
                      % (label, c, 100.0 * c / len(ratio),
                         "#" * int(round(40.0 * c / top))))
            for kind, cuts, fn in (("flat", FLAT_TRIALS, lambda c: ratio < c),
                                   ("sat", SAT_TRIALS, lambda c: ratio > c)):
                print("        %-5s cut   spans   total_s   longest_s   at_s" % kind)
                for cut in cuts:
                    sp = spans_from_mask(fn(cut), t, args.step, args.min_span)
                    tot = sum(b - a for a, b in sp)
                    la, lb = (max(sp, key=lambda ab: ab[1] - ab[0])
                              if sp else (float("nan"), float("nan")))
                    print("        %9.2f   %5d  %8.1f  %10.1f  %7.1f"
                          % (cut, len(sp), tot, (lb - la) if sp else 0.0, la))

    if not rows:
        return 1

    # ---- the bound.  A file with NO flat span provably has no dropout, so the
    # lowest windowed range it ever shows is legitimate signal, and the flat cut
    # must sit below it.  This is the same construction as k_min: bound the
    # threshold by the worst thing measured rather than by a round number.
    print("  " + "-" * 128)
    dropout_free = [w for w in rows if w["flat_s"] == 0.0]
    print("  %d of %d file(s) carry no flat span at %.2f and so provably "
          "contain no dropout." % (len(dropout_free), len(rows),
                                   profile.no_signal_frac))
    if dropout_free:
        worst = min(dropout_free, key=lambda w: w["minR"])
        print("  Lowest range/A on any dropout-free file: %.3f  (%s at t=%.0f s)"
              % (worst["minR"], worst["name"], worst["minR_at"]))
        flat_hi = worst["minR"]
        flat_lo = max([float(np.max(w["ratio"][w["ratio"] < profile.no_signal_frac]))
                       for w in rows if w["flat_s"] > 0.0] or [0.0])
        if flat_lo > 0:
            print("  Highest range/A inside a detected flat span:        %.3f"
                  % flat_lo)
            mid = float(np.sqrt(max(flat_lo, 1e-6) * flat_hi))
            print("  => safe window for the flat cut: %.3f .. %.3f, "
                  "geometric midpoint %.3f" % (flat_lo, flat_hi, mid))
            print("     separation %.1fx.  A cut is safe in proportion to this"
                  % (flat_hi / max(flat_lo, 1e-6)))
            print("     ratio, not to where it sits between the two numbers.")
        else:
            print("  No file here has a flat span, so the cut is bounded from")
            print("  ABOVE only.  Run a file with a known dropout to bound it")
            print("  from below before fixing the number.")
        hi_clean = max(w["maxR"] for w in dropout_free)
        print("  Highest range/A on a dropout-free file: %.2f  -- any saturation"
              % hi_clean)
        print("  cut must sit above this or it will excise clean signal.")
    print()
    print("  minR / maxR are the extremes over every window; p1 is the 1st")
    print("  percentile.  flat_s is how much time the ADOPTED no-signal cut")
    print("  would select, sat_s the adopted saturation cut, sat10_s a stricter")
    print("  trial.  Nothing is suppressed by this run: excision is forced off")
    print("  here so that the measurement cannot be conditioned on its own")
    print("  conclusion.  To see the cut ACTING, run `report`.")
    return 0


def print_rate_block(r):
    ig, qc = r.integrity, r.qc
    print("-" * 108)
    print("  rate           %.2f bpm   (beats/duration -- the estimator that couplets do not bias)"
          % ig["bpm"])
    print("  modal rate     %.2f bpm   (%.0f ms)   short intervals %.1f%% of beats"
          % (ig["modal_bpm"], ig["modal_rr_ms"], ig["short_pct"]))
    print("  QC             %.1f%% of %d windows accepted; gated rate %.2f bpm (sd %.2f)"
          % (qc["accept_pct"], qc["n_windows"], qc["gated_bpm"], qc["gated_sd"]))
    print("  morphology     tmplQ %.3f over %d cluster(s); clipped %.3f%% of samples"
          % (r.tmplq, r.n_clusters, 100.0 * r.clip_frac))
    print("  completeness   maxGap %.1fx baseline; %d gap(s) >1.8x; %.2f%% of time in gaps"
          % (ig["max_gap"], ig["n_gaps"], ig["gap_time_pct"]))
    # Only printed when it is not the whole file.  A line saying "0.0 s excised"
    # on every clean record is noise, and noise is how a line that matters gets
    # skipped.  When it IS printed, it shows the whole arithmetic, because the
    # rate above is a ratio of two numbers that both just changed.
    if ig.get("nosig_s", 0.0) > 0:
        print("  coverage       %.1f s of %.1f s excised as NO SIGNAL; rate is over "
              "the remaining %.1f s"
              % (ig["nosig_s"], r.dur, ig.get("analysable_s", float("nan"))))
        print("                 %d beat(s) inside it were dropped with it, and %d "
              "interval(s) bridging it"
              % (ig.get("nosig_dropped", 0), ig.get("n_bridging", 0)))
        print("                 are excluded from the gap figures above.")
    _es = ig.get("empty_s", 0.0) or 0.0
    if _es > 0 or ig.get("keep_empty"):
        if ig.get("keep_empty"):
            print("  empty gaps     KEPT as real pauses (--keep-empty): %.1f s in"
                  " %d beatless gap(s) stay in the denominator"
                  % (_es, ig.get("n_empty", 0)))
        else:
            print("  empty gaps     DROPPED (default): %.1f s in %d beatless"
                  " gap(s) > %.1fx baseline RR excised;"
                  % (_es, ig.get("n_empty", 0),
                     getattr(r, "empty_gap_mult", 3.0)))
            print("                 rate is over %.1f s of %.1f s.  --keep-empty"
                  " counts them as pauses."
                  % (ig.get("analysable_s", float("nan")), r.dur))
    if ig.get("sat_s", 0.0) > 0:
        print("  saturation     %.1f s above %.0fx the median QRS.  ADVISORY: nothing "
              "is removed" % (ig["sat_s"], r.profile.saturated_frac))
        print("                 for this, because saturated stretches here still "
              "carry real beats.")
    if ig["flags"]:
        print("  ** FLAGS: %s" % ", ".join(ig["flags"]))
        if "DROPOUT_SUSPECTED" in ig["flags"]:
            print("     The measured rate is BELOW the modal rate while the short")
            print("     population is small.  Only early beats can push the mean above")
            print("     the mode, so their absence means beats are MISSING, not early.")
            print("     Treat this file's rate as a lower bound until reviewed.")
        if "NO_SIGNAL" in ig["flags"]:
            print("     ADVISORY.  The dead time has been removed from BOTH the beat")
            print("     count and the duration, so the rate above is over real signal")
            print("     only and can be believed.  What cannot be known is what")
            print("     happened during the excised stretch; nothing here claims to.")
        if "NO_SIGNAL_MAJOR" in ig["flags"]:
            print("     DISQUALIFYING.  More than %.0f%% of this record is dead."
                  % (100.0 * NO_SIGNAL_MAJOR_FRAC))
            print("     The excision arithmetic is the same as the advisory case and")
            print("     is still correct, but reporting a confident rate for a small")
            print("     surviving fraction of a record invites it to be read as a")
            print("     fact about the whole recording.  Look at the file.")
    else:
        print("  ** no integrity flags")


# ==================================================================== compare

def _lag_coverage(a, b, lag, tol_s):
    """Fraction of `a` that finds a partner in `b` within tol once shifted."""
    if not len(a) or not len(b):
        return 0.0
    x = a + lag
    i = np.searchsorted(b, x)
    i0 = np.clip(i - 1, 0, len(b) - 1)
    i1 = np.clip(i, 0, len(b) - 1)
    d = np.minimum(np.abs(b[i0] - x), np.abs(b[i1] - x))
    return float(np.mean(d <= tol_s))


def peak_train_lag(auto_s, man_s, max_lag_s=5.0, tol_s=0.05, bin_s=0.010,
                   topk=64):
    """MEASURE the constant offset between two peak trains.  Never assume it.

    Two beat lists of the same heart can be written against different origins,
    and nothing in either file forces them to agree.  Ponemah's `Cycle` export
    is timed from ITS FIRST BEAT; a waveform read from sample zero is timed
    from the START OF THE RECORDING.  On P10 those differ by 0.254 s -- the
    first beat lands a quarter-second into the file.  That is five times the
    50 ms matching window, so every beat would miss its partner and the score
    would come back near zero on two lists that actually agree.  The failure is
    silent and it looks exactly like a broken detector.

    A histogram of pairwise differences finds candidate offsets, but its peak
    height CANNOT score them, and the first version of this function was wrong
    for exactly that reason.  A beat train is periodic: at RR = 0.6 s, shifting
    by 0.254 s and by 0.854 s both line every beat up against SOME beat, so the
    two bins tie at 400 votes each and the "peak over median bin" ratio reads
    1.0 -- indistinguishable from noise -- while argmax silently picks whichever
    alias came first.  Selftest [22] caught it choosing -0.946 s on a train
    built with a +0.254 s shift.

    So candidates are scored by COVERAGE: the fraction of beats in (a) that
    land within tol of a beat in (b).  Coverage separates the real cases --
    ~1.0 for two renderings of one recording, ~2*tol*rate for unrelated lists --
    and it does not care how tall any bin was.

    The periodic aliases still tie on coverage, because on a perfectly regular
    train they are genuinely indistinguishable from the beat times alone.  The
    tie is broken toward the SMALLEST |lag|, which is the only defensible
    choice: a larger alias claims beat k of one list is beat k+1 of the other,
    which is a different assertion than a clock offset and one no evidence
    here supports.  Real ECG breaks the tie by itself -- RR varies, so only the
    true offset aligns every beat -- and the tie-break then never engages.

    Returns (lag_s, n_matched, coverage).  `coverage` is 0..1 and is the number
    to threshold on.  Nothing is applied here; the caller decides.
    """
    a = np.asarray(auto_s, dtype=float)
    b = np.asarray(man_s, dtype=float)
    if len(a) < 2 or len(b) < 2:
        return 0.0, 0, 0.0
    lo = np.searchsorted(b, a - max_lag_s, side="left")
    hi = np.searchsorted(b, a + max_lag_s, side="right")
    diffs = [b[lo[i]:hi[i]] - a[i] for i in range(len(a)) if hi[i] > lo[i]]
    if not diffs:
        return 0.0, 0, 0.0
    d = np.concatenate(diffs)
    if not len(d):
        return 0.0, 0, 0.0
    nb = max(1, int(round(2.0 * max_lag_s / bin_s)))
    hist, edges = np.histogram(d, bins=nb, range=(-max_lag_s, max_lag_s))
    order = np.argsort(hist)[::-1][:topk]
    best = []
    for k in order:
        if hist[k] <= 0:
            continue
        # The bin edge is arbitrary; the differences inside it are not.
        sel = d[(d >= edges[k] - bin_s) & (d <= edges[k + 1] + bin_s)]
        cand = float(np.mean(sel)) if len(sel) else float(
            0.5 * (edges[k] + edges[k + 1]))
        best.append((_lag_coverage(a, b, cand, tol_s), cand))
    if not best:
        return 0.0, 0, 0.0
    top = max(c for c, _ in best)
    # Among candidates that explain essentially as much, take the least shift.
    near = [lg for c, lg in best if c >= top - 1e-9 or c >= 0.98 * top]
    lag = min(near, key=abs) if near else 0.0
    cov = _lag_coverage(a, b, lag, tol_s)
    return lag, int(round(cov * len(a))), cov


def match_peaks(auto_s, man_s, tol_s):
    """One-to-one nearest matching within tol.  Greedy on |dt|, which is
    optimal enough here because tol is far below the beat interval."""
    pairs = []
    if len(auto_s) and len(man_s):
        j0 = 0
        for i, t in enumerate(auto_s):
            while j0 < len(man_s) and man_s[j0] < t - tol_s:
                j0 += 1
            j = j0
            while j < len(man_s) and man_s[j] <= t + tol_s:
                pairs.append((abs(man_s[j] - t), i, j))
                j += 1
    pairs.sort()
    ua, um = set(), set()
    matched = []
    for d, i, j in pairs:
        if i in ua or j in um:
            continue
        ua.add(i); um.add(j); matched.append((i, j, d))
    fp = [i for i in range(len(auto_s)) if i not in ua]
    fn = [j for j in range(len(man_s)) if j not in um]
    return matched, fp, fn


def arbitrate(auto_s, man_s, fp, fn, arb_s, tol_s):
    """Ask a THIRD simultaneous lead about each disagreement.  No printing.

    A two-way comparison can say that (a) and (b) disagree.  It cannot say
    which is wrong, and on this project that limitation is not academic:
    Ponemah's own two ECG leads disagree with each other by 7,902 beats on
    P10, so `(b) rejected it` is not evidence that a detection is false.

    A third lead can say, because the underlying fact is not in dispute.
    Every lead is wired to the same heart and sees every beat; only the
    DETECTIONS differ.  So a beat that (a) reports, (b) does not, and the
    arbiter does, is a beat (b) missed -- and a beat that (a) reports and
    neither of the others does is one of the few that might be (a)'s.

    This is the majority vote made explicit, and it is the strongest thing
    available short of a human reading the trace, because there is no ground
    truth in these files.  Two important limits, both of which the caller
    has to police rather than this function:

      * the arbiter must be a DIFFERENT electrode from (b), or it is not an
        independent witness, and
      * it must be a different electrode from (a) too.  A noise spike is a
        property of an electrode; two detectors on one wire will confirm
        each other's artifacts happily.

    Returns dict of INDEX lists into fp / fn:
      fp_yes  (a) found it, (b) did not, the arbiter agrees with (a)
      fp_no   only (a) has it -- unconfirmed, the honest FP ceiling
      fn_yes  (b) has it, the arbiter agrees, (a) genuinely missed it
      fn_no   only (b) has it -- likely (b)'s own error
    """
    arb = np.sort(np.asarray(arb_s, dtype=float))

    def _near(t):
        if not len(arb):
            return False
        k = int(np.searchsorted(arb, t))
        for kk in (k - 1, k):
            if 0 <= kk < len(arb) and abs(arb[kk] - t) <= tol_s:
                return True
        return False

    return dict(
        fp_yes=[i for i in fp if _near(float(auto_s[i]))],
        fp_no=[i for i in fp if not _near(float(auto_s[i]))],
        fn_yes=[j for j in fn if _near(float(man_s[j]))],
        fn_no=[j for j in fn if not _near(float(man_s[j]))])


# ------------------------------------------------- choosing the arbiter
#
# The arbiter used to be something the user had to know to ask for, and had
# to pick by hand.  Everything needed to pick it is measurable, so it is now
# measured.  The numbers that set these constants, all on P10 after the clock
# offset is removed:
#
#   median |dt| between matched beats
#     ours  vs Ponemah ch3    0.2 ms    one electrode, two detectors
#     ours  vs Ponemah ch4    2.0 ms    two electrodes
#     ch3   vs ch4            2.4 ms    two electrodes
#   F1 of ch3 vs ch4          ~95%      two good leads on one heart
#   Ponemah ch1               missed ~84% of beats
#
# A median |dt| under ARBITER_SAME_ELECTRODE_MS therefore means ONE wire: the
# R peak arrives at a slightly different instant on every electrode, and two
# detectors on the same wire agree to a fraction of a sample (2 ms at 500 Hz).
# 1.0 ms sits 5x above the same-wire figure and 2x below the nearest
# different-wire one.  Such a candidate is not an independent witness and is
# rejected -- see arbitrate() for why that is a refusal and not a nuance.
ARBITER_SAME_ELECTRODE_MS = 1.0
# Below this F1 against (b) the chosen arbiter is still used -- a weak third
# opinion is better than none -- but the run says so, because a lead that
# misses one beat in ten turns many of (b)'s real beats into "(b) alone".
ARBITER_WARN_F1 = 0.90
# The same floor the manual --arbiter path uses to accept a clock offset: a
# simultaneous lead lines up ~100% of beats, an unrelated list ~2*tol*rate.
ARBITER_MIN_COVERAGE = 0.5


def _median_abs_dt_ms(x_s, y_s, tol_s):
    """(median |dt| in ms over matched pairs, n_matched, f1) of two trains."""
    if not len(x_s) or not len(y_s):
        return float("nan"), 0, 0.0
    matched, _fp, _fn = match_peaks(x_s, y_s, tol_s)
    tp = len(matched)
    sens = tp / float(len(y_s))
    ppv = tp / float(len(x_s))
    f1 = (2 * sens * ppv / (sens + ppv)) if (sens + ppv) else 0.0
    if not tp:
        return float("nan"), 0, f1
    return float(np.median([d for _, _, d in matched])) * 1000.0, tp, f1


def marks_arbiter_candidates(path):
    """Every Ponemah channel context in a .PnmMarks, as arbiter candidates.

    Returns (candidates, note).  Each candidate is a dict with times_s (on the
    recording's clock where the .PnmWav companion states it, else on the
    sidecar's first beat -- compare measures the residual either way), the
    subject channel, the context id and whether it is CARDIAC.

    Beats inside Ponemah's own BadDataMark intervals are dropped, exactly as
    `marks --export-beats` writes them keep=0 and read_peaks drops them.  A
    candidate must be scored on the same footing as a (b) exported that way,
    or its F1 against (b) would be depressed by beats (b) never contained.
    """
    m = read_marks(path)
    if not m["ok"]:
        return [], "cannot read %s: %s" % (os.path.basename(path), m["why"])
    exp_t0, _src = _pnm_container_origin(path)
    if exp_t0 is None:
        exp_t0 = m["t0"]
    merged = merge_tick_spans([(a, b) for _s, a, b in m["bad"]])
    starts = np.array([a for a, _ in merged], dtype=np.int64)
    ends = np.array([b for _, b in merged], dtype=np.int64)
    out = []
    for c in m["contexts"]:
        t = np.asarray(c["times"], dtype=np.int64)
        if len(merged) and len(t):
            i = np.searchsorted(starts, t, side="right") - 1
            bad = (i >= 0) & (t <= ends[np.clip(i, 0, None)])
            t = t[~bad]
        fs = c.get("fs")
        sub = c.get("SubjectChannelId")
        out.append(dict(
            label="%s ctx %d" % (os.path.basename(path), c["ctx"]),
            times_s=np.sort((t - int(exp_t0)) / float(NET_TICKS_PER_S)),
            ch=("" if sub is None else str(sub)).strip(),
            ctx=int(c["ctx"]), src=os.path.abspath(path),
            cardiac=(fs is None) or (float(fs) >= 100.0),
            fs=fs))
    return out, ""


def csv_arbiter_candidate(path):
    """One peak file (e.g. `marks --export-beats` output) as a candidate."""
    t, meta, _rows = read_peaks(path)
    mctx = re.search(r"ChannelContextId\s+(\d+)", meta.get("origin", "") or "")
    fs = None
    try:
        fs = float(meta.get("fs_hz", "") or 0) or None
    except ValueError:
        fs = None
    return dict(label=os.path.basename(path), times_s=np.sort(t),
                ch=(meta.get("subject_channel") or "").strip(),
                ctx=int(mctx.group(1)) if mctx else None,
                src=os.path.abspath(meta.get("source_file") or path),
                path=os.path.abspath(path),
                seg_off=meta.get("segment_offset_s"),
                # An epoch context exported by mistake is caught by the
                # measurements anyway; only a STATED low rate rejects here.
                cardiac=(fs is None) or (fs >= 100.0), fs=fs)


def find_marks_file(inputs, man_meta=None):
    """The .PnmMarks to draw arbiter candidates from, and how it was found.

    In this order, and stopping at the first that answers:
      1. the file (b) itself says it came from (`# source_file:` written by
         `marks --export-beats`), if it exists here;
      2. the directory of the first --input, then its parent -- the P10
         layout keeps the sidecar one level above `sample EDFs/`.
    Only a directory holding EXACTLY ONE .PnmMarks answers.  Two means two
    animals or two sessions, and guessing between them would draw the
    arbiter from the wrong heart; that is reported rather than resolved.
    Returns (path or None, note).
    """
    src = ((man_meta or {}).get("source_file") or "").strip()
    if src and src.lower().endswith(".pnmmarks") and os.path.isfile(src):
        return src, "the file (b) was exported from"
    first = None
    for p in (inputs or []):
        if p:
            first = p
            break
    if not first:
        return None, "no --input to look beside, and (b) names no sidecar"
    d = os.path.dirname(os.path.abspath(first))
    for where, dd in (("beside --input", d),
                      ("in --input's parent folder", os.path.dirname(d))):
        try:
            hits = sorted(os.path.join(dd, n) for n in os.listdir(dd)
                          if n.lower().endswith(".pnmmarks")
                          and os.path.isfile(os.path.join(dd, n)))
        except OSError:
            hits = []
        if len(hits) == 1:
            return hits[0], "found %s" % where
        if len(hits) > 1:
            return None, ("%d .PnmMarks files %s (%s) -- ambiguous; pass "
                          "--marks" % (len(hits), where, dd))
    return None, "no .PnmMarks beside --input or in its parent folder"


def select_arbiter(auto_s, man_s, cands, tol_s, align=True, max_lag_s=5.0,
                   cmp_win=None, man_ch="", auto_ch="", a_is_pon=False,
                   man_ctx=None, man_src="", man_path=""):
    """Pick the third lead automatically.  No printing.  Returns (chosen, rows).

    The rule, in order, per candidate:
      * not cardiac (a 1-10 Hz epoch context)             -> rejected
      * IS (b): same context of the same sidecar, or the same file
                                                            -> rejected
      * no clock offset puts it on (b)'s or (a)'s clock: fewer than
        ARBITER_MIN_COVERAGE of that list's beats find a partner
                                                            -> rejected
      * same subject channel as (b), or as (a) when (a) is itself a Ponemah
        list (channel numbers are Ponemah's, so they are only compared
        between Ponemah lists; a detection's own lead is judged by timing)
                                                            -> rejected
      * median |dt| vs (b) or vs (a) under ARBITER_SAME_ELECTRODE_MS: the
        same wire as that list, so not an independent witness -> rejected
    Among the rest the highest F1 against (b) wins.  (b) is the list whose
    disagreements with (a) the arbiter must adjudicate, so agreement with it
    on the beats they share is the qualification that matters.

    Offsets are measured, never assumed: once against (b) for the F1 and the
    (b) timing, once against (a) for the (a) timing and for the arbitration
    itself -- which is how the manual --arbiter path aligns, so both paths
    hand arbitrate() the same thing.  `chosen["times_a"]` is on (a)'s clock
    and cut to the compared window.
    """
    auto_s = np.sort(np.asarray(auto_s, dtype=float))
    man_s = np.sort(np.asarray(man_s, dtype=float))
    rows = []
    man_src_b = os.path.basename(man_src or "")

    def _cut(x):
        if cmp_win is None:
            return x
        return x[(x >= -tol_s) & (x <= cmp_win + tol_s)]

    for c in cands:
        t = np.sort(np.asarray(c.get("times_s", []), dtype=float))
        row = dict(label=c.get("label", "?"), ch=c.get("ch") or "",
                   ctx=c.get("ctx"), n=0, lag_b=float("nan"),
                   cov_b=float("nan"), f1_b=float("nan"),
                   dt_a_ms=float("nan"), dt_b_ms=float("nan"),
                   lag_a=float("nan"), cov_a=float("nan"),
                   ok=False, why="", times_a=None)
        rows.append(row)
        if not c.get("cardiac", True):
            fs = c.get("fs")
            row["why"] = ("not cardiac: %s Hz epoch ticks, not beats"
                          % ("%g" % fs if fs else "?"))
            continue
        same_b = False
        if (man_ctx is not None and c.get("ctx") is not None
                and int(c["ctx"]) == int(man_ctx) and man_src_b
                and os.path.basename(c.get("src") or "") == man_src_b):
            same_b = True
        if man_path and c.get("path"):
            try:
                same_b = same_b or os.path.samefile(c["path"], man_path)
            except OSError:
                pass
        if same_b:
            row["why"] = "this IS (b): same list, not a third opinion"
            continue
        if len(t) < 2 or len(man_s) < 2:
            row["why"] = "too few beats to measure"
            continue
        if align:
            lag_b, _nb, cov_b = peak_train_lag(man_s, t, max_lag_s=max_lag_s,
                                               tol_s=tol_s)
        else:
            lag_b, cov_b = 0.0, _lag_coverage(man_s, t, 0.0, tol_s)
        row["lag_b"], row["cov_b"] = float(lag_b), float(cov_b)
        tb = _cut(t - lag_b)
        row["n"] = int(len(tb))
        row["dt_b_ms"], _tpb, row["f1_b"] = _median_abs_dt_ms(tb, man_s, tol_s)
        if len(auto_s) >= 2:
            if align:
                lag_a, _na, cov_a = peak_train_lag(auto_s, t,
                                                   max_lag_s=max_lag_s,
                                                   tol_s=tol_s)
            else:
                lag_a, cov_a = 0.0, _lag_coverage(auto_s, t, 0.0, tol_s)
            row["lag_a"], row["cov_a"] = float(lag_a), float(cov_a)
            ta = _cut(t - lag_a)
            row["dt_a_ms"], _tpa, _f1a = _median_abs_dt_ms(ta, auto_s, tol_s)
            row["times_a"] = ta
        if not cov_b >= ARBITER_MIN_COVERAGE:
            row["why"] = ("only %.0f%% of (b)'s beats find a partner at the "
                          "best offset (need %.0f%%)"
                          % (100.0 * cov_b, 100.0 * ARBITER_MIN_COVERAGE))
            continue
        if not (row["cov_a"] >= ARBITER_MIN_COVERAGE):
            row["why"] = ("only %.0f%% of (a)'s beats find a partner at the "
                          "best offset (need %.0f%%)"
                          % (100.0 * (row["cov_a"] if np.isfinite(row["cov_a"])
                                      else 0.0),
                             100.0 * ARBITER_MIN_COVERAGE))
            continue
        if man_ch and row["ch"] and row["ch"] == man_ch:
            row["why"] = "same subject channel as (b) (%s)" % man_ch
            continue
        if a_is_pon and auto_ch and row["ch"] and row["ch"] == auto_ch:
            row["why"] = "same subject channel as (a) (%s)" % auto_ch
            continue
        if row["dt_b_ms"] < ARBITER_SAME_ELECTRODE_MS:
            row["why"] = ("same electrode as (b): median |dt| %.2f ms < %.1f ms"
                          % (row["dt_b_ms"], ARBITER_SAME_ELECTRODE_MS))
            continue
        if row["dt_a_ms"] < ARBITER_SAME_ELECTRODE_MS:
            row["why"] = ("same electrode as (a): median |dt| %.2f ms < %.1f ms"
                          % (row["dt_a_ms"], ARBITER_SAME_ELECTRODE_MS))
            continue
        row["ok"] = True
        row["why"] = "independent of (a) and (b)"
    ok = [r for r in rows if r["ok"]]
    chosen = max(ok, key=lambda r: (r["f1_b"], -abs(r["lag_b"]))) if ok else None
    if chosen is not None:
        chosen["why"] = "CHOSEN: highest F1 vs (b) among independent leads"
        if chosen["f1_b"] < ARBITER_WARN_F1:
            chosen["why"] += " (below %.0f%% -- weak)" % (100.0 * ARBITER_WARN_F1)
    return chosen, rows


def _row_time_in(row, lo_s, hi_s, meta, shift_s=0.0):
    """Is this peak-file row inside [lo_s, hi_s]?

    Kept beside the array clip in `compare` so the rows and the times cannot
    drift apart: the counts printed at the end are taken from the rows, and if
    only the array were cut they would describe a different window than the
    score above them.

    shift_s is added to the row's own time before the test, and exists for the
    same reason.  `compare` moves the reference train onto the recording's
    clock before it cuts it to the read window; a row filter that skipped that
    step would cut the rows on the ORIGINAL clock and the two would disagree
    by the offset -- on P10, 254 ms, which is a beat every few hundred
    windows and silently lands in the first and last window only.  Pass the
    same shift that was applied to the array.
    """
    t = (row.get("time_s") or "").strip()
    if not t:
        s = (row.get("sample") or "").strip()
        if not s:
            return True
        try:
            fs = float(meta.get("fs_hz", "0") or 0)
        except ValueError:
            return True
        if fs <= 0:
            return True
        try:
            t = float(s) / fs
        except ValueError:
            return True
    try:
        tv = float(t)
    except ValueError:
        return True
    return lo_s <= tv + shift_s <= hi_s


PNM_EXTS = {".pnmwav", ".pnmmarks", ".pnmexp", ".pnmresults", ".pnmexplog"}


def _pnm_siblings(fa, fm):
    """Are these two paths companion files of ONE Ponemah experiment?

    `compare` warns when (a) and (b) name different source files, which is a
    warning worth having: scoring a detection on one animal against a beat
    list from another is a mistake that produces plausible-looking numbers.

    But the normal Ponemah workflow trips it every single time.  The waveform
    is `<exp>.<animal>.<stamp>.PnmWav` and the beat list comes from
    `<exp>.N.<animal>.PnmMarks` -- different files by construction, the same
    recording by construction.  A warning that fires on every correct run
    teaches the reader to skip warnings, and the next one may be real.

    The test is deliberately narrow.  Both must sit in the same directory,
    both must carry a Ponemah extension, and both basenames must begin with
    the same experiment token -- the text before the first dot, which on P10
    is `08062023 P10` for the waveform and for the sidecar alike.  A
    directory holding two animals therefore still warns, because their
    experiment tokens differ.
    """
    if not fa or not fm:
        return False
    if os.path.dirname(os.path.abspath(fa)) != os.path.dirname(os.path.abspath(fm)):
        return False
    ba, bm = os.path.basename(fa), os.path.basename(fm)
    if os.path.splitext(ba)[1].lower() not in PNM_EXTS:
        return False
    if os.path.splitext(bm)[1].lower() not in PNM_EXTS:
        return False
    ta, tm = ba.split(".", 1)[0].strip(), bm.split(".", 1)[0].strip()
    return bool(ta) and ta == tm


def _pnm_container_origin(path, limit=4000):
    """(ticks, note) for the RECORDING's start, from the .PnmWav beside `path`.

    A sidecar states beat times as absolute .NET ticks and has no opinion on
    where the waveform begins.  Exporting them relative to the FIRST BEAT is
    therefore a guess dressed as an origin, and on P10 it is wrong by 0.254 s:
    the container starts on a whole second (tag 5038, `...990000000`, zero
    ticks past) and the first beat arrives 2,540,000 ticks later.  Nothing is
    defective about that -- a heart does not beat at sample zero -- but an
    export that calls the first beat t=0 shifts every beat and every bad-data
    edge by the gap.

    `compare` already measures and removes that offset, so the SCORES were
    never wrong.  What was wrong is everything that cannot measure it: a peak
    file handed to `show` draws every marker a quarter-second from its beat,
    which is why that command has had to carry a warning about it.  Fixing the
    origin at the source removes the warning and the trap together.

    Only a small prefix of the chain is walked: the timestamps sit at offsets
    120 and 1024 on P10, and walking 197 MB to read byte 1024 would make every
    `marks` run pay for the whole file.

    Returns (None, reason) rather than raising or guessing.  A missing or
    unreadable companion is normal -- sidecars travel alone -- and the caller
    must be able to say which origin it used.
    """
    d = os.path.dirname(os.path.abspath(path))
    try:
        names = sorted(os.listdir(d))
    except OSError as e:                                     # noqa: BLE001
        return None, "cannot list %s (%s)" % (d, e)
    cands = [os.path.join(d, n) for n in names
             if os.path.splitext(n)[1].lower() == ".pnmwav"
             and _pnm_siblings(os.path.join(d, n), path)]
    if not cands:
        return None, "no .PnmWav companion in the same directory"
    wav = cands[0]
    try:
        _sz, recs, _stop, _why, _how = pnmwav_walk_file(wav, limit=limit)
    except OSError as e:                                     # noqa: BLE001
        return None, "cannot read %s (%s)" % (os.path.basename(wav), e)
    # Same agreement rule as everywhere else: an 8-byte integer is a plausible
    # date under several epochs, so a decode on its own is worth nothing.
    tk = pnmwav_start_ticks(recs, want_dt=_parse_name_start(wav))
    if tk is None:
        return None, ("%s states no start that agrees with its filename"
                      % os.path.basename(wav))
    return int(tk), os.path.basename(wav)


def _shq(s):
    """Quote a path for a command line that a human will paste.

    Every Ponemah path in this project contains a space -- the directory is
    `08062023 P10` and the files repeat the animal name -- so a hint printing
    a bare path emits a command that splits into two arguments and fails.  A
    printed command that cannot be run is worse than no hint, because it
    costs a round trip to find out.
    """
    import shlex
    return shlex.quote(str(s))


def write_compare_diff(path, fp_s, fn_s, tp_s, meta, wsz=60.0, arb=None,
                       t_off=0.0):
    """Write `compare`'s disagreements as a peak file, on the RECORDING's clock.

    The point of this file is to be handed straight back to `show`, so the
    beats that disagree can be looked at instead of merely counted.  That
    imposes two requirements that are easy to get wrong.

    First, the clock.  `compare` measures an offset between the two trains --
    on P10, 254 ms, from the sidecar timing its beats from the first beat
    while the waveform starts at sample zero.  Until this file existed, the
    closing hint told the reader to run `show --peaks ponemah.csv`, which
    draws that file's RAW times: every marker 254 ms off its beat, on a
    display whose whole purpose is judging whether a marker sits on a beat.
    A reader would have seen the detector missing every single QRS by a
    quarter second and had no way to know the display was lying.  So the
    times written here are already on the recording's clock and need no
    further correction by anything downstream.

    Second, the display scale.  `show` scales panels to the median height of
    the peaks in view, which is what stops one artifact from flattening every
    real beat.  If this file held only FPs and FNs, that scale would be built
    from the handful of disputed points -- quite possibly noise spikes -- and
    the panel would be unreadable exactly where it matters.  So the agreed
    beats are written too, with keep=1, and they carry the scale.  Use
    `show --mark-source FP,FN` to draw only the disputed ones over a
    correctly scaled trace.

    `arb`, when given, is {"fp_yes": set-of-times, "fn_yes": set-of-times}
    from a third lead, and each disputed row's note records that lead's
    verdict.  It goes in the note rather than the source column on purpose:
    changing the source would silently change what `--mark-source FP,FN`
    draws, and a row's source should keep meaning "who reported this beat",
    not "who was right about it".

    `t_off` is the stretch start when compare scored one stretch (--start,
    or a segment page's header): times arrive counted from it and are
    written with it added back, so the file stays on the RECORDING's clock;
    the w<N> window notes keep counting from the stretch, as printed.
    """
    arb = arb or {}
    fp_yes = set(arb.get("fp_yes") or ())
    fn_yes = set(arb.get("fn_yes") or ())
    have_arb = bool(arb)

    def _note(t, kind):
        w = "w%d" % int(t // wsz)
        if not have_arb or kind == "TP":
            return w
        yes = (t in fp_yes) if kind == "FP" else (t in fn_yes)
        return "%s %s" % (w, "arb=yes" if yes else "arb=no")

    rows = []
    for t in fp_s:
        rows.append(dict(time_s="%.4f" % (t + t_off), sample="", amp="",
                         rhythm="", cluster=-1, qc=0, source="FP", keep=1,
                         note=_note(t, "FP")))
    for t in fn_s:
        rows.append(dict(time_s="%.4f" % (t + t_off), sample="", amp="",
                         rhythm="", cluster=-1, qc=0, source="FN", keep=1,
                         note=_note(t, "FN")))
    for t in tp_s:
        rows.append(dict(time_s="%.4f" % (t + t_off), sample="", amp="",
                         rhythm="", cluster=-1, qc=1, source="TP", keep=1,
                         note=_note(t, "TP")))
    rows.sort(key=lambda d: float(d["time_s"]))

    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)
    with open(path, "w", newline="") as f:
        f.write("# %s\n" % VERSION)
        for k in ("source_file", "fs_hz", "duration_s", "lead", "lead_name",
                  "species", "config", "config_sha1"):
            if meta.get(k):
                f.write("# %s: %s\n" % (k, meta[k]))
        f.write("#\n")
        f.write("# compare disagreements.  source=FP  (a) found it, (b) did not\n")
        f.write("#                         source=FN  (b) marked it, (a) missed it\n")
        f.write("#                         source=TP  both agreed\n")
        f.write("# n_fp: %d\n" % len(fp_s))
        f.write("# n_fn: %d\n" % len(fn_s))
        f.write("# n_tp: %d\n" % len(tp_s))
        f.write("#\n")
        f.write("# TIMES ARE ON THE RECORDING'S CLOCK -- the measured offset\n")
        f.write("# between the two peak trains has ALREADY been removed, so\n")
        f.write("# these seek directly with `show --start`.  Do not shift them\n")
        f.write("# again.\n")
        if t_off:
            f.write("# stretch_start_s: %.4f  (compare scored one stretch;"
                    " already added to time_s, w<N> notes count from it)\n"
                    % t_off)
        f.write("#\n")
        f.write("# TP rows are here so `show` can scale the display to real\n")
        f.write("# beat height.  To draw only the disagreements over that\n")
        f.write("# scale:  show --peaks THIS --mark-source FP,FN\n")
        w = csv.DictWriter(f, fieldnames=PEAK_FIELDS)
        w.writeheader()
        for row in rows:
            w.writerow(row)
    return len(rows)


def find_view_exports(dirs, limit=8):
    """Files in `dirs` that are `view` Export CSV output, newest first.

    Found by CONTENT (the `# edited_in:` header line), not by name, because
    the name is the browser's decision: Safari has saved blob downloads from
    a local page as "Unknown", and any browser appends " (1)" when the name
    is taken.  A filename search would miss exactly the cases that need it.
    """
    seen, out = set(), []
    for d in dirs:
        d = os.path.expanduser(d)
        try:
            names = os.listdir(d)
        except OSError:
            continue
        for nm in names:
            p = os.path.join(d, nm)
            if p in seen or not os.path.isfile(p):
                continue
            seen.add(p)
            try:
                if os.path.getsize(p) > 200 * 1024 * 1024:
                    continue
                with open(p, "rb") as f:
                    head = f.read(8192)
            except OSError:
                continue
            if b"# edited_in:" in head:
                out.append((os.path.getmtime(p), p))
    out.sort(reverse=True)
    return [p for _, p in out[:limit]]


def _missing_peak_file(path, role):
    """Explain a missing peak file, and point at view exports that DO exist."""
    print("  %s: no such file:\n    %s" % (role, path), file=sys.stderr)
    cands = find_view_exports([os.path.dirname(os.path.abspath(path)),
                               "~/Downloads", "."])
    if cands:
        print("  `view` exports found (newest first) -- one of these may be it:",
              file=sys.stderr)
        for c in cands:
            print("    %s" % _shq(c), file=sys.stderr)
    else:
        print("  No `view` export was found in that folder, ~/Downloads or here.\n"
              "  In the page: press E, click beats, then Export CSV -- the status\n"
              "  bar then says where the file went.", file=sys.stderr)
    return 2


def _meta_num(meta, key):
    """A numeric peak-file header value, or None when absent or unreadable."""
    try:
        v = float(str((meta or {}).get(key, "") or "").split()[0])
    except (ValueError, IndexError):
        return None
    return v if np.isfinite(v) else None


def _to_stretch_clock(t, meta, s0, length, margin, force_recording=False):
    """Put one beat list on the clock of the stretch [s0, s0 + length].

    Returns (times, kind, shift_s, n_before).  kind is
      "segment"   -- the file says where its clock starts (# segment_offset_s,
                     written by a segment page or `view --start`): moved by
                     offset - s0, which is 0 when it is this stretch's page;
      "recording" -- timed from the recording start (no header, and its beats
                     run past the stretch length or mostly lie outside it):
                     cut to [s0, s0 + length] (+- margin, so the offset can
                     still be measured at the edges) and shifted by -s0;
      "stretch"   -- no header and it already fits 0..length: taken as given.
    A .PnmMarks candidate is recording-clock by construction; pass
    force_recording so a short recording cannot be mistaken for a stretch.
    """
    t = np.asarray(t, dtype=float)
    off = None if force_recording else _meta_num(meta, "segment_offset_s")
    if off is not None:
        return t + (off - s0), "segment", off - s0, len(t)
    if not force_recording:
        n_in = int(np.sum((t >= -margin) & (t <= length + margin)))
        if not (len(t) and (t.max() > length + margin or n_in < 0.5 * len(t))):
            return t, "stretch", 0.0, len(t)
    k = t[(t >= s0 - margin) & (t <= s0 + length + margin)] - s0
    return k, "recording", -float(s0), len(t)


def _stretch_clock_note(who, kind, shift, n_kept, n_all, s0, length):
    """The one line compare prints for what _to_stretch_clock did."""
    if kind == "segment":
        off = s0 + shift
        if abs(shift) < 1e-6:
            return ("  %s is this stretch's segment page (# segment_offset_s"
                    " %.1f s): times already count from %s" % (who, off, _hms(off)))
        return ("  %s counts from ITS # segment_offset_s %.1f s (%s): moved"
                " %+.1f s onto this stretch" % (who, off, _hms(off), shift))
    if kind == "recording":
        return ("  %s is on the RECORDING's clock (no # segment_offset_s header):"
                " cut to %s-%s and shifted by %+.1f s -- %s of %s beat(s) kept"
                % (who, _hms(s0), _hms(s0 + length), shift,
                   "{:,}".format(n_kept), "{:,}".format(n_all)))
    return ("  %s has no # segment_offset_s header and fits 0-%.0f s: taken as"
            " counted from the stretch start" % (who, length))


def cmd_compare(args):
    profile = SPECIES[args.species]

    # (a) is either a peak file written earlier by `detect`, or -- when only a
    # recording is given -- this build's detection of that recording.  The
    # second form exists because the common case is now comparing against
    # Ponemah's own beat list, and requiring a round trip through a CSV for
    # that added a step whose only effect was somewhere else to get the clock
    # wrong.
    # Checked BEFORE the detection below, which takes a minute on an hour of
    # recording -- a typo in a path should cost nothing.
    _arb_opt = getattr(args, "arbiter", None)
    if _arb_opt and str(_arb_opt).strip().lower() == "none":
        _arb_opt = None
    for _role, _p in ((("--manual", args.manual), ("--auto", args.auto),
                       ("--arbiter", _arb_opt),
                       ("--marks", getattr(args, "marks", None)))
                      + tuple(("--arbiter-candidates", _c) for _c in
                              (getattr(args, "arbiter_candidates", None)
                               or []))):
        if _p and not os.path.isfile(_p):
            return _missing_peak_file(_p, _role)
    r = None
    files = expand_inputs(args.input) if args.input else []
    # (b) is read FIRST: an export from a segment page (view --segment, or
    # view --start) says which stretch of the recording it covers, and that
    # decides what is detected below.  Scoring a one-hour page against the
    # whole 18.6 h detection would count every other hour as (a)'s FPs.
    man_s, mmeta, mrows = read_peaks(args.manual)
    st_s0, st_len, st_lines = None, None, []
    _hoff = _meta_num(mmeta, "segment_offset_s")
    _hdur = _meta_num(mmeta, "duration_s") if _hoff is not None else None
    _mins = float(getattr(args, "minutes", 0.0) or 0.0)
    _sopt = getattr(args, "start", None)
    if _mins > 0:
        _slen, _lhow = _mins * 60.0, "--minutes"
    elif _hdur:
        _slen, _lhow = _hdur, "(b)'s # duration_s"
    else:
        _slen, _lhow = (SEGMENT_MIN_DEFAULT * 60.0,
                        "the %d min default" % SEGMENT_MIN_DEFAULT)
    if _sopt is not None:
        try:
            st_s0 = parse_clock_s(_sopt)
        except ValueError:
            print("  --start %r: give seconds (5400) or HH:MM:SS (01:30:00)"
                  % (_sopt,), file=sys.stderr)
            return 2
        if not files:
            print("  compare --start needs --input RECORDING: the stretch is"
                  " cut from it", file=sys.stderr)
            return 2
        st_len = _slen
        st_lines.append("  stretch   %s-%s of the recording (%.1f s): start from"
                        " --start, length from %s"
                        % (_hms(st_s0), _hms(st_s0 + st_len), st_len, _lhow))
        if _hoff is not None and abs(_hoff - st_s0) > 1.0:
            st_lines += [
                "  ** WARNING: --start %s (%.1f s) but (b) says # segment_offset_s"
                " %.1f s (%s) -- %+.1f s apart." % (_sopt, st_s0, _hoff,
                                                     _hms(_hoff), _hoff - st_s0),
                "     (b) was exported from a DIFFERENT page.  Its times count"
                " from %s, so they are" % _hms(_hoff),
                "     moved %+.1f s onto this stretch and only its beats inside"
                " it are scored." % (_hoff - st_s0),
                "     Drop --start to score (b) on its own page."]
    elif _hoff is not None and files:
        st_s0, st_len = _hoff, _slen
        st_lines.append("  stretch   %s-%s of the recording (%.1f s): start from"
                        " (b)'s # segment_offset_s header, length from %s"
                        "  (--start overrides)"
                        % (_hms(st_s0), _hms(st_s0 + st_len), st_len, _lhow))
    if files:
        if st_s0 is not None:
            r, _scols, _sinfo, _serr = next(iter(iter_analyses(
                files[0], args, profile, stretch=(st_s0, st_len))))
            _scols = None
            if _serr is not None:
                print("  %s" % _serr, file=sys.stderr)
                return 2
            if float(r.dur) < st_len - 1e-6:
                st_lines.append("            the recording ends %.1f s in, so"
                                " %.1f s of it are compared"
                                % (st_s0 + float(r.dur), float(r.dur)))
            st_len = float(r.dur)
        else:
            r = analyse(files[0], args, profile)
    if args.auto:
        auto_s, ameta, _ = read_peaks(args.auto)
        auto_label = args.auto
    elif r is not None:
        auto_s = np.asarray(r.anchors, dtype=float) / float(r.fs)
        ameta = {"source_file": os.path.abspath(files[0]),
                 "duration_s": "%.4f" % r.analysable_s,
                 "fs_hz": "%.4f" % r.fs,
                 "lead": str(r.lead),
                 "lead_name": (r.ch_names[r.lead]
                               if r.ch_names and r.lead < len(r.ch_names)
                               else "")}
        auto_label = "%s  lead %d%s (detected now)" % (
            os.path.basename(files[0]), r.lead,
            " = %s" % ameta["lead_name"] if ameta["lead_name"] else "")
    else:
        print("  compare needs either --auto PEAKS.csv or --input RECORDING",
              file=sys.stderr)
        return 2
    print("=" * 108)
    print("COMPARE   (a) automatic  vs  (b) manually reviewed")
    print("=" * 108)
    print("  (a) %s   %d peaks" % (auto_label, len(auto_s)))
    print("  (b) %s   %d peaks" % (args.manual, len(man_s)))

    # ---- one stretch, one clock.  Detection above is timed from the
    # stretch start; every list is put on that clock here, BEFORE any offset
    # is measured, since the offset search only looks +- --align-max wide.
    man_shift = 0.0
    _mg = 0.0
    if st_s0 is not None:
        for _l in st_lines:
            print(_l)
        _mg = (float(getattr(args, "align_max", 5.0) or 5.0)
               + (args.match_tol if args.match_tol
                  else profile.match_tol_ms) / 1000.0)
        if args.auto:
            auto_s, _k, _sh, _n0 = _to_stretch_clock(auto_s, ameta, st_s0,
                                                     st_len, _mg)
            print(_stretch_clock_note("(a)", _k, _sh, len(auto_s), _n0,
                                      st_s0, st_len))
        man_s, _k, man_shift, _n0 = _to_stretch_clock(man_s, mmeta, st_s0,
                                                      st_len, _mg)
        print(_stretch_clock_note("(b)", _k, man_shift, len(man_s), _n0,
                                  st_s0, st_len))

    sa = ameta.get("config_sha1"); sm = mmeta.get("config_sha1")
    if sa and sm and sa != sm:
        print()
        print("  ** WARNING: the two files were produced under DIFFERENT configs")
        print("     (a) %s" % ameta.get("config", "?"))
        print("     (b) %s" % mmeta.get("config", "?"))
        print("     Differences below may be configuration, not detection quality.")
    fa, fm = ameta.get("source_file"), mmeta.get("source_file")
    if fa and fm and fa != fm:
        if _pnm_siblings(fa, fm):
            print("  (b) comes from this recording's own Ponemah sidecar")
            print("      %s" % os.path.basename(fm))
            print("      -- same experiment directory, same experiment name,"
                  " so these are")
            print("      companion files rather than different recordings.")
        else:
            print("  ** WARNING: different source recordings: %s vs %s"
                  % (fa, fm))

    # ---- are the two lists even describing the same LEAD?
    #
    # They need not be, and on P10 the defaults do not agree: detection picks
    # its lead by tmplQ, while `marks --export-beats` defaults to the context
    # with the most cycles.  Those landed on different electrodes, and since
    # Ponemah's own leads disagree with each other by 7,902 beats, scoring
    # across a mismatch measures the ELECTRODES, not the detector.  The channel
    # is in both headers, so it can be checked rather than hoped for.
    man_ch = (mmeta.get("subject_channel") or "").strip()
    auto_ch = ""
    if ameta.get("lead_name"):
        _m = re.search(r"(\d+)\s*$", ameta["lead_name"])
        auto_ch = _m.group(1) if _m else ""
    # A Ponemah export names its channel outright and has no lead_name, so
    # without this fall-back the channel check goes quiet on exactly the
    # comparison where the channels matter most: Ponemah against itself.
    if not auto_ch:
        auto_ch = (ameta.get("subject_channel") or "").strip()

    # Is (a) also a Ponemah beat list?  `marks --export-beats` stamps the
    # origin line; detection never does.
    a_is_pon = "ponemah" in (ameta.get("origin") or "").lower()
    b_is_pon = "ponemah" in (mmeta.get("origin") or "").lower()

    if man_ch and auto_ch and man_ch != auto_ch and a_is_pon and b_is_pon:
        # Not a mistake.  Both sides are Ponemah, on two electrodes of one
        # heart, and the disagreement between them is the quantity being
        # measured -- it is the internal-consistency baseline that says how
        # much of any detector's disagreement with Ponemah is Ponemah's own.
        # Warning here, and telling the reader to re-export onto one lead,
        # would be telling them to destroy the measurement.
        print()
        print("  INTER-LEAD: both sides are PONEMAH, on different electrodes")
        print("     (a) subject channel %s, (b) subject channel %s, one heart."
              % (auto_ch, man_ch))
        print("     Simultaneous leads see the same beats, so everything that")
        print("     follows is Ponemah disagreeing with ITSELF.  Read it as the")
        print("     floor: no detector scored against this beat list can be")
        print("     expected to agree with it more closely than it agrees with")
        print("     its own other lead.")
    elif man_ch and auto_ch and man_ch != auto_ch:
        print()
        print("  ** WARNING: these are DIFFERENT LEADS.")
        print("     (a) is subject channel %s, (b) is subject channel %s."
              % (auto_ch, man_ch))
        print("     Ponemah's own leads disagree with each other, so what")
        print("     follows measures the electrodes as much as the detector.")
        print("     Re-export (b) for this lead with:")
        print("       marks --input ....PnmMarks --context N --export-beats ...")
        print("     (the context whose subjectChannel is %s)" % auto_ch)
    elif man_ch and auto_ch:
        print("  both lists describe subject channel %s" % man_ch)

    tol = (args.match_tol if args.match_tol else profile.match_tol_ms) / 1000.0

    # ---- FIRST, put (a) on the recording's clock if it is not already there.
    #
    # Everything downstream -- the window clip against r.dur, the 60 s window
    # numbering, the times written by --export-diff, the --start that `show`
    # will seek to -- is in RECORDING seconds.  When (a) is this build's
    # detection that is automatic.  When (a) is a peak FILE it is an
    # assumption, and on the Ponemah exports it is a wrong one: they are timed
    # from the sidecar's first beat, 0.254 s after sample zero on P10.
    #
    # The residual is small -- a quarter second against a 1800 s window moves
    # well under one beat -- but "small" is not the same as "measured", and
    # the 254 ms that was catastrophic three builds ago is the same quarter
    # second.  We have the recording's own detection in hand, so the offset
    # can be measured instead of hoped for.
    rec_lag = 0.0
    if args.auto and r is not None and getattr(args, "align", True):
        rec_s = np.asarray(r.anchors, dtype=float) / float(r.fs)
        rl, rl_n, rl_cov = peak_train_lag(
            auto_s, rec_s, max_lag_s=float(getattr(args, "align_max", 5.0)),
            tol_s=tol)
        print()
        if rl_cov >= 0.5:
            rec_lag = rl
            auto_s = auto_s + rl
            print("  (a) is a peak file, so its clock was checked against this")
            print("      recording's own detection:  %+.4f s   (%s of %s beat(s),"
                  " %.1f%%)"
                  % (rl, "{:,}".format(rl_n), "{:,}".format(len(auto_s)),
                     100.0 * rl_cov))
            if abs(rl) > 1e-4:
                print("      Removed, so every time below -- including the"
                      " 60 s window")
                print("      numbers and anything --export-diff writes -- is in")
                print("      RECORDING seconds.")
            else:
                print("      They already agree; nothing to remove.")
        else:
            print("  ** (a)'s clock could NOT be checked against the recording:")
            print("     the best offset (%+.4f s) explains only %.1f%% of its"
                  % (rl, 100.0 * rl_cov))
            print("     beats.  Either (a) is a different recording, or a")
            print("     different lead that shares few beats.  Times below are")
            print("     taken as given, which may be wrong by a constant.")

    # ---- put the two clocks on one origin before scoring anything.
    #
    # See peak_train_lag: a Ponemah export is timed from its first beat, a
    # waveform from sample zero, and on P10 that is a 0.254 s difference
    # against a 50 ms window.  Unmeasured, it reports 0% sensitivity on two
    # lists that agree.  Measured, it is one subtraction.
    lag, lag_n, lag_cov = (0.0, 0, 0.0)
    if getattr(args, "align", True):
        lag, lag_n, lag_cov = peak_train_lag(
            auto_s, man_s, max_lag_s=float(getattr(args, "align_max", 5.0)),
            tol_s=tol)
        print()
        if lag_cov >= 0.5:
            print("  clock offset (b) - (a):  %+.4f s   measured, not assumed"
                  % lag)
            print("     %s of %s beat(s) in (a) find a partner at that offset"
                  " (%.1f%%)"
                  % ("{:,}".format(lag_n), "{:,}".format(len(auto_s)),
                     100.0 * lag_cov))
            if abs(lag) > tol:
                print("     This is LARGER than the %.0f ms matching window, so"
                      " without" % (tol * 1000))
                print("     removing it every beat below would have been scored"
                      " a miss.")
            # Move (b) onto (a)'s clock, not the other way about.
            #
            # (a) is the RECORDING.  Its times are sample index over fs; they
            # are what `show --start` seeks to, what the 60 s disagreement
            # windows below are named after, and the only clock a waveform can
            # actually be drawn on.  Shifting (a) onto the sidecar's
            # first-beat origin instead -- which is what this did -- left
            # every figure below expressed in a coordinate system no other
            # command in this tool understands, and it put the window clip
            # that follows on the wrong clock: `man_s <= cmp_win + tol`
            # measured against a cmp_win in waveform seconds kept reference
            # beats 254 ms past the end of what was analysed and dropped
            # those in the first 174 ms, which is why window 0 was the only
            # early window ever to show an FN.
            man_s = man_s - lag
        else:
            print("  clock offset: NO offset explains these two lists.")
            print("     The best candidate (%+.4f s) accounts for only %.1f%% of"
                  % (lag, 100.0 * lag_cov))
            print("     (a)'s beats, where two renderings of one recording give")
            print("     ~100%%.  Scoring them as given.")
            print("     Suspect different leads or different recordings -- not")
            print("     a clock problem, which a shift would have fixed.")
            lag = 0.0

    # ---- score over the SAME window, or the score is arithmetic on two
    # different recordings wearing one heading.
    #
    # `--minutes N` reads the first N minutes; Ponemah's list covers all 18.6 h
    # of P10.  Matched against each other whole, every one of the ~73,000
    # beats outside the read window counts as a miss, sensitivity reads ~2%,
    # and the detector looks catastrophic when it was simply not shown the
    # rest of the file.  The window is known -- it is what was read -- so the
    # reference is cut to it and the cut is stated.
    cmp_win = None
    if r is not None and getattr(r, "dur", 0):
        cmp_win = float(r.dur)
        # BOTH sides, not just (b).
        #
        # When (a) is this build's detection it already stops at cmp_win, so
        # cutting it is a no-op and the asymmetry never showed.  But (a) may
        # be a peak FILE -- and the moment it is a whole-record one, as when
        # Ponemah's own two leads are scored against each other over a
        # windowed recording, the old code left (a) at 18.6 hours while (b)
        # was cut to 30 minutes.  Sensitivity would look respectable and PPV
        # would collapse to a few percent, purely from the mismatch.
        n_before_a = len(auto_s)
        auto_s = auto_s[(auto_s >= -tol) & (auto_s <= cmp_win + tol)]
        n_before = len(man_s)
        man_s = man_s[(man_s >= -tol) & (man_s <= cmp_win + tol)]
        mrows = [d for d in mrows
                 if _row_time_in(d, -tol, cmp_win + tol, mmeta,
                                 shift_s=man_shift - lag)]
        if len(auto_s) < n_before_a:
            print()
            print("  (a) is a peak file covering more than the read window;"
                  " it is cut too:")
            print("      %s of %s beat(s) kept."
                  % ("{:,}".format(len(auto_s)),
                     "{:,}".format(n_before_a)))
        if len(man_s) < n_before:
            print()
            print("  (a) covers %.1f s of the recording; (b) covers the whole"
                  " file." % cmp_win)
            print("      (b) is cut to the same window: %s of %s beat(s) kept."
                  % ("{:,}".format(len(man_s)), "{:,}".format(n_before)))
            print("      Without this the %s beats outside the window would"
                  % "{:,}".format(n_before - len(man_s)))
            print("      every one be scored a miss.")

    matched, fp, fn = match_peaks(auto_s, man_s, tol)
    tp = len(matched)
    sens = tp / len(man_s) if len(man_s) else float("nan")
    ppv = tp / len(auto_s) if len(auto_s) else float("nan")
    f1 = (2 * sens * ppv / (sens + ppv)) if (sens + ppv) else float("nan")

    print()
    print("  matching window +-%.0f ms  (%s profile)" % (tol * 1000, profile.name))
    print("  " + "-" * 70)
    print("  %-34s %10s" % ("true positives  (a and b agree)", tp))
    print("  %-34s %10s   <- (a) found, (b) rejected" % ("false positives (a only)", len(fp)))
    print("  %-34s %10s   <- (b) marked, (a) missed" % ("false negatives (b only)", len(fn)))
    print("  " + "-" * 70)
    print("  %-34s %9.2f%%   TP/(TP+FN)" % ("sensitivity", 100.0 * sens))
    print("  %-34s %9.2f%%   TP/(TP+FP)" % ("positive predictive value", 100.0 * ppv))
    print("  %-34s %9.2f%%" % ("F1", 100.0 * f1))
    if tp:
        dt = np.array([d for _, _, d in matched]) * 1000.0
        print()
        print("  timing of matched peaks: median |dt| %.1f ms, p95 %.1f ms, max %.1f ms"
              % (np.median(dt), np.percentile(dt, 95), dt.max()))
        if np.median(dt) > 0.5 * tol * 1000:
            print("  ** median offset is over half the matching window -- suspect a")
            print("     systematic shift (different snap window or lead), not noise.")

    # ---- EMPTY GAPS, from BOTH lists, on the shared clock.
    #
    # analyse() measured r's empty gaps from (a)'s beats alone.  Used as the
    # compare denominator that was one-sided: where Ponemah has beats inside
    # our gap, those are OUR misses, yet the time they occupy had been taken
    # out of the denominator while (b)'s beats there stayed in its count.
    # Here the spans are re-derived AFTER alignment from the union, so a
    # stretch is only empty if neither list has a beat in it, and the ONE
    # resulting exclusion applies to both counts and to the time.
    cmp_empty, cmp_empty_s, cmp_base_s = [], 0.0, 0.0
    cmp_keep_empty = bool(getattr(args, "keep_empty", False))
    cmp_empty_ok = False
    if cmp_win is not None and hasattr(r, "excise_base_spans"):
        cmp_base = merge_spans(
            [(max(0.0, float(a)), min(cmp_win, float(b)))
             for a, b in (r.excise_base_spans or [])
             if min(cmp_win, float(b)) > max(0.0, float(a))])
        cmp_base_s = total_span_s(cmp_base)
        cmp_empty, _cM, _cn = compare_empty_spans(
            auto_s, man_s, fn, r.fs, cmp_win, cmp_base,
            float(getattr(r, "empty_gap_mult", 3.0)))
        cmp_empty_s = total_span_s(cmp_empty)
        cmp_empty_ok = True
        _inner = [(a + 1e-9, b - 1e-9) for a, b in cmp_empty]
        _ina = int(_in_spans_mask(auto_s, _inner).sum())
        _inb = int(_in_spans_mask(man_s, _inner).sum())
        _a_only_s = float(getattr(r, "empty_s", 0.0) or 0.0)
        print()
        print("  empty gaps  derived from the UNION of (a) and (b) beats (after"
              " alignment):")
        print("      %.1f s in %d gap(s) %s  [(a) alone: %.1f s; %.1f s not"
              " empty because"
              % (cmp_empty_s, len(cmp_empty),
                 "KEPT as pauses (--keep-empty)" if cmp_keep_empty
                 else "EXCISED from both counts' time",
                 _a_only_s, max(0.0, _a_only_s - cmp_empty_s)))
        print("      (b) has beats there -- scored as (a)'s misses]")
        if _ina or _inb:
            # Cannot happen by construction; if it ever does, say so loudly
            # rather than print a rate whose two halves disagree.
            print("  ** CONSISTENCY FAILURE: %d (a) and %d (b) beat(s) lie"
                  " inside the union's empty spans" % (_ina, _inb))
        _nb_base = int(_in_spans_mask(man_s, cmp_base).sum())
        if _nb_base:
            print("      note: %d of (b)'s beats fall in (a)'s no-signal/marked"
                  " time; they stay in (b)'s count" % _nb_base)

    # ---- THE THIRD LEAD
    #
    # Everything above stops at "they disagree".  It cannot go further,
    # because neither list is ground truth -- and on this recording that is
    # not a quibble: Ponemah's own two ECG leads disagree with each other by
    # 7,902 beats, so an FP against one of them is as likely to be that
    # lead's miss as our error.  Reporting PPV 92.89% and leaving it there
    # invites exactly the wrong reading.
    #
    # A third simultaneous lead settles most of it.  All three wires are on
    # one heart and every one of them sees every beat; only the detections
    # differ.  See arbitrate().
    arb_res = None
    arb_truth = None
    arb_use = None          # the arbiter's beats on (a)'s clock, window-cut
    arb_how = ""
    arb_label = ""
    arb_raw = getattr(args, "arbiter", None)
    arb_off = bool(arb_raw) and str(arb_raw).strip().lower() == "none"
    if arb_off:
        print()
        print("  ARBITER  disabled (--arbiter none): two-way scores only.")
    elif arb_raw:
        # --arbiter FILE: the user's choice overrides the automatic one, and
        # is held to the same independence rules it always was.
        arb_how = "given with --arbiter (automatic choice overridden)"
        arb_label = arb_raw
        arb_s, armeta, _arows = read_peaks(arb_raw)
        arb_ch = (armeta.get("subject_channel") or "").strip()
        print()
        print("  ARBITER  %s   %s peaks"
              % (arb_raw, "{:,}".format(len(arb_s))))
        if st_s0 is not None:
            arb_s, _k, _sh, _n0 = _to_stretch_clock(arb_s, armeta, st_s0,
                                                    st_len, _mg)
            print("    " + _stretch_clock_note("the arbiter", _k, _sh,
                                               len(arb_s), _n0, st_s0,
                                               st_len).strip())
        # Independence, checked rather than assumed.  An arbiter on (b)'s
        # electrode is not a second opinion, and one on (a)'s electrode
        # confirms (a)'s artifacts -- a noise spike belongs to a wire, not
        # to a heart.  Both are silent failures that would make the numbers
        # below look better than the truth, so both are refusals.
        if arb_ch and man_ch and arb_ch == man_ch:
            print("  ** REFUSED: the arbiter is subject channel %s, the same"
                  " electrode as (b)." % arb_ch)
            print("     A third opinion from the same wire is not a third"
                  " opinion.  It")
            print("     would confirm (b)'s every detection and reject (b)'s"
                  " every miss,")
            print("     which reads as proof and is arithmetic.")
        elif arb_ch and auto_ch and arb_ch == auto_ch:
            print("  ** REFUSED: the arbiter is subject channel %s, the same"
                  " electrode as (a)." % arb_ch)
            print("     Noise is a property of an electrode.  Two detectors on"
                  " one wire")
            print("     agree about artifacts as readily as about beats, so"
                  " 'confirmed'")
            print("     would mean nothing here.")
        else:
            # Same clock discipline as everything else: measure, do not
            # assume.  A Ponemah export is timed from its own first beat.
            a_lag, a_n, a_cov = (0.0, 0, 1.0)
            if getattr(args, "align", True):
                a_lag, a_n, a_cov = peak_train_lag(
                    auto_s, arb_s,
                    max_lag_s=float(getattr(args, "align_max", 5.0)),
                    tol_s=tol)
            if a_cov < 0.5:
                print("  ** REFUSED: no offset puts the arbiter on this"
                      " recording's clock.")
                print("     The best candidate (%+.4f s) explains %.1f%% of its"
                      " beats," % (a_lag, 100.0 * a_cov))
                print("     where a simultaneous lead gives ~100%.  This is"
                      " probably not")
                print("     the same recording.")
            else:
                arb_s = arb_s - a_lag
                n_arb_all = len(arb_s)
                if cmp_win is not None:
                    arb_s = arb_s[(arb_s >= -tol) & (arb_s <= cmp_win + tol)]
                if arb_ch:
                    print("      subject channel %s -- a THIRD electrode,"
                          " independent of (a) and (b)" % arb_ch)
                print("      clock offset vs (a): %+.4f s  (%.1f%% of its beats"
                      " find a partner)" % (a_lag, 100.0 * a_cov))
                if len(arb_s) < n_arb_all:
                    print("      cut to the same window: %s of %s beat(s) kept"
                          % ("{:,}".format(len(arb_s)),
                             "{:,}".format(n_arb_all)))
                arb_use = arb_s
    else:
        # ---- AUTOMATIC: every other lead we can find, measured, and the
        # best independent one chosen.  See select_arbiter() for the rule
        # and the constants beside ARBITER_SAME_ELECTRODE_MS for the
        # evidence behind them.
        cands, notes = [], []
        mk = getattr(args, "marks", None)
        mk_how = "given with --marks" if mk else ""
        if not mk:
            mk, mk_how = find_marks_file(files, mmeta)
            if not mk:
                notes.append(".PnmMarks: %s" % mk_how)
        if mk:
            _mc, _mn = marks_arbiter_candidates(mk)
            if st_s0 is not None and _mc:
                for _c in _mc:
                    _c["times_s"] = _to_stretch_clock(
                        _c["times_s"], None, st_s0, st_len, _mg,
                        force_recording=True)[0]
                _mn = ((_mn + "; ") if _mn else "") + (
                    "recording clock: cut to %s-%s, shifted by %+.1f s"
                    % (_hms(st_s0), _hms(st_s0 + st_len), -st_s0))
            cands.extend(_mc)
            notes.append("%s  (%s): %d channel context(s)"
                         % (mk, mk_how, len(_mc)) + ("  -- " + _mn if _mn
                                                      else ""))
        for _cp in (getattr(args, "arbiter_candidates", None) or []):
            try:
                _cc = csv_arbiter_candidate(_cp)
                if st_s0 is not None:
                    _cc["times_s"], _k, _sh, _n0 = _to_stretch_clock(
                        _cc["times_s"],
                        {"segment_offset_s": _cc.get("seg_off") or ""},
                        st_s0, st_len, _mg)
                    notes.append(_stretch_clock_note(
                        os.path.basename(_cp), _k, _sh, len(_cc["times_s"]),
                        _n0, st_s0, st_len).strip())
                cands.append(_cc)
            except (OSError, ValueError) as _e:
                notes.append("%s: unreadable (%s)" % (_cp, _e))
        print()
        print("  ARBITER  chosen automatically  (--arbiter FILE overrides,"
              " --arbiter none disables)")
        for _n in notes:
            print("      %s" % _n)
        if not cands:
            print("      no candidate leads, so no arbitration.  Pass --marks"
                  " FILE.PnmMarks or")
            print("      --arbiter-candidates CSV ... to enable it.")
        else:
            _man_ctx = re.search(r"ChannelContextId\s+(\d+)",
                                 mmeta.get("origin", "") or "")
            chosen, arows = select_arbiter(
                auto_s, man_s, cands, tol,
                align=getattr(args, "align", True),
                max_lag_s=float(getattr(args, "align_max", 5.0)),
                cmp_win=cmp_win, man_ch=man_ch, auto_ch=auto_ch,
                a_is_pon=a_is_pon,
                man_ctx=int(_man_ctx.group(1)) if _man_ctx else None,
                man_src=mmeta.get("source_file", "") or "",
                man_path=os.path.abspath(args.manual))

            def _f(v, fmt):
                return (fmt % v) if (v is not None and np.isfinite(v)) else "-"

            print()
            print("      %-34s %4s %9s %9s %7s %8s %8s  %s"
                  % ("candidate", "ch", "beats", "off_b_s", "F1_b%",
                     "|dt|a_ms", "|dt|b_ms", "verdict"))
            print("      " + "-" * 118)
            for _r in arows:
                print("      %-34s %4s %9s %9s %7s %8s %8s  %s"
                      % (_r["label"][-34:], _r["ch"] or "-",
                         "{:,}".format(_r["n"]) if _r["n"] else "-",
                         _f(_r["lag_b"], "%+.4f"),
                         _f(100.0 * _r["f1_b"] if np.isfinite(_r["f1_b"])
                            else float("nan"), "%.2f"),
                         _f(_r["dt_a_ms"], "%.2f"), _f(_r["dt_b_ms"], "%.2f"),
                         ("ACCEPTED: " if _r["ok"] else "rejected: ")
                         + _r["why"]))
            print("      same-electrode cut: median |dt| < %.1f ms vs (a) or"
                  " (b);  F1 warning below %.0f%%"
                  % (ARBITER_SAME_ELECTRODE_MS, 100.0 * ARBITER_WARN_F1))
            if chosen is None:
                print("      ** no candidate is an independent third lead, so"
                      " no arbitration.")
                print("         Reasons are in the verdict column above.")
            else:
                arb_label = chosen["label"]
                arb_how = "chosen automatically"
                arb_use = chosen["times_a"]
                print()
                print("  ARBITER  %s   %s peaks  (subject channel %s)"
                      % (chosen["label"], "{:,}".format(len(arb_use)),
                         chosen["ch"] or "?"))
                print("      clock offset vs (a): %+.4f s  (%.1f%% of its beats"
                      " find a partner)"
                      % (chosen["lag_a"], 100.0 * chosen["cov_a"]))
                if chosen["f1_b"] < ARBITER_WARN_F1:
                    print("  ** WARNING: the best independent lead agrees with"
                          " (b) at only F1 %.2f%%"
                          % (100.0 * chosen["f1_b"]))
                    print("     (below %.0f%%).  It is used, but a weak"
                          " third lead calls many of"
                          % (100.0 * ARBITER_WARN_F1))
                    print("     (b)'s real beats '(b) alone'.  Read the vote"
                          " below with that in mind.")
    if arb_use is not None:
        arb_res = arbitrate(auto_s, man_s, fp, fn, arb_use, tol)
        n_fpy, n_fpn = len(arb_res["fp_yes"]), len(arb_res["fp_no"])
        n_fny, n_fnn = len(arb_res["fn_yes"]), len(arb_res["fn_no"])
        print()
        print("      of the %d beat(s) (a) found and (b) rejected:"
              % len(fp))
        print("        %6d  the arbiter has too  ->  (b) MISSED them;"
              " (a) was right" % n_fpy)
        print("        %6d  in neither other lead  ->  unconfirmed,"
              " possibly (a)'s" % n_fpn)
        print("      of the %d beat(s) (b) marked and (a) missed:"
              % len(fn))
        print("        %6d  the arbiter has too  ->  (a) really MISSED"
              " them" % n_fny)
        print("        %6d  in neither other lead  ->  (b) alone;"
              " likely (b)'s error" % n_fnn)

        # Re-score against the majority: beats that at least TWO of
        # the three leads report.  That set is not ground truth and
        # is not claimed to be -- it is the best available stand-in,
        # and it is stated as a vote so the reader can discount it.
        found = tp + n_fpy                 # (a) has these
        truth = found + n_fny              # plus the ones (a) missed
        arb_truth = truth
        if truth:
            m_sens = found / float(truth)
            m_ppv = found / float(len(auto_s)) if len(auto_s) else \
                float("nan")
            m_f1 = (2 * m_sens * m_ppv / (m_sens + m_ppv)
                    if (m_sens + m_ppv) else float("nan"))
            print()
            print("      scored against the %s beat(s) at least TWO of"
                  " the three leads see:" % "{:,}".format(truth))
            print("        %-14s %8.2f%%   (was %.2f%% against (b)"
                  " alone)" % ("sensitivity", 100.0 * m_sens,
                               100.0 * sens))
            print("        %-14s %8.2f%%   (was %.2f%%)"
                  % ("PPV", 100.0 * m_ppv, 100.0 * ppv))
            print("        %-14s %8.2f%%   (was %.2f%%)"
                  % ("F1", 100.0 * m_f1, 100.0 * f1))
        if len(auto_s):
            print()
            print("      %d of (a)'s %s detections (%.2f%%) are"
                  " confirmed by no other"
                  % (n_fpn, "{:,}".format(len(auto_s)),
                     100.0 * n_fpn / len(auto_s)))
            print("      lead.  That is the CEILING on (a)'s false"
                  " positives here, not an")
            print("      estimate: a real beat missed by both other"
                  " leads would also")
            print("      land in it.")

    # ---- rate, which is what the numbers are ultimately for
    #
    # One denominator for both sides, and it must be the window they were
    # actually scored over.  Taking (a)'s declared duration while (b) has just
    # been cut to a shorter window would divide two different beat counts by
    # two different spans and print the result as a difference.
    stale = False
    if cmp_win is not None and cmp_empty_ok:
        dur = max(1e-9, cmp_win - cmp_base_s
                  - (0.0 if cmp_keep_empty else cmp_empty_s))
        dur_src = ("analysable seconds of the compared window: no-signal/"
                   "marked %.1f s out" % cmp_base_s)
        if cmp_keep_empty:
            dur_src += "; empty gaps KEPT as pauses (--keep-empty)"
        else:
            dur_src += ("; empty gaps from (a)+(b) DROPPED: %.1f s"
                        " (--keep-empty keeps them)" % cmp_empty_s)
    elif cmp_win is not None:
        dur = float(getattr(r, "analysable_s", 0) or 0) or cmp_win
        dur_src = ("analysable seconds of the compared window"
                   if getattr(r, "analysable_s", 0) else "compared window")
    else:
        # A peak file whose beats have been cleaned needs a duration that has
        # been cleaned the same way.
        #
        # `marks --export-beats` writes bad-data beats keep=0 and read_peaks
        # drops them, so the beat count arriving here is already excised.
        # `duration_s` is the raw span.  Dividing one by the other understates
        # the rate by exactly the marked fraction -- on P10 that is 8.41%,
        # which turned 58.6 bpm into 53.7 and would have been read as a real
        # difference between the leads.  Numerator and denominator have to be
        # excised together; that is the whole of goal 6.
        an_a = float(ameta.get("analysable_s", 0) or 0)
        an_b = float(mmeta.get("analysable_s", 0) or 0)
        raw = float(ameta.get("duration_s", 0) or 0) or (r.dur if r else 0.0)
        stale = False
        if an_a > 0:
            dur = an_a
            dur_src = "(a)'s ANALYSABLE seconds -- bad-data time removed"
            if an_b > 0 and abs(an_b - an_a) > max(1.0, 0.01 * an_a):
                dur_src += ("  [(b) states %.1f s; they should agree on one "
                            "recording]" % an_b)
        else:
            dur = raw
            dur_src = "(a)'s declared duration"
            # Was the numerator cleaned even though the denominator was not?
            n_bad_a = float(ameta.get("n_in_bad_data", "0").split()[0] or 0) \
                if ameta.get("n_in_bad_data") else 0.0
            n_bad_b = float(mmeta.get("n_in_bad_data", "0").split()[0] or 0) \
                if mmeta.get("n_in_bad_data") else 0.0
            stale = bool(n_bad_a or n_bad_b)
        # No recording, so no no-signal/marked spans to measure live gap
        # length against: empty gaps are not applied to either list here.
        dur_src += "; no empty-gap excision without --input"
    if dur > 0:
        ra, rb = 60.0 * len(auto_s) / dur, 60.0 * len(man_s) / dur
        print()
        print("  rate from (a) %.2f bpm    rate from (b) %.2f bpm    difference %+.2f bpm (%+.2f%%)"
              % (ra, rb, ra - rb, 100.0 * (ra - rb) / rb if rb else float("nan")))
        print("  both over %.1f s -- %s" % (dur, dur_src))
        if arb_truth:
            # Goal 6 is a multi-hour rate TREND, and a trend inherits whatever
            # bias sits in the beat list it was built from.  Sensitivity and
            # PPV do not say how large that bias is -- they are per-beat, and
            # a detector's misses and phantoms can cancel.  So divide the
            # majority count by the same denominator and show both sides'
            # error in the only unit the trend is plotted in.
            rm = 60.0 * arb_truth / dur
            print("  rate from the 2-of-3 majority %.2f bpm"
                  "   -- (a) %+.2f%%, (b) %+.2f%%"
                  % (rm,
                     100.0 * (ra - rm) / rm if rm else float("nan"),
                     100.0 * (rb - rm) / rm if rm else float("nan")))
            print("  A long-horizon trend built on either list alone carries"
                  " that bias end to end;")
            print("  it does not average out, because it is not noise.")
        if cmp_win is None and stale:
            print("  ** BOTH RATES ARE BIASED LOW.  These peak files drop"
                  " bad-data beats")
            print("     from the count, but were written before the export"
                  " recorded how")
            print("     many SECONDS that removed, so the divisor above is the"
                  " raw span.")
            print("     The ratio between the two rates survives -- both are"
                  " biased by the")
            print("     same factor -- but neither absolute figure is the"
                  " animal's rate.")
            print("     Re-run `marks --export-beats` on this build to get"
                  " analysable_s.")
        print("  A detector can be wrong beat-by-beat and still right on rate if its")
        print("  errors cancel; it can also be right on rate while misplacing beats.")
        print("  Read the two together, never the rate alone.")

    # ---- where the disagreements are, so they can be found
    if fp or fn:
        print()
        print("  WHERE THEY DISAGREE  (60 s windows with any disagreement)")
        wsz = 60.0
        from collections import defaultdict
        d = defaultdict(lambda: [0, 0])
        for i in fp:
            d[int(auto_s[i] // wsz)][0] += 1
        for j in fn:
            d[int(man_s[j] // wsz)][1] += 1
        print("      %8s %8s %8s   %s" % ("window", "FP", "FN", "start time"))
        if st_s0 is not None:
            print("      (windows count from the stretch start; start time is"
                  " RECORDING time)")
        for w in sorted(d)[: args.max_windows]:
            a, b = d[w]
            print("      %8d %8d %8d   %6.1f s"
                  % (w, a, b, w * wsz + (st_s0 or 0.0)))
        if len(d) > args.max_windows:
            print("      ... and %d more window(s)" % (len(d) - args.max_windows))

        # Point at the WORST window, not the first one.
        #
        # This used to offer sorted(d)[0], which is simply the earliest window
        # containing any disagreement at all.  On the P10 ch3 run that is
        # window 0, with one FP and two FNs, while window 1 holds 25 FPs --
        # so the hint sent the reader to look at the least informative place
        # on the page and called it "inspect one".
        worst = max(d, key=lambda k: (d[k][0] + d[k][1], -k))

        # ---- a peak file that can actually be displayed
        #
        # Everything above is on the recording's clock now, so the
        # disagreements can be written out and handed straight to `show`.
        # Without this the only file to point at was (b) itself, whose times
        # are on the sidecar's first-beat origin: `show` would have drawn
        # every marker 254 ms from its beat, and the reader had no way to
        # tell that from a detector that misses every beat.
        diff_path = getattr(args, "export_diff", None)
        if diff_path:
            dmeta = dict(ameta)
            if r is not None:
                try:
                    _cfg, _sig = config_signature(r)
                    dmeta.setdefault("config", _cfg)
                    dmeta.setdefault("config_sha1", _sig)
                    dmeta.setdefault("species", r.profile.name)
                except Exception:
                    pass
            _arb_note = None
            if arb_res is not None:
                _arb_note = dict(
                    fp_yes=set(float(auto_s[i]) for i in arb_res["fp_yes"]),
                    fn_yes=set(float(man_s[j]) for j in arb_res["fn_yes"]))
            n_rows = write_compare_diff(
                diff_path,
                [float(auto_s[i]) for i in fp],
                [float(man_s[j]) for j in fn],
                [float(auto_s[i]) for i, _, _ in matched],
                dmeta, wsz=wsz, arb=_arb_note, t_off=st_s0 or 0.0)
            print()
            print("      wrote %s  (%d row(s): %d FP, %d FN, %d TP)"
                  % (diff_path, n_rows, len(fp), len(fn), tp))
            if _arb_note is not None:
                print("      Each FP and FN row carries the third lead's"
                      " verdict in its note")
                print("      column: arb=yes means that lead has the beat too.")
            print("      Times in it are on the RECORDING's clock -- the"
                  " %+.4f s offset" % lag)
            print("      is already removed, so these seek correctly:")
            # TWO commands, because one cannot do both jobs.
            #
            # The first draws the whole worst window.  A 60 s window in 100
            # columns is 600 ms per column against a 14 ms QRS, so it is an
            # ENVELOPE -- fine for "where in this window is the trouble", and
            # `show` now says so in its own header rather than letting it pass
            # for a waveform.  The earlier version of this hint printed only
            # this form, at --seconds 10, and a reader who wanted to see
            # whether an FP sat on a QRS got a panel that could not have
            # shown them either way.
            #
            # The second zooms to the first disputed beat at a span chosen by
            # panel_resolution to put three columns across a QRS, which is
            # the resolution at which that question has an answer.
            _fs = float(r.fs) if r is not None else profile.fs_expected
            _zsec = panel_resolution(1.0, 100, _fs,
                                     profile.qrs_width_ms)["seconds_for_morphology"]
            # Floor, never round.  0.4667 rounds to 0.47, which is 2.98
            # columns per QRS and back in the "peaks" regime -- advice that
            # fails its own test the moment it is taken.
            _zsec = max(0.05, np.floor(_zsec * 100.0) / 100.0)
            _disp = sorted([float(auto_s[i]) for i in fp]
                           + [float(man_s[j]) for j in fn])
            _win = [t for t in _disp
                    if worst * wsz <= t < (worst + 1) * wsz]
            _zt = max(0.0, (_win[0] if _win else worst * wsz) - 2 * _zsec)
            print()
            print("        # 1. the whole window -- an ENVELOPE, for locating"
                  " the trouble")
            print("        python3 ecg_rpeaks.py show \\")
            print("          --input %s \\"
                  % _shq(files[0] if files else "RECORDING"))
            print("          --peaks %s --mark-source FP,FN \\" % _shq(diff_path))
            print("          --start %.0f --seconds 10 --panels 6"
                  % (worst * wsz + (st_s0 or 0.0)))
            print()
            print("        # 2. the first disputed beat, at a span that"
                  " RESOLVES a QRS")
            print("        python3 ecg_rpeaks.py show \\")
            print("          --input %s \\"
                  % _shq(files[0] if files else "RECORDING"))
            print("          --peaks %s \\" % _shq(diff_path))
            print("          --start %.2f --seconds %.2f --panels 6"
                  % (_zt + (st_s0 or 0.0), _zsec))
            print()
            print("      That is window %d, the worst one: %d FP, %d FN."
                  % (worst, d[worst][0], d[worst][1]))
            print("      Command 2 drops --mark-source on purpose: at this"
                  " zoom the")
            print("      question is what the trace does, so every beat should"
                  " be marked.")
            print("      In command 1 --mark-source draws only the disputed"
                  " beats while")
            print("      the agreed ones still set the display scale --"
                  " otherwise the")
            print("      panel would be scaled to whatever the disputed points")
            print("      happen to be, which may be noise.")
        else:
            print()
            print("      To look at the worst window (%d: %d FP, %d FN) re-run"
                  % (worst, d[worst][0], d[worst][1]))
            print("      with --export-diff DIFF.csv, which writes the disputed")
            print("      beats on the RECORDING's clock and prints a ready-made")
            print("      `show` command.  Do NOT pass (b) to `show` directly:")
            print("      its times carry the %+.4f s offset measured above and"
                  % lag)
            print("      every marker would be drawn that far from its beat.")

    # ---- what the reviewer actually changed
    #
    # A Ponemah beat list is not a review file and must not be scored as one.
    # Every row in it reads source=PONEMAH, so the three counters below are all
    # zero and the old code concluded "the manual file is unedited -- this
    # comparison is (a) against itself".  That is exactly backwards: nothing
    # could be LESS like (a) against itself than a second detector's opinion,
    # and on P10 that opinion is the one whose own leads disagree by 7,902
    # beats.  Saying the comparison means nothing would have retired the most
    # informative run in the project.
    n_pon = sum(1 for d in mrows if d.get("source") == "PONEMAH")
    n_rej = sum(1 for d in mrows if d.get("source") == "AUTO"
                and str(d.get("keep", "1")).strip() in ("0", "0.0"))
    n_acc = sum(1 for d in mrows if d.get("source") == "SUGGEST"
                and str(d.get("keep", "0")).strip() not in ("0", "0.0", ""))
    n_add = sum(1 for d in mrows if d.get("source") == "MANUAL")
    print()
    if n_pon and not (n_rej or n_acc or n_add):
        n_bad = sum(1 for d in mrows if d.get("source") == "PONEMAH"
                    and str(d.get("keep", "1")).strip() in ("0", "0.0"))
        print("  (b) is PONEMAH's own detection, not a human review:"
              " %d beat(s)," % n_pon)
        print("      %d of them inside a BadDataMark interval and excluded"
              " here." % n_bad)
        print("      So this is detector against detector.  Neither side is")
        print("      ground truth, and disagreement does not say which one is")
        print("      wrong -- but Ponemah's leads disagree with EACH OTHER on")
        print("      this recording, so its beat list carries known errors.")
        if arb_res is not None:
            print("      The ARBITER block above is what resolves most of"
                  " them: a third")
            print("      electrode on the same heart, voting on each"
                  " disagreement.")
        else:
            print("      Read a disagreement as a place to look, not a"
                  " verdict.")
            # Do not leave this at "neither side is ground truth" when a
            # third lead exists on this rig and would settle most of it.
            # The observation without the remedy is what left the earlier
            # 92.89% PPV standing as though it were a measurement of us.
            print()
            print("      This recording has a THIRD ECG lead.  Point compare at"
                  " the sidecar")
            print("      and the best independent lead is chosen for you, or"
                  " pass one as")
            print("      --arbiter; each disagreement above then becomes a"
                  " verdict rather")
            print("      than a question:")
            print("        compare ... --manual %s --marks ....PnmMarks"
                  % os.path.basename(args.manual))
            print("        marks --input ....PnmMarks --context N"
                  " --export-beats other.csv")
            print("        compare ... --manual %s --arbiter other.csv"
                  % os.path.basename(args.manual))
    else:
        print("  reviewer actions: %d AUTO rejected, %d SUGGEST accepted,"
              " %d MANUAL added" % (n_rej, n_acc, n_add))
        if n_rej == 0 and n_acc == 0 and n_add == 0:
            print("  ** the manual file is unedited -- this comparison is (a) against")
            print("     itself and the perfect scores above mean nothing.")


# ==================================================================== commands

def check_provenance(meta, r, fatal=True):
    _, sig = config_signature(r)
    got = meta.get("config_sha1")
    if got and got != sig:
        msg = ("peak file was written under a different config\n"
               "    file:    %s\n    current: %s" % (meta.get("config", "?"),
                                                     config_signature(r)[0]))
        if fatal:
            sys.exit("ERROR: " + msg)
        print("  ** WARNING: " + msg, file=sys.stderr)


def expand_inputs(specs):
    if isinstance(specs, str):
        specs = [specs]
    paths = []
    for spec in specs:
        spec = os.path.expanduser(os.path.expandvars(spec))
        if os.path.isdir(spec):
            paths += sorted(glob.glob(os.path.join(spec, "*.edf")))
        else:
            hits = sorted(glob.glob(spec))
            paths += hits if hits else [spec]
    seen, out = set(), []
    for p in paths:
        if p not in seen and os.path.isfile(p):
            seen.add(p); out.append(p)
    return out


def _hexdump(buf, n=64, base=0):
    """Classic offset / hex / printable dump.  ASCII only, safe to paste."""
    lines = []
    for i in range(0, min(n, len(buf)), 16):
        chunk = buf[i:i + 16]
        hx = " ".join("%02x" % c for c in chunk)
        pr = "".join(chr(c) if 32 <= c < 127 else "." for c in chunk)
        lines.append("    %04x  %-47s  |%s|" % (base + i, hx, pr))
    return lines


def cmd_marks(args):
    """Report -- and export -- Ponemah's own beat list and bad-data intervals.

    Two things this project could not previously obtain at any price:

      (b) a second opinion on every beat, to measure the detector against,
          with nothing marked by hand; and
      the intervals to exclude, stated by the acquisition system rather than
      inferred by this tool.

    Both are in the .PnmMarks sidecar.  This command reads them, states what
    it found, and tests the one thing that decides how they may be used: does
    the beat list already exclude the bad intervals, or not.
    """
    paths = expand_inputs(args.input)
    if not paths:
        print("  no input files matched", file=sys.stderr)
        return 2

    print("=" * 120)
    print("%s  marks  |  %d file(s)  |  Ponemah's own detections"
          % (VERSION, len(paths)))
    print("=" * 120)
    print("  Times in this file are .NET ticks: 100 ns since 0001-01-01.  The")
    print("  unit was checked, not assumed -- see the note beside")
    print("  NET_TICKS_PER_S in the source.  Elapsed seconds are differences,")
    print("  so they hold whatever the epoch and whatever the timezone.")
    print()

    rc = 0
    for path in paths:
        print("  " + "-" * 116)
        print("  file        %s" % path)
        m = read_marks(path)
        if not m["ok"]:
            print("  NOT READ    %s" % m["why"])
            if m["tables"]:
                print("  tables      %s"
                      % ", ".join("%s(%s)" % (k, v)
                                  for k, v in sorted(m["tables"].items())))
            rc = 1
            continue

        t0, t1 = m["t0"], m["t1"]
        # Two different origins, and they are not interchangeable.
        #
        # t0 (the first beat) is what the narrative below is measured from,
        # because "3,412 s after the first beat" is how a reader navigates a
        # beat list.  exp_t0 is what the EXPORTS are measured from, because a
        # peak file is read back against a WAVEFORM, and a waveform's zero is
        # the start of the recording.  Using the first beat for both is what
        # put every exported marker 0.254 s from its beat on P10.
        exp_t0, exp_src = _pnm_container_origin(path)
        if exp_t0 is None:
            exp_t0, exp_note = t0, ("first beat -- %s" % exp_src)
        else:
            exp_note = "recording start, stated by %s" % exp_src

        d0, d1 = ticks_to_dt(t0), ticks_to_dt(t1)
        print("  first beat  %s" % (d0.isoformat(sep=" ") if d0 else t0))
        print("  last beat   %s" % (d1.isoformat(sep=" ") if d1 else t1))
        print("  span        %.3f s = %.4f h" % (m["span_s"], m["span_s"] / 3600.0))
        if m["created"]:
            dc = ticks_to_dt(m["created"])
            lead = (m["created"] - t0) / float(NET_TICKS_PER_S)
            print("  db created  %s (%.1f s %s the first beat)"
                  % (dc.isoformat(sep=" ") if dc else m["created"],
                     abs(lead), "before" if lead < 0 else "after"))
        # The filename of the waveform beside it carries a stamp.  If this
        # directory holds one, say whether the two agree -- an independent
        # witness to the tick unit costs one line and is worth having in the
        # output rather than only in a comment.
        nm = _parse_name_start(path)
        if nm and d0:
            skew = abs((d0 - nm).total_seconds())
            print("  filename    %s (%s by %.0f s)"
                  % (nm.isoformat(sep=" "),
                     "AGREES" if skew <= 86400 else "DISAGREES", skew))

        # ------------------------------------------------------- the beats
        print()
        print("  cycle table -- one row per detected cycle, written by Ponemah")
        print()
        print("     ctx  subjectChannel        cycles     span_s   bpm_mean"
              "  bpm_modal   sampleHz   kind")
        print("    " + "-" * 108)
        cardiac_ctxs = []
        epoch_ctxs = []
        for c in m["contexts"]:
            sub = c.get("SubjectChannelId")
            fs = c.get("fs")
            is_ecg = (fs is None) or (float(fs) >= 100.0)
            kind = "cardiac (ECG)" if is_ecg else "epoch (1/s tick)"
            if is_ecg:
                cardiac_ctxs.append(c)
            else:
                epoch_ctxs.append(c)
            print("    %4d  %14s  %11s  %10.1f  %9.2f  %9.2f  %9s   %s"
                  % (c["ctx"], sub if sub is not None else "-",
                     "{:,}".format(c["n"]), c["span_s"], c["bpm_mean"],
                     c["bpm_modal"],
                     ("%g" % fs) if fs else "not stated", kind))
        if epoch_ctxs:
            print()
            print("    NOTE  contexts %s run at 1-10 Hz and show modal 60.00"
                  " because they emit"
                  % ", ".join(str(c["ctx"]) for c in epoch_ctxs))
            print("          one reduction epoch per second (60/min), not"
                  " cardiac beats.")
        # Inter-lead agreement check across simultaneous ECG leads.
        if len(cardiac_ctxs) >= 2:
            counts = sorted(c["n"] for c in cardiac_ctxs)
            spread_all = counts[-1] - counts[0]
            print()
            print("    INTER-LEAD CHECK (same heart, same %.2f h):"
                  % (m["span_s"] / 3600.0))
            print("      simultaneous ECG leads report %s beats"
                  % ", ".join("{:,} (ctx {})".format(c["n"], c["ctx"])
                              for c in cardiac_ctxs))
            print("      spread across all ECG leads:   {:,} beats".format(
                spread_all))
            # Even ignoring dead/dropped leads (<50% of max), check active leads
            active = [c for c in cardiac_ctxs if c["n"] >= 0.5 * counts[-1]]
            if len(active) >= 2:
                ac = sorted(c["n"] for c in active)
                diff = ac[-1] - ac[0]
                pct = 100.0 * diff / float(ac[0]) if ac[0] else 0.0
                print("      spread between active leads:   {:,} beats"
                      " ({:.1f}% disagreement on the same heart)".format(
                          diff, pct))
        for c in cardiac_ctxs:
            if (np.isfinite(c["bpm_mean"]) and np.isfinite(c["bpm_modal"])
                    and c["bpm_modal"] > 0
                    and c["bpm_mean"] < 0.9 * c["bpm_modal"]):
                print("    NOTE  ctx %d: mean rate is %.0f%% of the modal rate"
                      " -- Ponemah missed ~%.0f%% of beats on this lead."
                      % (c["ctx"], 100.0 * c["bpm_mean"] / c["bpm_modal"],
                         100.0 * (1.0 - c["bpm_mean"] / c["bpm_modal"])))

        # ------------------------------------------------- the bad intervals
        print()
        raw_bad = [(a, b) for _s, a, b in m["bad"]]
        merged = merge_tick_spans(raw_bad)
        if not merged:
            print("  bad-data intervals -- none recorded")
        else:
            tot = sum(b - a for a, b in merged) / float(NET_TICKS_PER_S)
            rawtot = sum(b - a for a, b in raw_bad) / float(NET_TICKS_PER_S)
            print("  bad-data intervals -- Ponemah's OWN statement of what to"
                  " exclude")
            print()
            print("    marks        %d (%d after merging overlaps)"
                  % (len(raw_bad), len(merged)))
            print("    excluded     %.1f s = %.3f h = %.2f%% of the span"
                  % (tot, tot / 3600.0,
                     100.0 * tot / m["span_s"] if m["span_s"] else 0.0))
            if rawtot > tot + 0.5:
                print("                 (summing them unmerged would have said"
                      " %.1f s --" % rawtot)
                print("                  %.1f s of double-counted overlap)"
                      % (rawtot - tot))
            durs = sorted(((b - a) / float(NET_TICKS_PER_S), a)
                          for a, b in merged)
            print("    shortest     %.2f s" % durs[0][0])
            print("    median       %.2f s" % durs[len(durs) // 2][0])
            print("    longest      %.2f s, starting %.1f s in"
                  % (durs[-1][0],
                     (durs[-1][1] - t0) / float(NET_TICKS_PER_S)))
            print()
            print("    the five longest, as seconds from the first beat")
            for dur, a in durs[-5:][::-1]:
                print("      %10.1f .. %10.1f  (%.1f s)"
                      % ((a - t0) / float(NET_TICKS_PER_S),
                         (a - t0) / float(NET_TICKS_PER_S) + dur, dur))

            # ---- the question that decides how to use these two tables
            print()
            print("  are the marked intervals already excluded, and what is"
                  " the clean rate?")
            print()
            print("     ctx       in_marks   expected  status      clean_beats"
                  "   clean_span_s   clean_bpm")
            print("    " + "-" * 86)
            for c in m["contexts"]:
                inside = beats_in_spans(c["times"], merged)
                frac_t = tot / m["span_s"] if m["span_s"] else 0.0
                expect = frac_t * c["n"]
                verdict = ("EXCLUDED" if inside <= 0.2 * expect
                           else "KEPT" if inside >= 0.7 * expect
                           else "PARTIAL")
                # Overlap of merged bad spans with this context's [t0, t1].
                c_bad_s = sum(
                    max(0, min(b, c["t1"]) - max(a, c["t0"]))
                    for a, b in merged
                ) / float(NET_TICKS_PER_S)
                clean_n = c["n"] - inside
                clean_s = max(0.0, c["span_s"] - c_bad_s)
                clean_bpm = (60.0 * clean_n / clean_s
                             if clean_s > 0 else float("nan"))
                print("    %4d  %12s  %9.0f   %-9s  %11s   %12.1f   %9.2f"
                      % (c["ctx"], "{:,}".format(inside), expect, verdict,
                         "{:,}".format(clean_n), clean_s, clean_bpm))
            print()
            print("    EXCLUDED means Ponemah already dropped those cycles."
                  "  KEPT means")
            print("    Ponemah detected right through its own bad-data marks"
                  " and left them")
            print("    in the table -- clean_bpm excises both the marked"
                  " beats (numerator)")
            print("    and the marked seconds (denominator).")

        # ------------------------------------------------------- the exports
        if getattr(args, "export_beats", None):
            want = getattr(args, "context", None)
            pool = cardiac_ctxs if cardiac_ctxs else m["contexts"]
            picks = ([c for c in m["contexts"] if c["ctx"] == want] if want
                     is not None else
                     # Default to the busiest CARDIAC context (so a 1-Hz epoch
                     # channel is never exported as heartbeats by accident).
                     [max(pool, key=lambda c: c["n"])])
            if not picks:
                print("  --context %s matched no context" % want,
                      file=sys.stderr)
                rc = 1
            else:
                c = picks[0]
                n = write_marks_peaks(args.export_beats, c, exp_t0, path,
                                      merged)
                print()
                print("  wrote %s" % args.export_beats)
                print("        %d beat(s) from context %d, times in seconds"
                      % (n, c["ctx"]))
                print("        from the %s." % exp_note)
                print("        This is the format `compare --manual` reads.")
                if exp_t0 != t0:
                    print("        The first beat therefore sits at %.4f s,"
                          " not 0 -- which is"
                          % ((t0 - exp_t0) / float(NET_TICKS_PER_S)))
                    print("        correct: a heart does not beat at sample"
                          " zero.  These times can")
                    print("        now go straight to `show` without a shift.")

        if getattr(args, "export_excl", None):
            _excl_dir = os.path.dirname(os.path.abspath(args.export_excl))
            if _excl_dir:
                os.makedirs(_excl_dir, exist_ok=True)
            with open(args.export_excl, "w", newline="") as f:
                f.write("# %s\n" % VERSION)
                f.write("# source_file: %s\n" % os.path.abspath(path))
                f.write("# origin: Ponemah BadDataMark, merged\n")
                f.write("# origin_is: %s\n" % exp_note)
                f.write("# t0_ticks: %d\n" % exp_t0)
                w = csv.writer(f)
                w.writerow(["start_s", "end_s", "dur_s"])
                for a, b in merged:
                    # Same origin as the beat export above, and for the
                    # stronger reason: a span is used to CUT a waveform, so an
                    # origin 0.254 s out moves both edges of all 344 intervals
                    # and either leaks bad samples in or excises good ones.
                    w.writerow(["%.4f" % ((a - exp_t0) / float(NET_TICKS_PER_S)),
                                "%.4f" % ((b - exp_t0) / float(NET_TICKS_PER_S)),
                                "%.4f" % ((b - a) / float(NET_TICKS_PER_S))])
            print("  wrote %s" % args.export_excl)
            print("        %d merged interval(s), from the %s"
                  % (len(merged), exp_note))

        print()
    return rc


def write_marks_peaks(path, ctx, t0, src, bad_spans=()):
    """Write a Ponemah beat list in the peak-file format `compare` reads.

    Times are seconds from `t0`, which the CALLER chooses and which is written
    into the header as t0_ticks so it can be checked rather than assumed.

    There are only two sane choices and they differ by a quarter of a second
    on P10.  The recording's start, stated by the .PnmWav container, is the
    one that lines these times up with a waveform -- that is what
    `cmd_marks` passes when the companion file is present.  The first beat in
    the sidecar is the fallback when it is not, and it is a fallback, not an
    origin: it puts t=0 at the first heartbeat, which is 0.254 s after the
    recording actually began.


    Rows inside a bad-data interval are written with keep=0 rather than
    dropped.  Dropping them would hide the exclusion; keep=0 makes it visible,
    reversible, and countable, and `read_peaks` already honours it.
    """
    times = np.asarray(ctx["times"], dtype=np.int64)
    inside = set()
    if len(bad_spans):
        starts = np.array([a for a, _ in bad_spans], dtype=np.int64)
        ends = np.array([b for _, b in bad_spans], dtype=np.int64)
        i = np.searchsorted(starts, times, side="right") - 1
        ok = (i >= 0) & (times <= ends[np.clip(i, 0, None)])
        inside = set(np.nonzero(ok)[0].tolist())
    fs = ctx.get("fs")

    # How much TIME the exclusion removed, not just how many beats.
    #
    # The rows below drop bad-data beats from the numerator (keep=0, which
    # read_peaks honours).  A reader that then divides by `duration_s` is
    # dividing a cleaned beat count by an uncleaned span, and gets a rate
    # biased low by exactly the marked fraction -- 8.41% on P10.  That is the
    # precise error this project exists to avoid, so the denominator has to
    # travel with the numerator.
    span_lo = int(times[0]) if len(times) else int(t0)
    span_hi = int(times[-1]) if len(times) else int(t0)
    excl_ticks = 0
    for _a, _b in bad_spans:
        lo, hi = max(int(_a), span_lo), min(int(_b), span_hi)
        if hi > lo:
            excl_ticks += hi - lo
    excluded_s = excl_ticks / float(NET_TICKS_PER_S)
    analysable_s = max(0.0, float(ctx["span_s"]) - excluded_s)

    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", newline="") as f:
        f.write("# %s\n" % VERSION)
        f.write("# source_file: %s\n" % os.path.abspath(src))
        f.write("# origin: Ponemah Cycle table, ChannelContextId %d\n"
                % ctx["ctx"])
        f.write("# subject_channel: %s\n" % ctx.get("SubjectChannelId"))
        if fs:
            f.write("# fs_hz: %.4f\n" % fs)
        f.write("# t0_ticks: %d\n" % t0)
        f.write("# duration_s: %.4f\n" % ctx["span_s"])
        f.write("# excluded_s: %.4f\n" % excluded_s)
        f.write("# analysable_s: %.4f\n" % analysable_s)
        f.write("# n_beats: %d\n" % len(times))
        f.write("# n_in_bad_data: %d  (written keep=0)\n" % len(inside))
        f.write("#\n")
        f.write("# These beats were detected by PONEMAH, not by this tool.\n")
        f.write("# Use them with `compare --manual` to measure agreement.\n")
        f.write("# Agreement is not accuracy: both detectors can be wrong in\n")
        f.write("# the same place, and on a paced animal with dissociated P\n")
        f.write("# waves they may well be.\n")
        w = csv.DictWriter(f, fieldnames=PEAK_FIELDS)
        w.writeheader()
        for k, t in enumerate(times):
            sec = (int(t) - int(t0)) / float(NET_TICKS_PER_S)
            w.writerow(dict(time_s="%.4f" % sec,
                            sample=(int(round(sec * fs)) if fs else ""),
                            amp="", rhythm="", cluster=-1, qc=0,
                            source="PONEMAH",
                            keep=0 if k in inside else 1,
                            note="bad_data" if k in inside else ""))
    return len(times)


def cmd_probe(args):
    """Report what an unrecognised file actually is, with evidence.

    Deliberately read-only and deliberately non-committal: it never claims to
    have decoded anything, it reports measurements and ranks hypotheses.  The
    output is meant to be pasted back, because the file itself cannot be.
    """
    paths = expand_inputs(args.input)
    if not paths:
        print("  no such file", file=sys.stderr)
        return 2
    print("=" * 120)
    print("%s  probe  |  %d file(s)  |  assuming %g Hz where a rate is needed"
          % (VERSION, len(paths), float(args.fs_hint)))
    print("=" * 120)
    fs_hint = float(args.fs_hint)

    for path in paths:
        size = os.path.getsize(path)
        with open(path, "rb") as f:
            head = f.read(min(size, 1 << 16))
            # Sample from a third of the way in as well: many containers open
            # with a long text or index block, and judging the payload by the
            # first 64 KB alone would score the header, not the data.
            mid_off = (size // 3) & ~4095
            f.seek(mid_off)
            body = f.read(min(1 << 21, max(0, size - mid_off)))

        print("  " + "-" * 116)
        print("  file        %s" % path)
        print("  size        %d bytes (%.2f MB)" % (size, size / 1048576.0))

        magic = [d for m, d in _MAGICS if head.startswith(m)]
        if head[:4] == b"RIFF" and head[8:12] == b"WAVE":
            magic = ["RIFF/WAVE -- this tool can read it: use the file directly"]
        print("  magic       %s" % (magic[0] if magic else "none recognised"))

        printable = sum(1 for c in head if 32 <= c < 127 or c in (9, 10, 13))
        pfrac = printable / float(len(head)) if head else 0.0
        print("  printable   %.1f%% of the first %d bytes" % (100.0 * pfrac, len(head)))

        # -------------------------------------------------- text export path
        if pfrac > 0.95:
            print()
            print("  This is a TEXT file.  First lines verbatim:")
            try:
                txt = head.decode("utf-8", "replace")
            except Exception:                                # noqa: BLE001
                txt = head.decode("latin-1", "replace")
            lines = txt.splitlines()
            for ln in lines[:20]:
                print("    | %s" % ln[:150])
            # Delimiter and width, from the LAST lines rather than the first:
            # a header block usually does not share the data's column count.
            tail = [l for l in lines[5:60] if l.strip()]
            if tail:
                cand = {",": 0, "\t": 0, ";": 0, " ": 0}
                for d in cand:
                    counts = [l.count(d) for l in tail]
                    # A real delimiter appears a consistent number of times.
                    cand[d] = (min(counts), len(set(counts)))
                best = max(cand, key=lambda d: (cand[d][0] > 0, -cand[d][1], cand[d][0]))
                nm = {",": "comma", "\t": "TAB", ";": "semicolon", " ": "space"}[best]
                print()
                print("  delimiter   probably %s (%d per line, %d distinct counts"
                      " over %d sampled lines)"
                      % (nm, cand[best][0], cand[best][1], len(tail)))
                print("  fields      %d" % (cand[best][0] + 1))
            print()
            print("  No ASCII reader is wired up yet.  Send this output and one")
            print("  will be written against the real column layout rather than")
            print("  a guessed one -- including which column is time, which is")
            print("  ECG, and whether the rate is stated or must be inferred.")
            continue

        # ------------------------------------------------------ archive path
        # An .xlsx is a ZIP of XML, so the standard library can say what is in
        # it.  Worth doing before the layout search, because searching
        # DEFLATE-compressed bytes for a waveform can only ever produce noise
        # dressed up as a candidate.
        if head[:2] == b"PK":
            zi = zip_describe(path)
            print()
            if not zi["ok"]:
                print("  ZIP-like magic, but it did not open: %s" % zi["why"])
                continue
            print("  %s archive -- %d entr%s"
                  % (zi["kind"], zi["n_entries"],
                     "y" if zi["n_entries"] == 1 else "ies"))
            if zi["sheets"]:
                print("  worksheets  %s" % ", ".join(zi["sheets"]))
            print()
            print("      bytes  name")
            print("    " + "-" * 76)
            for nm, sz in sorted(zi["entries"], key=lambda t: -t[1])[:16]:
                print("    %9d  %s" % (sz, nm[:64]))
            if zi["n_entries"] > 16:
                print("    ... %d more" % (zi["n_entries"] - 16))
            print()
            if zi["kind"] == "xlsx":
                print("  This is a spreadsheet.  If it holds Ponemah's OWN derived")
                print("  results -- per-interval heart rate, RR statistics -- it is")
                print("  the one thing this project cannot generate for itself: an")
                print("  independent second opinion to check `trend` against, and a")
                print("  way to measure detection accuracy without hand-marking.")
                print("  Send the worksheet names and the first few rows of the one")
                print("  that looks like results, and a reader will be written")
                print("  against the real columns.")
            continue

        # ------------------------------------------------------ SQLite path
        # Ponemah's four sidecars are all SQLite, and one of them is the most
        # valuable file in the directory: a Cycle table indexed on CycleTime,
        # which is very likely Ponemah's OWN per-beat detections -- the
        # independent second opinion this project otherwise has no source for.
        if head.startswith(b"SQLite format 3"):
            si = sqlite_describe(path, sample=int(getattr(args, "rows", 0) or 0))
            print()
            if not si["ok"]:
                print("  SQLite magic, but it did not open: %s" % si["why"])
                print("  (opened read-only and immutable, so a lock held by a")
                print("   running Ponemah is not the explanation)")
                continue
            print("  SQLite database -- %d table(s), %d pages of %d bytes"
                  % (len(si["tables"]), si["npages"], si["page_size"]))
            print()
            print("      rows  table / columns")
            print("    " + "-" * 110)
            for t in si["tables"]:
                print("    %9s  %s"
                      % ("?" if t["nrow"] is None else "{:,}".format(t["nrow"]),
                         t["name"]))
                if t["why"]:
                    print("               (%s)" % t["why"][:90])
                cols = ", ".join("%s %s" % (c, ty or "?") for c, ty in t["cols"])
                for k in range(0, len(cols), 96) or [0]:
                    print("               %s" % cols[k:k + 96])
                for cn, (lo, hi) in t["spans"].items():
                    # The tick unit is now settled (see NET_TICKS_PER_S), so a
                    # span in that range is shown decoded AND raw.  Anything
                    # outside the range is left raw: a value that is not a
                    # timestamp must not be rendered as a date.
                    dlo, dhi = ticks_to_dt(lo), ticks_to_dt(hi)
                    plausible = (dlo is not None and dhi is not None
                                 and 1990 <= dlo.year <= 2100
                                 and 1990 <= dhi.year <= 2100)
                    if plausible:
                        print("               %s  %s .. %s  (%.1f s = %.3f h)"
                              % (cn, dlo.isoformat(sep=" "),
                                 dhi.isoformat(sep=" "),
                                 (hi - lo) / float(NET_TICKS_PER_S),
                                 (hi - lo) / float(NET_TICKS_PER_S) / 3600.0))
                    else:
                        print("               %s spans %s .. %s" % (cn, lo, hi))
                for ri, r in enumerate(t["rows"], 1):
                    # Labelled, one field per line.  A bare tuple is unreadable
                    # the moment a column holds a paragraph of configuration,
                    # which is exactly what ConfigInfo.Payload does.
                    print("               row %d" % ri)
                    names = [c for c, _ty in t["cols"]] or [
                        "col%d" % k for k in range(len(r))]
                    for cn, v in zip(names, r):
                        s = repr(v)
                        print("                 %-22s %s"
                              % (cn, s[:200] + (" ..." if len(s) > 200 else "")))
            print()
            print("  No waveform search was run: the magic already identified")
            print("  this as a database, and searching B-tree pages for a")
            print("  biosignal can only produce noise dressed up as a finding.")
            print("  (An earlier build did exactly that and pronounced a 122 KB")
            print("   event log a near-certain biosignal layout.  The phrase it")
            print("   used is deliberately not repeated here, so that grepping")
            print("   this output for a verdict finds only real ones.)")
            print()
            print("  Re-run with --rows N to see the first N rows of each table.")
            continue

        # -------------------------------------------- EDF: use the real reader
        # The layout search on an EDF returns "NOT RESOLVED" every time, which
        # reads as a failure and is nothing of the kind -- the file is one this
        # tool opens directly.  Say that instead of searching.
        if head.startswith(b"0       "):
            print()
            try:
                edf = MiniEDF(path)
                print("  EDF -- this tool reads it directly, so no search is")
                print("  needed.  %d signal(s):" % edf.ns)
                for i in range(edf.ns):
                    print("    %2d  %-18s %8g Hz  %s"
                          % (i, edf.labels[i][:18], edf.fs[i], edf.units[i]))
                print("  duration    %g s over %d record(s) of %g s"
                      % (edf.num_records * edf.rec_duration, edf.num_records,
                         edf.rec_duration))
                print("  start       %s (header bytes 168-184: %s %s)"
                      % (edf.start_dt.isoformat(sep=" ") if edf.start_dt
                         else "not stated", edf.start_raw[0], edf.start_raw[1]))
            except (ValueError, OSError, AttributeError) as e:
                print("  EDF magic, but the header did not parse: %s" % e)
                print("  That IS worth a layout search -- re-run with --force.")
                if not getattr(args, "force", False):
                    continue
            else:
                continue

        # ------------------- other containers the magic has already identified
        # Searching compressed or structured bytes for an interleaved waveform
        # is guaranteed to return SOMETHING, and that something is noise.  The
        # 13 matplotlib PNGs in the P10 directory each got a confident verdict.
        _KNOWN_NOT_SIGNAL = [
            (b"\x89PNG\r\n\x1a\n", "PNG image"),
            (b"\x1f\x8b", "gzip stream"),
            (b"\x89HDF", "HDF5"),
            (b"\xd0\xcf\x11\xe0", "OLE2 / Compound File"),
            (b"%PDF", "PDF"),
        ]
        _kn = next((d for m, d in _KNOWN_NOT_SIGNAL if head.startswith(m)), None)
        if _kn and not getattr(args, "force", False):
            print()
            print("  %s.  No waveform search was run -- the magic settles it,"
                  % _kn)
            print("  and a search over these bytes returns a confident verdict")
            print("  about nothing.  Use --force to search anyway.")
            continue

        # ------------------------------------------------- binary probe path
        print()
        print("  first 64 bytes")
        for ln in _hexdump(head, 64):
            print(ln)

        runs = probe_text(head, minlen=6, limit=12)
        if runs:
            print()
            print("  printable runs in the header (offset: text)")
            for off, s in runs:
                print("    %6d: %s" % (off, s[:100]))

        # If the header is text followed by binary, the changeover is a strong
        # candidate for the data offset, so feed it to the search.
        extra = []
        container_endian = None
        for off, s in runs:
            extra.append(off + len(s))
        if head[:4] == b"RIFF":
            container_endian = "little"          # RIFF is little-endian by spec
            try:
                info = wav_describe(path)
                print()
                print("  RIFF/WAVE header")
                print("    chunks    %s" % ", ".join(
                    "%s@%d(%d)" % (c, p, s) for c, p, s in info["chunks"][:8]))
                fm = info["fmt"]
                print("    format    tag %d, %d ch, %g Hz, %d-bit"
                      % (fm["audio_format"], fm["nch"], fm["fs"], fm["bits"]))
                print("    data      offset %d, %d bytes" % info["data"])
                extra.append(info["data"][0])
            except ValueError as e:
                print("    (RIFF header did not parse: %s)" % e)

        if head.startswith(PNMWAV_MAGIC):
            # The metadata chain decodes, so print what it says.  Every length
            # in it is little-endian, which is recorded and later used to
            # challenge a big-endian candidate rather than just noted.
            container_endian = "little"
            pw = pnmwav_describe(path)
            print()
            print("  Ponemah native container -- metadata chain reads")
            print("    (uint16 tag, uint32 length, value; little-endian.  The")
            print("     TAG NUMBERS are mostly not decoded: nothing in the")
            print("     file says what 5000 or 5044 mean, so they are")
            print("     reported, not named.  The %d tag(s) that ARE named"
                  % len(PNMWAV_TAG_NAMES))
            print("     below each have two independent witnesses; see")
            print("     PNMWAV_TAG_NAMES in the source for which.)")
            print()
            print("      offset    tag   len  value")
            print("    " + "-" * 110)
            for r in pw["records"][:40]:
                _nm = PNMWAV_TAG_NAMES.get(r["tag"])
                print("    %8d  %5d  %4d  %s%s"
                      % (r["offset"], r["tag"], r["length"],
                         pnmwav_render(r["value"])[:80],
                         "   <- %s" % _nm[0] if _nm else ""))

            if len(pw["records"]) > 40:
                print("    ... %d more record(s)" % (len(pw["records"]) - 40))
            print()
            print("    %d record(s); chain stops at byte %d"
                  % (len(pw["records"]), pw["stop"]))
            print("    because: %s" % pw["why"])

            # What is this file made of?  A chain of half a million records
            # cannot be read line by line, and does not need to be: one row
            # per tag says it.
            cens = pw["census"]
            if len(cens) > 1 or (cens and cens[0]["count"] > 40):
                print()
                print("    tag census -- what the chain is made of")
                print("        tag   count        bytes   share  value"
                      " length(s)          meaning")
                print("    " + "-" * 94)
                for c in cens[:14]:
                    lens = ", ".join(str(x) for x in c["lengths"][:5])
                    if len(c["lengths"]) > 5:
                        lens += ", ..."
                    _nm = PNMWAV_TAG_NAMES.get(c["tag"])
                    print("      %5d  %6d  %11d  %5.1f%%  %-18s %s"
                          % (c["tag"], c["count"], c["bytes"],
                             100.0 * c["bytes"] / max(1, pw["size"]),
                             lens[:18], _nm[0] if _nm else ""))

                if len(cens) > 14:
                    print("      ... %d more tag(s)" % (len(cens) - 14))

            # Timestamps only count when they agree with a clock we already
            # trust.  Any 8-byte value can be read as a date; one that lands
            # on the filename's second cannot be a coincidence.
            name_dt = _parse_name_start(path)
            clocks = pnmwav_clocks(pw["records"], want_dt=name_dt)
            agree = [c for c in clocks if c["agrees"]]
            if agree:
                print()
                print("    timestamps that AGREE with the filename (%s)"
                      % name_dt.isoformat(sep=" "))
                for c in agree[:4]:
                    print("      offset %d, tag %d: %s as %s"
                          % (c["offset"], c["tag"], c["dt"].isoformat(sep=" "),
                             c["epoch"]))
                # If one record is the start, the natural companion is the end.
                same = [c for c in clocks if c["epoch"] == agree[0]["epoch"]
                        and c["dt"] > agree[0]["dt"]]
                if same:
                    span = (same[-1]["dt"] - agree[0]["dt"]).total_seconds()
                    print("      the latest other %s value is %s,"
                          % (agree[0]["epoch"], same[-1]["dt"].isoformat(sep=" ")))
                    print("      %.0f s = %.3f h after it -- compare that against"
                          % (span, span / 3600.0))
                    print("      how long the recording actually ran.")

            if pw["bulk_tag"] is not None:
                # The samples are INSIDE the chain, not after it.
                nsp = len(pw["bulk_spans"])
                lens = sorted(set(L for _o, L in pw["bulk_spans"]))
                print()
                print("    BLOCK-FRAMED: tag %d carries %d bytes (%.1f MB, %.1f%%"
                      " of the file)"
                      % (pw["bulk_tag"], pw["bulk_bytes"],
                         pw["bulk_bytes"] / 1048576.0,
                         100.0 * pw["bulk_bytes"] / max(1, pw["size"])))
                print("    in %d record(s) of %s byte(s) each."
                      % (nsp, lens[0] if len(lens) == 1
                         else "%d..%d" % (lens[0], lens[-1])))
                print("    There is therefore NO contiguous payload to search:")
                print("    every block is separated from the next by a 6-byte")
                print("    header, which is enough to destroy any correlation.")
                print("    `verify` concatenates the block values and searches")
                print("    those instead.")
                payload = pw["bulk_bytes"]
            elif pw["data_offset"]:
                payload = pw["size"] - pw["data_offset"]
                print("    payload %d bytes (%.2f MB) follow"
                      % (payload, payload / 1048576.0))
                extra.append(pw["data_offset"])
            else:
                payload = 0
                print("    no trailing payload: the chain accounts for the file.")

            # Which (width x channels) divide the payload exactly?  This is
            # arithmetic, not evidence, and is labelled as such -- but it does
            # rule things out, and the durations make wrong ones obvious.
            want_s = None
            if agree:
                same = [c for c in clocks if c["epoch"] == agree[0]["epoch"]
                        and c["dt"] > agree[0]["dt"]]
                if same:
                    want_s = (same[-1]["dt"] - agree[0]["dt"]).total_seconds()
            opts = pnmwav_payload_options(payload, fs_hint, want_s=want_s)
            if opts:
                print()
                print("    if the payload is plain interleaved samples at %g Hz,"
                      " these strides divide it exactly:" % fs_hint)
                if want_s:
                    print("    (ranked against the %.0f s the container's own"
                          " timestamps span)" % want_s)
                print("      stride      frames     duration   width x channels")
                for o in opts[:10]:
                    print("      %6d  %10d   %8.1f s = %5.2f h   %s"
                          % (o["stride"], o["nsamp"], o["dur_s"],
                             o["dur_s"] / 3600.0,
                             ", ".join("%dB x %d" % (i, c)
                                       for i, c in o["splits"])))
                print("    (divisibility is a WEAK test -- a 2-byte stride divides")
                print("     almost anything.  And every split on a row is exactly")
                print("     as consistent as the others: duration fixes the frame")
                print("     stride, never the width/channel split.  Compare the")
                print("     durations against how long the recording actually ran,")
                print("     then use `verify` to settle the split.)")

        cands = probe_layouts(body, extra_offsets=extra)
        if not cands:
            print()
            print("  Not enough data to test any layout.")
            continue

        print()
        print("  layout search -- %d interpretations tested on %d bytes from"
              " offset %d" % (len(cands), len(body), mid_off))
        print("  (r1..r4 = autocorrelation at lags 1-4.  A waveform correlates")
        print("   with itself at the lag equal to its channel count: ~0.99 for a")
        print("   clean trace, but as low as ~0.3 for a noisy one.  What settles")
        print("   it is the CONTRAST -- a wrong reading of the same bytes scores")
        print("   ~0.00 -- so compare the rows, do not judge the number alone.)")
        print()
        # Offsets are printed ABSOLUTE.  They are searched relative to the
        # sampled window, and printing them that way once produced a table
        # reading "offset 0" for a window that began 68 MB into the file --
        # which says "the data starts at the top of the file" when it says
        # nothing of the kind.
        print("    dtype  file offset      r1      r2      r3      r4   peak  nch?  ties")
        print("    " + "-" * 73)
        # Group first, print second.  Counting ties while printing gets the
        # count wrong for every row, because the ties arrive after the row that
        # reports them.
        groups, order = {}, []
        for c in cands:
            # One row per (dtype, score-to-tolerance).  Different offsets that
            # score the same are the same claim about the format.
            key = (c["dtype"], int(c["score"] / PROBE_TIE))
            if key not in groups:
                groups[key] = [c, 0]
                order.append(key)
            groups[key][1] += 1
        for key in order[:8]:
            c, ntie = groups[key]
            a = c["acs"]
            print("    %-5s %11d  %6.3f  %6.3f  %6.3f  %6.3f  %5.3f  %4s  %4d"
                  % (c["dtype"], mid_off + c["offset"], a[0], a[1], a[2], a[3],
                     c["score"], c["nch_hint"] or "-", ntie - 1))
        print("    (`ties` counts other offsets scoring the same for that dtype;")
        print("     the offset shown is the earliest of them, as an absolute")
        print("     position in the file.)")

        best = cands[0]
        print()

        # De-interleave on the inferred channel count and run the confirmatory
        # periodicity test.  Smoothness alone can be produced by reading the
        # high bytes of a wider word; a peak at a physiological interval is a
        # much stronger claim.
        nch = max(1, best["nch_hint"])
        dt = np.dtype(best["dtype"])
        navail = (len(body) - best["offset"]) // dt.itemsize
        n = int(min(navail, 120000)) // nch * nch
        bpm = float("nan")
        rac = chance = 0.0
        if n >= nch * 64:
            x = np.frombuffer(body, dtype=dt, count=n,
                              offset=best["offset"]).astype(np.float64)
            ch0 = x.reshape(-1, nch)[:, 0]
            bpm, rac, chance = probe_rate(ch0 - ch0.mean(), fs_hint)
            print("  best candidate: %s at file offset %d, %d interleaved channel(s)"
                  % (best["dtype"], mid_off + best["offset"], nch))
            print("    channel 0   %d samples, range %.6g .. %.6g"
                  % (len(ch0), ch0.min(), ch0.max()))
            print("    at %g Hz that is %.1f s of recording per channel"
                  % (fs_hint, len(ch0) / fs_hint))
            print("    periodicity strongest at %.1f bpm (r = %.3f, chance %.3f,"
                  " %.0fx)" % (bpm, rac, chance,
                               (rac / chance) if chance > 0 else 0.0))
            print()

        _, vlines = probe_verdict(best, bpm, rac, chance, fs_hint,
                                  container_endian=container_endian)
        for ln in vlines:
            print(("  " + ln) if ln else "")
    print()
    return 0


def verify_channels(raw, groups, id_tag, descs, ref, ref_fs, ref_labels,
                    seconds=10.0, dtype="<i2"):
    """Match every RAW channel against every REFERENCE channel, and report.

    A multiplexed container has no single "the payload".  Concatenating all its
    blocks and correlating once answers a question nobody asked: on P10 that
    scored 0.988, which looks like a near miss and is actually a clean match
    against whichever channel happened to own the first block, with the other
    six channels spliced in behind it.  A near miss and a clean match on the
    wrong stream are indistinguishable from one number, so stop producing one
    number.

    Each channel is read as its own stream and scored against each reference
    channel.  That turns the ambiguity into a mapping -- which raw channel IS
    which exported lead -- and the mapping is the thing a reader needs.

    Returns (rows, best) where `best` is the winning row or None.
    """
    order = sorted(groups)
    big = max((sum(L for _o, L in groups[c]) for c in order), default=0)
    want = int(max(64, seconds * ref_fs))
    rows = []
    for ch in order:
        spans = groups[ch]
        nbytes = sum(L for _o, L in spans)
        src = BlockSource(raw, spans)
        buf = src.read_at(0, want * 2)
        v = np.frombuffer(buf, dtype=dtype)
        row = dict(ch=ch, blocks=len(spans), nbytes=nbytes,
                   nsamp=nbytes // 2, src=src, r=0.0, lag=0, ref_ch=-1,
                   # Rate RELATIVE to the largest channel.  Absolute rates
                   # would need a duration, and the duration is exactly what
                   # the container's clocks only imply; a ratio needs nothing.
                   rel=(float(nbytes) / big if big else 0.0))
        if len(v) >= 64:
            a = _lin_detrend(v.astype(np.float64))
            for j in range(ref.shape[1]):
                r, lag = _xcorr_best(a, _lin_detrend(ref[:len(a), j]),
                                     max_lag=int(0.5 * ref_fs))
                if abs(r) > abs(row["r"]):
                    row.update(r=r, lag=lag, ref_ch=j)
        d = descs.get(ch) or {}
        row["gain"] = d.get("gain")
        row["eng"] = (d.get("eng_lo"), d.get("eng_hi"))
        rows.append(row)

    print("  channels -- tag %d splits the payload into %d stream(s)"
          % (id_tag, len(rows)))
    print("  (rate is relative to the largest channel, which needs no")
    print("   duration to state; refCh/r is this channel against the export)")
    print()
    print("     ch  blocks        bytes      samples   rate  refCh       r"
          "   lag      gain/count")
    print("    " + "-" * 92)
    for w in rows:
        g = ("%.6g" % w["gain"]) if w["gain"] is not None else "not stated"
        print("    %3d %7d %12d %12d %6.4g %6s %7.3f %5d   %s"
              % (w["ch"], w["blocks"], w["nbytes"], w["nsamp"], w["rel"],
                 w["ref_ch"] if w["ref_ch"] >= 0 else "-", w["r"], w["lag"],
                 g))
    best = max(rows, key=lambda w: abs(w["r"])) if rows else None
    if best is not None and abs(best["r"]) < VERIFY_REJECT:
        best = None
    return rows, best


def cmd_verify(args):
    """Settle a binary layout by reproducing an export of the same recording.

    `probe` asks "do these bytes look like a signal?".  This asks the much
    stronger question "are these bytes the signal we already have?", which has
    a checkable answer whenever an export of the same recording exists -- and
    for this project it always does, because the EDF corpus came out of the
    Ponemah files.
    """
    raws = expand_inputs([args.raw])
    if len(raws) != 1:
        print("  --raw must name exactly one file (got %d)" % len(raws),
              file=sys.stderr)
        return 2
    raw = raws[0]
    refs = expand_inputs(args.against)
    if not refs:
        print("  no reference files matched --against", file=sys.stderr)
        return 2

    print("=" * 120)
    print("%s  verify  |  raw %s  |  %d reference export(s)"
          % (VERSION, os.path.basename(raw), len(refs)))
    print("=" * 120)
    print("  The question is not whether the bytes look like a signal.  It is")
    print("  whether they ARE the signal the export already contains.  A wrong")
    print("  layout correlates at ~0; the right one at ~1.  Nothing here is a")
    print("  judgement call.")
    print()

    size = os.path.getsize(raw)
    bases = [0]
    source = FileSource(raw)
    pw = pnmwav_describe(raw)
    demux_tag, demux_groups, demux_descs = None, {}, {}
    print("  raw file    %s" % raw)
    print("  size        %d bytes (%.2f MB)" % (size, size / 1048576.0))
    if pw["ok"] and pw["bulk_tag"] is not None:
        # The samples live inside the chain.  Searching file offsets here is
        # searching a stream interrupted every few thousand samples by six
        # bytes of header -- which is what produced the earlier NO MATCH at
        # r = -0.32 on P10.  Concatenate the block values and the ordinary
        # search applies again, unchanged.
        source = BlockSource(raw, pw["bulk_spans"])
        print("  container   Ponemah native, %d record(s); BLOCK-FRAMED"
              % len(pw["records"]))
        print("              tag %d holds the data: %s"
              % (pw["bulk_tag"], source.label))
        print("              offsets below are into the concatenated payload,")
        print("              not into the file")
        # ... unless the blocks belong to DIFFERENT channels, in which case
        # concatenating them splices unrelated signals together and the single
        # correlation that comes out is uninterpretable.  Demux first.
        demux_tag, demux_groups, _tbl = pnmwav_channel_tag(
            pw["records"], pw["bulk_tag"])
        if demux_groups:
            demux_descs = pnmwav_descriptors(pw["records"], demux_tag,
                                             pw["bulk_tag"])
            print("              MULTIPLEXED: tag %d splits those blocks into"
                  " %d channel(s)" % (demux_tag, len(demux_groups)))
    elif pw["ok"] and pw["data_offset"]:
        bases.insert(0, pw["data_offset"])
        print("  container   Ponemah native, %d metadata record(s), payload"
              " starts at byte %d" % (len(pw["records"]), pw["data_offset"]))
    elif pw["ok"]:
        print("  container   Ponemah native, %d record(s), but no payload was"
              " located" % len(pw["records"]))
        print("              (%s)" % pw["why"])
    else:
        print("  container   not a Ponemah header (%s); trying offset 0 and the"
              " usual header sizes" % pw["why"])
        bases += [16, 32, 44, 64, 128, 256, 512, 1024, 2048, 4096]
    for extra in getattr(args, "offsets", None) or []:
        bases.append(int(extra))

    # Order the references on the clock so "first" means first.
    placed = []
    for p in refs:
        dt, src, _ = record_start(p)
        placed.append((dt, p, src))
    placed.sort(key=lambda t: (t[0] is None, t[0] or datetime.datetime.min))
    ref_dt, ref_path, ref_src = placed[0]

    seconds = float(args.seconds)
    try:
        ref_cols, ref_fs, ref_labels, _ = load_signals(
            ref_path, minutes=max(0.5, (seconds * 3.0) / 60.0))
    except (ValueError, OSError) as e:
        print("  could not read the reference %s: %s" % (ref_path, e),
              file=sys.stderr)
        return 2
    nref = int(min(len(ref_cols), int(seconds * ref_fs)))
    ref = np.ascontiguousarray(ref_cols[:nref, :])
    print("  reference   %s" % os.path.basename(ref_path))
    print("              %d channel(s) %s at %g Hz, using the first %.1f s"
          % (ref.shape[1], ref_labels, ref_fs, nref / ref_fs))
    print("              placed at %s (%s)"
          % (ref_dt.isoformat(sep=" ") if ref_dt else "unknown", ref_src))
    print()

    # What the DIRECT per-channel match found, if the container was
    # multiplexed.  The layout search below re-derives width/count/offset from
    # scratch, and its number is the one the closing verdict used to quote --
    # which is how a run that measured r = 1.000 on three channels could end
    # with "PARTIAL ... do not write a reader yet" three lines later.  The
    # verdict has to see both numbers to avoid contradicting the table above it.
    ch_r = None
    if demux_groups:
        _rows, best_ch = verify_channels(raw, demux_groups, demux_tag,
                                         demux_descs, ref, ref_fs, ref_labels,
                                         seconds=seconds)
        print()
        if best_ch is None:
            print("  No channel matched the export.  The split is real -- the")
            print("  byte ratios are exact -- but none of these streams is the")
            print("  signal in the reference, so either the width is not 16-bit")
            print("  or the reference is a different recording.")
            return 1
        print("  channel %d is the export's channel %d (r = %.3f).  Everything"
              % (best_ch["ch"], best_ch["ref_ch"], best_ch["r"]))
        print("  below is that ONE channel, not the concatenated payload.")
        print()
        ch_r = abs(float(best_ch["r"]))
        # Narrow to the winner.  The remaining search still runs: it re-derives
        # the width and offset independently, and agreeing with a result we
        # already believe is worth more than asserting it.
        source, bases = best_ch["src"], [0]

    cands = verify_layouts(source, ref, bases, ref_fs, seconds=seconds,
                           max_nch=int(args.max_channels))
    # If nothing matched, the payload may begin off a sample boundary -- an odd
    # byte, say.  The main search only tries whole-sample starts, so it cannot
    # reach that case at all.  Sweeping single bytes is 7x the work, which is
    # why it runs only when the cheap pass has already failed.
    if not cands or abs(cands[0]["r"]) < VERIFY_REJECT:
        nudged = [b + k for b in bases for k in range(1, 8)]
        more = verify_layouts(source, ref, nudged, ref_fs, seconds=seconds,
                              max_nch=int(args.max_channels))
        if more and (not cands or abs(more[0]["r"]) > abs(cands[0]["r"])):
            print("  (no whole-sample start matched; a byte-level sweep of the")
            print("   payload offset found a better one)")
            print()
            cands = more
    # Still nothing, and the payload is framed?  Then the blocks may each open
    # with their own preamble -- a timestamp or a sequence number -- before the
    # samples start, in which case concatenating the values whole splices that
    # preamble into the middle of the signal once per block.  Dropping a fixed
    # prefix from every block is the one extra hypothesis worth testing, and it
    # is cheap because only offset 0 needs trying for each skip.
    if (source.framed and (not cands or abs(cands[0]["r"]) < VERIFY_REJECT)):
        best_skip, best_src, best_c = 0, source, cands
        for skip in (2, 4, 6, 8, 12, 16, 24, 32, 64):
            trial = BlockSource(raw, pw["bulk_spans"], skip=skip)
            if trial.nbytes < 4096:
                continue
            got = verify_layouts(trial, ref, [0], ref_fs, seconds=seconds,
                                 max_nch=int(args.max_channels))
            if got and (not best_c or abs(got[0]["r"]) > abs(best_c[0]["r"])):
                best_skip, best_src, best_c = skip, trial, got
        if best_skip:
            print("  (whole blocks did not match; dropping the first %d byte(s)"
                  % best_skip)
            print("   of every block did better -- so each block appears to")
            print("   carry a %d-byte preamble of its own)" % best_skip)
            print()
            source, cands = best_src, best_c
    if not cands:
        print("  No layout could even be decoded.  The payload may be")
        print("  compressed or the offset may be wrong.")
        return 1

    print("  layout search -- ranked by how well each reproduces the export")
    print()
    print("     dtype  ch        offset  rawCh  refCh      r   lag")
    print("    " + "-" * 62)
    for c in cands:
        print("     %-5s  %2d  %12d  %5d  %5d  %6.3f  %4d"
              % (c["dtype"], c["nch"], c["offset"], c["raw_ch"],
                 c["ref_ch"], c["r"], c["lag"]))
    print()

    best = cands[0]
    rabs = abs(best["r"])
    if rabs < VERIFY_REJECT:
        print("  VERDICT: NO MATCH.  The best of %d interpretations reaches"
              " only r = %.3f." % (len(cands), best["r"]))
        print()
        if source.framed:
            print("  The payload IS block-framed and was searched as such, so")
            print("  that explanation is already spent.  What remains: the")
            print("  blocks are compressed; the block values are not plain")
            print("  interleaved samples; more than one tag carries data; or")
            print("  the reference is not this recording.")
        else:
            print("  That means one of: the payload is not plain interleaved")
            print("  samples (compressed, or block-framed); the reference is not")
            print("  the same recording; or the payload starts somewhere not")
            print("  tried.")
        print("  Re-run with --offsets to add candidates, and send this")
        print("  output together with `probe` on the same file.")
        return 1

    fit = verify_fit(source, best, ref[:, best["ref_ch"]], ref_fs,
                     best["offset"], seconds=seconds)
    dt = np.dtype(best["dtype"])
    stride = dt.itemsize * best["nch"]
    payload = source.nbytes - best["offset"]

    level, vlines = verify_verdict(rabs, ch_r)
    for ln in vlines:
        print(("  " + ln) if ln else "")
    if level != "confirmed":
        return 1
    if best["r"] < 0:
        print("  The correlation is NEGATIVE: this channel is stored with the")
        print("  opposite polarity to the export.  That is a sign convention,")
        print("  not an error, but a reader must apply it or every QRS inverts.")
    print()
    print("    sample width   %s (%d-bit, %s-endian)"
          % (best["dtype"], 8 * dt.itemsize,
             "little" if dt.byteorder in ("<", "=", "|") else "big"))
    print("    channels       %d interleaved, frame stride %d bytes"
          % (best["nch"], stride))
    print("    first sample   byte %d" % best["offset"])
    print("    matched        raw channel %d  ->  export channel %d (%s)"
          % (best["raw_ch"], best["ref_ch"],
             ref_labels[best["ref_ch"]] if best["ref_ch"] < len(ref_labels) else "?"))
    if fit.get("ok"):
        print("    scale          %.6g export units per raw count" % fit["gain"])
        print("    residual       %.4g rms, %.2f%% of the export's range"
              % (fit["rms"], 100.0 * fit["rms_frac"]))
        print("                   (the gain is the mV calibration the container")
        print("                    never states -- measured, not assumed.  The")
        print("                    DC offset is NOT recoverable this way: the")
        print("                    reference is detrended when it is loaded, so")
        print("                    the intercept here describes the comparison,")
        print("                    not the hardware.)")
    print("    payload        %d bytes = %d frames = %.2f h at %g Hz"
          % (payload, payload // stride, payload / stride / ref_fs / 3600.0,
             ref_fs))
    if payload % stride:
        print("    NOTE           the payload is NOT a whole number of frames")
        print("                   (%d bytes left over).  Either the file ends"
              % (payload % stride))
        print("                   mid-frame or there is a trailer after the")
        print("                   samples.  Worth resolving before reading the")
        print("                   final seconds of the recording.")

    # ------------------------------------------------------ contiguity test
    #
    # One match proves the layout at one place.  The failure mode that matters
    # is a payload broken into blocks with headers between them: it matches
    # perfectly at the start and drifts further out, so it would be found only
    # after someone trusted a whole night of heart rates.  Predicting each
    # later export's byte offset from ELAPSED TIME ALONE and re-testing there
    # is a direct test of that -- if it matches ten hours in, the payload is
    # one unbroken interleaved block.
    raw_dt = _parse_name_start(raw)
    print()
    if raw_dt is None:
        print("  CONTIGUITY: not tested.  The raw filename carries no timestamp,")
        print("  so there is no way to predict where a later export should land.")
        print("  The layout is confirmed at the start of the file only.")
        return 0
    if len(placed) < 2:
        print("  CONTIGUITY: not tested -- only one reference was given.  Pass")
        print("  more exports (the whole directory) to test the payload further in.")
        return 0

    print("  contiguity -- each later export is matched at the byte offset")
    print("  predicted by elapsed time alone (raw starts %s)"
          % raw_dt.isoformat(sep=" "))
    print()
    print("    export                                    elapsed    predicted byte"
          "        r   lag")
    print("    " + "-" * 100)
    nbad, ntested = 0, 0
    for dtp, path, _src in placed:
        if dtp is None:
            print("    %-40s  (unplaceable on the clock -- skipped)"
                  % os.path.basename(path)[:40])
            continue
        elapsed = (dtp - raw_dt).total_seconds()
        if elapsed < 0:
            print("    %-40s  starts BEFORE the raw file -- skipped"
                  % os.path.basename(path)[:40])
            continue
        off = best["offset"] + int(round(elapsed * ref_fs)) * stride
        # Bound against the SOURCE, not the file.  For a framed payload those
        # differ by every record header in the chain, and using the file size
        # would let the test read past the end of the concatenated stream.
        if off + stride * 64 > source.nbytes:
            print("    %-40s  %8.0f s  predicted past the end -- skipped"
                  % (os.path.basename(path)[:40], elapsed))
            continue
        try:
            cols, fs2, _, _ = load_signals(path, minutes=max(0.5, (seconds * 3.0) / 60.0))
        except (ValueError, OSError) as e:
            print("    %-40s  unreadable (%s)" % (os.path.basename(path)[:40], e))
            continue
        if abs(fs2 - ref_fs) > 1e-6:
            print("    %-40s  %g Hz, not %g -- skipped"
                  % (os.path.basename(path)[:40], fs2, ref_fs))
            continue
        n2 = int(min(len(cols), int(seconds * fs2)))
        f2 = verify_fit(source, best,
                        np.ascontiguousarray(cols[:n2, best["ref_ch"]]),
                        fs2, off, seconds=seconds)
        ntested += 1
        okk = abs(f2.get("r", 0.0)) >= VERIFY_MATCH
        nbad += 0 if okk else 1
        print("    %-40s  %8.0f s  %14d  %6.3f  %4d%s"
              % (os.path.basename(path)[:40], elapsed, off, f2.get("r", 0.0),
                 f2.get("lag", 0), "" if okk else "   <-- MISMATCH"))
    print()
    if ntested and not nbad:
        print("  CONTIGUOUS: every export matched at its predicted offset, so the")
        print("  payload is one unbroken interleaved block -- no per-block headers,")
        print("  no drift.  A reader can seek to any time with plain arithmetic.")
    elif nbad:
        print("  NOT CONTIGUOUS: %d of %d exports did not match where elapsed time"
              % (nbad, ntested))
        print("  says they should.  The start of the file decodes correctly, so the")
        print("  sample layout is right, but something interrupts the payload --")
        print("  block headers, a gap, or a rate that is not exactly %g Hz." % ref_fs)
        print("  Do NOT seek by arithmetic until this is understood.")
        return 1
    else:
        print("  CONTIGUITY: no later export could be tested.")
    return 0


def cmd_detect(args):
    profile = SPECIES[args.species]
    files = expand_inputs(args.input)
    if not files:
        sys.exit("no input files matched %r  (tip: ~ is NOT expanded inside "
                 "double quotes; use $HOME)" % (args.input,))
    if args.outdir:
        os.makedirs(args.outdir, exist_ok=True)
    print("=" * 108)
    print("%s  detect  |  %s profile%s  |  %d file(s)"
          % (VERSION, profile.name, "" if profile.validated else "  (UNVALIDATED)",
             len(files)))
    print("=" * 108)
    for i, path in enumerate(files, 1):
        print("  [%d/%d] %s" % (i, len(files), os.path.basename(path)), file=sys.stderr)
        try:
            r = analyse(path, args, profile)
        except Exception as e:                               # noqa: BLE001
            print("\n%s\n  ERROR: %s" % (os.path.basename(path), e))
            if args.traceback:
                traceback.print_exc()
            continue
        print()
        print("%s" % os.path.basename(path))
        print("  lead %d of %d chosen by tmplQ%s" %
              (r.lead, len(r.lead_q) or 1,
               ("  (" + ", ".join("L%d %.3f" % (k, v) for k, v in sorted(r.lead_q.items())) + ")")
               if r.lead_q else " (forced)"))
        print_rate_block(r)
        if args.outdir:
            out = os.path.join(args.outdir, os.path.splitext(os.path.basename(path))[0]
                               + ".peaks.csv")
            n, _ = write_peaks(out, r, review=False)
            print("  wrote %d peaks -> %s" % (n, out))


def cmd_review(args):
    profile = SPECIES[args.species]
    files = expand_inputs(args.input)
    if not files:
        sys.exit("no input files matched %r" % (args.input,))
    r = analyse(files[0], args, profile)
    n, ns = write_peaks(args.out, r, review=True)
    print("=" * 108)
    print("REVIEW FILE WRITTEN")
    print("=" * 108)
    print("  %s" % args.out)
    print("  %d rows: %d detected beats + %d suggestions inside gaps"
          % (n, len(r.anchors), ns))
    print()
    flagged = sum(1 for i in range(len(r.anchors))
                  if r.labels[i] < 0 or r.cls[i] in (1, 3))
    print("  %d beat(s) carry a note worth your attention:" % flagged)
    print("    orphan  odd morphology -- real beat corrupted by noise, or not a beat")
    print("    split?  the s~1 signature, i.e. it divides one interval: the shape a")
    print("            genuine false positive has")
    print("    pvc?    compensatory pause, so the underlying timer was not disturbed")
    print("    win     the 60 s window around it failed QC")
    print()
    print("  Edit keep=0/1, then:")
    print("    python3 %s compare --input %s --auto <detect output> --manual %s"
          % (os.path.basename(sys.argv[0]), files[0], args.out))
    print()
    print_rate_block(r)


def read_span_file(path):
    """Read a start_s,end_s span list -- what `marks --export-excl` writes.

    Returns dict(spans, t0_ticks, source, why).  `spans` are seconds from
    whatever origin the file declares, and t0_ticks is that origin when the
    file states one.  A span list with no origin is still usable, but the
    CALLER has to say out loud which clock it assumed, because a bad-data
    interval placed against the wrong origin is worse than no exclusion at
    all: it removes good signal at one edge and admits bad at the other,
    silently, once per interval.

    This is the consumer side of the export whose origin was fixed in
    e1a7a984.  Files written before that build carry the FIRST BEAT as their
    origin, which on P10 is 0.254 s late; they still declare t0_ticks, so the
    mismatch is detectable rather than silent.
    """
    out = dict(spans=[], t0_ticks=None, source=path, why="")
    try:
        with open(path, "r", newline="") as f:
            lines = []
            for line in f:
                if line.startswith("#"):
                    body = line[1:].strip()
                    if ":" in body:
                        k, v = body.split(":", 1)
                        if k.strip() == "t0_ticks":
                            try:
                                out["t0_ticks"] = int(v.strip())
                            except ValueError:
                                pass
                    continue
                lines.append(line)
    except OSError as e:                                     # noqa: BLE001
        out["why"] = "cannot read (%s)" % e
        return out
    if not lines:
        out["why"] = "no data rows"
        return out
    for d in csv.DictReader(lines):
        try:
            a = float(d.get("start_s", ""))
            b = float(d.get("end_s", ""))
        except (TypeError, ValueError):
            continue
        if b > a:
            out["spans"].append((a, b))
    out["spans"] = merge_spans_s(out["spans"])
    return out


# ============================================================ long recordings
#
# A native .PnmWav holds a whole study in one file -- P10 is 18.6 h, three
# leads at 500 Hz -- where the EDF export of the same study is 19 hourly
# files.  Everything downstream (report rows, trend placement, one viewer
# page per file) was built around hour-sized files, and one 18.6 h array is
# ~800 MB per float64 copy, of which analyse() makes several.  So a long
# input is cut into SEGMENTS and each is analysed as if it were its own file.
#
#   * Read once, one segment at a time.  A .PnmWav segment is decoded
#     straight from the int16 payload (_SegReader.block), so peak memory is
#     one segment's worth whatever the recording length.  Other formats have
#     no seekable reader here and are loaded once, then sliced.
#   * Each segment gets DEFAULTS["lead_in_s"] of signal from each neighbour.
#     Detection runs over lead-in + core + lead-out, and analyse(core=...)
#     then keeps only beats inside the core, so a beat on a boundary is
#     found by exactly one segment, with thresholds already warm.
#   * Its own clock: segment start = recording start + offset, which is
#     what trend places, what the viewer's time axis shows, and what the
#     peak-file header states.
#   * Its own excision: BadDataMark is sliced to the segment by the reader,
#     no-signal and empty gaps are measured within it.

def _hms(t):
    t = int(round(max(0.0, float(t))))
    return "%02d:%02d:%02d" % (t // 3600, t % 3600 // 60, t % 60)


def parse_clock_s(text):
    """'5400', '5400.5', '01:30:00' or '90:00' -> seconds from the start."""
    txt = str(text).strip()
    if ":" in txt:
        parts = [float(p) for p in txt.split(":")]
        if len(parts) > 3 or any(p < 0 for p in parts):
            raise ValueError("not HH:MM:SS: %r" % text)
        v = 0.0
        for p in parts:
            v = v * 60.0 + p
        return v
    v = float(txt)
    if v < 0 or not np.isfinite(v):
        raise ValueError("negative or non-finite start: %r" % text)
    return v


def segment_bounds(n, fs, seg_min):
    """[(a, b), ...] sample bounds of the segments of an n-sample record, or
    None when it is not to be split (segmenting off, or n is within one
    segment plus SEGMENT_TOL_FRAC of one).  A remainder no longer than that
    tolerance is folded into the last segment rather than left as a stub."""
    if not seg_min or seg_min <= 0 or fs <= 0:
        return None
    L = int(round(float(seg_min) * 60.0 * fs))
    if L <= 0:
        return None
    tol = int(round(SEGMENT_TOL_FRAC * L))
    if n <= L + tol:
        return None
    k = n // L
    rem = n - k * L
    out = [(i * L, (i + 1) * L) for i in range(k)]
    if rem > tol:
        out.append((k * L, n))
    else:
        out[-1] = (out[-1][0], n)
    return out


def _seg_info(path, i, nseg, a, b, fs, stretch=False):
    """Name, tag and clock of one segment.  Tags are zero-padded so pages
    sort in time order: seg01 .. seg19."""
    base = os.path.splitext(os.path.basename(path))[0]
    t0, t1 = a / float(fs), b / float(fs)
    if stretch:
        tag = "%s-%s" % (_hms(t0).replace(":", ""), _hms(t1).replace(":", ""))
        name = "%s (%s-%s)" % (base, _hms(t0), _hms(t1))
    else:
        tag = "seg%0*d" % (max(2, len(str(nseg))), i)
        name = "%s %s (%s-%s)" % (base, tag, _hms(t0), _hms(t1))
    return dict(i=int(i), n=int(nseg), a=int(a), b=int(b), t0_s=t0, t1_s=t1,
                tag=tag, base=base, name=name, stretch=bool(stretch))


def _is_pnmwav(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in PNMWAV_EXTS:
        return True
    if ext in (".edf", ".bdf", ".rec", ".wav", ".wave") or ext in _ASCII_EXTS:
        return False
    return _sniff_format(path)[0] == "pnmwav"


def segment_plan(path, args):
    """The segment NAMES `path` will produce, from headers only -- no
    samples read -- or None if it will not be split (or the length is not
    knowable without reading it, e.g. an ASCII export).  Used to size the
    report's name column before any row is printed."""
    seg = float(getattr(args, "segment", 0.0) or 0.0)
    if seg <= 0:
        return None
    minutes = float(getattr(args, "minutes", 0.0) or 0.0)
    ext = os.path.splitext(path)[1].lower()
    try:
        if _is_pnmwav(path):
            _d, pl = _pnmwav_plan(path, minutes, quiet=True)
            if pl is None:
                return None
            n, fs = pl["n"], pl["fs"]
        elif ext in (".edf", ".bdf", ".rec"):
            e = MiniEDF(path)
            valid = [i for i in range(e.ns)
                     if not any(k in e.labels[i].lower() for k in SKIP_LABELS)]
            ecg = [i for i in valid if "ecg" in e.labels[i].lower()] or valid[:3]
            if not ecg:
                return None
            fs = float(e.fs[ecg[0]])
            nrec = (e.num_records if minutes <= 0 else
                    min(e.num_records,
                        int(np.ceil(minutes * 60.0 / e.rec_duration))))
            n = nrec * e.spr[ecg[0]]
        elif ext in (".wav", ".wave"):
            w = wav_describe(path)
            fm = w["fmt"]
            wid = fm["bits"] // 8
            n = w["data"][1] // (wid * fm["nch"]) if wid and fm["nch"] else 0
            fs = float(fm["fs"])
            if minutes > 0:
                n = min(n, int(round(minutes * 60.0 * fs)))
        else:
            return None
    except Exception:                                        # noqa: BLE001
        return None
    b = segment_bounds(n, fs, seg)
    if not b:
        return None
    return [_seg_info(path, i, len(b), a, bb, fs)["name"]
            for i, (a, bb) in enumerate(b, 1)]


class _SegReader(object):
    """One recording, readable a stretch at a time.

    .PnmWav: nothing but the container walk and the sidecar is read up
    front; block() decodes just the samples asked for from the int16
    payload -- scaled, detrended over that block, BadDataMark samples set
    to NaN -- so an 18.6 h file never exists as a float64 array.  Every
    other format is read whole by load_signals() once and sliced.
    """

    def __init__(self, path, minutes=0.0):
        self.path = path
        self.plan = None
        self.loaded = None
        if _is_pnmwav(path):
            _d, self.plan = _pnmwav_plan(path, minutes, quiet=True)
        if self.plan is not None:
            self.fs = float(self.plan["fs"])
            self.labels = list(self.plan["labels"])
            self.n = int(self.plan["n"])
            self._src = {ch: BlockSource(path, self.plan["spans"][ch])
                         for ch in self.plan["chs"]}
        else:
            self.loaded = load_signals(path, minutes)
            cols, fs, labels, _dur = self.loaded
            self.fs, self.labels, self.n = float(fs), list(labels), int(cols.shape[0])

    def block(self, s0, s1):
        s0, s1 = max(0, int(s0)), min(self.n, int(s1))
        if self.plan is None:
            return np.array(self.loaded[0][s0:s1], dtype=float, copy=True)
        cols = []
        for ch in self.plan["chs"]:
            buf = self._src[ch].read_at(2 * s0, 2 * (s1 - s0))
            arr = np.frombuffer(buf, dtype="<i2").astype(np.float64)
            g = self.plan["gains"][ch]
            if g is not None:
                arr *= g
            cols.append(arr)
        m = min(len(a) for a in cols)
        mat = np.column_stack([a[:m] for a in cols])
        del cols
        _detrend_cols(mat)
        fs = self.fs
        for a, b in self.plan["bad_spans_s"]:
            i0 = max(s0, int(np.floor(a * fs)))
            i1 = min(s0 + m, int(np.ceil(b * fs)))
            if i1 > i0:
                mat[i0 - s0:i1 - s0, :] = np.nan
        return mat


def iter_analyses(path, args, profile, stretch=None):
    """Yield (r, cols, info, err) for every piece of `path` to report on.

    Unsegmented (a file within one --segment, or --segment 0): ONE item,
    info None, cols None, r exactly what analyse(path) returns.  Segmented:
    one item per segment, info from _seg_info, cols that segment's samples
    (for its viewer page), r.seg = info.  `stretch` = (start_s, length_s)
    asks for one arbitrary piece instead (view --start).  A failure is
    yielded as err rather than raised, so one bad hour does not lose the
    other seventeen; callers decide whether to re-raise.
    """
    seg_min = float(getattr(args, "segment", 0.0) or 0.0)
    if stretch is None and seg_min <= 0:
        try:
            r = analyse(path, args, profile)
        except Exception as e:                               # noqa: BLE001
            yield None, None, None, e
            return
        r.seg = None
        yield r, None, None, None
        return
    try:
        rd = _SegReader(path, 0.0 if stretch is not None
                        else float(getattr(args, "minutes", 0.0) or 0.0))
    except Exception as e:                                   # noqa: BLE001
        yield None, None, None, e
        return
    fs, n = rd.fs, rd.n
    if stretch is not None:
        a = int(round(float(stretch[0]) * fs))
        b = min(n, a + int(round(float(stretch[1]) * fs)))
        if a >= n or b <= a:
            yield None, None, None, ValueError(
                "%s: --start %s is at or past the end of the recording (%s)"
                % (os.path.basename(path), _hms(stretch[0]), _hms(n / fs)))
            return
        bounds = [(a, b)]
    else:
        bounds = segment_bounds(n, fs, seg_min)
        if bounds is None:
            try:
                if rd.loaded is not None:
                    r = analyse(path, args, profile, loaded=rd.loaded)
                else:
                    rd = None
                    r = analyse(path, args, profile)
            except Exception as e:                           # noqa: BLE001
                yield None, None, None, e
                return
            r.seg = None
            yield r, None, None, None
            return
    if rd.plan is not None and rd.plan.get("origin_warning"):
        print(rd.plan["origin_warning"], file=sys.stderr)
    lead = int(round(DEFAULTS["lead_in_s"] * fs))
    for i, (a, b) in enumerate(bounds, 1):
        info = _seg_info(path, i, len(bounds), a, b, fs,
                         stretch=stretch is not None)
        try:
            e0, e1 = max(0, a - lead), min(n, b + lead)
            blk = rd.block(e0, e1)
            r = analyse(path, args, profile,
                        loaded=(blk, fs, list(rd.labels), blk.shape[0] / fs),
                        core=(a - e0, b - e0))
        except Exception as e:                               # noqa: BLE001
            yield None, None, info, e
            continue
        r.seg = info
        core_cols = blk[a - e0:b - e0]
        del blk
        yield r, core_cols, info, None


def segment_index_row(r, info, href, start_dt):
    """One row of a <base>.index.html page."""
    ig = r.integrity
    wall = ((start_dt + datetime.timedelta(seconds=info["t0_s"]))
            .strftime("%Y-%m-%d %H:%M:%S") if start_dt is not None else "")
    return dict(tag=info["tag"], name=info["name"], wall=wall,
                span="%s-%s" % (_hms(info["t0_s"]), _hms(info["t1_s"])),
                dur_s=float(r.dur), beats=int(ig["n"]), bpm=float(ig["bpm"]),
                analysable_s=float(r.analysable_s),
                removed_s=float(getattr(r, "excised_s", 0.0) or 0.0),
                nosig_s=float(ig.get("nosig_s", 0.0) or 0.0),
                mark_s=float(ig.get("mark_s", 0.0) or 0.0),
                empty_s=float(ig.get("empty_s", 0.0) or 0.0),
                flags=",".join(ig["flags"]), trust=bool(ig["trustworthy"]),
                href=href)


def write_segment_index(path, src_path, rows):
    """<base>.index.html: every segment of one recording, linked to its page.

    Plain HTML, no script at all -- a table is all it is -- and the links are
    bare file names, so the folder can be zipped and sent as it stands."""
    esc = lambda v: _html_escape(str(v))
    base = os.path.splitext(os.path.basename(src_path))[0]
    good = [d for d in rows if not d.get("error")]
    tb = sum(d["beats"] for d in good)
    ta = sum(d["analysable_s"] for d in good)
    tr_ = sum(d["removed_s"] for d in good)
    td = sum(d["dur_s"] for d in good)
    tok = sum(1 for d in good if d["trust"])
    bpm = "%.2f" % (60.0 * tb / ta) if ta > 0 else "n/a"
    h = ["<!DOCTYPE html>\n<html lang=\"en\"><head><meta charset=\"utf-8\">",
         "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">",
         "<title>%s - %d segments</title><style>%s</style></head><body>"
         % (esc(base), len(rows), REPORT_CSS),
         "<header><h1>%s &mdash; %d segments</h1>" % (esc(base), len(rows)),
         "<div class=\"sub\">%s &nbsp;|&nbsp; %s &nbsp;|&nbsp; open a segment "
         "to see its beats</div>" % (esc(VERSION), esc(os.path.basename(src_path))),
         "<div class=\"modes\">Each segment is analysed as its own file: its "
         "own lead, detection and excision.\nbpm = beats / analysable s;  "
         "removed = seconds left out of the rate.  no-signal s, marked s and "
         "empty s say why; they can overlap (Ponemah's bad intervals are "
         "blanked, so they also read as no-signal), overlapping time is removed "
         "once, and the three do not add up to removed.  Empty gaps are removed "
         "unless --keep-empty.</div></header><main>",
         "<div class=\"cards\">"]
    for v, k in (("{:,}".format(tb), "beats"), (bpm, "overall bpm"),
                 ("{:,.1f}".format(ta), "analysable seconds"),
                 ("{:,.1f}".format(tr_), "removed seconds"),
                 ("%.2f" % (td / 3600.0), "hours recorded"),
                 ("%d / %d" % (tok, len(rows)), "segments with no disqualifying flag")):
        h.append("<div class=\"card\"><b>%s</b><span>%s</span></div>" % (esc(v), esc(k)))
    h.append("</div><table><tr><th class=\"l\">segment</th><th class=\"l\">"
             "start (wall clock)</th><th class=\"l\">from recording start</th>"
             "<th>beats</th><th>bpm</th><th>analysable s</th><th>removed s</th>"
             "<th>no-signal s</th><th>marked s</th><th>empty s</th>"
             "<th class=\"l\">flags</th></tr>")
    for d in rows:
        if d.get("error"):
            h.append("<tr class=\"bad\"><td class=\"l\">%s</td><td class=\"l f\" "
                     "colspan=\"10\">ERROR: %s</td></tr>" % (esc(d["tag"]), esc(d["error"])))
            continue
        link = ("<a href=\"%s\">%s</a>" % (esc(d["href"]), esc(d["tag"]))
                if d.get("href") else esc(d["tag"]))
        h.append("<tr%s><td class=\"l\">%s</td><td class=\"l\">%s</td>"
                 "<td class=\"l\">%s</td><td>%d</td><td>%s</td><td>%.1f</td>"
                 "<td>%.1f</td><td>%.1f</td><td>%.1f</td><td>%.1f</td>"
                 "<td class=\"l f\">%s</td></tr>"
                 % ("" if d["trust"] else " class=\"bad\"", link, esc(d["wall"]),
                    esc(d["span"]), d["beats"],
                    "%.2f" % d["bpm"] if np.isfinite(d["bpm"]) else "-",
                    d["analysable_s"], d["removed_s"], d["nosig_s"], d["mark_s"],
                    d["empty_s"], esc(d["flags"] or "-")))
    h.append("<tr class=\"tot\"><td class=\"l\">TOTAL</td><td class=\"l\"></td>"
             "<td class=\"l\">%s</td><td>%d</td><td>%s</td><td>%.1f</td>"
             "<td>%.1f</td><td>%.1f</td><td>%.1f</td><td>%.1f</td>"
             "<td class=\"l\">%d of %d with no disqualifying flag</td></tr>"
             % (esc(_hms(td)), tb, bpm, ta, tr_,
                sum(d["nosig_s"] for d in good), sum(d["mark_s"] for d in good),
                sum(d["empty_s"] for d in good), tok, len(rows)))
    h.append("</table></main></body></html>\n")
    return _write_html(path, "\n".join(h))


def segment_totals_line(path, done):
    """The per-recording TOTAL line `report` prints under its segments.
    `done` is [(r or None, info), ...].  Sums, not averages: bpm is all the
    beats over all the analysable seconds, the same estimator as each row."""
    good = [r for r, _i in done if r is not None]
    tb = sum(int(r.integrity["n"]) for r in good)
    ta = sum(float(r.analysable_s) for r in good)
    return ("  = %s TOTAL: %d segment(s)%s, %.1f min, %d beats, %s bpm over "
            "%.1f s analysable (no-signal %.1f s, marked %.1f s, empty %.1f s);"
            " %d/%d with no disqualifying flag"
            % (os.path.basename(path), len(done),
               (" (%d failed)" % (len(done) - len(good))) if len(good) < len(done) else "",
               sum(float(r.dur) for r in good) / 60.0, tb,
               "%.2f" % (60.0 * tb / ta) if ta > 0 else "n/a", ta,
               sum(float(r.integrity.get("nosig_s", 0.0) or 0.0) for r in good),
               sum(float(r.integrity.get("mark_s", 0.0) or 0.0) for r in good),
               sum(float(r.integrity.get("empty_s", 0.0) or 0.0) for r in good),
               sum(1 for r in good if r.integrity["trustworthy"]), len(done)))


# ================================================================ HTML reports
#
# `trend --html` and `report --html` each write ONE self-contained file, the
# same way `view` does: the data travel as JSON inside the page and a few
# hundred lines of inline JS draw it.  No network, no CDN, no fonts to fetch
# -- a lab member double-clicks the file and it opens in any browser, today
# or in five years, with or without a connection.  The text output is still
# printed exactly as before and is embedded in the page too, so the page is
# never a DIFFERENT answer from the terminal, only an easier one to read.

REPORT_CSS = """
body{margin:0;font:14px -apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;background:#0f141a;color:#e2e8f0}
header,main{padding:12px 20px}h1{font-size:19px;margin:0 0 4px}
.sub{color:#8899a6;font-size:12px}
.modes{margin:10px 0;padding:8px 12px;background:#171d24;border-left:3px solid #ffca28;font:12px ui-monospace,Menlo,Consolas,monospace;white-space:pre-wrap}
.cards{display:flex;flex-wrap:wrap;gap:10px;margin:10px 0}
.card{background:#171d24;border:1px solid #2a3441;border-radius:6px;padding:8px 12px;min-width:150px}
.card b{display:block;font-size:18px;color:#fff}.card span{color:#8899a6;font-size:12px}
#wrap{position:relative;background:#090c0f;border:1px solid #2a3441;border-radius:6px}
canvas{display:block;width:100%;height:420px}
#tip{position:absolute;pointer-events:none;background:rgba(23,29,36,.96);border:1px solid #2a3441;padding:6px 8px;font:12px ui-monospace,Menlo,Consolas,monospace;display:none;white-space:pre}
table{border-collapse:collapse;font:12px ui-monospace,Menlo,Consolas,monospace;margin-top:8px}
th,td{padding:3px 9px;border-bottom:1px solid #1c242e;text-align:right}
th{color:#8899a6;background:#0f141a}
td.l,th.l{text-align:left}tr.thin td{color:#ffb74d}tr.hole td{color:#556677}
tr.bad td.f{color:#ff8a80}tr.tot td{font-weight:bold;border-top:2px solid #2a3441}
a{color:#8ab4f8}details{margin:12px 0}summary{cursor:pointer;color:#8ab4f8}
pre.log{font:11px ui-monospace,Menlo,Consolas,monospace;color:#aab4c0;white-space:pre;overflow:auto;max-height:520px;background:#090c0f;padding:8px;border:1px solid #1c242e}
.legend span{margin-right:16px;font-size:12px;color:#8899a6}
"""

TREND_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title><style>__CSS__</style></head><body>
<header><h1 id="h1"></h1><div class="sub" id="sub"></div><div class="modes" id="modes"></div></header>
<main>
<div class="cards" id="cards"></div>
<div class="legend"><span style="color:#52e396">&#9679; bin with enough coverage</span><span style="color:#ffb74d">&#9675; thin bin (not joined)</span><span>&#9617; no recording (a hole, never joined across)</span></div>
<div id="wrap"><canvas id="cv"></canvas><div id="tip"></div></div>
<details><summary>Files placed</summary><table id="ftbl"></table></details>
<details><summary>Bin table (the same columns --csv writes)</summary><table id="tbl"></table></details>
<details><summary>Full text output of this run</summary><pre class="log" id="log"></pre></details>
</main>
<script type="application/json" id="payload">__DATA__</script>
<script>
"use strict";
const P=JSON.parse(document.getElementById("payload").textContent);
const $=id=>document.getElementById(id);
const R=P.rows,BIN=P.bin_s;
$("h1").textContent="Heart-rate trend \\u2014 "+P.title;
$("sub").textContent=P.version+"   |   "+P.profile+" profile   |   "+P.files.length+" file(s) placed   |   "+P.bin_min+"-minute bins   |   "+P.span;
$("modes").textContent=P.modes.join("\\n");
$("log").textContent=P.log;
function el(tag,txt,cls){const e=document.createElement(tag);if(txt!=null)e.textContent=txt;if(cls)e.className=cls;return e;}
for(const [v,k] of P.cards){const c=el("div",null,"card");c.appendChild(el("b",v));c.appendChild(el("span",k));$("cards").appendChild(c);}
(function(){const t=$("ftbl"),h=el("tr");for(const c of ["file","start (wall clock)","clock source"])h.appendChild(el("th",c,"l"));t.appendChild(h);
 for(const f of P.files){const tr=el("tr");for(const v of f)tr.appendChild(el("td",v,"l"));t.appendChild(tr);}
 for(const f of P.unplaced){const tr=el("tr","","hole");tr.appendChild(el("td",f[0],"l"));tr.appendChild(el("td","NOT PLACED","l"));tr.appendChild(el("td",f[1],"l"));t.appendChild(tr);}})();
(function(){const t=$("tbl"),h=el("tr");
 for(const c of P.cols)h.appendChild(el("th",c,c==="bin_start"?"l":""));t.appendChild(h);
 for(const r of R){const tr=el("tr",null,r.hole?"hole":(r.ok?"":"thin"));
  for(const v of [r.lab,r.t.toFixed(0),P.bin_min,r.beats,r.live.toFixed(3),r.span.toFixed(3),r.cov.toFixed(4),r.bpm==null?"":r.bpm.toFixed(4),r.ok?1:0])tr.appendChild(el("td",String(v)));
  tr.firstChild.className="l";t.appendChild(tr);}})();
function pad2(n){return (n<10?"0":"")+n;}
function hm(t){const d=new Date(t*1000);return pad2(d.getUTCHours())+":"+pad2(d.getUTCMinutes());}
function md(t){const d=new Date(t*1000);return d.getUTCFullYear()+"-"+pad2(d.getUTCMonth()+1)+"-"+pad2(d.getUTCDate());}
let pts=[];
function nice(x){const e=Math.pow(10,Math.floor(Math.log10(x))),f=x/e;return (f<=1?1:f<=2?2:f<=5?5:10)*e;}
function draw(){const cv=$("cv"),d=window.devicePixelRatio||1,W=cv.clientWidth,H=cv.clientHeight;
 cv.width=Math.round(W*d);cv.height=Math.round(H*d);const c=cv.getContext("2d");c.setTransform(d,0,0,d,0,0);
 c.fillStyle="#090c0f";c.fillRect(0,0,W,H);pts=[];
 const L=58,RM=16,T=16,B=40;if(!R.length)return;
 const vals=R.filter(r=>r.bpm!=null&&!r.hole).map(r=>r.bpm);
 let lo=vals.length?Math.min.apply(null,vals):0,hi=vals.length?Math.max.apply(null,vals):1;
 if(hi-lo<4){const m=(hi+lo)/2;lo=m-2;hi=m+2;}const pd=0.08*(hi-lo);lo-=pd;hi+=pd;
 const t0=R[0].t,t1=R[R.length-1].t+BIN;
 const X=t=>L+(t-t0)/(t1-t0)*(W-L-RM),Y=v=>T+(hi-v)/(hi-lo)*(H-T-B);
 c.font="11px sans-serif";c.lineWidth=1;
 const ys=nice((hi-lo)/6);c.strokeStyle="#1c242e";c.fillStyle="#8899a6";
 for(let v=Math.ceil(lo/ys)*ys;v<=hi;v+=ys){const y=Math.round(Y(v))+0.5;c.beginPath();c.moveTo(L,y);c.lineTo(W-RM,y);c.stroke();c.fillText(v.toFixed(ys<1?1:0),8,y+4);}
 const steps=[300,600,900,1800,3600,7200,10800,21600,43200,86400,172800,604800];
 const xs=steps.find(s=>(t1-t0)/s<=10)||604800;
 for(let t=Math.ceil(t0/xs)*xs;t<=t1;t+=xs){const x=Math.round(X(t))+0.5;c.beginPath();c.moveTo(x,T);c.lineTo(x,H-B);c.stroke();
  c.fillText(hm(t),x+3,H-B+14);if(t%86400===0||xs>=86400)c.fillText(md(t),x+3,H-B+27);}
 c.save();c.translate(14,T+(H-T-B)/2);c.rotate(-Math.PI/2);c.fillText("bpm (beats / analysable s)",-60,0);c.restore();
 c.fillStyle="rgba(120,130,150,0.13)";
 for(const r of R)if(r.hole)c.fillRect(X(r.t),T,Math.max(1,X(r.t+BIN)-X(r.t)),H-T-B);
 c.strokeStyle="#52e396";c.lineWidth=1.6;c.beginPath();let prev=-2;
 R.forEach((r,i)=>{if(!(r.ok&&r.bpm!=null))return;const x=X(r.t+BIN/2),y=Y(r.bpm);
  if(prev===i-1)c.lineTo(x,y);else c.moveTo(x,y);prev=i;});
 c.stroke();
 R.forEach((r,i)=>{if(r.bpm==null||r.hole)return;const x=X(r.t+BIN/2),y=Y(r.bpm);pts.push([x,y,i]);
  if(r.ok){c.fillStyle="#52e396";c.beginPath();c.arc(x,y,2.2,0,6.283);c.fill();}
  else{c.strokeStyle="#ffb74d";c.lineWidth=1.3;c.beginPath();c.arc(x,y,3.2,0,6.283);c.stroke();}});
 c.strokeStyle="#2a3441";c.lineWidth=1;c.strokeRect(L+0.5,T+0.5,W-L-RM-1,H-T-B-1);}
$("cv").addEventListener("mousemove",e=>{const b=$("cv").getBoundingClientRect(),mx=e.clientX-b.left,my=e.clientY-b.top;
 let best=null,bd=1e9;for(const p of pts){const d=Math.abs(p[0]-mx);if(d<bd){bd=d;best=p;}}
 const tip=$("tip");if(!best||bd>24){tip.style.display="none";return;}const r=R[best[2]];
 tip.textContent=r.lab+" (+"+P.bin_min+" min)\\n"+(r.bpm==null?"-":r.bpm.toFixed(2))+" bpm\\n"+r.beats+" beats\\n"+r.live.toFixed(1)+" s live of "+r.span.toFixed(1)+" s  ("+(100*r.cov).toFixed(0)+"% of bin)"+(r.ok?"":"\\nTHIN: below "+(100*P.min_cov).toFixed(0)+"% coverage");
 tip.style.display="block";tip.style.left=Math.min(b.width-220,best[0]+12)+"px";tip.style.top=Math.max(0,best[1]-40)+"px";});
$("cv").addEventListener("mouseleave",()=>{$("tip").style.display="none";});
window.addEventListener("resize",draw);draw();
</script></body></html>
"""

REPORT_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title><style>__CSS__</style></head><body>
<header><h1 id="h1"></h1><div class="sub" id="sub"></div><div class="modes" id="modes"></div></header>
<main>
<div class="cards" id="cards"></div>
<table id="tbl"></table>
<details><summary>Full text output of this run</summary><pre class="log" id="log"></pre></details>
</main>
<script type="application/json" id="payload">__DATA__</script>
<script>
"use strict";
const P=JSON.parse(document.getElementById("payload").textContent);
const $=id=>document.getElementById(id);
function el(tag,txt,cls){const e=document.createElement(tag);if(txt!=null)e.textContent=txt;if(cls)e.className=cls;return e;}
$("h1").textContent="Rate and QC report \\u2014 "+P.files.length+" file(s)";
$("sub").textContent=P.version+"   |   "+P.profile+" profile";
$("modes").textContent=P.modes.join("\\n");
$("log").textContent=P.log;
for(const [v,k] of P.cards){const c=el("div",null,"card");c.appendChild(el("b",v));c.appendChild(el("span",k));$("cards").appendChild(c);}
const t=$("tbl"),h=el("tr");
const cols=["file","lead","beats","analysable s","no-signal s","marked s","empty s","bpm","flags"].concat(P.has_view?["viewer"]:[]);
cols.forEach((c,i)=>h.appendChild(el("th",c,(i===0||i===1||i===8)?"l":"")));t.appendChild(h);
function f1(v){return v==null?"-":v.toFixed(1);}
for(const r of P.files){const tr=el("tr",null,r.trust?"":"bad");
 if(r.error){tr.appendChild(el("td",r.file,"l"));const td=el("td","ERROR: "+r.error,"l f");td.colSpan=cols.length-1;tr.appendChild(td);t.appendChild(tr);continue;}
 for(const [v,c] of [[r.file,"l"],[r.lead,"l"],[String(r.beats),""],[f1(r.analysable_s),""],[f1(r.nosig_s),""],[f1(r.mark_s),""],[f1(r.empty_s),""],[r.bpm==null?"-":r.bpm.toFixed(2),""],[r.flags||"-","l f"]])tr.appendChild(el("td",v,c));
 if(P.has_view){const td=el("td",null,"l");if(r.view){const a=el("a","open");a.href=r.view;td.appendChild(a);}else td.textContent="-";tr.appendChild(td);}
 t.appendChild(tr);}
const T=P.totals,tr=el("tr",null,"tot");
for(const [v,c] of [["TOTAL ("+T.n+" analysed)","l"],["","l"],[String(T.beats),""],[f1(T.analysable_s),""],[f1(T.nosig_s),""],[f1(T.mark_s),""],[f1(T.empty_s),""],[T.bpm==null?"-":T.bpm.toFixed(2),""],[T.ok+" of "+T.n+" with no disqualifying flag","l"]])tr.appendChild(el("td",v,c));
if(P.has_view)tr.appendChild(el("td",""));t.appendChild(tr);
</script></body></html>
"""


def _jsonable(v):
    """NaN/inf -> None, numpy scalars -> Python, recursively.  JSON.parse
    rejects the bare NaN json.dumps writes by default, and a page that fails
    to parse is a blank page with no error a lab member would ever see."""
    if isinstance(v, dict):
        return {str(k): _jsonable(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v]
    if isinstance(v, (bool, np.bool_)):
        return bool(v)
    if isinstance(v, (int, np.integer)):
        return int(v)
    if isinstance(v, (float, np.floating)):
        return float(v) if np.isfinite(v) else None
    return v


def _fill_report_html(template, title, payload):
    import json
    blob = json.dumps(_jsonable(payload), separators=(",", ":"),
                      allow_nan=False).replace("</", "<\\/")
    return (template.replace("__CSS__", REPORT_CSS)
            .replace("__TITLE__", _html_escape(str(title)))
            .replace("__DATA__", blob))


def _write_html(path, html):
    path = os.path.expanduser(path)
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(html)
    return path


class _TeeStdout(object):
    """Copy everything printed while active, still printing it.  So the page
    can embed the exact text the terminal showed, rather than a second
    rendering of the same numbers that could drift from the first."""

    def __init__(self):
        import io
        self.buf = io.StringIO()
        self.orig = sys.stdout
        sys.stdout = self

    def write(self, s):
        self.orig.write(s)
        self.buf.write(s)

    def flush(self):
        self.orig.flush()

    def close(self):
        sys.stdout = self.orig
        return self.buf.getvalue()


def cmd_trend(args):
    """`trend`, plus --html.  The text is printed unchanged either way."""
    out = getattr(args, "html", None)
    if not out:
        return _trend_body(args, None)
    col = {}
    tee = _TeeStdout()
    try:
        rc = _trend_body(args, col)
    finally:
        log = tee.close()
    if col:
        col["log"] = log
        where = _write_html(out, _fill_report_html(
            TREND_HTML, "trend - %s" % col.get("title", ""), col))
        print("wrote %s" % where)
    return rc


def cmd_report(args):
    """`report`, plus --html and --view-dir.  The text is printed unchanged."""
    out = getattr(args, "html", None)
    if not out:
        return _report_body(args, None)
    col = {}
    tee = _TeeStdout()
    try:
        rc = _report_body(args, col)
    finally:
        log = tee.close()
    if col:
        col["log"] = log
        where = _write_html(out, _fill_report_html(REPORT_HTML, "report", col))
        print("wrote %s" % where)
    return rc


def _trend_body(args, collect):
    """N-minute average heart rate over wall-clock time, across many files.

    The estimator is beats/analysable-seconds per bin -- the same one the
    whole-file rate uses, so a trend and a report of the same data reconcile.
    It is deliberately NOT a mean of per-beat instantaneous rates: under this
    pathology a third of the beats are early, and averaging 60/RR over a
    couplet-loaded stretch weights the short intervals equally with the long
    ones and reads high.  Nor is it the modal rate, which reads up to 10.1% LOW
    here for the mirror-image reason.

    Dead time is removed from each bin's denominator exactly as it is from the
    file's, so a bin containing a dropout reports the rate of the signal that
    was actually there, and reports its reduced coverage alongside.
    """
    profile = SPECIES[args.species]
    files = expand_inputs(args.input)
    if not files:
        sys.exit("no input files matched %r" % (args.input,))
    bin_s = float(args.bin) * 60.0
    if bin_s <= 0:
        sys.exit("--bin must be positive")
    acc, placed, unplaced, notes = {}, [], [], []
    # The same bins under the OTHER empty-gap mode, so the seconds line can
    # show both without a second run: DROPPED vs KEPT differ only in which
    # spans count as dead, never in the beats (no beat lies in an empty gap).
    acc_alt = {}
    tr_empty_s = 0.0

    # ---- exclusions supplied by the caller, on the WALL clock.
    #
    # `nosig_spans` below is this tool inferring silence from an amplitude
    # ratio, and it only catches time that is FLAT.  Ponemah's BadDataMark is
    # a different claim -- the acquisition system stating its signal was not
    # trustworthy -- and it lives in a sidecar that an EDF export does not
    # carry.  Without this flag a trend over EDF parts silently runs over the
    # marked time as though it were clean, which on P10 is 5,645 s (8.41%).
    #
    # Goal 6 is excision from the numerator AND the denominator.  Doing only
    # the denominator would inflate every bin it touched, so the beats are
    # dropped here too -- bin_record does not do it, whatever its docstring
    # says about counting beats "AFTER excision".
    ex_spans_rel, ex_note, ex_base = [], "", None
    for xp in expand_inputs(getattr(args, "exclude", None) or []):
        sf = read_span_file(xp)
        if sf["why"]:
            sys.exit("--exclude %s: %s" % (xp, sf["why"]))
        ex_spans_rel.extend(sf["spans"])
        if sf["t0_ticks"] is not None and ex_base is None:
            ex_base = sf["t0_ticks"]
            ex_note = ("%s, origin stated as %s"
                       % (os.path.basename(xp),
                          (ticks_to_dt(sf["t0_ticks"]) or "?")))
        elif sf["t0_ticks"] is None:
            ex_note = ("%s states NO origin" % os.path.basename(xp))
    # Merged, not just sorted.  --exclude takes several files, and two span
    # lists over the same recording will overlap wherever both flagged it.
    # Left unmerged, the overlap is double-counted in the reported total and
    # the membership test below can miss a beat inside a long span that a
    # short one starts inside of.
    ex_spans_rel = merge_spans_s(ex_spans_rel)
    ex_hit_s, ex_hit_n = 0.0, 0
    # The spans arrive as seconds from a .NET tick origin; the bins are keyed
    # by epoch seconds.  Convert once, here, rather than inside the loop --
    # and only via ticks_to_dt, so a nonsense origin fails loudly instead of
    # placing every interval somewhere plausible-looking.
    ex_base_epoch = None
    if ex_base is not None:
        _ex_dt = ticks_to_dt(ex_base)
        if _ex_dt is None:
            sys.exit("--exclude: t0_ticks %r is not a usable date" % ex_base)
        ex_base_epoch = to_epoch(_ex_dt)
    if ex_spans_rel and ex_base_epoch is None:
        ex_note += ("  -- assuming they are seconds from the start of the"
                    " EARLIEST file placed")


    seg_paths, placed_paths, _first_e0 = set(), set(), None
    for path in files:
        print("  ... %s" % os.path.basename(path), file=sys.stderr)
        _clock = None
        for r, _scols, _info, _err in iter_analyses(path, args, profile):
            _scols = None
            _name = _info["name"] if _info else os.path.basename(path)
            if _err is not None:
                if getattr(args, "traceback", False):
                    raise _err
                unplaced.append((_name, "FAILED: %s" % _err))
                continue
            if _clock is None:
                _clock = record_start(path)
                if _clock[0] is not None and _clock[2]:
                    notes.append((os.path.basename(path), _clock[2]))
            st, src, note = _clock
            if st is None:
                # Refused rather than defaulted.  Placing a file at an arbitrary
                # offset would produce a trend that looks entirely normal and is
                # wrong, which is worse than a trend with a file missing from it.
                unplaced.append((os.path.basename(path), note))
                break
            # A segment sits at recording start + its offset -- the one fact
            # that makes 18 segments of a .PnmWav land where 18 hourly EDFs
            # of the same recording land.
            _off = float(_info["t0_s"]) if _info else 0.0
            if _info:
                seg_paths.add(path)
            e0 = to_epoch(st) + _off
            beats = e0 + np.asarray(r.anchors, dtype=float) / r.fs
            # Everything analyse() excised from THIS file's rate: no-signal,
            # exporter-marked and -- unless --keep-empty -- empty gaps.  This used
            # to take nosig_spans alone, so on a marked (ASCII) export the marked
            # BEATS were gone from the count (analyse drops them) while the
            # marked SECONDS stayed in every bin's live time: bins biased low by
            # the marked fraction.  r.excise_spans is the one list the file rate
            # itself divides by, so the trend and the report now reconcile.
            nos = [(e0 + s, e0 + e) for s, e in
                   (getattr(r, "excise_spans", None)
                    or getattr(r, "nosig_spans", []))]
            tr_empty_s += float(getattr(r, "empty_s", 0.0) or 0.0)
            exc = merge_spans_s(nos)
            if ex_spans_rel:
                # The base is the exclusion file's OWN stated origin when it has
                # one.  Falling back to this file's start would be wrong for
                # every file after the first, since the spans are numbered from
                # the start of the RECORDING, not of each part.
                base = (ex_base_epoch if ex_base_epoch is not None
                        else _first_e0 if _first_e0 is not None
                        else e0 - _off)
                # Clipped to this file's extent.  bin_record accumulates into a
                # shared table, so handing it the whole list once per file would
                # subtract an overlapping span once for every file that saw it.
                f0, f1 = e0, e0 + r.dur
                here = merge_spans_s([(max(base + a, f0), min(base + b, f1))
                                      for a, b in ex_spans_rel
                                      if base + b > f0 and base + a < f1])
                # Merged ACROSS both sources.  bin_record computes dead time as
                # the plain sum of its spans' overlaps with a bin, so a stretch
                # that is both no-signal and operator-marked would be subtracted
                # twice.  It clamps live at zero, so the damage shows up as a bin
                # reading less coverage than it has -- never as an exception.
                before = sum(b - a for a, b in exc)
                exc = merge_spans_s(nos + here)
                # The MARGINAL seconds --exclude removed, not the seconds it
                # asked for.  Keeping it marginal is what lets the header add it
                # back to recover the rate this run would have printed without
                # the flag; counting the overlap twice would overshoot.
                ex_hit_s += sum(b - a for a, b in exc) - before
                if len(beats) and here:
                    st_a = np.array([a for a, _ in here], dtype=float)
                    en_a = np.array([b for _, b in here], dtype=float)
                    j = np.searchsorted(st_a, beats, side="right") - 1
                    inside = (j >= 0) & (beats <= en_a[np.clip(j, 0, None)])
                    ex_hit_n += int(inside.sum())
                    beats = beats[~inside]
            bin_record(acc, e0, r.dur, beats, exc, bin_s)
            if hasattr(r, "excise_base_spans"):
                _b_e = [(e0 + a, e0 + b) for a, b in (r.excise_base_spans or [])]
                _e_e = [(e0 + a, e0 + b) for a, b in (r.empty_spans or [])]
                _alt = _b_e + _e_e if getattr(args, "keep_empty", False) else _b_e
            else:
                _alt = nos
            bin_record(acc_alt, e0, r.dur, beats,
                       merge_spans_s(_alt + (here if ex_spans_rel else [])), bin_s)
            placed.append((_name, (st + datetime.timedelta(seconds=_off))
                           if _off else st, src, r))
            placed_paths.add(path)
            if _first_e0 is None:
                _first_e0 = e0 - _off
            # Only the numbers are used from here on.  Holding every
            # segment's filtered traces to the end would undo the point of
            # segmenting a long recording.
            r.wide = r.det = r.missing = None


    if not acc:
        print("no file could be placed on a clock; nothing to trend")
        for n, why in unplaced:
            print("  %-42s %s" % (n[:42], why))
        return 1

    rows = bins_to_rows(acc, bin_s, args.min_coverage)
    good = [r for r in rows if r["ok"] and np.isfinite(r["bpm"])]
    thin = [r for r in rows if not r["ok"] and not r["empty"]]
    holes = [r for r in rows if r["empty"]]

    print("=" * 120)
    print("%s  trend  |  %s profile  |  %s  |  %g-minute bins"
          % (VERSION, profile.name,
             ("%d file(s) placed as %d segment(s)" % (len(placed_paths), len(placed))
              if seg_paths else "%d file(s) placed" % len(placed)), args.bin))
    print("=" * 120)
    t_first = from_epoch(rows[0]["t0"])
    t_last = from_epoch(rows[-1]["t0"] + bin_s)
    print("  span        %s .. %s  (%.1f h, %d bins)"
          % (t_first.strftime("%Y-%m-%d %H:%M:%S"),
             t_last.strftime("%Y-%m-%d %H:%M:%S"),
             (rows[-1]["t0"] + bin_s - rows[0]["t0"]) / 3600.0, len(rows)))
    tot_beats = sum(r["beats"] for r in rows)
    tot_live = sum(r["live"] for r in rows)
    print("  data        %d beats over %.1f h of analysable recording"
          % (tot_beats, tot_live / 3600.0))
    # SECONDS, both ways.  Hours to one decimal cannot be checked against a
    # Ponemah figure like 61,462 s; seconds can, and showing the other
    # empty-gap mode alongside says how much of any difference that is.
    rows_alt = bins_to_rows(acc_alt, bin_s, args.min_coverage)
    tot_live_alt = sum(r["live"] for r in rows_alt)
    _ke = bool(getattr(args, "keep_empty", False))
    _s_drop, _s_keep = (tot_live_alt, tot_live) if _ke else (tot_live, tot_live_alt)
    print("  analysable  %.1f s (%.2f h) with empty gaps DROPPED;  %.1f s"
          " (%.2f h) with them KEPT   [%s in use]"
          % (_s_drop, _s_drop / 3600.0, _s_keep, _s_keep / 3600.0,
             "KEPT" if _ke else "DROPPED"))
    if tot_live > 0:
        print("  overall     %.2f bpm  (all beats / all analysable time)"
              % (60.0 * tot_beats / tot_live))
    if good:
        bpms = [r["bpm"] for r in good]
        lo_r = min(good, key=lambda r: r["bpm"])
        hi_r = max(good, key=lambda r: r["bpm"])
        print("  per-bin     min %.2f at %s;  max %.2f at %s;  sd %.2f"
              % (lo_r["bpm"], from_epoch(lo_r["t0"]).strftime("%m-%d %H:%M"),
                 hi_r["bpm"], from_epoch(hi_r["t0"]).strftime("%m-%d %H:%M"),
                 float(np.std(bpms))))
    print("  coverage    %d bin(s) full, %d thin (<%.0f%%), %d with no recording"
          % (len(good), len(thin), 100.0 * args.min_coverage, len(holes)))
    if getattr(args, "keep_empty", False):
        print("  empty gaps  KEPT as real pauses (--keep-empty): %.1f s of"
              " beatless gaps stay in the bins' live time" % tr_empty_s)
    else:
        print("  empty gaps  DROPPED (default): %.1f s of beatless gaps"
              " (> %.1fx baseline RR) excised" %
              (tr_empty_s, float(getattr(args, "refill_gap_mult", 3.0))))
        print("              from the bins' live time; --keep-empty counts"
              " them as pauses")
    if ex_spans_rel:
        # Report what LANDED, not what was asked for.  The declared total and
        # the applied total differ whenever the span list covers time that no
        # placed file holds -- which is normal (a sidecar describes the whole
        # recording; the trend may hold a subset) but is also exactly what a
        # mis-anchored file looks like.  Printing only the declared figure
        # would make those two cases indistinguishable.
        _ex_tot = sum(b - a for a, b in ex_spans_rel)
        _ex_span = sum(r["span"] for r in rows)
        print("  excluded    %d interval(s) declared, %.1f s = %.2f h;"
              " %.1f s landed inside"
              % (len(ex_spans_rel), _ex_tot, _ex_tot / 3600.0, ex_hit_s))
        print("              the placed files (%.2f%% of the %.1f h recorded),"
              " taking %d beat(s)"
              % (100.0 * ex_hit_s / _ex_span if _ex_span else float("nan"),
                 _ex_span / 3600.0, ex_hit_n))
        print("              from %s" % (ex_note or "(unnamed)"))
        print("              removed from the beat count AND the seconds,"
              " which is the")
        print("              only way a rate survives an excision.")
        # Both rates, side by side.  The excision is a JUDGEMENT -- Ponemah's
        # own Cycle table is kept through its own bad marks, and beats are
        # found inside them at physiological rates, so the intervals are
        # "quality flagged", not "no signal".  Whoever reads this is entitled
        # to see what the flag did rather than re-run without it and diff.
        # The add-back is exact because ex_hit_s is the marginal dead time.
        _ex_l0, _ex_n0 = tot_live + ex_hit_s, tot_beats + ex_hit_n
        if tot_live > 0 and _ex_l0 > 0:
            _ex_r1 = 60.0 * tot_beats / tot_live
            _ex_r0 = 60.0 * _ex_n0 / _ex_l0
            print("  with/without  %.2f bpm excluded  vs  %.2f bpm had the"
                  " flag not been given" % (_ex_r1, _ex_r0))
            print("              over %.1f s analysable with the exclusion,"
                  " %.1f s without it" % (tot_live, _ex_l0))
            print("              a difference of %+.2f bpm (%+.2f%%).  These"
                  " stay close when the" % (_ex_r1 - _ex_r0,
                                            100.0 * (_ex_r1 - _ex_r0) / _ex_r0
                                            if _ex_r0 else float("nan")))
            print("              excluded time carried beats at about the"
                  " same rate as the rest,")
            print("              which is evidence the marks flag QUALITY"
                  " rather than absence.")

        if _ex_tot > 0 and ex_hit_s < 0.5 * _ex_tot:
            # Not fatal -- a legitimate subset does this too -- but it is the
            # loudest symptom of an origin that is wrong, and an exclusion
            # anchored wrongly removes good signal at one edge while admitting
            # bad signal at the other, once per interval, in silence.
            print("              ** only %.0f%% of the declared time landed."
                  "  Check the origin:" % (100.0 * ex_hit_s / _ex_tot))
            print("              a span list written against a different"
                  " clock looks just like this.")


    for nm, note in notes:
        print("  ** %s: %s" % (nm, note))
    for nm, why in unplaced:
        print("  ** NOT PLACED  %-30s %s" % (nm[:30], why))
    print()

    for line in ascii_trend(rows, bin_s, width=args.width):
        print(line)

    print("  * = bin with at least %.0f%% coverage;  ? = measured but thinner;"
          % (100.0 * args.min_coverage))
    print("  x on the axis = no recording at all in that bin.  Holes are drawn")
    print("  rather than closed up: joining across unmeasured time is the one")
    print("  thing a trend plot must never do.")
    print()
    print("  Each bin is beats/analysable-seconds, the same estimator as the")
    print("  file rate in `report`, so the two reconcile.  It is NOT a mean of")
    print("  60/RR: a third of these beats are early, and that estimator would")
    print("  weight a couplet's short interval equally with the long one.")

    if getattr(args, "table", False):
        print()
        print("  %-19s %8s %8s %8s %8s" % ("bin start", "beats", "live_s",
                                           "cov%", "bpm"))
        print("  " + "-" * 56)
        for r in rows:
            print("  %-19s %8d %8.1f %8.1f %8s"
                  % (from_epoch(r["t0"]).strftime("%Y-%m-%d %H:%M:%S"),
                     r["beats"], r["live"], 100.0 * r["cov"],
                     "%.2f" % r["bpm"] if np.isfinite(r["bpm"]) else "-"))

    if getattr(args, "csv", None):
        # The bridge to matplotlib, Excel, or anything else.  Written even for
        # empty and thin bins, with the coverage alongside, so that whoever
        # plots it downstream can make the same distinction this display makes
        # rather than inheriting a pre-filtered series with the holes closed.
        with open(os.path.expanduser(args.csv), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["bin_start", "epoch_s", "bin_minutes", "beats",
                        "live_s", "span_s", "coverage", "bpm", "usable"])
            for r in rows:
                w.writerow([from_epoch(r["t0"]).strftime("%Y-%m-%d %H:%M:%S"),
                            "%.0f" % r["t0"], "%g" % args.bin, r["beats"],
                            "%.3f" % r["live"], "%.3f" % r["span"],
                            "%.4f" % r["cov"],
                            "%.4f" % r["bpm"] if np.isfinite(r["bpm"]) else "",
                            int(r["ok"])])
        print()
        print("  wrote %d bins to %s" % (len(rows), os.path.expanduser(args.csv)))
    if collect is not None:
        _ke = bool(getattr(args, "keep_empty", False))
        _gm = float(getattr(args, "refill_gap_mult", 3.0))
        modes = [
            "empty gaps  %s: %.1f s of beatless gaps (> %.1fx baseline RR)%s"
            % ("KEPT as pauses (--keep-empty)" if _ke else "DROPPED (default)",
               tr_empty_s, _gm,
               " stay in the live time" if _ke else " excised from the live time"),
            "analysable  %.1f s (%.2f h) with empty gaps DROPPED;  %.1f s "
            "(%.2f h) with them KEPT" % (_s_drop, _s_drop / 3600.0,
                                         _s_keep, _s_keep / 3600.0),
            "no-signal   %s;  bins %g min, thin below %.0f%% coverage"
            % ("excised" if getattr(args, "nosig", True) else "OFF (--no-nosig)",
               args.bin, 100.0 * args.min_coverage)]
        cards = [["{:,}".format(tot_beats), "beats"],
                 ["{:,.1f}".format(tot_live), "analysable seconds"],
                 ["%.2f" % (tot_live / 3600.0), "analysable hours"],
                 ["%.2f" % (60.0 * tot_beats / tot_live) if tot_live > 0
                  else "n/a", "overall bpm (beats / analysable s)"],
                 ["{:,.1f}".format(tot_live_alt),
                  "analysable s with empty gaps %s" % ("DROPPED" if _ke else "KEPT")],
                 ["%.2f" % (60.0 * tot_beats / tot_live_alt) if tot_live_alt > 0
                  else "n/a",
                  "bpm with empty gaps %s" % ("DROPPED" if _ke else "KEPT")]]
        if ex_spans_rel:
            _xt = sum(b - a for a, b in ex_spans_rel)
            _l0, _n0 = tot_live + ex_hit_s, tot_beats + ex_hit_n
            modes.append("excluded    %s: %d interval(s), %.1f s declared, "
                         "%.1f s landed in the placed files, %d beat(s) removed"
                         % (ex_note or "(unnamed)", len(ex_spans_rel), _xt,
                            ex_hit_s, ex_hit_n))
            cards += [["%.2f" % (60.0 * tot_beats / tot_live) if tot_live > 0
                       else "n/a", "bpm WITH the exclusion"],
                      ["%.2f" % (60.0 * _n0 / _l0) if _l0 > 0 else "n/a",
                       "bpm WITHOUT it (%s s, %s beats)"
                       % ("{:,.1f}".format(_l0), "{:,}".format(_n0))]]
        collect.update(dict(
            title=", ".join(n for n, _st, _s, _r in placed[:3])
            + (" ... (+%d)" % (len(placed) - 3) if len(placed) > 3 else ""),
            version=VERSION, profile=profile.name, bin_s=bin_s, bin_min=args.bin,
            min_cov=args.min_coverage,
            span="%s .. %s (%.1f h)" % (
                t_first.strftime("%Y-%m-%d %H:%M:%S"),
                t_last.strftime("%Y-%m-%d %H:%M:%S"),
                (rows[-1]["t0"] + bin_s - rows[0]["t0"]) / 3600.0),
            files=[[n, st.strftime("%Y-%m-%d %H:%M:%S"), str(src)]
                   for n, st, src, _r in placed],
            unplaced=[[n, str(why)] for n, why in unplaced],
            modes=modes, cards=cards,
            cols=["bin_start", "epoch_s", "bin_minutes", "beats", "live_s",
                  "span_s", "coverage", "bpm", "usable"],
            rows=[dict(t=r["t0"], lab=from_epoch(r["t0"]).strftime(
                "%Y-%m-%d %H:%M:%S"), beats=r["beats"], live=r["live"],
                span=r["span"], cov=r["cov"], bpm=r["bpm"], ok=r["ok"],
                hole=r["empty"]) for r in rows],
            analysable_s=tot_live, analysable_s_alt=tot_live_alt,
            beats=tot_beats, empty_s=tr_empty_s, keep_empty=_ke))
    return 0


def _report_body(args, collect):
    profile = SPECIES[args.species]
    files = expand_inputs(args.input)
    if not files:
        sys.exit("no input files matched %r" % (args.input,))
    print("=" * 153)
    print("%s  report  |  %s profile  |  %d file(s)  |  clip_k %g  |  refill %s"
          "  |  no-signal %s  |  empty gaps %s"
          % (VERSION, profile.name, len(files),
             getattr(args, "clip_k", DEFAULTS["clip_k"]),
             "on" if getattr(args, "refill", True) else "OFF",
             "on" if getattr(args, "nosig", True) else "OFF",
             "KEPT (--keep-empty)" if getattr(args, "keep_empty", False)
             else "DROPPED (default)"))
    print("=" * 169)
    # nosig_s and mark_s sit immediately left of flags on purpose: they are the
    # numbers that explain why bpm moved, and a reader who sees the NO_SIGNAL
    # flag should not have to run a second command to find out how much time it
    # cost.  They are separate columns because they are different kinds of
    # claim -- mark_s is the exporter stating it had no sample, nosig_s is this
    # tool inferring silence from an amplitude ratio.  One is a reading, the
    # other is a judgement, and summing them would hide which.  empty_s is the
    # third kind -- a POLICY about beatless gaps -- and gets its own column for
    # the same reason.
    # A segment name ("<base> seg03 (02:00:00-03:00:00)") is longer than
    # the 38 columns a file name gets.  Widen the column to fit rather than
    # truncate away the part that says WHICH hour a row is; a run with no
    # segmented input keeps the old width exactly.
    W = 38
    for _p in files:
        for _nm in (segment_plan(_p, args) or []):
            W = max(W, len(_nm))
    print("  %-*s %4s %6s %6s %5s %7s %7s %6s %6s %6s %6s %8s %6s %6s %6s %6s %7s %7s %7s  %s"
          % (W, "file", "lead", "mins", "beats", "fill", "bpm", "modal", "short%",
             "tmplQ", "QC%", "maxGap", "gapAt_s", "edge_s", "floor%", "p99/A",
             "k_min", "nosig_s", "mark_s", "empty_s", "flags"))
    print("  " + "-" * (167 + W - 38))
    ok = 0
    floor_tot = []
    kmin_tot = []
    kcrit_tot = []
    followups = []
    empty_tot = [0.0, 0.0, 0]     # seconds measured, seconds of duration, files
    html_rows = []
    view_dir = getattr(args, "view_dir", None)
    view_written = []
    n_rows = 0
    seg_files = 0
    index_written = []
    for path in files:
        print("  ... %s" % os.path.basename(path), file=sys.stderr)
        seg_done = []                      # (r or None, info, page, err)
        for r, _scols, _info, _err in iter_analyses(path, args, profile):
            n_rows += 1
            _name = _info["name"] if _info else os.path.basename(path)
            if _err is not None:
                print("  %-*s  ERROR: %s" % (W, _name[:W], _err))
                html_rows.append(dict(file=_name, error=str(_err),
                                      trust=False))
                if _info:
                    seg_done.append((None, _info, None, _err))
                continue
            if _info:
                print("  ... %s" % _info["name"], file=sys.stderr)
            ig = r.integrity
            _vpath = None
            if view_dir:
                # The viewer page for this file, from the SAME analysis the row
                # reports -- not a second detection that could differ from it.
                os.makedirs(os.path.expanduser(view_dir), exist_ok=True)
                if _info is None:
                    _vcols = load_signals(path, getattr(args, "minutes", 0.0))[0]
                    _vpath = os.path.join(
                        os.path.expanduser(view_dir),
                        os.path.splitext(os.path.basename(path))[0] + ".view.html")
                    _vtitle = os.path.basename(path)
                else:
                    # One page per SEGMENT, from the segment's own samples.
                    _vcols = _scols
                    _vpath = os.path.join(
                        os.path.expanduser(view_dir),
                        "%s.%s.view.html" % (_info["base"], _info["tag"]))
                    _vtitle = _info["name"]
                with open(_vpath, "w", encoding="utf-8") as _fh:
                    _fh.write(build_view_html(r, _vcols, _vtitle))
                _vcols = None
                view_written.append(_vpath)
            _scols = None
            html_rows.append(dict(
                file=_name,
                lead=(r.ch_names[r.lead] if r.ch_names and r.lead < len(r.ch_names)
                      else str(r.lead)),
                beats=int(ig["n"]), analysable_s=float(r.analysable_s),
                nosig_s=float(ig.get("nosig_s", 0.0) or 0.0),
                mark_s=float(ig.get("mark_s", 0.0) or 0.0),
                empty_s=float(ig.get("empty_s", 0.0) or 0.0),
                empty_applied_s=float(ig.get("empty_applied_s", 0.0) or 0.0),
                bpm=float(ig["bpm"]), flags=",".join(ig["flags"]),
                trust=bool(ig["trustworthy"]), view_abs=_vpath))
            ok += 1 if ig["trustworthy"] else 0
            floor_tot.append(100.0 * r.floor_removed)
            empty_tot[0] += float(ig.get("empty_s", 0.0) or 0.0)
            empty_tot[1] += float(r.dur)
            empty_tot[2] += 1
            if np.isfinite(getattr(r, "k_min_safe", float("nan"))):
                kmin_tot.append(r.k_min_safe)
            if np.isfinite(getattr(r, "k_crit", float("nan"))):
                kcrit_tot.append(r.k_crit)
            print("  %-*s %4d %6.1f %6d %5d %7.2f %7.2f %6.1f %6.3f %6.1f %6.1f %8.1f %6.2f %6.1f %6.2f %6.2f %7.1f %7.1f %7.1f  %s"
                  % (W, _name[:W], r.lead, r.dur / 60.0, ig["n"],
                     getattr(r, "refill_added", 0),
                     ig["bpm"], ig["modal_bpm"], ig["short_pct"], r.tmplq,
                     r.qc["accept_pct"], ig["max_gap"], ig["max_gap_at"],
                     ig.get("gap_end_edge_s", float("nan")),
                     100.0 * r.floor_removed,
                     getattr(r, "p99_over_a", float("nan")),
                     getattr(r, "k_min_safe", float("nan")),
                     ig.get("nosig_s", 0.0),
                     ig.get("mark_s", 0.0),
                     ig.get("empty_s", 0.0),
                     ",".join(ig["flags"]) or "-"))
            if ig["max_gap"] > 10.0 and np.isfinite(ig["max_gap_at"]):
                # gapAt_s is on the row's own clock; `show` reads the whole
                # file, so a segment's gap is moved onto the recording's.
                _goff = float(_info["t0_s"]) if _info else 0.0
                followups.append((_name, path, ig["max_gap_at"] + _goff,
                                  ig["max_gap"] * ig["modal_rr_ms"] / 1000.0))
            if _info:
                seg_done.append((r, _info, _vpath, None))
                # Keep the numbers, drop the samples: 19 segments' filtered
                # traces held to the end would undo the point of segmenting.
                r.wide = r.det = r.missing = None
        if seg_done:
            seg_files += 1
            print(segment_totals_line(path, [(r_, i_) for r_, i_, _v, _e in seg_done]))
            if view_dir:
                _st0 = record_start(path)[0]
                _irows = []
                for r_, i_, v_, e_ in seg_done:
                    if r_ is None:
                        _irows.append(dict(tag=i_["tag"], name=i_["name"],
                                           error=str(e_)))
                    else:
                        _irows.append(segment_index_row(
                            r_, i_, os.path.basename(v_) if v_ else None, _st0))
                index_written.append(write_segment_index(
                    os.path.join(os.path.expanduser(view_dir),
                                 seg_done[0][1]["base"] + ".index.html"),
                    path, _irows))
    print("  " + "-" * (151 + W - 38))
    print("  " + REMOVED_OVERLAP_NOTE)
    print("  %d/%d %s carry no disqualifying flag.  (%s are advisory and"
          % (ok, n_rows, "row(s)" if seg_files else "file(s)",
             ", ".join(sorted(ADVISORY_FLAGS))))
    print("  do not count against a file.  So is AMP_FLOOR_n.nn%, which reports")
    print("  the share of detections the amplitude floor removed: below %.2g%%"
          % (100.0 * AMP_FLOOR_NOTE_FRAC))
    print("  it is silent, above %.2g%% it becomes AMP_FLOOR_MAJOR and disqualifies.)"
          % (100.0 * AMP_FLOOR_MAJOR_FRAC))
    print()
    print("  fill = beats recovered by re-detecting inside a gap, restarting")
    print("  just after the artifact that opened it instead of waiting for the")
    print("  chunk grid to reset neurokit's threshold.  Expect 0 on a clean")
    print("  file -- a clean file has no gap to re-scan, so a nonzero fill")
    print("  there would mean the refill is inventing beats.  Re-run with")
    print("  --no-refill to compare on this same build.")
    print()
    print("  nosig_s = seconds carrying no signal at all, measured as a window")
    print("  whose peak-to-peak is under %.2f of this file's own median QRS."
          % profile.no_signal_frac)
    print("  That time is removed from the rate's DENOMINATOR and the beats")
    print("  inside it from its NUMERATOR, so bpm describes real signal only.")
    print("  Intervals bridging such a span are also dropped from maxGap and")
    print("  gapTime, which would otherwise report the excised hole as a gap.")
    print("  Expect 0.0 everywhere except a file with a genuine dropout: 16 of")
    print("  17 pig files measured 0.0, and the 17th is a lead-off event.")
    print("  Re-run with --no-nosig to compare on this same build.")
    print()
    print("  mark_s = seconds the EXPORT ITSELF marked as having no valid")
    print("  sample -- a literal 'x' (or an empty field) in the data, which is")
    print("  Ponemah stating it had nothing to write.  Excised exactly like")
    print("  nosig_s, from both the numerator and the denominator.")
    print()
    print("  It is a SEPARATE column from nosig_s because it is a different")
    print("  kind of claim.  nosig_s is this tool inferring silence from an")
    print("  amplitude ratio and could be wrong; mark_s is a reading off the")
    print("  file and cannot be.  It also carries no minimum length and no")
    print("  threshold: one marked sample is one sample removed.")
    print()
    print("  Where they overlap -- marked time is usually flat, so both")
    print("  usually fire -- the overlap is counted ONCE.  The two columns")
    print("  can therefore sum to more than the time actually removed.")
    print()
    print("  A marked file is flagged MARKED_n.nn%, advisory, becoming")
    print("  MARKED_MAJOR above %.2g%% of the record, which disqualifies."
          % (100.0 * NO_SIGNAL_MAJOR_FRAC))
    print("  EDF exports carry no such marker, so expect 0.0 on the P10 fleet;")
    print("  it is the ASCII exports where this appears.")
    print()
    _em = float(getattr(args, "refill_gap_mult", 3.0))
    if getattr(args, "keep_empty", False):
        print("  empty_s = seconds inside beatless gaps longer than %.1fx the"
              % _em)
        print("  baseline RR.  MODE: KEPT (--keep-empty) -- these gaps are")
        print("  counted as real pauses and their seconds STAY in the rate's")
        print("  denominator.  Across these files that is %.1f s (%.3f%% of"
              % (empty_tot[0], 100.0 * empty_tot[0] / empty_tot[1]
                 if empty_tot[1] else 0.0))
        print("  the %.1f s read); the default would have removed it." %
              empty_tot[1])
    else:
        print("  empty_s = seconds inside beatless gaps longer than %.1fx the"
              % _em)
        print("  baseline RR (the refill's own threshold) that no-signal and")
        print("  marked time did not already cover.  MODE: DROPPED (the")
        print("  default) -- each such gap's interior is excised, keeping ONE")
        print("  normal interval (half at each end), so its time leaves the")
        print("  rate's DENOMINATOR.  No beat lies inside, so the count is")
        print("  unchanged.  Removed across these files: %.1f s (%.3f%% of the"
              % (empty_tot[0], 100.0 * empty_tot[0] / empty_tot[1]
                 if empty_tot[1] else 0.0))
        print("  %.1f s read).  maxGap / LONG_GAP still describe these gaps;"
              % empty_tot[1])
        print("  --keep-empty counts them as real pauses instead.")
    print()
    print("  bpm is beats/duration.  'modal' is 60/modal-RR and will read LOW")
    print("  wherever short% is large -- that is the couplet bias, not an error.")
    print("  A file whose bpm sits BELOW its modal rate is self-contradictory")
    print("  and is flagged DROPOUT_SUSPECTED: only early beats can lift the mean")
    print("  rate above the mode, so a deficit means beats are MISSING.")
    print()
    print("  tmplQ is NOT a cross-file quality score under this pathology.  A")
    print("  single template is fitted per file, so a file with many genuine")
    print("  early beats scores low for having TWO real morphologies.  Compare")
    print("  tmplQ between LEADS of one file, which is what it is used for.")
    if floor_tot:
        print()
        print("  floor%% = detections rejected as too small to be a QRS (<%.0f%% of the"
              % (100.0 * profile.amp_floor_frac))
        print("  median).  Expect ~0: real beats here measured 0.87-1.18x normal.")
        print("  max %.2f%%, median %.2f%% across these files."
              % (max(floor_tot), float(np.median(floor_tot))))
        if max(floor_tot) > 1.0:
            print("  NONZERO floor% means your neurokit was emitting sub-QRS")
            print("  detections, and any earlier analysis run without this filter")
            print("  counted them as beats.")
    if kmin_tot:
        _ck = getattr(args, "clip_k", DEFAULTS["clip_k"])
        _kworst = max(kmin_tot)
        _kcrit = max(kcrit_tot) if kcrit_tot else float("nan")
        print()
        print("  p99/A and k_min are MEASURED per file, not assumed.  There are")
        print("  TWO thresholds and they mean different things:")
        print("    k_min  = 1.18/(p99/A).  Below it the clip grazes the tops of")
        print("             the tallest real beats.  ADVISORY: a clipped beat is")
        print("             still far above the acceptance floor, and clipsweep")
        print("             confirms it -- at k=2, below every measured k_min,")
        print("             clean files gained 0 and 1 beat with tmplQ flat.")
        print("    k_crit = 0.30/(p99/A).  Below it the clip level sits IN the")
        print("             P-wave band, so beats and P waves clip to the same")
        print("             level and stop being distinguishable.  That is real")
        print("             damage and it clears the trustworthy verdict.")
        print("  clip_k in use %.2f;  k_min here %.2f-%.2f;  worst k_crit %.2f."
              % (_ck, min(kmin_tot), _kworst, _kcrit))
        if np.isfinite(_kcrit) and _ck < _kcrit:
            print("  ** clip_k IS BELOW k_crit.  Those rows carry CLIP_DESTROYS_QRS")
            print("  ** and their beat counts are not usable.  Re-run at --clip-k %.1f"
                  % (float(np.ceil(_kcrit * 10.0)) / 10.0))
        elif _ck < _kworst:
            print("  clip_k is below k_min on at least one file (CLIP_BELOW_KMIN).")
            print("  Advisory only -- but if that file also looks short on beats,")
            print("  re-run it at --clip-k %.1f and see whether the count moves."
                  % (float(np.ceil(_kworst * 10.0)) / 10.0))
        else:
            print("  Margin %.2f above the worst k_min.  The window is narrow, so"
                  % (_ck - _kworst))
            print("  watch this column when new animals or new gain settings arrive.")
    if followups:
        print()
        print("  LOOK AT THESE.  A long gap is either the signal dropping out")
        print("  (nothing to recover) or the detector losing a stretch it should")
        print("  have found.  edge_s is the evidence: it is the distance from the")
        print("  gap's END to the nearest chunk boundary, and a value near 0 means")
        print("  the gap was made by this tool, not by the animal.  Those files")
        print("  are flagged GAP_ENDS_ON_CHUNK_EDGE and their beats ARE")
        print("  recoverable -- run `clipsweep` on them.  Each command below")
        print("  centres the worst gap for a visual check:")
        for name, path, at, secs in followups:
            print("    # %s -- %.0f s gap at t=%.0f s" % (name, secs, at))
            print("    python3 ecg_rpeaks.py show --input %s \\" % path)
            print("        --start %.0f --seconds 12 --panels 4" % max(0.0, at - 2.0))
    if view_written:
        print()
        print("  viewer pages: %d written to %s" % (len(view_written),
                                                   os.path.expanduser(view_dir)))
        if index_written:
            print("  segment index pages: %s" % ", ".join(
                os.path.basename(p_) for p_ in index_written))
    if collect is not None:
        _out = os.path.expanduser(getattr(args, "html", None) or ".")
        _od = os.path.dirname(os.path.abspath(_out))
        good_rows = [d for d in html_rows if not d.get("error")]
        for d in html_rows:
            if d.get("view_abs"):
                # Relative, so the report and its viewer pages still link
                # after the whole folder is zipped and sent to someone else.
                d["view"] = os.path.relpath(d["view_abs"], _od).replace(os.sep, "/")
            d.pop("view_abs", None)
        _tb = sum(d["beats"] for d in good_rows)
        _ta = sum(d["analysable_s"] for d in good_rows)
        _ke = bool(getattr(args, "keep_empty", False))
        totals = dict(n=len(good_rows), ok=ok, beats=_tb, analysable_s=_ta,
                      nosig_s=sum(d["nosig_s"] for d in good_rows),
                      mark_s=sum(d["mark_s"] for d in good_rows),
                      empty_s=sum(d["empty_s"] for d in good_rows),
                      bpm=(60.0 * _tb / _ta) if _ta > 0 else None)
        modes = [
            "empty gaps  %s: %.1f s across these files (> %.1fx baseline RR)"
            % ("KEPT as pauses (--keep-empty)" if _ke else "DROPPED (default)",
               empty_tot[0], _em),
            "no-signal   %s;  refill %s;  clip_k %g" % (
                "excised" if getattr(args, "nosig", True) else "OFF (--no-nosig)",
                "on" if getattr(args, "refill", True) else "OFF",
                getattr(args, "clip_k", DEFAULTS["clip_k"])),
            "bpm = beats / analysable seconds; analysable = recorded minus "
            "no-signal, marked%s" % ("" if _ke else " and empty-gap time"),
            REMOVED_OVERLAP_NOTE]
        cards = [["%d / %d" % (ok, n_rows),
                  "rows (segments) with no disqualifying flag" if seg_files
                  else "files with no disqualifying flag"],
                 ["{:,}".format(_tb), "beats"],
                 ["{:,.1f}".format(_ta), "analysable seconds"],
                 ["%.2f" % (_ta / 3600.0), "analysable hours"],
                 ["%.2f" % totals["bpm"] if totals["bpm"] is not None else "n/a",
                  "overall bpm"]]
        collect.update(dict(version=VERSION, profile=profile.name,
                            files=html_rows, totals=totals, modes=modes,
                            cards=cards, has_view=bool(view_written)))


def cmd_clipsweep(args):
    """Test whether the long gaps are the SPKI ratchet, by varying the clip.

    The prediction is specific and falsifiable.  If a gap is caused by the
    acceptance floor (0.25 * SPKI) being driven above real beats, then lowering
    the clip level C caps SPKI and the gap must SHRINK, because 0.25 * C falls
    below the beat amplitude.  If the gap is the signal genuinely dropping out,
    no clip level can recover a beat that was never recorded, and the gap must
    NOT move.

    Two files therefore behave differently under the same sweep, which is what
    makes this a test rather than a tuning exercise.
    """
    profile = SPECIES[args.species]
    files = expand_inputs(args.input)
    if not files:
        sys.exit("no input files matched %r" % (args.input,))
    ks = args.clip_ks
    print("=" * 110)
    print("%s  clipsweep  |  %s  |  %d file(s)  |  clip_k %s"
          % (VERSION, profile.name, len(files), ", ".join("%g" % k for k in ks)))
    print("=" * 110)
    print("  Prediction: a RATCHET gap shrinks as clip_k falls (the floor")
    print("  0.25*clip drops below a real beat).  A DROPOUT gap does not move,")
    print("  because no threshold can recover a beat that was never recorded.")
    print()
    print("  %-26s %6s %7s %7s %8s %7s %6s %6s %7s %7s  %s"
          % ("file", "clip_k", "beats", "dBeats", "maxGap_s", "edge_s",
             "tmplQ", "short%", "p99/A", "k_min", "verdict"))
    print("  " + "-" * 116)
    for path in files:
        base = os.path.basename(path)[:30]
        first = None
        for k in ks:
            a2 = argparse.Namespace(**vars(args))
            a2.clip_k = float(k)
            print("  ... %s clip_k=%g" % (base, k), file=sys.stderr)
            try:
                r = analyse(path, a2, profile)
            except Exception as e:                           # noqa: BLE001
                print("  %-30s %7g  ERROR: %s" % (base, k, e))
                continue
            ig = r.integrity
            gap_s = ig["max_gap"] * ig["modal_rr_ms"] / 1000.0
            if first is None:
                first = (gap_s, ig["n"])
                verdict = "(baseline)"
            else:
                g0, n0 = first
                dgap = (gap_s - g0) / g0 if g0 > 0 else 0.0
                dbeat = (ig["n"] - n0) / float(n0) if n0 else 0.0
                # Judge on BOTH.  An earlier version looked only at maxGap and
                # called part010 "unchanged" while it was recovering 146 beats,
                # because one long gap had merely shortened rather than closed.
                if dgap < -0.5 or dbeat > 0.02:
                    verdict = "RECOVERING"
                elif dgap < -0.1 or dbeat > 0.005:
                    verdict = "partly recovering"
                else:
                    verdict = "unchanged -> not the clip"
            print("  %-26s %6g %7d %7s %8.1f %7.2f %6.3f %6.1f %7.2f %7.2f  %s"
                  % (base, k, ig["n"],
                     "%+d" % (ig["n"] - first[1]) if first else "0",
                     gap_s, ig.get("gap_end_edge_s", float("nan")),
                     r.tmplq, ig["short_pct"],
                     getattr(r, "p99_over_a", float("nan")),
                     getattr(r, "k_min_safe", float("nan")),
                     verdict))
        print()
    print("  " + "-" * 116)
    print("  k_min is MEASURED, not assumed: the smallest clip_k that still keeps")
    print("  the clip level above the largest real beat (1.18x the median QRS).")
    print("  Crossing it is ADVISORY -- a clipped beat still towers over the")
    print("  acceptance floor.  The line that actually matters is k_crit =")
    print("  0.30/(p99/A), where the clip drops into the P-wave band; `report`")
    print("  prints it.  p99/A is the ratio both derive from, measured on the")
    print("  unclipped detection signal.")
    print()
    print("  READ tmplQ AND short% AS THE SAFETY CHECK.  Lowering the clip can")
    print("  drag the acceptance floor down toward the P wave.  Measured on the")
    print("  pig fleet: real beats 0.87-1.18 A, P-wave false positives 0.1-0.3 A,")
    print("  p99/A 0.42-0.50 (the p99/A column above is for THIS file).  The")
    print("  floor is 0.25*SPKI, which on clean signal settles")
    print("  at ~0.25 A; the clip only CAPS it, at 0.25*k*p99 ~ 0.115*k*A.  So")
    print("  k=3 caps it at ~0.35 A, above its natural value, i.e. no effect on")
    print("  a clean stretch -- while k=2 caps it at ~0.23 A, BELOW the natural")
    print("  floor and inside the P-wave band, so k=2 actively invites false")
    print("  positives.  If a step gains beats while tmplQ FALLS and short%")
    print("  RISES, it is admitting P waves, not recovering QRS complexes.")
    print("  Include a file that is already clean as a control: it has nothing")
    print("  to recover, so any beats it gains as k falls are false positives,")
    print("  and that is what bounds how low k can go.")
    print()
    print("  edgeDist = seconds between the gap's END and the nearest chunk")
    print("  boundary.  Near zero is the ratchet signature: the animal cannot")
    print("  know where this tool's %g s grid falls." % getattr(args, "chunk", DEFAULTS["chunk_s"]))
    print()
    print("  Why clip_k matters (see clip_artifacts): SPKI cannot exceed the")
    print("  clip level C, so neurokit's acceptance floor cannot exceed 0.25*C.")
    print("  That is harmless until an artifact taller than a beat pushes SPKI")
    print("  up: with C = k*p99 and the MEASURED p99 ~ 0.46 A, k=8 lets SPKI")
    print("  reach ~3.7 A and the floor ~0.9 A -- at or above every real beat,")
    print("  and the rest of the chunk is lost.  k=3 holds the floor at ~0.35 A.")


# ==================================================================== selftest

def _st_write_edf(path, sigs, fs, labels, rec_duration=1.0, start=None):
    """Minimal EDF writer, used only by selftest.

    `start` is the recording start written into header bytes 168-184.  It
    defaults to the EDF `01.01.85` "not set" placeholder rather than to some
    real-looking date, because a synthetic file genuinely has no start time and
    the writer must not manufacture one.  This is not cosmetic: the header used
    to say `01.01.23`, which parses fine, and that single constant defeated the
    harness check that `trend` REFUSES to place a file carrying no timestamp --
    the file was placed at an arbitrary epoch and the test passed anyway.  It
    also made every trend run emit two header-vs-filename disagreement warnings,
    which is the fastest way to teach a reader to ignore that warning.
    """
    ns = len(sigs)
    spr = int(round(fs * rec_duration))
    nrec = min(len(x) for x in sigs) // spr
    sigs = [np.asarray(x[: nrec * spr], float) for x in sigs]
    pmin, pmax, dmin, dmax = -5.0, 5.0, -32768, 32767

    def fx(v, n):
        b = str(v).encode("ascii")[:n]
        return b + b" " * (n - len(b))

    def blk(vals, n):
        return b"".join(fx(v, n) for v in vals)

    # dd.mm.yy / hh.mm.ss, per EDF.  No start given means the placeholder, which
    # _parse_edf_start() refuses by design -- so an untimestamped synthetic file
    # is genuinely unplaceable rather than quietly landing in January 2023.
    d_s = "01.01.85" if start is None else start.strftime("%d.%m.%y")
    t_s = "00.00.00" if start is None else start.strftime("%H.%M.%S")
    hdr = fx(0, 8) + fx("X", 80) + fx("X", 80) + fx(d_s, 8) + fx(t_s, 8)
    hdr += fx(256 + ns * 256, 8) + fx("", 44) + fx(nrec, 8) + fx(rec_duration, 8) + fx(ns, 4)
    hdr += blk(labels, 16) + blk(["t"] * ns, 80) + blk(["mV"] * ns, 8)
    hdr += blk([pmin] * ns, 8) + blk([pmax] * ns, 8)
    hdr += blk([dmin] * ns, 8) + blk([dmax] * ns, 8)
    hdr += blk([""] * ns, 80) + blk([spr] * ns, 8) + blk([""] * ns, 32)
    scale = (dmax - dmin) / (pmax - pmin)
    digi = [np.clip((x - pmin) * scale + dmin, dmin, dmax).astype("<i2") for x in sigs]
    recs = []
    for k in range(nrec):
        for d in digi:
            recs.append(d[k * spr:(k + 1) * spr])
    with open(path, "wb") as f:
        f.write(hdr)
        f.write(np.concatenate(recs).astype("<i2").tobytes())


# The first 64 bytes of a real Ponemah `.PnmWav` (P10, 2023-08-06), verbatim,
# transcribed one dump row per line so it can be checked against the original
# by eye.  The fixture writer below is asserted to reproduce these exactly, so
# the walk is exercised against the vendor's own bytes rather than against my
# understanding of them -- the same discipline as the ASCII rows in [15].
_ST_PNMWAV_HEAD64 = bytes.fromhex(
    "af 55 55 aa 88 13 08 00 00 00 a4 00 00 00 00 00 "
    "00 00 8a 13 04 00 00 00 02 00 00 00 b2 13 15 00 "
    "00 00 45 61 73 74 65 72 6e 20 53 74 61 6e 64 61 "
    "72 64 20 54 69 6d 65 b4 13 08 00 00 00 01 00 00 ")


def _st_write_pnmwav(path, leads, gain):
    """Write a Ponemah-shaped container: real header bytes, then samples.

    Returns the byte offset of the first sample.  Note that offset is ODD (69)
    with these records, which is deliberate: np.frombuffer refuses an unaligned
    offset, so an odd payload start is exactly the case a reader can get wrong,
    and raw_window() sidesteps it by seeking and reading rather than slicing.
    """
    hdr = bytearray(PNMWAV_MAGIC)

    def rec(tag, val):
        hdr.extend(int(tag).to_bytes(2, "little"))
        hdr.extend(len(val).to_bytes(4, "little"))
        hdr.extend(val)

    rec(5000, (164).to_bytes(8, "little"))
    rec(5002, (2).to_bytes(4, "little"))
    rec(5042, b"Eastern Standard Time")
    rec(5044, (1).to_bytes(8, "little"))
    n = min(len(x) for x in leads)
    inter = np.empty((n, len(leads)), dtype="<i2")
    for j, x in enumerate(leads):
        inter[:, j] = np.clip(np.round(np.asarray(x[:n], float) / gain),
                              -32768, 32767).astype("<i2")
    with open(path, "wb") as f:
        f.write(bytes(hdr))
        f.write(inter.tobytes())
    return len(hdr)


def _st_write_pnmwav_mux(path, leads, start_dt, block=4096):
    """A MULTIPLEXED .PnmWav of the shape read_ponemah decodes natively.

    _st_write_pnmwav above writes a trailing-payload container, which is the
    shape `verify` exists for and read_ponemah refuses.  This one is what P10
    actually is: a recording-start record (5012), a per-channel descriptor
    block (5045 id, 5025/5026 raw range, 5029/5030 engineering range), then
    sample blocks (5015) tagged by channel and interleaved in time -- three
    full-rate ECG channels (ids 2, 3, 4) and one housekeeping channel (5) at
    1/250 of the rate, so the full-rate selection has something to exclude.
    Returns the mV-per-count gain the descriptors state.
    """
    raw_lo, raw_hi, eng_lo, eng_hi = -32256, 32255, -14.0, 14.0
    gain = (eng_hi - eng_lo) / float(raw_hi - raw_lo)
    _d = start_dt - datetime.datetime(1, 1, 1)
    tk = ((_d.days * 86400 + _d.seconds) * int(NET_TICKS_PER_S)
          + _d.microseconds * (int(NET_TICKS_PER_S) // 1000000))
    chans = [2, 3, 4]
    n = min(len(x) for x in leads)
    q = [np.clip(np.round(np.asarray(x[:n], float) / gain), -32768, 32767)
         .astype("<i2").tobytes() for x in leads[:3]]
    slow = bytes((n // 250) * 2)
    with open(path, "wb") as f:
        f.write(PNMWAV_MAGIC)

        def rec(tag, val):
            f.write(struct.pack("<HI", tag, len(val)))
            f.write(val)
        rec(5012, struct.pack("<Q", tk))
        for ch in chans + [5]:
            rec(5045, struct.pack("<Q", ch))
            rec(5025, struct.pack("<h", raw_lo))
            rec(5026, struct.pack("<h", raw_hi))
            rec(5029, struct.pack("<f", eng_lo))
            rec(5030, struct.pack("<f", eng_hi))
        nb = (len(q[0]) + block - 1) // block
        for k in range(nb):
            for ch, b in zip(chans, q):
                rec(5045, struct.pack("<Q", ch))
                rec(5015, b[k * block:(k + 1) * block])
            if k * block < len(slow):
                rec(5045, struct.pack("<Q", 5))
                rec(5015, slow[k * block:(k + 1) * block])
    return gain


def _st_build(dur_s, fs, baseline_ms, early_every=0, early_ms=560.0, seed=1,
              blackout=None, silent=False):
    """Synthetic 3-lead ECG with a known beat list.

    Lead 1 is clean, lead 0 is inverted and small, lead 2 is noisy, so lead
    selection has something to get right.  A slow sinusoid stands in for the
    dissociated P wave.
    """
    rng = np.random.default_rng(seed)
    n = int(dur_s * fs)
    peaks, t, i = [], 1.0, 0
    while t < dur_s - 1.0:
        peaks.append(int(round(t * fs)))
        i += 1
        t += (early_ms if (early_every and i % early_every == 0) else baseline_ms) / 1000.0
    peaks = np.asarray(peaks, dtype=int)
    if blackout:
        a, b = blackout
        peaks = peaks[(peaks < a * fs) | (peaks > b * fs)]

    w = int(round(0.014 * fs))
    tt = np.linspace(-1.5, 1.5, max(3, w))
    qrs = (1 - tt ** 2) * np.exp(-0.5 * tt ** 2)
    half = len(qrs) // 2
    leads = []
    for gain, noise in ((-0.35, 0.05), (1.0, 0.01), (0.8, 0.12)):
        x = rng.normal(0, noise, n)
        for p in peaks:
            a0, b0 = p - half, p - half + len(qrs)
            if a0 >= 0 and b0 <= n:
                x[a0:b0] += gain * qrs
        x += 0.06 * np.sin(2 * np.pi * 1.07 * (np.arange(n) / fs))
        if blackout and silent:
            x[int(blackout[0] * fs):int(blackout[1] * fs)] = 0.0
        leads.append(x)
    return leads, peaks


# ======================================================================= view
#
# `view` writes ONE self-contained HTML file per input: every lead as a
# stacked track, the lead analyse() chose drawn gold, and this tool's R peaks
# marked.  The look follows the lab's earlier "EDF ECG Multi-Detector EP
# Suite" viewer, but nothing is DETECTED in the browser -- the peaks are
# exactly the ones `detect` would write, so what is seen is what is counted.
#
# Three things the page can do beyond looking:
#   * overlay Ponemah's own beats (--ponemah, a `marks --export-beats` file),
#     placed on this file's clock and then offset-measured, never assumed;
#   * Edit R: click to reject a detected beat or add a missed one, then
#     export a peak file in the same format `review` writes, so `compare`
#     scores it as (b) against the detection as (a);
#   * choose the display filter.  Filtering happens in the browser on the
#     visible window only, so it costs nothing to switch and the stored
#     signal stays raw.
#
# The signals travel as base64 int16, not JSON numbers: an hour of three
# leads at 500 Hz is 5.4 M samples, which is ~14 MB this way and ~50 MB as
# text.  Each lead is stored minus its median over the lead's own peak
# |x - median| -- the median removal is what keeps the resolution for the QRS
# when the raw trace sits on a large DC offset.

VIEW_WINDOWS_S = (2, 5, 10, 20, 30, 60, 300)
VIEW_BASELINE_HZ = 0.5            # the default display high-pass
VIEW_EDIT_TOL_MS = 80.0           # a click this close to a beat hits it
VIEW_SNAP_MS = 40.0               # an added beat snaps to the extremum here

VIEW_HTML = r"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>__TITLE__</title>
<style>
:root{--bg:#0f1318;--panel:#171d24;--border:#2a3441;--text:#e2e8f0;
--muted:#8899a6;--lead:#52e396;--best:#ffca28;--peak:#00e676;--man:#ff5252;
--pon:#29b6f6;--cv:#090c0f}
*{box-sizing:border-box}
html,body{margin:0;height:100%;background:var(--bg);color:var(--text);
font:13px -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
body{display:flex;flex-direction:column}
header,footer{background:var(--panel);border-color:var(--border);
border-style:solid;border-width:0;display:flex;align-items:center;
gap:12px;padding:7px 12px;flex-wrap:wrap}
header{border-bottom-width:1px}
footer{border-top-width:1px;justify-content:space-between}
.grp{display:flex;align-items:center;gap:5px}
.sep{width:1px;height:22px;background:var(--border)}
.lbl{color:var(--muted);font-size:11px;letter-spacing:.06em;text-transform:uppercase}
.fname{font-weight:600;max-width:340px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
button,select{background:#222b36;color:var(--text);border:1px solid var(--border);
border-radius:4px;padding:3px 9px;font:inherit;cursor:pointer}
button:hover,select:hover{border-color:#3d4b5c}
button:disabled,select:disabled{opacity:.4;cursor:default}
button.on{border-color:var(--man);color:var(--man);background:#2a1c20}
button.exp{border-color:#2e7d52;color:#52e396}
input[type=range]{width:220px;accent-color:var(--best)}
#wrap{flex:1;position:relative;min-height:200px}
canvas{position:absolute;inset:0;width:100%;height:100%;background:var(--cv)}
canvas.edit{cursor:crosshair}
.chip{background:#222b36;border:1px solid var(--border);border-radius:10px;
padding:2px 10px;margin-left:6px;white-space:nowrap}
.legend span{margin-right:12px;color:var(--muted)}
.sw{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px;vertical-align:-1px}
</style></head><body>
<header>
 <div class="grp"><span class="fname" id="fname"></span></div>
 <div class="grp"><span class="lbl">Window</span><select id="win"></select></div>
 <div class="grp"><span class="lbl">Gain</span>
  <button id="gdn" title="smaller (-)">&minus;</button><button id="gup" title="larger (+)">+</button>
  <button id="gauto" title="fit each lead to this window">auto</button></div>
 <div class="grp"><button id="prev" title="back (Left arrow)">&lsaquo;</button>
  <input type="range" id="pos" min="0" max="1000" step="1" value="0">
  <button id="next" title="forward (Right arrow)">&rsaquo;</button>
  <span id="tpos" class="lbl"></span></div>
 <div class="sep"></div>
 <div class="grp"><span class="lbl">Filter</span><select id="filt">
   <option value="base">Baseline removed (0.5 Hz high-pass)</option>
   <option value="raw">Raw (offset removed)</option>
   <option value="band">Bandpass</option>
   <option value="det">Detection band</option></select>
  <span class="lbl">HP</span><select id="hp">
   <option>0.05</option><option selected>0.5</option><option>1</option><option>5</option></select>
  <span class="lbl">LP</span><select id="lp">
   <option>15</option><option selected>40</option><option>100</option><option>150</option></select>
  <span class="lbl">Notch</span><select id="notch">
   <option value="0">off</option><option value="50">50</option><option value="60">60</option></select></div>
 <div class="sep"></div>
 <div class="grp"><label id="ponlbl"><input type="checkbox" id="pon" checked> Ponemah</label></div>
 <div class="grp"><label id="emptylbl" title="Beatless gaps longer than the refill threshold (x baseline RR), recomputed from the CURRENT beats including your edits. Checked: their interior is excised from the rate's denominator (one normal interval kept). Unchecked: they count as real pauses (= --keep-empty)."><input type="checkbox" id="dropempty"> Drop empty gaps</label></div>
 <div class="grp"><button id="edit" title="click a beat to reject it, click empty trace to add one (E)">Edit R</button>
  <button id="undo" title="undo last edit (Ctrl/Cmd+Z)" disabled>Undo</button>
  <button id="export" class="exp" title="save a peak file that compare reads">Export CSV</button></div>
</header>
<div id="wrap"><canvas id="cv"></canvas></div>
<footer>
 <div id="status"></div>
 <div class="legend">
  <span><i class="sw" style="background:var(--best)"></i>detection lead</span>
  <span><i class="sw" style="background:var(--peak)"></i>R peak (this tool)</span>
  <span id="lgpon"><i class="sw" style="background:var(--pon)"></i>Ponemah</span>
  <span><i class="sw" style="background:var(--man)"></i>added by you</span>
  <span><i class="sw" style="background:#667788"></i>rejected by you</span>
  <span><i class="sw" style="background:#ff5252;opacity:.4"></i>excised: no signal / marked</span>
  <span id="lgempty"><i class="sw" style="background:#b388ff;opacity:.6"></i><i id="lgemptytxt" style="font-style:normal">empty gap</i></span>
 </div>
 <div id="chips"></div>
</footer>
<script type="application/json" id="payload">__DATA__</script>
<script>
"use strict";
const P=JSON.parse(document.getElementById("payload").textContent);
function b64(s,T){const b=atob(s),u=new Uint8Array(b.length);
 for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return new T(u.buffer);}
const fs=P.fs,N=P.n,dur=N/fs;
const leads=P.leads.map(L=>({name:L.name,scale:L.scale,best:L.best,q:L.q,
 lo:L.lo,hi:L.hi,y:b64(L.data,Int16Array)}));
const bestK=Math.max(0,leads.findIndex(L=>L.best));
const peaks=b64(P.peaks,Int32Array);           // sample indices, sorted
const keep=new Uint8Array(peaks.length).fill(1);
for(const i of P.removed)keep[i]=0;
let manual=P.added.slice().sort((a,b)=>a-b);   // samples, sorted
const pon=P.pon?b64(P.pon.data,Int32Array):new Int32Array(0);
// ---- excision.  `base` is no-signal U marked (from Python, fixed); `empty`
// is RECOMPUTED here from the current beat list -- detected beats still kept
// plus beats you added -- with the same rule and the same constants as
// empty_gap_spans()/robust_baseline_rr() in Python (P.empty_cfg).  Change one,
// change the other.
const base=P.excised_base,EC=P.empty_cfg,DUR=P.dur_s;
let empty=[],emptyM=NaN,parity="";
function median(a){const b=Float64Array.from(a).sort(),n=b.length;if(!n)return NaN;
 const h=n>>1;return n%2?b[h]:(b[h-1]+b[h])/2;}
function robustRR(rr){let M=median(rr);
 for(let it=0;it<EC.iters;it++){const sel=[];for(const v of rr)if(Math.abs(v/M-1)<EC.tol)sel.push(v);
  if(sel.length<EC.min_sel)break;const M2=median(sel);if(Math.abs(M2-M)<1e-7){M=M2;break;}M=M2;}
 return M;}
function ovl(a0,a1,b0,b1){return Math.max(0,Math.min(a1,b1)-Math.max(b0,a0));}
function subtractSp(lo,hi,sp){const out=[];let cur=lo;
 for(const [a,b] of sp){if(b<=cur)continue;if(a>=hi)break;if(a>cur)out.push([cur,Math.min(a,hi)]);
  cur=Math.max(cur,b);if(cur>=hi)break;}
 if(cur<hi)out.push([cur,hi]);return out.filter(([a,b])=>b>a);}
function mergeSp(sp){const s=sp.filter(([a,b])=>b>a).sort((x,y)=>x[0]-y[0]||x[1]-y[1]),out=[];
 for(const [a,b] of s){if(out.length&&a<=out[out.length-1][1])out[out.length-1][1]=Math.max(out[out.length-1][1],b);else out.push([a,b]);}
 return out;}
function totalSp(sp){let t=0;for(const [a,b] of sp)t+=b-a;return t;}
const baseS=base.map(([a])=>Math.round(a*fs)),baseE=base.map(([,b])=>Math.round(b*fs));
function inBase(s){let lo=0,hi=baseS.length;while(lo<hi){const m=(lo+hi)>>1;if(baseS[m]<=s)lo=m+1;else hi=m;}
 return lo>0&&s<baseE[lo-1];}
function liveBeats(){return effective(0,N+1).filter(s=>!inBase(s));}
function emptyFrom(bt){const n=bt.length;if(n<EC.min_beats||!(DUR>0))return {spans:[],M:NaN};
 const rr=new Float64Array(n-1);for(let i=0;i<n-1;i++)rr[i]=(bt[i+1]-bt[i])/fs;
 const M=robustRR(rr);if(!(M>0)||!isFinite(M))return {spans:[],M};
 const lim=EC.gap_mult*M,out=[];
 const edge=(g0,g1,kind)=>{if(g1-g0<=lim)return;let live=g1-g0;
  for(const [s,e] of base)live-=ovl(g0,g1,s,e);if(live<=lim)return;
  const lo=kind==="head"?g0:g0+0.5*M,hi=kind==="tail"?g1:g1-0.5*M;
  if(hi>lo)for(const p of subtractSp(lo,hi,base))out.push(p);};
 edge(0,bt[0]/fs,"head");for(let i=0;i<n-1;i++)edge(bt[i]/fs,bt[i+1]/fs,"mid");edge(bt[n-1]/fs,DUR,"tail");
 return {spans:mergeSp(out),M};}
let liveN=0;
function recomputeEmpty(){const bt=liveBeats();liveN=bt.length;const r=emptyFrom(bt);empty=r.spans;emptyM=r.M;}
function dropEmpty(){return $("dropempty").checked;}
const TOL=Math.round(P.edit_tol_ms/1000*fs),SNAP=Math.round(P.snap_ms/1000*fs);
let win=P.window,t0=0,gain=1,editing=false,dirty=false;const undo=[];
const cv=document.getElementById("cv"),ctx=cv.getContext("2d");
const $=id=>document.getElementById(id);
$("fname").textContent=P.title;$("fname").title=P.title;
for(const w of P.windows){const o=document.createElement("option");
 o.value=w;o.textContent=w>=60?(w/60)+" min":w+" s";if(w==win)o.selected=true;$("win").appendChild(o);}
$("filt").options[3].textContent="Detection band ("+P.det_band[0]+"\u2013"+P.det_band[1]+" Hz)";
if(!P.pon){$("ponlbl").style.display="none";$("lgpon").style.display="none";}
function fmt(t){t=Math.max(0,t)+(P.t_offset_s||0);const h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=t%60;
 const ss=(win<10?s.toFixed(1):Math.floor(s).toString()).padStart(win<10?4:2,"0");
 return (h?h+":"+String(m).padStart(2,"0"):m)+":"+ss;}
function lowerBound(a,v){let lo=0,hi=a.length;while(lo<hi){const m=(lo+hi)>>1;if(a[m]<v)lo=m+1;else hi=m;}return lo;}
function clampT(){t0=Math.min(Math.max(0,t0),Math.max(0,dur-win));}
// ---- filtering: 2nd-order Butterworth sections run forward and backward
// (zero phase, like scipy filtfilt) over the visible window plus padding.
function bq(kind,f0,Q){const w=2*Math.PI*Math.min(f0,0.45*fs)/fs,c=Math.cos(w),al=Math.sin(w)/(2*Q);
 let b0,b1,b2;if(kind==="hp"){b0=(1+c)/2;b1=-(1+c);b2=b0;}
 else if(kind==="lp"){b0=(1-c)/2;b1=1-c;b2=b0;}else{b0=1;b1=-2*c;b2=1;}
 const a0=1+al;return {k:[b0/a0,b1/a0,b2/a0,-2*c/a0,(1-al)/a0],dc:kind!=="hp"};}
function pass(x,f,rev){const [b0,b1,b2,a1,a2]=f.k,n=x.length;if(!n)return;
 const c=rev?x[n-1]:x[0];let z1=0,z2=0;
 for(let j=0;j<n;j++){const i=rev?n-1-j:j,v=x[i]-c,y=b0*v+z1;z1=b1*v-a1*y+z2;z2=b2*v-a2*y;x[i]=f.dc?y+c:y;}}
function chain(){const m=$("filt").value,out=[];let hp=0;
 if(m==="base"){hp=P.baseline_hz;out.push(bq("hp",hp,Math.SQRT1_2));}
 else if(m==="band"){hp=+$("hp").value;out.push(bq("hp",hp,Math.SQRT1_2),bq("lp",+$("lp").value,Math.SQRT1_2));}
 else if(m==="det"){hp=P.det_band[0];out.push(bq("hp",hp,Math.SQRT1_2),bq("lp",P.det_band[1],Math.SQRT1_2));}
 const nf=+$("notch").value;if(nf)out.push(bq("notch",nf,30));
 return {fl:out,pad:Math.round(fs*(hp?Math.min(30,Math.max(1,3/hp)):(nf?1:0)))};}
let cache={key:""};
function seg(){const s0=Math.floor(t0*fs),s1=Math.min(N,Math.ceil((t0+win)*fs));
 const key=[s0,s1,$("filt").value,$("hp").value,$("lp").value,$("notch").value].join("|");
 if(cache.key===key)return cache;
 const C=chain(),a=Math.max(0,s0-C.pad),b=Math.min(N,s1+C.pad);
 const data=leads.map(L=>{const x=new Float64Array(b-a);for(let i=a;i<b;i++)x[i-a]=L.y[i]*L.scale;
  for(const f of C.fl){pass(x,f,false);pass(x,f,true);}return x.subarray(s0-a,s1-a);});
 cache={key,s0,s1,data};return cache;}
function autoGain(){const S=seg();
 leads.forEach((L,k)=>{let lo=Infinity,hi=-Infinity;for(const v of S.data[k]){if(v<lo)lo=v;if(v>hi)hi=v;}
  if(hi>lo){const p=0.08*(hi-lo);L.lo=lo-p;L.hi=hi+p;}});gain=1;draw();}
function resize(){const r=cv.getBoundingClientRect(),d=window.devicePixelRatio||1;
 cv.width=Math.round(r.width*d);cv.height=Math.round(r.height*d);ctx.setTransform(d,0,0,d,0,0);draw();}
function diamond(x,y,r){ctx.beginPath();ctx.moveTo(x,y-r);ctx.lineTo(x+r,y);ctx.lineTo(x,y+r);ctx.lineTo(x-r,y);ctx.closePath();}
function rate(list,a,b){const n=b-a;if(n<2)return ["\u2013",n];const sp=(list[b-1]-list[a])/fs;
 return [sp>0?(60*(n-1)/sp).toFixed(1):"\u2013",n];}
function effective(s0,s1){const out=[];let i=lowerBound(peaks,s0),j=lowerBound(manual,s0);
 while(true){const pa=i<peaks.length&&peaks[i]<s1?peaks[i]:Infinity,ma=j<manual.length&&manual[j]<s1?manual[j]:Infinity;
  if(pa===Infinity&&ma===Infinity)break;if(pa<=ma){if(keep[i])out.push(pa);i++;}else{out.push(ma);j++;}}return out;}
function draw(){
 const W=cv.clientWidth,H=cv.clientHeight,axisH=22,gut=6,S=seg(),s0=S.s0,s1=S.s1;
 ctx.fillStyle="#090c0f";ctx.fillRect(0,0,W,H);
 const nL=leads.length,th=(H-axisH)/nL,x=s=>(s/fs-t0)/win*W,showPon=P.pon&&$("pon").checked;
 ctx.fillStyle="rgba(255,82,82,0.10)";
 for(const [a,b] of base){if(b<t0||a>t0+win)continue;
  const xa=Math.max(0,(a-t0)/win*W),xb=Math.min(W,(b-t0)/win*W);ctx.fillRect(xa,0,xb-xa,H-axisH);}
 const dE=dropEmpty();
 ctx.fillStyle="rgba(179,136,255,0.16)";ctx.strokeStyle="rgba(179,136,255,0.55)";ctx.lineWidth=1;
 if(!dE)ctx.setLineDash([4,4]);
 for(const [a,b] of empty){if(b<t0||a>t0+win)continue;
  const xa=Math.max(0,(a-t0)/win*W),xb=Math.min(W,(b-t0)/win*W);
  if(dE)ctx.fillRect(xa,0,xb-xa,H-axisH);else ctx.strokeRect(xa+0.5,0.5,Math.max(0,xb-xa-1),H-axisH-1);}
 ctx.setLineDash([]);
 const steps=[0.2,0.5,1,2,5,10,15,30,60,120,300,600];const st=steps.find(v=>win/v<=12)||600;
 ctx.strokeStyle="#1c242e";ctx.fillStyle="#8899a6";ctx.font="11px sans-serif";ctx.lineWidth=1;
 for(let t=Math.ceil(t0/st)*st;t<=t0+win+1e-9;t+=st){const xx=Math.round((t-t0)/win*W)+0.5;
  ctx.beginPath();ctx.moveTo(xx,0);ctx.lineTo(xx,H-axisH);ctx.stroke();ctx.fillText(fmt(t),xx+3,H-7);}
 const pa=lowerBound(peaks,s0),pb=lowerBound(peaks,s1),ma=lowerBound(manual,s0),mb=lowerBound(manual,s1);
 const qa=lowerBound(pon,s0),qb=lowerBound(pon,s1),dots=(pb-pa)<W/3;
 leads.forEach((L,k)=>{
  const top=k*th,lane=showPon?26:14,y0=top+lane+gut,h=th-lane-2*gut,D=S.data[k];
  ctx.strokeStyle="#2a3441";ctx.beginPath();ctx.moveTo(0,top+th+0.5);ctx.lineTo(W,top+th+0.5);ctx.stroke();
  const mid=(L.lo+L.hi)/2,span=Math.max(1e-12,(L.hi-L.lo)/gain);
  const Y=v=>y0+h/2-((v-mid)/span)*h;
  ctx.save();ctx.beginPath();ctx.rect(0,top,W,th);ctx.clip();
  ctx.strokeStyle=L.best?"#ffca28":"#52e396";ctx.lineWidth=L.best?1.3:1;ctx.beginPath();
  const spp=(s1-s0)/W;
  if(spp<=2){for(let i=s0;i<s1;i++){const xx=x(i),yy=Y(D[i-s0]);if(i==s0)ctx.moveTo(xx,yy);else ctx.lineTo(xx,yy);}}
  else{for(let px=0;px<W;px++){const a=Math.floor(px*spp),b=Math.min(s1-s0,Math.floor((px+1)*spp));
   let lo=Infinity,hi=-Infinity;for(let i=a;i<b;i++){const v=D[i];if(v<lo)lo=v;if(v>hi)hi=v;}
   if(lo===Infinity)continue;ctx.moveTo(px+0.5,Y(hi));ctx.lineTo(px+0.5,Y(lo)+0.5);}}
  ctx.stroke();
  for(let j=pa;j<pb;j++){const xx=x(peaks[j]);
   if(keep[j]){ctx.fillStyle="#00e676";diamond(xx,top+8,5);ctx.fill();
    if(L.best&&dots){ctx.beginPath();ctx.arc(xx,Y(D[peaks[j]-s0]),2.5,0,6.283);ctx.fill();}}
   else{ctx.strokeStyle="#667788";ctx.lineWidth=1.2;diamond(xx,top+8,5);ctx.stroke();
    ctx.beginPath();ctx.moveTo(xx-5,top+3);ctx.lineTo(xx+5,top+13);ctx.stroke();}}
  ctx.fillStyle="#ff5252";
  for(let j=ma;j<mb;j++){const xx=x(manual[j]);diamond(xx,top+8,5);ctx.fill();
   if(L.best&&dots){ctx.beginPath();ctx.arc(xx,Y(D[manual[j]-s0]),3,0,6.283);ctx.fill();}}
  if(showPon){ctx.fillStyle="#29b6f6";for(let j=qa;j<qb;j++){const xx=x(pon[j]);
   ctx.beginPath();ctx.moveTo(xx-4,top+16);ctx.lineTo(xx+4,top+16);ctx.lineTo(xx,top+23);ctx.closePath();ctx.fill();}}
  ctx.restore();
  const txt=(L.best?"\u2605 USED FOR DETECTION  ":"")+L.name+(L.q==null?"":"  \u00b7  tmplQ "+L.q.toFixed(3));
  ctx.font="bold 11px sans-serif";const tw=ctx.measureText(txt).width+14;
  ctx.fillStyle="rgba(23,29,36,0.9)";ctx.fillRect(W-tw-8,top+lane+4,tw,18);
  ctx.strokeStyle=L.best?"#ffca28":"#2a3441";ctx.lineWidth=1;ctx.strokeRect(W-tw-8+0.5,top+lane+4.5,tw-1,17);
  ctx.fillStyle=L.best?"#ffca28":"#e2e8f0";ctx.fillText(txt,W-tw-1,top+lane+17);
 });
 const eff=effective(s0,s1),[wb,wn]=rate(eff,0,eff.length);
 const nrem=keep.length-keep.reduce((a,v)=>a+v,0),nadd=manual.length;
 let chips='<span class="chip">window: '+wn+' beats \u00b7 '+wb+' bpm</span>';
 if(showPon){const [pbpm,pn]=rate(pon,qa,qb);chips+='<span class="chip" style="color:#29b6f6">Ponemah: '+pn+' \u00b7 '+pbpm+' bpm</span>';}
 if(nrem||nadd)chips+='<span class="chip" style="color:#ff5252">edits: \u2212'+nrem+' +'+nadd+(dirty?' (unsaved)':'')+'</span>';
 const exS=totalSp(base)+(dE?totalSp(empty):0),ana=Math.max(1e-9,DUR-exS);
 const fbpm=liveN?(60*liveN/ana).toFixed(2):"n/a",eS=totalSp(empty);
 chips+='<span class="chip">file: '+liveN+' beats \u00b7 '+fbpm+' bpm over '+(ana/3600).toFixed(2)+' h</span>';
 chips+='<span class="chip" style="color:#b388ff">empty gaps: '+empty.length+' \u00b7 '+eS.toFixed(1)+' s '+(dE?'dropped':'kept as pauses')+'</span>';
 $("lgemptytxt").textContent=dE?"empty gap (dropped)":"empty gap (kept as pause)";
 $("chips").innerHTML=chips;
 $("status").textContent=fmt(t0)+" \u2013 "+fmt(t0+win)+"   of "+fmt(dur)+"   |   "+P.version+(P.pon?"   |   "+P.pon.note:"")+(parity?"   |   "+parity:"")+(lastExport?"   |   Export: "+lastExport:"");
 $("tpos").textContent=fmt(t0);
 $("pos").value=dur>win?Math.round(1000*t0/(dur-win)):0;
 $("undo").disabled=!undo.length;
}
// ---- Edit R
function nearest(list,s){const i=lowerBound(list,s);let best=-1,d=Infinity;
 for(const j of [i-1,i])if(j>=0&&j<list.length&&Math.abs(list[j]-s)<d){d=Math.abs(list[j]-s);best=j;}return [best,d];}
function snap(s){const S=seg(),D=S.data[bestK],a=Math.max(S.s0,s-SNAP),b=Math.min(S.s1,s+SNAP+1);
 if(b<=a)return s;let m=0;for(let i=a;i<b;i++)m+=D[i-S.s0];m/=(b-a);
 let bi=s,bv=-1;for(let i=a;i<b;i++){const v=Math.abs(D[i-S.s0]-m);if(v>bv){bv=v;bi=i;}}return bi;}
function apply(op,rev){if(op.t==="auto")keep[op.i]^=1;
 else{const add=(op.t==="add")!==rev;if(add)manual.splice(lowerBound(manual,op.s),0,op.s);
  else{const j=lowerBound(manual,op.s);if(manual[j]===op.s)manual.splice(j,1);}}}
cv.addEventListener("click",e=>{if(!editing)return;const r=cv.getBoundingClientRect();
 const s=Math.round((t0+(e.clientX-r.left)/r.width*win)*fs);let op;
 const [ai,ad]=nearest(peaks,s),[mi,md]=nearest(manual,s);
 if(mi>=0&&md<=TOL&&(md<=ad||ai<0))op={t:"del",s:manual[mi]};
 else if(ai>=0&&ad<=TOL)op={t:"auto",i:ai};
 else op={t:"add",s:snap(s)};
 apply(op,false);undo.push(op);dirty=true;recomputeEmpty();draw();});
function doUndo(){const op=undo.pop();if(!op)return;apply(op,true);dirty=true;recomputeEmpty();draw();}
function setEdit(v){editing=v;$("edit").classList.toggle("on",v);cv.classList.toggle("edit",v);}
// ---- Export: the same peak-file format `review` writes; compare reads it as (b)
function csvq(v){v=String(v==null?"":v);return /[",\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;}
function buildCSV(){const nrem=keep.length-keep.reduce((a,v)=>a+v,0);
 const lines=P.csv_head.slice();
 lines.push("# edited_in: "+P.version+" view");
 lines.push("# edits: "+nrem+" detected beat(s) rejected (keep=0), "+manual.length+" added (source=MANUAL)");
 // Informational only: read_peaks keeps "# key: value" lines as metadata,
 // and compare recomputes its own excision from the recording.
 lines.push("# empty_gaps: "+(dropEmpty()?"dropped":"kept")+", "+totalSp(empty).toFixed(1)+" s in "+empty.length+" gap(s) (view)");
 lines.push(P.fields.join(","));
 const rows=[];
 for(let i=0;i<peaks.length;i++){const R=P.rows[i];
  rows.push([peaks[i],[(peaks[i]/fs).toFixed(4),peaks[i],R[0],R[1],R[2],R[3],"AUTO",keep[i],R[4]]]);}
 for(const s of manual)rows.push([s,[(s/fs).toFixed(4),s,"","",-1,0,"MANUAL",1,"added in view"]]);
 rows.sort((a,b)=>a[0]-b[0]);
 for(const [,r] of rows)lines.push(r.map(csvq).join(","));
 return lines.join("\n")+"\n";}
let lastExport="";
async function doExport(){const text=buildCSV(),name=P.export_name;
 const api=window.pywebview&&window.pywebview.api;
 if(api&&api.save_csv){const where=await api.save_csv(name,text);
  if(where){dirty=false;lastExport="saved "+where;draw();}return;}
 // Chrome/Edge: a real Save dialog, so the user picks the folder and name.
 if(window.showSaveFilePicker){try{
   const h=await window.showSaveFilePicker({suggestedName:name,
     types:[{description:"CSV",accept:{"text/csv":[".csv"]}}]});
   const w=await h.createWritable();await w.write(text);await w.close();
   dirty=false;lastExport="saved "+h.name+" (folder you chose)";draw();return;}
  catch(e){if(e&&e.name==="AbortError")return;}}
 // Safari/Firefox: a download.  Where it lands is the browser's setting.
 const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([text],{type:"text/csv"}));
 a.download=name;document.body.appendChild(a);a.click();a.remove();
 dirty=false;lastExport="downloaded as "+name+" \u2013 check the browser's Downloads list";draw();}
// ---- wiring
$("win").onchange=e=>{const c=t0+win/2;win=+e.target.value;t0=c-win/2;clampT();draw();};
$("gup").onclick=()=>{gain*=1.25;draw();};
$("gdn").onclick=()=>{gain/=1.25;draw();};
$("gauto").onclick=autoGain;
$("prev").onclick=()=>{t0-=0.9*win;clampT();draw();};
$("next").onclick=()=>{t0+=0.9*win;clampT();draw();};
$("pos").oninput=e=>{t0=(+e.target.value/1000)*Math.max(0,dur-win);draw();};
function syncFilt(){const b=$("filt").value==="band";$("hp").disabled=!b;$("lp").disabled=!b;}
$("filt").onchange=()=>{syncFilt();autoGain();};
$("hp").onchange=autoGain;$("lp").onchange=autoGain;$("notch").onchange=()=>draw();
$("pon").onchange=()=>draw();
$("dropempty").onchange=()=>draw();
$("edit").onclick=()=>setEdit(!editing);
$("undo").onclick=doUndo;
$("export").onclick=doExport;
window.addEventListener("keydown",e=>{if(e.target.tagName==="SELECT"||e.target.tagName==="INPUT")return;
 const f=e.shiftKey?0.1:0.9;
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="z"){doUndo();e.preventDefault();}
 else if(e.key==="ArrowRight"){t0+=f*win;clampT();draw();e.preventDefault();}
 else if(e.key==="ArrowLeft"){t0-=f*win;clampT();draw();e.preventDefault();}
 else if(e.key==="+"||e.key==="="){gain*=1.25;draw();}
 else if(e.key==="-"){gain/=1.25;draw();}
 else if(e.key==="e"||e.key==="E"){setEdit(!editing);}});
window.addEventListener("beforeunload",e=>{if(dirty){e.preventDefault();e.returnValue="";}});
window.addEventListener("resize",resize);
$("dropempty").checked=!!P.drop_empty;
recomputeEmpty();
// Unedited page: the JS spans must be the ones Python excised.  Say so in
// the status bar if they are not, rather than show a rate nobody computed.
if(!P.removed.length&&!P.added.length){const py=P.empty_py||[];
 if(py.length!==empty.length||Math.abs(totalSp(py)-totalSp(empty))>1e-6)
  parity="empty-gap JS/Python MISMATCH: "+empty.length+" gap(s) "+totalSp(empty).toFixed(3)+" s vs "+py.length+" gap(s) "+totalSp(py).toFixed(3)+" s";}
syncFilt();resize();
</script></body></html>
"""


def _b64(a, dtype):
    import base64
    return base64.b64encode(
        np.ascontiguousarray(a, dtype=dtype).tobytes()).decode("ascii")


def _html_escape(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _view_rows(r):
    """write_peaks' own header and per-beat columns, for the page's export.

    Taken from write_peaks rather than rebuilt, so the exported file carries
    the SAME config and config_sha1 lines `detect` writes -- which is what
    lets `compare` accept it against that detection instead of refusing it
    as scored against a different configuration.
    """
    import tempfile
    fd, tmp = tempfile.mkstemp(suffix=".csv")
    os.close(fd)
    try:
        write_peaks(tmp, r, review=False)
        with open(tmp, "r", newline="") as f:
            text = f.read()
    finally:
        os.remove(tmp)
    lines = text.splitlines()
    head = [ln for ln in lines if ln.startswith("#")]
    body = [ln for ln in lines if ln and not ln.startswith("#")]
    rows = list(csv.DictReader(body))
    return head, rows


def place_ponemah(pon_s, meta, file_start, ours_s, dur, max_lag_s=5.0):
    """Ponemah beat times moved onto THIS file's clock: (times_s, info).

    Two steps, in this order, and the second is not optional:
      1. The coarse placement.  A `marks --export-beats` file states its
         origin as t0_ticks; this file's start comes from record_start().
         Their difference puts an 18-hour beat list against a 1-hour EDF
         part.  With no stated origin the two are assumed to share one,
         which is right for a beat list exported from the same file.
      2. The residual offset, MEASURED by peak_train_lag against this tool's
         own beats.  An EDF header states its start to the whole second, so
         step 1 alone can be off by up to a second -- twenty times the
         matching tolerance.  It is applied only if it explains at least
         half the beats; otherwise the coarse placement stands and `info`
         says so, because an offset that matches nothing is not a clock.
    """
    info = dict(coarse_s=0.0, lag_s=0.0, coverage=0.0, applied=False,
                how="no origin stated; assumed to share this file's")
    pon_s = np.sort(np.asarray(pon_s, dtype=float))
    t0 = (meta or {}).get("t0_ticks")
    if t0 and file_start is not None:
        dt = ticks_to_dt(int(str(t0).split()[0]))
        if dt is not None:
            info["coarse_s"] = to_epoch(dt) - to_epoch(file_start)
            info["how"] = ("origin %s vs file start %s"
                           % (dt.isoformat(sep=" "), file_start.isoformat(sep=" ")))
    placed = pon_s + info["coarse_s"]
    near = placed[(placed > -max_lag_s) & (placed < dur + max_lag_s)]
    ours = np.sort(np.asarray(ours_s, dtype=float))
    if len(near) >= 2 and len(ours) >= 2:
        lag, _n, cov = peak_train_lag(ours, near, max_lag_s)
        info["lag_s"], info["coverage"] = float(lag), float(cov)
        if cov >= 0.5:
            placed = placed - lag
            info["applied"] = True
    inside = placed[(placed >= 0) & (placed < dur)]
    info["n_inside"] = int(len(inside))
    return inside, info


def build_view_html(r, cols, title, window_s=20, pon=None, edits=None):
    """The viewer page for one analysed file, as a string.

    `r` is analyse()'s Result and `cols` the SAME file's samples from
    load_signals().  `pon` is (times_s, info) from place_ponemah, `edits`
    (removed_indices, added_samples) from read_view_edits.  Kept apart from
    cmd_view so selftest can check the page without the CLI.
    """
    import json
    cols, _miss = fill_missing(np.asarray(cols, dtype=float))
    fs = float(r.fs)
    anchors = np.sort(np.asarray(r.anchors, dtype=np.int64))
    leads = []
    for j in range(cols.shape[1]):
        x = cols[:, j]
        centre = float(np.median(x)) if len(x) else 0.0
        xc = x - centre
        peak = float(np.max(np.abs(xc))) if len(xc) else 0.0
        scale = peak / 32000.0 if peak > 0 else 1.0
        q = np.round(xc / scale).astype("<i2")
        # Default vertical range from the default display filter, by
        # percentile rather than max/min so one electrode pop cannot flatten
        # an hour of trace.  `auto` refits to the visible window.
        y = bp(xc, fs, VIEW_BASELINE_HZ, 0.45 * fs)
        lo, hi = (np.percentile(y, [0.1, 99.9]) if len(y) else (-1.0, 1.0))
        if not hi > lo:
            lo, hi = -1.0, 1.0
        pad = 0.1 * (hi - lo)
        name = r.ch_names[j] if j < len(r.ch_names) else "ch%d" % j
        tq = r.lead_q.get(j) if isinstance(r.lead_q, dict) else None
        leads.append(dict(
            name=str(name), scale=scale, centre=centre, best=(j == r.lead),
            q=(round(float(tq), 4) if tq is not None and np.isfinite(tq)
               and tq > -1.0 else None),
            lo=float(lo - pad), hi=float(hi + pad), data=_b64(q, "<i2")))
    head, rows = _view_rows(r)
    ana = float(getattr(r, "analysable_s", r.dur) or r.dur)
    bpm = 60.0 * len(anchors) / ana if ana > 0 else float("nan")
    pon_blob = None
    if pon is not None:
        ptimes, pinfo = pon
        psamp = np.round(np.asarray(ptimes, dtype=float) * fs).astype("<i4")
        note = ("Ponemah placed by %s, residual %+.3f s %s (%.0f%% of beats matched)"
                % ("stated origin" if pinfo["coarse_s"] else "shared origin",
                   pinfo["lag_s"],
                   "applied" if pinfo["applied"] else "NOT applied",
                   100.0 * pinfo["coverage"]))
        pon_blob = dict(data=_b64(np.sort(psamp), "<i4"), n=int(len(psamp)),
                        note=note)
    removed, added = edits if edits is not None else ([], [])
    # A segment page's title is "<base> seg03 (02:00:00-03:00:00)": splitext
    # on that cut at the last dot in the recording name, and every segment
    # of P10 exported as the SAME "08062023 P10.P10.edited.csv".  Name it
    # from the segment instead: <base>.<tag>.edited.csv.
    _vsg = getattr(r, "seg", None)
    base = ("%s.%s" % (_vsg["base"], _vsg["tag"]) if _vsg
            else os.path.splitext(str(title))[0])
    payload = dict(
        title=str(title), version=VERSION, fs=fs, n=int(cols.shape[0]),
        leads=leads, peaks=_b64(anchors, "<i4"), n_peaks=int(len(anchors)),
        bpm=("%.2f" % bpm) if np.isfinite(bpm) else "n/a",
        analysable_h="%.2f" % (ana / 3600.0),
        excised=[[float(a), float(b)] for a, b in
                 (getattr(r, "excise_spans", None) or [])],
        # no-signal U marked (fixed); the page recomputes EMPTY on top of
        # it from the current beats, with the same constants as Python.
        excised_base=[[float(a), float(b)] for a, b in
                      (getattr(r, "excise_base_spans", None) or [])],
        empty_py=[[float(a), float(b)] for a, b in
                  (getattr(r, "empty_spans", None) or [])],
        drop_empty=not bool(getattr(r, "keep_empty", False)),
        dur_s=float(r.dur),
        empty_cfg=dict(gap_mult=float(getattr(r, "empty_gap_mult", 3.0)),
                       tol=EMPTY_BASE_TOL, iters=EMPTY_BASE_ITERS,
                       min_sel=EMPTY_BASE_MIN_SEL,
                       min_beats=EMPTY_MIN_BEATS),
        windows=list(VIEW_WINDOWS_S),
        window=window_s if window_s in VIEW_WINDOWS_S else 20,
        baseline_hz=VIEW_BASELINE_HZ,
        det_band=[float(r.band[0]), float(r.band[1])],
        edit_tol_ms=VIEW_EDIT_TOL_MS, snap_ms=VIEW_SNAP_MS,
        csv_head=head, fields=list(PEAK_FIELDS),
        rows=[[d.get("amp", ""), d.get("rhythm", ""), d.get("cluster", ""),
               d.get("qc", ""), d.get("note", "")] for d in rows],
        removed=[int(i) for i in removed], added=[int(s) for s in added],
        pon=pon_blob, export_name=base + ".edited.csv",
        # Seconds from the RECORDING start to this page's sample zero: 0 for
        # a whole file, the segment start for one segment of a long record,
        # so the time axis reads recording time (02:00:00, not 0:00).
        t_offset_s=float((getattr(r, "seg", None) or {}).get("t0_s", 0.0)))
    # "</" would end the <script> element early if it ever appeared in a
    # channel name, title or note; the escaped form is identical JSON.
    blob = json.dumps(payload, separators=(",", ":")).replace("</", "<\\/")
    return (VIEW_HTML.replace("__TITLE__", _html_escape(str(title)))
            .replace("__DATA__", blob))


def read_view_edits(path, r):
    """A previously exported edit file, as (removed_indices, added_samples, note).

    AUTO rows are matched to this detection by SAMPLE; a row that matches no
    detected beat is counted and reported rather than silently dropped,
    since it means the file was edited against a different detection.
    """
    _times, meta, rows = read_peaks(path)
    fs = float(r.fs)
    anchors = np.sort(np.asarray(r.anchors, dtype=np.int64))
    pos = {int(a): i for i, a in enumerate(anchors)}
    removed, added, unmatched = [], [], 0
    for d in rows:
        src = (d.get("source") or "").strip().upper()
        try:
            k = int(float(d.get("keep", "1") or 1))
        except ValueError:
            k = 1
        s = (d.get("sample") or "").strip()
        samp = (int(float(s)) if s else
                int(round(float(d.get("time_s") or 0) * fs)))
        if src == "AUTO":
            if samp not in pos:
                unmatched += 1
            elif not k:
                removed.append(pos[samp])
        elif k:
            added.append(samp)
    note = ""
    if meta.get("config_sha1") and meta.get("config_sha1") != config_signature(r)[1]:
        note = "edit file was made with a different detection config"
    if unmatched:
        note = (note + "; " if note else "") + (
            "%d AUTO row(s) match no detected beat and were ignored" % unmatched)
    return sorted(removed), sorted(added), note


class _ViewAPI:
    """What the page may call in a pywebview window: a native Save dialog.

    A browser saves a download to ~/Downloads without asking; an embedded
    webview has no download manager at all, so without this Export would
    silently do nothing in --window mode.
    """

    def __init__(self):
        self.window = None

    def save_csv(self, name, text):
        import webview
        kind = getattr(getattr(webview, "FileDialog", None), "SAVE", None)
        if kind is None:
            kind = webview.SAVE_DIALOG
        got = self.window.create_file_dialog(kind, save_filename=name)
        if not got:
            return ""
        path = got if isinstance(got, str) else got[0]
        with open(path, "w", newline="") as f:
            f.write(text)
        return path


def cmd_view(args):
    profile = SPECIES[args.species]
    files = expand_inputs(args.input)
    if not files:
        sys.exit("no input files matched %r" % (args.input,))
    if (args.out or getattr(args, "edits", None)) and len(files) > 1:
        sys.exit("--out and --edits name ONE file; with %d inputs use --outdir"
                 % len(files))
    outdir = args.outdir or "."
    if not args.out:
        os.makedirs(outdir, exist_ok=True)
    pon_all = pon_meta = None
    if getattr(args, "ponemah", None):
        pon_all, pon_meta, _rows = read_peaks(args.ponemah)
    print("=" * 108)
    print("%s  view  |  %s profile  |  %d file(s)" % (VERSION, profile.name, len(files)))
    print("=" * 108)
    if pon_all is not None:
        print("  Ponemah   %s: %d beats kept" % (os.path.basename(args.ponemah), len(pon_all)))
    stretch = None
    if getattr(args, "start", None) is not None:
        try:
            _s0 = parse_clock_s(args.start)
        except ValueError:
            sys.exit("--start %r: give seconds (5400) or HH:MM:SS (01:30:00)"
                     % (args.start,))
        _len_min = (args.minutes if args.minutes and args.minutes > 0 else
                    float(getattr(args, "segment", 0.0) or 0.0)
                    or SEGMENT_MIN_DEFAULT)
        stretch = (_s0, _len_min * 60.0)
        print("  stretch   %g min from %s after the recording start"
              " (--start, --minutes)" % (_len_min, _hms(_s0)))
    written = []
    _seg_example = None
    for f in files:
        _clock = None
        _index = []
        for r, scols, info, err in iter_analyses(f, args, profile,
                                                 stretch=stretch):
            if err is not None:
                if info is None:
                    raise err
                print("  %-44s ERROR: %s" % (info["name"], err))
                _index.append(dict(tag=info["tag"], name=info["name"],
                                   error=str(err)))
                continue
            if info is None:
                cols, _fs, _names, _dur = load_signals(f, args.minutes)
                title = os.path.basename(f)
                base = os.path.splitext(title)[0]
                out = args.out or os.path.join(outdir, base + ".view.html")
                off = 0.0
            else:
                if getattr(args, "edits", None) and not info["stretch"]:
                    sys.exit("--edits belongs to ONE page, and %s is %d segments."
                             "  Add --start/--minutes for the stretch the edits"
                             " were made on." % (os.path.basename(f), info["n"]))
                cols = scols
                title = info["name"]
                if info["stretch"] and args.out:
                    out = args.out
                else:
                    _od = (os.path.dirname(os.path.abspath(args.out))
                           if args.out else outdir)
                    os.makedirs(_od, exist_ok=True)
                    out = os.path.join(_od, "%s.%s.view.html"
                                       % (info["base"], info["tag"]))
                off = float(info["t0_s"])
            scols = None
            pon = None
            if pon_all is not None:
                if _clock is None:
                    _clock = record_start(f)
                st = _clock[0]
                _pa = pon_all
                if off:
                    # This page's clock starts `off` into the recording.
                    if st is not None and (pon_meta or {}).get("t0_ticks"):
                        st = st + datetime.timedelta(seconds=off)
                    else:
                        _pa = np.asarray(pon_all, dtype=float) - off
                pon = place_ponemah(_pa, pon_meta, st,
                                    np.asarray(r.anchors, float) / r.fs, r.dur)
            edits = None
            if getattr(args, "edits", None):
                rem, add, enote = read_view_edits(args.edits, r)
                edits = (rem, add)
                print("  edits     %s: %d rejected, %d added%s"
                      % (os.path.basename(args.edits), len(rem), len(add),
                         ("  -- NOTE " + enote) if enote else ""))
            html = build_view_html(r, cols, title, args.seconds,
                                   pon=pon, edits=edits)
            if info is not None and _seg_example is None:
                _seg_example = "%s.%s.edited.csv" % (info["base"], info["tag"])
            cols = None
            with open(out, "w", encoding="utf-8") as fh:
                fh.write(html)
            if info is None or info["stretch"]:
                written.append((out, title))
            name = r.ch_names[r.lead] if r.lead < len(r.ch_names) else r.lead
            print("  %-44s %6d beats  lead %s  %5.1f MB  -> %s"
                  % (title, len(r.anchors), name,
                     len(html) / 1e6, out))
            html = None
            print("            empty gaps: %.1f s in %d gap(s), %s by default "
                  "(toggle \"Drop empty gaps\" in the page)"
                  % (float(getattr(r, "empty_s", 0.0)),
                     len(getattr(r, "empty_spans", None) or []),
                     "KEPT (--keep-empty)" if getattr(r, "keep_empty", False)
                     else "DROPPED"))
            if pon is not None:
                pi = pon[1]
                print("            Ponemah: %d beats inside; %s; residual offset "
                      "%+.3f s matched %.0f%% of beats -> %s"
                      % (pi["n_inside"], pi["how"], pi["lag_s"],
                         100.0 * pi["coverage"],
                         "applied" if pi["applied"] else
                         "NOT applied (too few matches to call it a clock offset)"))
            if info is not None and not info["stretch"]:
                if _clock is None:
                    _clock = record_start(f)
                _index.append(segment_index_row(r, info, os.path.basename(out),
                                                _clock[0]))
                r.wide = r.det = r.missing = None
        if _index and stretch is None:
            _ib = os.path.splitext(os.path.basename(f))[0]
            ipath = args.out or os.path.join(outdir, _ib + ".index.html")
            write_segment_index(ipath, f, _index)
            # The index, not 19 pages, is what gets opened (and what --window
            # shows): one window per segment would bury the desktop.
            written.append((ipath, os.path.basename(f)))
            print("  index     %d segment page(s) listed in %s"
                  % (len(_index), ipath))
    print()
    print("  Edit R: click a green beat to reject it, click empty trace to add")
    print("  one, then Export CSV.  Score the edits with:")
    print("    python3 %s compare --input %s --manual %s"
          % (os.path.basename(sys.argv[0]), _shq(files[0]),
             _shq(_seg_example) if _seg_example else
             os.path.splitext(os.path.basename(files[0]))[0] + ".edited.csv"))
    if _seg_example:
        print("  (each segment page exports <base>.<tag>.edited.csv; compare"
              " reads the stretch")
        print("   from the file's # segment_offset_s header)")
    print("  (a browser saves Export CSV to your Downloads folder)")
    print()
    if not args.window:
        print("  Open in a browser, e.g. on a Mac:")
        print("    open %s" % _shq(written[0][0]))
        print("  Keys: Left/Right page, Shift+Left/Right nudge, +/- gain,")
        print("        E edit mode, Ctrl/Cmd+Z undo.")
        return 0
    try:
        import webview                                  # pywebview
    except ImportError:
        print("  --window needs pywebview, which is not installed here:")
        print("    python3 -m pip install pywebview")
        print("  The HTML file(s) above were still written and open in any browser.")
        return 0
    for out, title in written:
        api = _ViewAPI()
        api.window = webview.create_window(
            title, url="file://" + os.path.abspath(out), js_api=api,
            width=1360, height=880)
    webview.start()
    return 0


def cmd_selftest(args):
    """Validate this install end to end, against data whose answer is known.

    This exists because the development tests had to STUB neurokit2 (its
    third_party visibility is restricted), so the one path they could not cover
    is the real detector call -- which is exactly the path that differs between
    machines and neurokit versions.  Run this once before trusting a long run.

    Detection-accuracy tolerances are deliberately generous: the point is to
    catch a broken environment, not to grade neurokit.  Every check prints its
    numbers so a marginal result can be judged rather than guessed at.
    """
    import tempfile
    fs, base_ms = 500.0, 960.0
    tmp = tempfile.mkdtemp(prefix="ecg_selftest_")
    results = []

    def chk(name, cond, detail=""):
        results.append((bool(cond), name, detail))
        print("  [%s] %-52s %s" % ("PASS" if cond else "FAIL", name, detail))
        return bool(cond)

    print("=" * 100)
    print("%s  selftest" % VERSION)
    print("=" * 100)
    print("  environment")
    # The absolute path of the file actually executing.  Without this, running
    # a stale copy from a different directory is indistinguishable from the
    # delivery having failed -- and that cost several rounds.
    #
    # Size and line count are printed alongside because the build tag alone can
    # only say "different", never HOW.  Same size but a different tag means the
    # transfer rewrote bytes (an editor substituting quotes or stripping
    # trailing whitespace); a different size means it is simply another
    # version.  Distinguishing those two took a whole round of guessing.
    try:
        _src = os.path.abspath(__file__)
        _mt = __import__("time").strftime("%Y-%m-%d %H:%M",
                                          __import__("time").localtime(os.path.getmtime(_src)))
        with open(_src, "rb") as _f:
            _raw = _f.read()
        _norm = _raw.replace(b"\r\n", b"\n").replace(b"\r", b"\n").rstrip(b"\n")
        _shape = "%d bytes, %d lines, %d non-ascii, %d tabs" % (
            len(_raw), len(_norm.split(b"\n")),
            sum(1 for _b in _raw if _b > 127), _raw.count(b"\t"))
    except Exception:                                        # noqa: BLE001
        _src, _mt, _shape = "?", "?", "?"
    print("    running     %s" % _src)
    print("    modified    %s" % _mt)
    print("    source      %s" % _shape)
    print("    python      %s" % sys.version.split()[0])
    print("    numpy       %s" % np.__version__)
    try:
        import scipy
        print("    scipy       %s" % scipy.__version__)
    except Exception:                                        # noqa: BLE001
        print("    scipy       ?")
    print("    neurokit2   %s" % getattr(nk, "__version__", "?"))
    print("    workdir     %s" % tmp)
    print()

    # ---------------------------------------------------------------- reader
    print("  [1] EDF reader")
    lc, pc = _st_build(200.0, fs, base_ms, early_every=3, early_ms=560.0, seed=1)
    good = os.path.join(tmp, "selftest_good.edf")
    _st_write_edf(good, lc, fs, ["ECG1", "ECG2", "ECG3"])
    cols, rfs, names, dur = load_signals(good)
    chk("reads back the sampling rate", abs(rfs - fs) < 1e-6, "%.1f Hz" % rfs)
    chk("reads back all three channels", cols.shape[1] == 3, "%d" % cols.shape[1])
    chk("reads back the duration", abs(dur - 200.0) < 1.5, "%.1f s" % dur)
    print()

    # ------------------------------------------------------------- detection
    print("  [2] detection with neurokit2 %s%s"
          % (getattr(nk, "__version__", "?"),
             "  -- STUBBED, proves the harness only"
             if "stub" in str(getattr(nk, "__version__", "")).lower()
             else "  (the real call the dev tests could not make)"))
    # nosig stated explicitly rather than left to the getattr default in
    # analyse(): the selftest's job is to exercise the shipping configuration,
    # and a default that is invisible here is one that can change without any
    # test noticing.
    a = argparse.Namespace(species="pig", minutes=0.0, lead=None, band=None,
                           refractory=None, qc_min=0.90, traceback=False,
                           nosig=True)
    r = analyse(good, a, PIG)
    err = 100.0 * abs(len(r.anchors) - len(pc)) / len(pc)
    chk("finds about the right number of beats", err < 5.0,
        "%d found vs %d true (%.1f%% off)" % (len(r.anchors), len(pc), err))
    chk("selects the clean lead", r.lead == 1,
        "lead %d; tmplQ %s" % (r.lead, {k: round(v, 3) for k, v in r.lead_q.items()}))
    if len(r.anchors) and len(pc):
        # Pair by TIME, not by index.  An index-aligned comparison silently
        # becomes a comparison of beat i against beat i+1 the moment a single
        # beat is missed, and then reports a whole beat interval as the
        # "offset" -- which is exactly what it did on neurokit 0.2.12 at 239
        # vs 240 beats.  Use the same matcher `compare` uses.
        at = np.sort(r.anchors) / fs
        tt = np.sort(pc) / fs
        mm, mfp, mfn = match_peaks(at, tt, PIG.match_tol_ms / 1000.0)
        off = float(np.median([d for _, _, d in mm])) if mm else float("inf")
        chk("peaks land on the true beats", off < 0.030,
            "median offset %.1f ms over %d matched (%d unmatched det, %d missed)"
            % (off * 1000, len(mm), len(mfp), len(mfn)))
    chk("morphology is coherent", r.tmplq > 0.80, "tmplQ %.3f" % r.tmplq)
    print()

    # ------------------------------------------------------------------ rate
    print("  [3] rate and integrity")
    ig = r.integrity
    chk("rate is beats/duration", abs(ig["bpm"] - 60.0 * len(r.anchors) / r.dur) < 0.01,
        "%.2f bpm" % ig["bpm"])
    chk("rate exceeds the modal rate under couplets", ig["bpm"] > ig["modal_bpm"],
        "%.2f vs modal %.2f" % (ig["bpm"], ig["modal_bpm"]))
    chk("clean file carries no DISQUALIFYING flag", ig["trustworthy"],
        str(ig["flags"]) or "none")
    # The synthetic record is quieter between beats than a real recording, so
    # p99/A is small and k_min_safe comes out high -- the shipped clip_k sits
    # below it.  That is exactly the case that must NOT be treated as damage:
    # this file was detected perfectly.  Pin both halves of the distinction.
    chk("k_min is measured, not assumed",
        np.isfinite(r.p99_over_a) and np.isfinite(r.k_min_safe)
        and np.isfinite(r.k_crit) and r.k_crit < r.k_min_safe,
        "p99/A %.3f, k_min %.2f, k_crit %.2f"
        % (r.p99_over_a, r.k_min_safe, r.k_crit))
    chk("grazing the QRS top is advisory, not disqualifying",
        "CLIP_DESTROYS_QRS" not in ig["flags"]
        and all(is_advisory(f) for f in ig["flags"]),
        "clip_k %.2f vs k_min %.2f / k_crit %.2f -> %s"
        % (ig["clip_k"], r.k_min_safe, r.k_crit, str(ig["flags"]) or "none"))
    print()

    # ------------------------------------------------------------ peak files
    print("  [4] peak file round trip")
    pf = os.path.join(tmp, "selftest.peaks.csv")
    n_rows, _ = write_peaks(pf, r, review=False)
    times, meta, rows = read_peaks(pf)
    chk("round trips every peak", len(times) == len(r.anchors),
        "%d written, %d read" % (len(r.anchors), len(times)))
    chk("carries provenance",
        all(k in meta for k in ("source_file", "fs_hz", "lead", "config_sha1")),
        meta.get("config_sha1", "?"))
    a2 = argparse.Namespace(**vars(a)); a2.refractory = 500.0
    r2 = analyse(good, a2, PIG)
    chk("provenance changes when the refractory changes",
        config_signature(r2)[1] != meta.get("config_sha1"),
        "%s vs %s" % (config_signature(r2)[1], meta.get("config_sha1")))
    a3 = argparse.Namespace(**vars(a)); a3.qc_min = 0.75
    r3 = analyse(good, a3, PIG)
    chk("provenance changes when the QC threshold changes",
        config_signature(r3)[1] != meta.get("config_sha1"),
        "%s vs %s" % (config_signature(r3)[1], meta.get("config_sha1")))
    print()

    # ------------------------------------------------------- review/compare
    print("  [5] review and compare arithmetic")
    rv = os.path.join(tmp, "selftest.review.csv")
    write_peaks(rv, r, review=True)
    _, _, rrows = read_peaks(rv)
    rej, add = 0, 3
    for d in rrows:
        if d["source"] == "AUTO" and rej < 5 and float(d["time_s"]) > 40:
            d["keep"] = "0"; rej += 1
    extra = [dict(time_s="%.4f" % (150.0 + k * 0.93), sample="", amp="", rhythm="",
                  cluster="-1", qc="0", source="MANUAL", keep="1", note="selftest")
             for k in range(add)]
    ed = os.path.join(tmp, "selftest.review.edited.csv")
    with open(ed, "w", newline="") as f:
        for line in open(rv):
            if line.startswith("#"):
                f.write(line)
        w = csv.DictWriter(f, fieldnames=PEAK_FIELDS)
        w.writeheader()
        for d in sorted(rrows + extra, key=lambda d: float(d["time_s"])):
            w.writerow({k: d.get(k, "") for k in PEAK_FIELDS})
    auto_s, _, _ = read_peaks(pf)
    man_s, _, _ = read_peaks(ed)
    matched, fp, fn = match_peaks(auto_s, man_s, PIG.match_tol_ms / 1000.0)
    chk("false positives equal the rejections", len(fp) == rej, "%d vs %d" % (len(fp), rej))
    chk("false negatives equal the additions", len(fn) == add, "%d vs %d" % (len(fn), add))
    chk("true positives account for the rest", len(matched) == len(auto_s) - rej,
        "%d vs %d" % (len(matched), len(auto_s) - rej))
    print()

    # ----------------------------------------------------------- the dropout
    print("  [6] dropout detection (the check that guards the reported rate)")
    ls, ps = _st_build(200.0, fs, base_ms, early_every=0, seed=4,
                       blackout=(80.0, 140.0), silent=True)
    sf = os.path.join(tmp, "selftest_silent.edf")
    _st_write_edf(sf, ls, fs, ["ECG1", "ECG2", "ECG3"])
    rs = analyse(sf, a, PIG)
    ig6 = rs.integrity
    # 80-140 s is set to literal 0.0, so ANY beat there was invented.  This is
    # checked separately from the flag because the two failures have different
    # causes and different fixes: phantoms are the detector, the flag is us.
    inside = int(np.sum((rs.anchors >= 80.0 * fs) & (rs.anchors <= 140.0 * fs)))
    chk("no beats are invented inside the flat segment", inside == 0,
        "%d found in 80-140 s where the signal is exactly 0.0" % inside)
    chk("finds the beats that do exist", abs(len(rs.anchors) - len(ps)) <= 3,
        "%d found vs %d true" % (len(rs.anchors), len(ps)))
    # The 60 s hole must be REPORTED.  It used to be reported by
    # DROPOUT_SUSPECTED, a coherence argument that infers a hole from the rate
    # sitting under the mode.  Now the hole is measured directly and excised,
    # which repairs the very incoherence that flag was reading -- so asserting
    # DROPOUT_SUSPECTED here would demand that the excision fail.
    #
    # What must not change is that a damaged file cannot pass quietly, so the
    # assertion is on the OUTCOME rather than on the mechanism: some
    # disqualifying flag is raised.  The mechanism is checked one line down,
    # and the coherence path is checked separately below with excision off.
    disq6 = [f for f in ig6["flags"] if not is_advisory(f)]
    chk("60 s of silence raises a disqualifying flag", bool(disq6),
        str(ig6["flags"]))
    chk("and it is the one that names the cause",
        "NO_SIGNAL_MAJOR" in ig6["flags"], str(ig6["flags"]))
    # Negative control for the chunk-edge test.  This hole ends at 140 s, which
    # is NOT on the 60 s grid, so a genuine dropout must NOT be blamed on the
    # chunking.  Without this check the edge test could flag everything and
    # still look like it worked.
    chk("a real dropout is NOT blamed on the chunk grid",
        "GAP_ENDS_ON_CHUNK_EDGE" not in ig6["flags"],
        "gap ends %.1f s from a chunk boundary" % ig6.get("gap_end_edge_s", float("nan")))
    print("       driving numbers: beats %d (pre-floor %d, floor removed %.1f%%)"
          % (len(rs.anchors), rs.n_pre_floor, 100.0 * rs.floor_removed))
    print("                        short%% %.1f | gaps %d | maxGap %.1fx | gapTime%% %.1f"
          % (ig6["short_pct"], ig6["n_gaps"], ig6["max_gap"], ig6["gap_time_pct"]))
    chk("the damaged file is not called trustworthy", not rs.integrity["trustworthy"])
    # The coherence flag is still the only guard for a dropout that is NOT
    # flat -- the detector losing a stretch to noise, where the signal is
    # present and the windowed range is normal.  Excision cannot see that case,
    # so DROPOUT_SUSPECTED has to keep working, and this pins it by re-running
    # the same file through the kill switch.  It doubles as the test that
    # --no-nosig genuinely restores the previous behaviour, which is what the
    # A/B on real data depends on.
    # Since empty-gap excision became the default, "the previous behaviour"
    # is --no-nosig AND --keep-empty: with only --no-nosig the beatless
    # stretch is excised as EMPTY instead, the rate is no longer diluted and
    # the coherence flag rightly has nothing to see (pinned just below).
    a_nonosig = argparse.Namespace(**vars(a))
    a_nonosig.nosig = False
    a_nonosig.keep_empty = True
    rs_off = analyse(sf, a_nonosig, PIG)
    a_nonosig_drop = argparse.Namespace(**vars(a_nonosig))
    a_nonosig_drop.keep_empty = False
    rs_off_drop = analyse(sf, a_nonosig_drop, PIG)
    chk("--no-nosig alone: the dropout is excised as EMPTY instead, not ignored",
        rs_off_drop.integrity.get("empty_applied_s", 0.0) > 10.0
        and abs(rs_off_drop.integrity["analysable_s"]
                - (rs_off_drop.dur - rs_off_drop.integrity["empty_s"])) < 1e-6
        and rs_off_drop.integrity["bpm"] > rs_off.integrity["bpm"],
        "empty %.1f s, analysable %.1f s, bpm %.2f (keep-empty %.2f)"
        % (rs_off_drop.integrity.get("empty_s", 0.0),
           rs_off_drop.integrity["analysable_s"],
           rs_off_drop.integrity["bpm"], rs_off.integrity["bpm"]))
    chk("with --no-nosig the old coherence flag still fires",
        "DROPOUT_SUSPECTED" in rs_off.integrity["flags"],
        str(rs_off.integrity["flags"]))
    chk("and the kill switch really excised nothing",
        rs_off.integrity.get("nosig_s", 0.0) == 0.0
        and abs(rs_off.integrity.get("analysable_s", 0.0) - rs_off.dur) < 1e-6,
        "nosig %.1f s, denominator %.1f s of %.1f s"
        % (rs_off.integrity.get("nosig_s", 0.0),
           rs_off.integrity.get("analysable_s", float("nan")), rs_off.dur))
    print()

    # --------------------------------------------------------- the gap refill
    print("  [7] artifact-anchored gap refill")
    # Tested as a UNIT, not through the pipeline.  The ratchet lives inside
    # neurokit, so whether a full-pipeline run reproduces it depends on which
    # neurokit is installed -- and under the stub it does not reproduce at all.
    # Handing refill_gaps a peak list with a hole in it tests the thing this
    # code is actually responsible for: does it put beats back where beats
    # exist, and does it stay silent where they do not.
    gl, gp = _st_build(200.0, fs, base_ms, early_every=0, seed=11)
    gdet = bp(gl[1], fs, PIG.band[0], PIG.band[1])
    gdet, _ = clip_artifacts(gdet, DEFAULTS["clip_k"])
    gthr = clip_level(bp(gl[1], fs, PIG.band[0], PIG.band[1]),
                      DEFAULTS["clip_k"])
    truth = enforce_refractory(gdet, np.asarray(gp, dtype=int), fs, PIG.refractory_ms)
    hole = (truth >= int(90 * fs)) & (truth < int(130 * fs))
    holed = truth[~hole]
    filled, added, rounds_used, spans = refill_gaps(
        gdet, holed, fs, PIG.refractory_ms, gthr)
    rec = len(filled) - len(holed)
    chk("refills a hole punched in the peak list",
        rec >= 0.80 * int(hole.sum()),
        "%d of %d recovered in %d round(s), %d span(s)"
        % (rec, int(hole.sum()), rounds_used, spans))
    m2, fp2, _ = match_peaks(np.sort(filled) / fs, np.sort(truth) / fs,
                             PIG.match_tol_ms / 1000.0)
    chk("the refilled beats land on real beats", len(fp2) <= 0.02 * len(truth),
        "%d matched, %d not on a true beat" % (len(m2), len(fp2)))
    # The kill switch: handed a complete list, it must add nothing at all.
    _, added_clean, _, _ = refill_gaps(gdet, truth, fs, PIG.refractory_ms, gthr)
    chk("adds NOTHING to an already complete peak list", added_clean == 0,
        "%d added" % added_clean)
    # And over real silence there is nothing to find, however clean the restart.
    sdet = bp(ls[1], fs, PIG.band[0], PIG.band[1])
    sdet, _ = clip_artifacts(sdet, DEFAULTS["clip_k"])
    sthr = clip_level(bp(ls[1], fs, PIG.band[0], PIG.band[1]),
                      DEFAULTS["clip_k"])
    _, added_sil, _, _ = refill_gaps(sdet, np.sort(rs.anchors), fs,
                                     PIG.refractory_ms, sthr)
    chk("invents no beats inside 60 s of true silence", added_sil == 0,
        "%d added over the 80-140 s blackout" % added_sil)
    print()

    # ----------------------------------------------------------- the display
    print("  [8] display scaling (an artifact must not flatten the beats)")
    # Regression test for a real failure: a part006 window holding 14 beats at
    # the file's modal RR rendered as a flat line, because min/max scaling let
    # the neighbouring artifact own the range.  The display is a deliverable in
    # its own right, and it went blind in exactly the windows worth inspecting.
    import contextlib as _ctx
    import io as _io
    dl, dp = _st_build(20.0, fs, base_ms, early_every=0, seed=21)
    dy = bp(dl[1], fs, PIG.band[0], PIG.band[1])
    dbase = float(np.median(dy))
    pk_i = np.asarray(dp, dtype=int)
    pk_i = pk_i[(pk_i >= 12) & (pk_i < len(dy) - 12)]
    # Snap to the bandpassed extremum: the builder's index is the truth for the
    # RAW lead, and filtering moves the apex a few samples.  beat_scale is given
    # detected peaks in real use, so give it well-located ones here too.
    pk_snap = np.array([i - 12 + int(np.argmax(np.abs(dy[i - 12:i + 12] - dbase)))
                        for i in pk_i], dtype=int)
    damp = float(np.median(np.abs(dy[pk_snap] - dbase)))
    dy_art = dy.copy()
    dy_art[int(3.0 * fs):int(3.2 * fs)] += 15.0 * damp   # 15x a QRS, 200 ms

    def _render(y, marks, scale):
        buf = _io.StringIO()
        with _ctx.redirect_stdout(buf):
            ascii_wave(y, 0.0, 20.0, marks_s=marks, yscale=scale)
        return [ln[4:] for ln in buf.getvalue().split("\n") if ln.startswith("   |")]

    def _zero_row(scale, height=13):
        """Baseline row, from the scale arithmetic rather than by counting '-'.

        Counting dashes is what the first version of this test did, and it was
        wrong in the one case that matters: on a silent trace every column of
        the baseline row is overwritten by a sample, leaving zero dashes, so
        the search picked row 0 and then reported all 100 samples as 'off the
        baseline' -- the exact opposite of the truth.
        """
        lo_, hi_ = float(scale[0]), float(scale[1])
        return int(round((hi_ - 0.0) / (hi_ - lo_) * (height - 1)))

    def _legible(rows, marks, scale, min_rows=2):
        """Beat columns plotting at least min_rows away from the baseline.

        'Not exactly on the baseline' is too weak a bar -- under min/max
        scaling a beat still lands one row off, which is not something a
        reader can see.  Require visible separation.  A one-column tolerance
        keeps this a test of SCALING rather than of bin arithmetic.
        """
        if not rows:
            return 0
        zr = _zero_row(scale)
        w = len(rows[0])
        n = 0
        for t in marks:
            c = int(t / 20.0 * w)
            far = 0
            for cc in (c - 1, c, c + 1):
                if not 0 <= cc < w:
                    continue
                hits = [abs(ri - zr) for ri, rr in enumerate(rows) if rr[cc] in "*#"]
                if hits:
                    far = max(far, max(hits))
            if far >= min_rows:
                n += 1
        return n

    marks = pk_snap / fs
    n_pk = len(marks)
    old_scale = (float(np.min(dy_art)), float(np.max(dy_art)))   # the old rule
    vis_old = _legible(_render(dy_art, marks, old_scale), marks, old_scale)
    new_scale = beat_scale(dy_art, pk_snap)
    rows_new = _render(dy_art, marks, new_scale)
    vis_new = _legible(rows_new, marks, new_scale)
    # Both directions are asserted.  Without the first check the second could
    # pass on a renderer that was never broken, and the fix would be unproven.
    chk("min/max scaling DOES hide beats beside an artifact",
        vis_old <= 0.20 * n_pk,
        "%d of %d beat columns legible" % (vis_old, n_pk))
    chk("beat-referenced scaling keeps those beats legible",
        vis_new >= 0.90 * n_pk,
        "%d of %d beat columns legible" % (vis_new, n_pk))
    n_hash = sum(rr.count("#") for rr in rows_new)
    chk("the artifact is still visible, as off-scale '#'", n_hash > 0,
        "%d off-scale column(s)" % n_hash)
    # The opposite failure mode: a silent stretch must not have its noise
    # stretched to full height merely because it is the only thing present.
    # This is what makes a dropout distinguishable from a crushed beat.
    nsil = int(20.0 * fs)
    sil = 0.001 * damp * np.sin(np.arange(nsil) * 0.01)
    rows_sil = _render(sil, marks[:0], new_scale)
    zr_s = _zero_row(new_scale)
    off = sum(1 for ri, rr in enumerate(rows_sil) if ri != zr_s
              for ch in rr if ch in "*#")
    chk("a silent stretch reads silent at the shared scale", off == 0,
        "%d glyph(s) off the baseline row" % off)

    # ---- the panel's own resolution, which used to go unstated.
    # 6 s over 100 columns is the DEFAULT, and it does not resolve a QRS.
    # That is the point: the tool's own default lands in the regime it now
    # has to declare, so a test that only exercised exotic arguments would
    # have missed the case every user hits first.
    pr_def = panel_resolution(6.0, 100, fs, PIG.qrs_width_ms)
    chk("the DEFAULT show panel is an envelope, and says so",
        pr_def["verdict"] == "envelope" and abs(pr_def["ms_per_col"] - 60.0) < 1e-9,
        "%.4g ms/col, %.3f col per QRS, verdict %s"
        % (pr_def["ms_per_col"], pr_def["cols_per_qrs"], pr_def["verdict"]))
    pr_bad = panel_resolution(10.0, 100, fs, PIG.qrs_width_ms)
    chk("the 10 s panel that produced the unreadable window is an envelope",
        pr_bad["verdict"] == "envelope" and pr_bad["cols_per_qrs"] < 0.2,
        "%.4g ms/col, %.3f col per QRS, %.0f samples per column"
        % (pr_bad["ms_per_col"], pr_bad["cols_per_qrs"], pr_bad["samp_per_col"]))
    # The recommendation must be self-consistent: feed it back and the verdict
    # has to change.  An advisory that does not survive being taken is worse
    # than none, because it is acted on.
    pr_fix = panel_resolution(pr_bad["seconds_for_morphology"], 100, fs,
                              PIG.qrs_width_ms)
    chk("--seconds it recommends does reach 'morphology'",
        pr_fix["verdict"] == "morphology",
        "%.4g s -> %.2f col per QRS, verdict %s"
        % (pr_bad["seconds_for_morphology"], pr_fix["cols_per_qrs"],
           pr_fix["verdict"]))
    pr_wide = panel_resolution(10.0, pr_bad["width_for_peaks"], fs,
                               PIG.qrs_width_ms)
    chk("--width it recommends does reach at least 'peaks'",
        pr_wide["verdict"] in ("peaks", "morphology"),
        "width %d -> %.2f col per QRS, verdict %s"
        % (pr_bad["width_for_peaks"], pr_wide["cols_per_qrs"],
           pr_wide["verdict"]))

    # ---- the envelope renderer, against the point renderer it replaced.
    #
    # Construct the situation that produced the unreadable panel: a noisy
    # stretch decimated hard, with real beats in it.  Ground truth is known
    # by construction -- 20 beats at 1 Hz, noise at 0.15x beat height, 20 s
    # drawn in 100 columns so each column holds 100 samples -- so both
    # renderers can be scored on the same picture.
    #
    # Locals are prefixed because this selftest is one very long function and
    # a bare `A`, `half` or `rng` here would quietly outlive the block.
    _ev_rng = np.random.RandomState(7)
    _ev_n = int(20.0 * fs)
    _ev_amp = 1.0
    _ev_y = 0.15 * _ev_amp * _ev_rng.standard_normal(_ev_n)
    _ev_beats = np.arange(0.5, 20.0, 1.0)
    _ev_half = max(1, int(round(0.5 * PIG.qrs_width_ms / 1000.0 * fs)))
    for _bt in _ev_beats:
        _i = int(_bt * fs)
        _ev_y[max(0, _i - _ev_half):_i + _ev_half + 1] += _ev_amp
    _ev_scale = (-1.4 * _ev_amp, 1.4 * _ev_amp)
    _ev_rows = _render(_ev_y, _ev_beats, _ev_scale)   # 200 ms per column
    _ev_zr = _zero_row(_ev_scale)

    def _ev_bar(c):
        """Rows of column c carrying any bar glyph, top first."""
        return [ri for ri, rr in enumerate(_ev_rows) if rr[c] in "*:#"]

    # (1) Every drawn column is a CONNECTED bar.  This is what turns snow
    #     into a band: the eye can follow a top edge because there is one.
    _ev_holes = sum(1 for c in range(len(_ev_rows[0]))
                    if _ev_bar(c)
                    and (_ev_bar(c)[-1] - _ev_bar(c)[0] + 1) != len(_ev_bar(c)))
    chk("every envelope column is one connected bar", _ev_holes == 0,
        "%d column(s) with a hole" % _ev_holes)

    # (2) Every column's bar CROSSES the baseline, because 100 samples of
    #     noise have a maximum above it and a minimum below it.  The point
    #     renderer could not do that -- it drew one side per column, chosen
    #     by whichever excursion was larger, and that coin flip is exactly
    #     what made the panel look like scatter.  Both directions are
    #     asserted so the fix is proven against the thing it fixed rather
    #     than merely passing.
    def _ev_pt_row(v):
        _lo, _hi = _ev_scale
        return int(round((_hi - v) / (_hi - _lo) * 12))

    _ev_pt_side, _ev_span = 0, 0
    _ev_base = float(np.nanmedian(_ev_y))
    for c, ci in enumerate(np.array_split(np.arange(_ev_n), 100)):
        seg = _ev_y[ci]
        # The old rule, reproduced here rather than imported, so this test
        # goes on recording what it was after the code is gone.
        v = float(seg[int(np.nanargmax(np.abs(seg - _ev_base)))])
        if _ev_pt_row(v) != _ev_zr:
            _ev_pt_side += 1
        g = _ev_bar(c)
        if g and g[0] <= _ev_zr <= g[-1]:
            _ev_span += 1
    chk("the point renderer DID draw noise columns off the baseline",
        _ev_pt_side >= 90,
        "%d of 100 columns drawn on one side only" % _ev_pt_side)
    chk("every envelope column spans the baseline instead",
        _ev_span == 100, "%d of 100 columns cross the baseline" % _ev_span)

    # (3) The beat still stands clear of the noise band, so the one
    #     comparison this panel exists to support survives the change.
    _ev_bcols = {int(_bt / 20.0 * 100) for _bt in _ev_beats}
    _ev_top_beat = min(_ev_bar(c)[0] for c in sorted(_ev_bcols) if _ev_bar(c))
    _ev_top_noise = min((_ev_bar(c) or [_ev_zr])[0]
                        for c in range(100) if c not in _ev_bcols)
    chk("beats still stand above the noise band",
        _ev_top_beat <= _ev_top_noise - 2,
        "beat top row %d vs noise top row %d"
        % (_ev_top_beat, _ev_top_noise))
    print()

    # ------------------------------------------------ span measurement
    print("  [9] windowed-range span measurement (Phase 1 primitives)")
    # Ground truth: `ls` has 80-140 s set to literal 0.0.  This validates the
    # MEASUREMENT before any threshold is derived from it.  If the machinery
    # cannot find a hole whose location is known by construction, nothing it
    # reports about a real file is worth reading.
    a_sil = median_qrs_amp(rs.wide, rs.anchors, fs, PIG)
    chk("a QRS scale is established on the silent file", np.isfinite(a_sil),
        "A = %.5g" % a_sil)
    srng, st = windowed_range(rs.wide, fs, 2.0, 0.25)
    ssp = spans_from_mask(srng / a_sil < 0.15, st, 0.25, 2.0)
    stot = sum(b - a for a, b in ssp)
    chk("finds the 60 s blackout as a single span", len(ssp) == 1,
        "%d span(s), %.1f s total" % (len(ssp), stot))
    # A 2 s CENTRED window is wholly inside a 60 s hole only from 81 to 139 s,
    # so 58 s is the right answer here, not 60.  The tolerance covers that
    # geometry rather than hiding it.
    chk("its duration matches the hole to within a window",
        abs(stot - 58.0) <= 4.0, "%.1f s (expect ~58 for a 2 s window)" % stot)
    chk("its location matches the hole", bool(ssp) and abs(ssp[0][0] - 80.0) <= 3.0,
        "starts %.1f s vs 80.0" % (ssp[0][0] if ssp else float("nan")))
    # Negative control.  Without it, a detector that flags EVERYTHING passes
    # all three checks above and looks perfect.
    rc_clean = analyse(good, a, PIG)
    a_cln = median_qrs_amp(rc_clean.wide, rc_clean.anchors, fs, PIG)
    crng, ct = windowed_range(rc_clean.wide, fs, 2.0, 0.25)
    csp = spans_from_mask(crng / a_cln < 0.15, ct, 0.25, 2.0)
    chk("a clean record yields NO flat span", len(csp) == 0,
        "%d span(s), %.1f s" % (len(csp), sum(b - a for a, b in csp)))
    # The two populations must be SEPARATED, not merely ordered -- a cut is
    # only safe if moving it does not move the answer.  Same hole, cuts from
    # 0.05 to 0.30, must agree to within a window.
    widths = [sum(b - a for a, b in
                  spans_from_mask(srng / a_sil < c, st, 0.25, 2.0))
              for c in (0.05, 0.10, 0.15, 0.20, 0.30)]
    chk("the answer is insensitive to the cut (the modes are separated)",
        max(widths) - min(widths) <= 4.0,
        "%.1f to %.1f s across cuts 0.05-0.30" % (min(widths), max(widths)))
    print()

    # ---------------------------------------------------------------- guards
    print("  [10] guards")
    try:
        read_ponemah("x.pnm"); pon = False
    except NotImplementedError:
        pon = True
    chk("Ponemah refuses rather than guessing", pon)
    print()

    # -------------------------------------------- excision (Phase 2, wired in)
    print("  [11] no-signal excision (the numerator/denominator invariant)")
    # THE test for this mechanism.  Excision touches the rate from both sides,
    # and the two failure modes are silent and opposite: drop the duration but
    # keep the beats and the rate reads high, drop the beats but keep the
    # duration and it reads low.  Neither raises.  Neither looks wrong.  The
    # only defence is a record whose correct rate is known before it is
    # measured, so that is what this is -- `ls` beats every 960 ms, i.e.
    # exactly 62.50 bpm, with 80-140 s set to literal 0.0.
    true_bpm = 60000.0 / base_ms
    ig11 = rs.integrity
    chk("the hole is excised from the denominator",
        abs(ig11.get("nosig_s", 0.0) - 58.0) <= 4.0,
        "%.1f s excised of a 60 s hole" % ig11.get("nosig_s", 0.0))
    # The residual is not an error to be tuned away, it is the window geometry:
    # a span is a run of window CENTRES, so it understates the true hole by
    # half a window at each end.  Pinned here because it is the quantity that
    # sets how far the rate can be off, and a future change to the windowing
    # would otherwise move it silently.
    residual = 60.0 - ig11.get("nosig_s", 0.0)
    chk("the residual is bounded by one window, and is the SAFE sign",
        0.0 <= residual <= 2.0 + 1e-6,
        "%.2f s of dead time left in the denominator (biases the rate LOW)"
        % residual)
    chk("beats and duration were removed TOGETHER",
        abs(ig11["bpm"] - true_bpm) <= 2.0,
        "%.2f bpm vs %.2f true; off by %.2f%%"
        % (ig11["bpm"], true_bpm, 100.0 * (ig11["bpm"] - true_bpm) / true_bpm))
    # The direction of any residual error must be DOWN, per the comment on
    # analysable_s.  A rate above truth would mean live time was excised.
    chk("and any residual error is downward, never upward",
        ig11["bpm"] <= true_bpm + 1e-6,
        "%.2f vs %.2f" % (ig11["bpm"], true_bpm))
    # Before this change the excision would have left a 60 s interval bridging
    # the hole, and maxGap would have read ~60x on a file whose dead time had
    # just been accounted for.  This is the check that rr_bridges_span works.
    chk("the excised hole is not ALSO reported as a gap",
        ig11["max_gap"] < 2.0,
        "maxGap %.1fx, %d gap(s), %d bridging interval(s) excluded"
        % (ig11["max_gap"], ig11["n_gaps"], ig11.get("n_bridging", 0)))
    # Negative control, and the one that protects all 18 clean files: a record
    # with no dead time must come through completely untouched.  Without this,
    # a bug that excised a little of everything would still pass every check
    # above, and would quietly inflate every rate in the fleet report.
    ig11c = rc_clean.integrity
    chk("a clean record is not touched at all",
        ig11c.get("nosig_s", 0.0) == 0.0
        and ig11c.get("nosig_dropped", 0) == 0
        and abs(ig11c.get("analysable_s", 0.0) - rc_clean.dur) < 1e-6,
        "%.1f s excised, %d beat(s) dropped, denominator %.1f s of %.1f s"
        % (ig11c.get("nosig_s", 0.0), ig11c.get("nosig_dropped", 0),
           ig11c.get("analysable_s", float("nan")), rc_clean.dur))
    chk("and carries no NO_SIGNAL flag",
        not [f for f in ig11c["flags"] if f.startswith("NO_SIGNAL")],
        str(ig11c["flags"]))
    # The two tiers.  30% of this record is dead, so it must be the
    # disqualifying one; the advisory tier is exercised on real data, where
    # part010's 16 s of 3600 is 0.44%.
    chk("a 30% hole is MAJOR, not advisory",
        "NO_SIGNAL_MAJOR" in ig11["flags"] and "NO_SIGNAL" not in ig11["flags"],
        "%.1f%% of the record dead -> %s"
        % (100.0 * ig11.get("nosig_s", 0.0) / rs.dur, ig11["flags"]))

    # ---- the refill fence, tested as a MECHANISM rather than on data.
    # [7] already shows the refill finds nothing in true silence, but it finds
    # nothing there for the honest reason that nothing is there, which cannot
    # distinguish a working fence from an absent one.  So fence off a region
    # that demonstrably DOES refill and require the refill to decline.
    gl11, gp11 = _st_build(200.0, fs, base_ms, early_every=0, seed=11)
    gdet11 = bp(gl11[1], fs, PIG.band[0], PIG.band[1])
    gdet11, _ = clip_artifacts(gdet11, DEFAULTS["clip_k"])
    gthr11 = clip_level(bp(gl11[1], fs, PIG.band[0], PIG.band[1]),
                        DEFAULTS["clip_k"])
    truth11 = enforce_refractory(gdet11, np.asarray(gp11, dtype=int), fs,
                                 PIG.refractory_ms)
    hole11 = (truth11 >= int(90 * fs)) & (truth11 < int(130 * fs))
    holed11 = truth11[~hole11]
    _, add_open, _, _ = refill_gaps(gdet11, holed11, fs, PIG.refractory_ms,
                                    gthr11)
    _, add_fenced, _, _ = refill_gaps(gdet11, holed11, fs, PIG.refractory_ms,
                                      gthr11, skip_spans=[(90.0, 130.0)])
    chk("the same hole refills when it is NOT fenced", add_open > 0,
        "%d beat(s) recovered" % add_open)
    chk("and refills NOTHING when it is", add_fenced == 0,
        "%d beat(s) placed inside a declared no-signal span" % add_fenced)

    # ---- span predicates, at the boundaries, where interval code fails.
    _sp = [(10.0, 20.0)]
    _probe = np.array([9.9, 10.0, 15.0, 19.9, 20.0, 20.1]) * fs
    _got = in_any_span(_probe.astype(int), _sp, fs)
    chk("in_any_span is half-open [start, end)",
        list(_got) == [False, True, True, True, False, False],
        "9.9/10.0/15.0/19.9/20.0/20.1 s -> %s" % list(map(bool, _got)))
    # Overlap, not containment: an interval from 5 s to 25 s contains the span
    # rather than sitting inside it, and it still has to be excluded.
    _anch = (np.array([5.0, 25.0, 26.0]) * fs).astype(int)
    _br = rr_bridges_span(_anch, fs, _sp)
    chk("rr_bridges_span catches an interval that STRADDLES a span",
        list(_br) == [True, False], "%s" % list(map(bool, _br)))
    print()

    # ------------------------------------------------- absolute time / trend
    print("  [12] wall-clock placement and N-minute binning")
    # Placement first.  Both witnesses are parsed independently, so each failure
    # mode gets its own check -- a single "does it find a time" test would pass
    # with one witness silently broken.
    chk("EDF header start parses",
        _parse_edf_start("06.08.23", "19.59.59")
        == datetime.datetime(2023, 8, 6, 19, 59, 59),
        str(_parse_edf_start("06.08.23", "19.59.59")))
    # The EDF two-digit year rule, both sides of the 84/85 hinge.
    chk("the EDF year rule is applied on both sides of the hinge",
        _parse_edf_start("01.02.84", "00.00.00").year == 2084
        and _parse_edf_start("01.02.85", "12.00.00").year == 1985,
        "84 -> %d, 85 -> %d" % (_parse_edf_start("01.02.84", "00.00.00").year,
                                _parse_edf_start("01.02.85", "12.00.00").year))
    # The placeholder must be REFUSED.  A 1985 date sorts and bins perfectly
    # happily, so believing it would produce a clean-looking trend 38 years off.
    chk("the 01.01.85 'not set' placeholder is refused",
        _parse_edf_start("01.01.85", "00.00.00") is None)
    chk("the filename timestamp parses",
        _parse_name_start("P10_seg01_part001_20230806_195959.edf")
        == datetime.datetime(2023, 8, 6, 19, 59, 59),
        str(_parse_name_start("P10_seg01_part001_20230806_195959.edf")))
    chk("a file with no timestamp anywhere is refused, not defaulted",
        record_start("/tmp/no_time_here.txt")[0] is None)

    # Reconciliation of the TWO witnesses, against real files on disk, because
    # the parsers above are only half the story: record_start() decides whether
    # a placement is confirmed, single-sourced, or disputed, and that decision
    # was previously untested.  It went wrong in exactly the way an untested
    # branch does -- the synthetic writer stamped a real-looking 01.01.23, every
    # run printed two "DISAGREES" warnings, and nobody read them.  Going through
    # a written file also round-trips header bytes 168-184 through MiniEDF
    # rather than testing the string parser against itself.
    _rsdir = os.path.join(tmp, "rs")
    os.makedirs(_rsdir, exist_ok=True)
    _rs_sig, _ = _st_build(4.0, fs, base_ms, seed=7)
    _true = datetime.datetime(2023, 8, 6, 19, 59, 59)

    # (a) both witnesses, agreeing.  This is the normal case for the real set.
    _agree = os.path.join(_rsdir, "P10_seg01_part001_20230806_195959.edf")
    _st_write_edf(_agree, _rs_sig, fs, ["ECG1", "ECG2", "ECG3"], start=_true)
    _dt, _src, _note = record_start(_agree)
    chk("agreeing header and filename place the file and say so",
        _dt == _true and _src == "header+name" and not _note,
        "%s via %s %s" % (_dt, _src, _note))

    # (b) both witnesses, disagreeing by an hour.  The rule is to prefer the
    # filename and REPORT the conflict -- not to silently average, pick the
    # earlier, or drop the file.  An hour is the dangerous size: it is a
    # plausible timezone error, so the wrong answer looks entirely normal.
    _dis = os.path.join(_rsdir, "P10_seg01_part002_20230806_195959.edf")
    _st_write_edf(_dis, _rs_sig, fs, ["ECG1", "ECG2", "ECG3"],
                  start=_true + datetime.timedelta(hours=1))
    _dt, _src, _note = record_start(_dis)
    chk("a header/filename conflict is surfaced, not silently resolved",
        _dt == _true and "DISAGREES" in _src and "3600 s apart" in _note,
        "%s via %s (%s)" % (_dt, _src, _note))

    # (c) placeholder header, good filename: one witness, used but labelled.
    _ph = os.path.join(_rsdir, "P10_seg01_part003_20230806_195959.edf")
    _st_write_edf(_ph, _rs_sig, fs, ["ECG1", "ECG2", "ECG3"])
    _dt, _src, _note = record_start(_ph)
    chk("a placeholder header falls back to the filename without complaint",
        _dt == _true and _src == "filename only" and not _note,
        "%s via %s %s" % (_dt, _src, _note))

    # (d) placeholder header, no filename timestamp: genuinely unplaceable.
    # This is the case the synthetic writer used to defeat, which let `trend`
    # place an untimestamped file at an arbitrary epoch.
    _no = os.path.join(_rsdir, "untimestamped.edf")
    _st_write_edf(_no, _rs_sig, fs, ["ECG1", "ECG2", "ECG3"])
    chk("an EDF with neither witness is unplaceable, not epoch-defaulted",
        record_start(_no)[0] is None, "%s" % (record_start(_no),))

    # Binning.  Build three one-hour records at 60 bpm exactly, wall-clocked
    # at 01:00, 02:00 and 04:00 -- so 03:00-04:00 is MISSING, the same shape as
    # the real set with part009 held out.
    tb = {}
    bin_m = 10.0
    tb_bin = bin_m * 60.0
    for hh in (1, 2, 4):
        e0 = to_epoch(datetime.datetime(2023, 8, 6, hh, 0, 0))
        beats = e0 + np.arange(3600, dtype=float)      # one beat per second
        bin_record(tb, e0, 3600.0, beats, [], tb_bin)
    trows = bins_to_rows(tb, tb_bin, 0.5)
    # 4 hours of wall clock at 10 min = 24 bins; 3 hours carry data (18) and
    # the missing hour is 6.  These numbers were wrong on the first pass -- the
    # test was, not the binning -- which is the argument for stating the
    # arithmetic in the check rather than just the totals.
    chk("bins span the whole interval INCLUDING the missing hour",
        len(trows) == 24, "%d bins over 01:00-05:00 at %g min (4 h / %g min = 24)"
        % (len(trows), bin_m, bin_m))
    filled = [r for r in trows if not r["empty"]]
    empty = [r for r in trows if r["empty"]]
    chk("the missing hour is present as empty bins, not closed up",
        len(empty) == 6 and len(filled) == 18,
        "%d empty (expect 6 = one hour), %d filled (expect 18 = three hours)"
        % (len(empty), len(filled)))
    chk("every filled bin reads the constructed rate",
        all(abs(r["bpm"] - 60.0) < 1e-6 for r in filled),
        "min %.4f max %.4f bpm" % (min(r["bpm"] for r in filled),
                                   max(r["bpm"] for r in filled)))
    chk("an empty bin has no rate rather than a zero",
        all(not np.isfinite(r["bpm"]) for r in empty))
    # Bins must be aligned to the WALL CLOCK, not to the first file.  With a
    # record starting exactly on the hour both conventions agree, so this is
    # checked with one that does not.
    tb2 = {}
    e0 = to_epoch(datetime.datetime(2023, 8, 6, 1, 7, 30))
    bin_record(tb2, e0, 600.0, e0 + np.arange(600, dtype=float), [], tb_bin)
    r2 = bins_to_rows(tb2, tb_bin, 0.5)
    chk("bins align to the clock, not to the file start",
        from_epoch(r2[0]["t0"]).strftime("%H:%M") == "01:00",
        "file starts 01:07:30, first bin starts %s"
        % from_epoch(r2[0]["t0"]).strftime("%H:%M"))
    # And the invariant again, one level down: excised time must leave the bin
    # denominator too, or the trend and the report would disagree about the
    # same seconds.
    tb3 = {}
    e3 = to_epoch(datetime.datetime(2023, 8, 6, 1, 0, 0))
    # 600 s bin, 300 s of it dead, beats only in the live half at 60 bpm.
    bin_record(tb3, e3, 600.0, e3 + np.arange(300, dtype=float),
               [(e3 + 300.0, e3 + 600.0)], tb_bin)
    r3 = bins_to_rows(tb3, tb_bin, 0.4)[0]
    chk("a half-dead bin reports the LIVE rate, not a halved one",
        abs(r3["bpm"] - 60.0) < 1e-6 and abs(r3["cov"] - 0.5) < 1e-6,
        "%.2f bpm at %.0f%% coverage (a shared denominator would read 30)"
        % (r3["bpm"], 100.0 * r3["cov"]))
    print()

    # ------------------------------------------- amplitude-floor banding
    print("  [13] the amplitude floor reports a value, not a coin-flip")

    def _floor_flag(frac):
        """The flag analyse() would append for this floor fraction, or None."""
        if not (frac > AMP_FLOOR_NOTE_FRAC):
            return None
        pct = 100.0 * frac
        return ("AMP_FLOOR_MAJOR_%.2f%%" % pct if frac > AMP_FLOOR_MAJOR_FRAC
                else "AMP_FLOOR_%.2f%%" % pct)

    def _verdict(frac):
        f = _floor_flag(frac)
        return "clean" if f is None else ("advisory" if is_advisory(f)
                                          else "disqualifying")

    # THE regression.  0.0131 and 0.0099 are not hypotheticals: they are
    # part010's floor fraction before and after no-signal excision.  Under the
    # old `> 1%` cliff they landed on opposite sides and the file's
    # trustworthiness flipped on a 0.32pp move -- a change a denominator edit
    # can produce on its own.  Whatever the bands are set to, these two must
    # agree with each other.
    chk("part010's before/after floor values get the SAME verdict",
        _verdict(0.0131) == _verdict(0.0099),
        "1.31%% -> %s, 0.99%% -> %s" % (_verdict(0.0131), _verdict(0.0099)))
    # ...and specifically they are reported rather than suppressed.  Agreeing
    # by both being silent would pass the check above while hiding the finding.
    chk("both are REPORTED, not silently dropped",
        _floor_flag(0.0131) is not None and _floor_flag(0.0099) is not None,
        "%s / %s" % (_floor_flag(0.0131), _floor_flag(0.0099)))
    # The label must distinguish what the decision distinguishes.  The old
    # %.0f%% printed "AMP_FLOOR_1%" for 1.01 and 1.49 alike.
    chk("the label distinguishes values the old one could not",
        _floor_flag(0.0101) != _floor_flag(0.0149),
        "%s vs %s" % (_floor_flag(0.0101), _floor_flag(0.0149)))
    # A clean record still says nothing at all.
    chk("a clean record raises no floor flag",
        _floor_flag(0.0) is None and _floor_flag(0.001) is None,
        "0%% -> %s, 0.1%% -> %s" % (_floor_flag(0.0), _floor_flag(0.001)))
    # And the top of the range still disqualifies, or the band would have
    # replaced a too-sharp rule with no rule.
    chk("a floor above the major cut still disqualifies",
        _verdict(0.12) == "disqualifying", "12%% -> %s" % _verdict(0.12))
    # is_advisory() must not be fooled by the shared prefix -- this is the one
    # way the predicate can fail silently, by waving through a MAJOR flag.
    chk("is_advisory is not fooled by the AMP_FLOOR_MAJOR prefix",
        is_advisory("AMP_FLOOR_0.99%") and not is_advisory("AMP_FLOOR_MAJOR_12.00%"))
    print()

    # ------------------------------------------- WAV reader and format probe
    print("  [14] RIFF/WAVE reader and the unknown-format probe")
    # The fixture is written by the STDLIB wave module, not by anything in this
    # file.  That matters more than it looks: every other reader check here
    # round-trips through _st_write_edf, so a shared wrong assumption between
    # my reader and my writer would cancel out and pass.  An independent writer
    # cannot collude.  This is the gap flagged against MiniEDF, closed for WAV.
    import wave as _wavemod
    _wpath = os.path.join(tmp, "probe_fixture.wav")
    _wfs, _wch = 500, 3
    _wsig, _wpk = _st_build(120.0, float(_wfs), base_ms, seed=11)
    _wi = np.empty((len(_wsig[0]), _wch), dtype="<i2")
    for _c in range(_wch):
        _wi[:, _c] = np.clip(_wsig[_c] / 5.0 * 32767.0, -32768, 32767).astype("<i2")
    with _wavemod.open(_wpath, "wb") as _w:
        _w.setnchannels(_wch)
        _w.setsampwidth(2)
        _w.setframerate(_wfs)
        _w.writeframes(_wi.tobytes())

    _wc, _wrfs, _wlab, _wdur = read_wav(_wpath)
    chk("reads back a stdlib-written WAV's rate and channel count",
        _wrfs == float(_wfs) and _wc.shape[1] == _wch,
        "%g Hz, %d ch, labels %s" % (_wrfs, _wc.shape[1], _wlab))
    chk("reads back the WAV's duration",
        abs(_wdur - len(_wsig[0]) / float(_wfs)) < 1e-6,
        "%.4f s vs %.4f s" % (_wdur, len(_wsig[0]) / float(_wfs)))
    # Sample fidelity, against the integers that were actually written -- so
    # this tests the [-1,1) normalisation and the interleave, not the ADC.
    _werr = np.abs(_wc - _wi.astype(np.float64) / 32768.0).max()
    chk("WAV samples round-trip to within one LSB",
        _werr <= 1.0 / 32768.0 + 1e-12, "max abs error %.3e" % _werr)
    # Channel ORDER must survive.  Getting the interleave transposed still
    # produces three plausible ECG traces, just attributed to the wrong leads.
    _wcorr = [float(np.corrcoef(_wc[:, c], _wi[:, c].astype(float))[0, 1])
              for c in range(_wch)]
    chk("channels come back in the order they were written",
        all(v > 0.999 for v in _wcorr),
        "per-channel r = %s" % ", ".join("%.4f" % v for v in _wcorr))

    # The probe, against a buffer whose layout is known by construction.
    _raw = _wi.tobytes()
    _cands = probe_layouts(_raw, max_samples=40000)
    _top = _cands[0]
    # Two separate claims, tested separately, because they have different
    # strengths of evidence behind them.
    #
    # The dtype is genuinely identifiable: reading these bytes as anything
    # other than <i2 destroys the sample-to-sample correlation.
    chk("the probe identifies the TRUE sample format",
        _top["dtype"] == "<i2",
        "picked %s (r=%.3f); runner-up %s (r=%.3f)"
        % (_top["dtype"], _top["score"], _cands[1]["dtype"], _cands[1]["score"]))
    # The offset is NOT identifiable in a headerless buffer -- every multiple of
    # the item size is an equally good start, and this fixture really does score
    # marginally higher at 4096 than at 0 by luck.  So what is asserted is the
    # tie-break: among candidates the data cannot separate, report the earliest.
    # Reporting 4096 would send a reader author looking for a 4096-byte header
    # that is not there.
    chk("among indistinguishable offsets the probe reports the earliest",
        _top["offset"] == 0,
        "picked offset %d; scores at 0 and 4096 differ by less than the %.2f"
        " tie tolerance" % (_top["offset"], PROBE_TIE))
    # The interleave count is read off the lag at which correlation peaks.
    chk("the probe infers the channel count from the correlation peak",
        _top["nch_hint"] == _wch,
        "inferred %d channel(s), truth %d; lags 1-4 = %s"
        % (_top["nch_hint"], _wch,
           ", ".join("%.3f" % v for v in _top["acs"][:4])))
    # And the confirmatory test: a real rate, recovered from bytes alone.
    _ch0 = np.frombuffer(_raw, dtype="<i2").astype(np.float64)[0::_wch]
    _bpm, _rac, _chance = probe_rate(_ch0 - _ch0.mean(), float(_wfs))
    _true_bpm = 60000.0 / base_ms
    _ratio = _rac / _chance if _chance > 0 else 0.0
    chk("the probe recovers the constructed heart rate from raw bytes",
        abs(_bpm - _true_bpm) < 2.0,
        "%.2f bpm (truth %.2f)" % (_bpm, _true_bpm))
    # Judged against chance, not against a fixed number.  A bare "r > 0.3" cut
    # was tried and rejected a correct 0.211 that stood 12x above chance.
    chk("and reports that rate as far above chance",
        _ratio >= 5.0,
        "r=%.3f vs chance %.4f = %.0fx" % (_rac, _chance, _ratio))

    # NEGATIVE CONTROL.  Without this the probe is unfalsifiable: a scorer that
    # returns "looks like a signal" for everything would pass every check above.
    _noise = np.random.default_rng(3).integers(-32768, 32767,
                                               size=200000).astype("<i2").tobytes()
    _ncands = probe_layouts(_noise, max_samples=40000)
    chk("the probe does NOT claim a waveform in random bytes",
        _ncands[0]["score"] < PROBE_WAVEFORM_CUT,
        "best score on noise = %.3f via %s (cut is %.2f; the real fixture "
        "scored %.3f)" % (_ncands[0]["score"], _ncands[0]["dtype"],
                          PROBE_WAVEFORM_CUT, _top["score"]))
    # And the separation itself is the thing that makes the cut meaningful, so
    # assert it rather than leaving it implicit in two independent numbers.
    chk("signal outscores noise by a wide margin",
        _top["score"] > 4.0 * max(_ncands[0]["score"], 1e-6),
        "signal %.3f vs noise %.3f = %.1fx"
        % (_top["score"], _ncands[0]["score"],
           _top["score"] / max(_ncands[0]["score"], 1e-6)))
    print()

    # ------------------------------------------------ ASCII export reader
    print("  [15] Ponemah ASCII export")
    # The header below is copied VERBATIM from a real export (animal P21,
    # 3/22/2024), including the quirk that its label row calls temperature and
    # activity "Input" while the `# Col` block names them properly.  Synthetic
    # headers test what I imagined the format to be; this one tests the format.
    _ax_hdr = (
        "# File created Monday, January 27, 2025 13:08:47 (UTC 0300)\n"
        "# User Name: jchen437\n"
        "# Time of first sample:  3/22/2024 12:00:00.000 AM\n"
        "# Time of last sample:   3/22/2024 12:00:00.100 AM\n"
        "# Col 2:1265277 - P21, ECG, ECG, mV, Sample Rate: 500.00\n"
        "# Col 3:1265277 - P21, ECG, ECG, mV, Sample Rate: 500.00\n"
        "# Col 4:1265277 - P21, ECG, ECG, mV, Sample Rate: 500.00\n"
        "# Col 5:1265277 - P21, Temperat, TEMP, Celsius, Sample Rate: 10.00\n"
        "# Col 6:1265277 - P21, Activity, ACT, Counts, Sample Rate: 1.00\n"
        "\n"
        "Time    ,1265277 - P21:ECG,1265277 - P21:ECG,1265277 - P21:ECG,"
        "1265277 - P21:Input,1265277 - P21:Input\n")
    # 51 real rows spanning one QRS complex, so the amplitudes below are the
    # animal's and not something this file invented.
    _ax_rows = [
        (-0.0115, -0.0067, -0.0119), (-0.0115, -0.0102, -0.0141),
        (-0.0111, -0.0106, -0.0158), (-0.0093, -0.0080, -0.0154),
        (-0.0085, -0.0072, -0.0141), (-0.0098, -0.0089, -0.0137),
        (-0.0115, -0.0132, -0.0150), (-0.0158, -0.0163, -0.0154),
        (-0.0193, -0.0132, -0.0137), (-0.0184, -0.0106, -0.0128),
        (-0.0163, -0.0124, -0.0119), (-0.0145, -0.0132, -0.0111),
        (-0.0115, -0.0111, -0.0124), (-0.0128, -0.0124, -0.0158),
        (-0.0171, -0.0132, -0.0167), (-0.0176, -0.0111, -0.0150),
        (-0.0137, -0.0119, -0.0145), (-0.0115, -0.0141, -0.0158),
        (-0.0111, -0.0106, -0.0171), (-0.0085, -0.0063, -0.0163),
        (-0.0080, -0.0076, -0.0145), (-0.0111, -0.0102, -0.0137),
        (-0.0119, -0.0098, -0.0150), (-0.0080, -0.0111, -0.0158),
        (-0.0054, -0.0124, -0.0158), (-0.0080, -0.0076, -0.0158),
        (-0.0111, -0.0050, -0.0150), (-0.0119, -0.0085, -0.0132),
        (-0.0111, -0.0119, -0.0132), (-0.0076, -0.0102, -0.0145),
        (-0.0059, -0.0063, -0.0141), (-0.0106, -0.0033, -0.0119),
        (-0.0150, 0.0011, -0.0085), (-0.0119, 0.0124, -0.0006),
        (-0.0041, 0.0289, 0.0119), (0.0028, 0.0445, 0.0254),
        (0.0063, 0.0579, 0.0362), (0.0046, 0.0527, 0.0315),
        (-0.0098, -0.0050, -0.0119), (-0.0336, -0.0983, -0.0835),
        (-0.0484, -0.1582, -0.1317), (-0.0514, -0.1656, -0.1369),
        (-0.0506, -0.1448, -0.1100), (-0.0345, -0.0631, -0.0354),
        (0.0002, 0.0857, 0.0801), (0.0263, 0.1973, 0.1630),
        (0.0349, 0.2242, 0.1825), (0.0410, 0.2289, 0.1829),
        (0.0445, 0.2307, 0.1790), (0.0349, 0.1925, 0.1495),
        (0.0193, 0.1287, 0.1035),
    ]

    def _ax_write(path, rows, hdr=_ax_hdr, t0=None, step_ms=2.0):
        """Write an export with the real header shape and given rows."""
        t0 = t0 or datetime.datetime(2024, 3, 22, 0, 0, 0)
        with open(path, "w") as f:
            f.write(hdr)
            for i, r in enumerate(rows):
                t = t0 + datetime.timedelta(milliseconds=step_ms * i)
                # The exporter writes 12-hour time with AM/PM and a leading space.
                stamp = "%d/%d/%d %d:%02d:%02d.%03d %s" % (
                    t.month, t.day, t.year,
                    12 if t.hour % 12 == 0 else t.hour % 12,
                    t.minute, t.second, t.microsecond // 1000,
                    "AM" if t.hour < 12 else "PM")
                f.write(" %s,%.4f,%.4f,%.4f,38.6046,383.6461\n"
                        % (stamp, r[0], r[1], r[2]))

    _axp = os.path.join(tmp, "P21_export.txt")
    _ax_write(_axp, _ax_rows)
    _axm = ascii_describe(_axp)

    chk("the '# Col' block is parsed, all five channels",
        len(_axm["cols"]) == 5
        and [c["fs"] for c in _axm["cols"]] == [500.0, 500.0, 500.0, 10.0, 1.0],
        "rates %s" % [c["fs"] for c in _axm["cols"]])
    # THE midnight trap.  "12:00:00.000 AM" is 00:00, not 12:00.  Reading it as
    # noon is a 12-hour error that bins and plots without complaint, and would
    # put a night recording in daylight.
    chk("'12:00:00.000 AM' is read as MIDNIGHT",
        _axm["start"] == datetime.datetime(2024, 3, 22, 0, 0, 0),
        "%s" % _axm["start"])
    chk("and '12:00:00.000 PM' is read as NOON",
        _parse_ascii_time("3/22/2024 12:00:00.000 PM")[0]
        == datetime.datetime(2024, 3, 22, 12, 0, 0),
        "%s" % (_parse_ascii_time("3/22/2024 12:00:00.000 PM")[0],))

    _axc, _axfs, _axlab, _axdur = read_ascii(_axp)
    # The whole point: five numeric columns exist, three are ECG.  Temperature
    # at 10 Hz and activity at 1 Hz are forward-filled to every row, so a
    # reader that returned all five would offer lead selection a flat line.
    chk("only the ECG columns are returned, not all five",
        _axc.shape[1] == 3 and _axlab == ["ECG1", "ECG2", "ECG3"],
        "shape %s, labels %s" % (_axc.shape, _axlab))
    chk("the ECG sample rate is read from the header",
        _axfs == 500.0, "%g Hz" % _axfs)
    chk("sample values survive the round trip exactly",
        abs(_axc[0][0] - (-0.0115)) < 1e-12
        and abs(_axc[48][1] - 0.2307) < 1e-12,
        "row0[0]=%.4f, row48[1]=%.4f" % (_axc[0][0], _axc[48][1]))
    # The R peak in these real rows is on column 2 at row 48.  Checking the
    # amplitude keeps the fixture honest: if the columns were transposed the
    # shape test above would still pass.
    chk("the QRS lands on the channel it does in the real file",
        int(np.argmax(np.abs(_axc[:, 1]))) == 48
        and 0.35 < (_axc[:, 1].max() - _axc[:, 1].min()) < 0.45,
        "peak row %d, ptp %.4f mV"
        % (int(np.argmax(np.abs(_axc[:, 1]))),
           _axc[:, 1].max() - _axc[:, 1].min()))
    chk("the declared rate is confirmed by the timestamps",
        abs(ascii_rate_from_timestamps(_axp, _axm["data_offset"]) - 500.0) < 1e-6,
        "%.4f Hz from the clock" % ascii_rate_from_timestamps(
            _axp, _axm["data_offset"]))
    # Placement for `trend`: these files carry no timestamp in the NAME, so the
    # header is the only witness and must be labelled as such.
    _axdt, _axsrc, _ = record_start(_axp)
    chk("record_start places the export from its header alone",
        _axdt == datetime.datetime(2024, 3, 22, 0, 0, 0) and _axsrc == "header only",
        "%s via %s" % (_axdt, _axsrc))

    # Rate disagreement must be NOTICED.  Write rows 4 ms apart under a header
    # still claiming 500 Hz: every downstream interval would be wrong by 2x.
    _axbad = os.path.join(tmp, "P21_badrate.txt")
    _ax_write(_axbad, _ax_rows, step_ms=4.0)
    chk("a clock that contradicts the declared rate is detected",
        abs(ascii_rate_from_timestamps(_axbad,
                                       ascii_describe(_axbad)["data_offset"])
            - 250.0) < 1e-6,
        "clock says %.1f Hz while the header says 500"
        % ascii_rate_from_timestamps(_axbad,
                                     ascii_describe(_axbad)["data_offset"]))
    # Ambiguous dates are flagged rather than silently resolved: 3/4/2024 is
    # either March 4th or April 3rd and nothing in the value decides it.
    chk("an ambiguous m/d date is flagged, an unambiguous one is not",
        _parse_ascii_time("3/4/2024 01:00:00 AM")[1]
        and not _parse_ascii_time("3/22/2024 01:00:00 AM")[1])
    # A file with no '# Col' block still reads, with its assumption declared.
    _axnc = os.path.join(tmp, "P21_nocols.txt")
    _ax_write(_axnc, _ax_rows,
              hdr="# Time of first sample:  3/22/2024 12:00:00.000 AM\n")
    _axc2, _axfs2, _, _ = read_ascii(_axnc)
    chk("an export with no '# Col' block falls back to the timestamps",
        _axc2.shape[1] == 5 and abs(_axfs2 - 500.0) < 1e-6,
        "%d column(s) at %g Hz (identity assumed, and said so)"
        % (_axc2.shape[1], _axfs2))
    print()

    # ----------------------------------------------------------------- [16]
    print("  [16] Ponemah native container, and verifying a layout against truth")
    # The container walk is checked against the REAL first 64 bytes of a
    # .PnmWav.  Everything after that is checked against a recording whose
    # correct decoding is known by construction: the same samples are written
    # both as a Ponemah-shaped binary and as EDF exports, so a layout either
    # reproduces the export or it does not.
    _pwfs = 500.0
    _pwgain = 0.0005                       # mV per count, recovered below
    _pwleads, _ = _st_build(60.0, _pwfs, 900.0, seed=11)
    _pwdir = os.path.join(tmp, "pnmwav")
    os.makedirs(_pwdir, exist_ok=True)
    # The real naming convention, including the unseparated timestamp.
    _pwpath = os.path.join(_pwdir, "08062023 P10.P10.20230806195959.PnmWav")
    _pwoff = _st_write_pnmwav(_pwpath, _pwleads, _pwgain)

    with open(_pwpath, "rb") as _f:
        _pwhead = _f.read(64)
    chk("the fixture's header is byte-identical to the real file's first 64",
        _pwhead == _ST_PNMWAV_HEAD64,
        "%d bytes match" % sum(1 for a, b in zip(_pwhead, _ST_PNMWAV_HEAD64)
                               if a == b))

    _pwd = pnmwav_describe(_pwpath)
    _pwtags = [r["tag"] for r in _pwd["records"]]
    chk("the metadata chain walks to the expected tags",
        _pwd["ok"] and _pwtags == [5000, 5002, 5042, 5044], "tags %s" % _pwtags)
    chk("a string record renders as its text, not as a number",
        pnmwav_render(_pwd["records"][2]["value"]) == '"Eastern Standard Time"',
        pnmwav_render(_pwd["records"][2]["value"]))
    # The walk must land on the payload exactly.  69 is odd, which is the case
    # np.frombuffer cannot slice -- see _st_write_pnmwav.
    chk("the walk stops exactly where the samples begin",
        _pwd["data_offset"] == _pwoff,
        "walk says %d, writer wrote %d (odd offset: %s)"
        % (_pwd["data_offset"], _pwoff, bool(_pwoff % 2)))

    chk("the unseparated .PnmWav timestamp is read from the filename",
        _parse_name_start(_pwpath) == datetime.datetime(2023, 8, 6, 19, 59, 59),
        str(_parse_name_start(_pwpath)))
    # Negative control for that pattern: 14 digits that are not a date.
    chk("a 14-digit run that is not a date is refused, not believed",
        _parse_name_start("/tmp/serial_99999999999999.dat") is None)

    # Two EDF exports of the SAME samples: one at the start, one 30 s in.
    _pwe1 = os.path.join(_pwdir, "P10_seg01_part001_20230806_195959.edf")
    _pwe2 = os.path.join(_pwdir, "P10_seg01_part002_20230806_200029.edf")
    _st_write_edf(_pwe1, [x[:int(20 * _pwfs)] for x in _pwleads], _pwfs,
                  ["ECG1", "ECG2", "ECG3"],
                  start=datetime.datetime(2023, 8, 6, 19, 59, 59))
    _st_write_edf(_pwe2,
                  [x[int(30 * _pwfs):int(50 * _pwfs)] for x in _pwleads], _pwfs,
                  ["ECG1", "ECG2", "ECG3"],
                  start=datetime.datetime(2023, 8, 6, 20, 0, 29))
    _pwref, _pwrfs, _, _ = load_signals(_pwe1, minutes=0.5)
    _pwref = np.ascontiguousarray(_pwref[:int(10 * _pwrfs), :])

    _pwc = verify_layouts(_pwpath, _pwref, [_pwd["data_offset"], 0], _pwrfs,
                          seconds=10.0, max_nch=6)
    _pwbest = _pwc[0] if _pwc else {}
    chk("the true layout wins the search outright",
        bool(_pwc) and _pwbest["dtype"] == "<i2" and _pwbest["nch"] == 3
        and _pwbest["offset"] == _pwoff and abs(_pwbest["r"]) >= 0.999,
        "%s nch=%d off=%d r=%.4f"
        % (_pwbest.get("dtype"), _pwbest.get("nch", 0),
           _pwbest.get("offset", -1), _pwbest.get("r", 0.0)))
    # The contrast that matters is against a different STRUCTURE.  Comparing
    # against the next row outright fails for the wrong reason: raw channel 1
    # against export channel 1 is the same layout reading a different lead, and
    # it correctly also scores ~1.  Only a different (dtype, channels, base) is
    # a competing claim about the format.
    def _struct(d):
        return (d["dtype"], d["nch"], d["base"])

    _pwrival = [c for c in _pwc if _struct(c) != _struct(_pwbest)]
    _pwrun = abs(_pwrival[0]["r"]) if _pwrival else 0.0
    chk("no DIFFERENT layout comes close",
        _pwrun < 0.90,
        "best %.4f vs best rival structure %.4f (%s)"
        % (abs(_pwbest.get("r", 0)), _pwrun,
           "%s nch=%d base=%d" % (_pwrival[0]["dtype"], _pwrival[0]["nch"],
                                  _pwrival[0]["base"]) if _pwrival else "none"))
    # ... and the same layout's OTHER channels should also match, which is what
    # makes the three-channel claim a claim about all three.
    _pwsame = [c for c in _pwc
               if _struct(c) == _struct(_pwbest) and abs(c["r"]) >= 0.99]
    chk("every channel of the winning layout matches its export channel",
        len(_pwsame) == 3 and sorted(c["raw_ch"] for c in _pwsame) == [0, 1, 2],
        "%d channel(s) matched: %s"
        % (len(_pwsame), [(c["raw_ch"], c["ref_ch"], round(c["r"], 4))
                          for c in _pwsame]))

    # Negative control 1: the SAME bytes read big-endian.  This is the reading
    # the real probe promoted to "very likely correct", so it must score badly
    # here or the verification is not discriminating.
    _pwbe = dict(_pwbest, dtype=">i2")
    _pwber = verify_fit(_pwpath, _pwbe, _pwref[:, _pwbest["ref_ch"]], _pwrfs,
                        _pwoff, seconds=10.0)
    chk("the same bytes read BIG-endian do not match",
        abs(_pwber.get("r", 1.0)) < 0.5, "r = %.4f" % _pwber.get("r", 1.0))
    # Negative control 2: correct layout, payload start off by one byte.
    _pwmis = verify_fit(_pwpath, _pwbest, _pwref[:, _pwbest["ref_ch"]], _pwrfs,
                        _pwoff + 1, seconds=10.0)
    chk("a one-byte error in the payload offset destroys the match",
        abs(_pwmis.get("r", 1.0)) < 0.5, "r = %.4f" % _pwmis.get("r", 1.0))

    # The gain is the calibration the container never states.  EDF round trips
    # through a 16-bit digital range, so recovery is close but not exact.
    _pwfit = verify_fit(_pwpath, _pwbest, _pwref[:, _pwbest["ref_ch"]], _pwrfs,
                        _pwoff, seconds=10.0)
    chk("the counts-to-mV gain is recovered from the export",
        _pwfit["ok"] and abs(abs(_pwfit["gain"]) - _pwgain) / _pwgain < 0.02,
        "recovered %.6g vs true %.6g (%.2f%% off)"
        % (_pwfit["gain"], _pwgain,
           100.0 * abs(abs(_pwfit["gain"]) - _pwgain) / _pwgain))

    # Contiguity: the second export is matched at the offset predicted by
    # elapsed time alone.  This is what rules out per-block headers.
    _pwstride = 2 * _pwbest["nch"]
    _pwcols2, _pwfs2, _, _ = load_signals(_pwe2, minutes=0.5)
    _pwpred = _pwoff + int(round(30.0 * _pwrfs)) * _pwstride
    _pwf2 = verify_fit(_pwpath, _pwbest,
                       np.ascontiguousarray(_pwcols2[:int(10 * _pwfs2),
                                                     _pwbest["ref_ch"]]),
                       _pwfs2, _pwpred, seconds=10.0)
    chk("an export 30 s later matches at the offset time alone predicts",
        abs(_pwf2.get("r", 0.0)) >= 0.99 and abs(_pwf2.get("lag", 99)) <= 1,
        "byte %d, r = %.4f, lag %d"
        % (_pwpred, _pwf2.get("r", 0.0), _pwf2.get("lag", 0)))

    # The refusal must be INFORMATIVE: it is the only thing a user sees when
    # they point the tool at a .PnmWav, and "not implemented" wasted rounds.
    try:
        load_signals(_pwpath)
        _pwmsg = ""
    except NotImplementedError as e:
        _pwmsg = str(e)
    chk("reading a .PnmWav refuses, but reports where the payload starts",
        ("byte %d" % _pwoff) in _pwmsg and "verify" in _pwmsg,
        "%d-char message naming the offset and the next command" % len(_pwmsg))

    # Payload arithmetic ranks the true frame STRIDE first when the real
    # duration is known -- and must admit that the stride does not pin down the
    # width/channel split, which is the whole reason `verify` exists.
    _pwopts = pnmwav_payload_options(
        os.path.getsize(_pwpath) - _pwoff, _pwfs, want_s=60.0)
    chk("payload arithmetic ranks the true frame stride first",
        bool(_pwopts) and _pwopts[0]["stride"] == 6
        and (2, 3) in _pwopts[0]["splits"],
        "stride %d = %.1f s, splits %s"
        % (_pwopts[0]["stride"], _pwopts[0]["dur_s"], _pwopts[0]["splits"]))
    chk("and reports that the stride does NOT pin the width/channel split",
        len(_pwopts[0]["splits"]) > 1,
        "%d indistinguishable split(s) listed" % len(_pwopts[0]["splits"]))

    # ---- the three verdict downgrades the real .PnmWav probe should have made
    _vgood = dict(dtype="<i2", score=0.8, rng=(-3000.0, 3000.0))
    chk("a clean candidate is still confirmed",
        probe_verdict(_vgood, 62.5, 0.30, 0.01, 500.0)[0] == "confirmed")
    # 250 bpm IS hr_hi: the search hit the wall, it did not find a peak.
    chk("a period at the edge of the search band is not confirmation",
        probe_verdict(_vgood, 250.0, 0.30, 0.01, 500.0)[0] == "unresolved")
    _vfull = dict(dtype=">i2", score=0.8, rng=(-32768.0, 32767.0))
    chk("a full-scale integer range is called out as arbitrary bytes",
        probe_verdict(_vfull, 62.5, 0.30, 0.01, 500.0)[0] == "unresolved")
    _vbe = dict(dtype=">i2", score=0.8, rng=(-3000.0, 3000.0))
    chk("a big-endian reading of a little-endian container is challenged",
        probe_verdict(_vbe, 62.5, 0.30, 0.01, 500.0,
                      container_endian="little")[0] == "unresolved")

    # ---- the verdict `verify` must NOT reach when the direct match is clean
    # This is the exact run that shipped: three channels at r = 1.000 in the
    # table, then "PARTIAL ... Do not write a reader yet" underneath them.
    _lvl, _lns = verify_verdict(0.988, ch_r=1.000)
    chk("a direct per-channel match at 1.000 settles the layout",
        _lvl == "confirmed", "got %s" % _lvl)
    chk("and the weaker re-derivation is reported, not buried",
        any("0.988" in s for s in _lns))
    chk("a verdict never contradicts a confirmed direct match",
        not any("PARTIAL" in s or "Do not write a reader" in s for s in _lns))
    # Without the demux there is nothing to reconcile, so the old text stands.
    chk("with no direct match, 0.988 is still PARTIAL",
        verify_verdict(0.988)[0] == "partial")
    chk("and both passes failing says so once, not twice",
        verify_verdict(0.7, ch_r=0.6)[0] == "partial")
    _lvl2, _lns2 = verify_verdict(0.999, ch_r=0.998)
    chk("two passes agreeing is stated as corroboration",
        _lvl2 == "confirmed" and any("agrees" in s for s in _lns2))
    print()

    # ----------------------------------------------------------------- [17]
    print("  [17] dispatch on CONTENT when the extension is unknown")
    # The real P21 export arrived as `.ascii`, which was not in the list, and
    # the tool refused a file it could read perfectly.  Extensions are a
    # convention; the bytes are the fact.  These checks cover the fallback and,
    # just as importantly, its limit.
    import contextlib as _ctx
    import io as _io
    _sfd = os.path.join(tmp, "sniff")
    os.makedirs(_sfd, exist_ok=True)

    # The suffix the real file actually used.
    _sf_ascii = os.path.join(_sfd, "20240322_P21_1.ascii")
    _ax_write(_sf_ascii, _ax_rows)
    _sfc, _sffs, _, _ = load_signals(_sf_ascii)
    chk("a '.ascii' export loads",
        _sfc.shape[1] == 3 and abs(_sffs - 500.0) < 1e-6,
        "%d channel(s) at %g Hz" % (_sfc.shape[1], _sffs))

    # An extension nobody has ever seen, holding the same text.
    _sf_odd = os.path.join(_sfd, "20240322_P21_1.qqq")
    _ax_write(_sf_odd, _ax_rows)
    _sferr = _io.StringIO()
    with _ctx.redirect_stderr(_sferr):
        _sfc2, _sffs2, _, _ = load_signals(_sf_odd)
    chk("an unknown extension holding text still loads",
        _sfc2.shape[1] == 3 and abs(_sffs2 - 500.0) < 1e-6,
        "%d channel(s) at %g Hz" % (_sfc2.shape[1], _sffs2))
    # A silent fallback is the dangerous kind: if the sniff is ever wrong, this
    # line is the only thing that explains why the numbers look odd.
    chk("and it SAYS it dispatched on content rather than doing so quietly",
        "'.qqq'" in _sferr.getvalue() and "printable" in _sferr.getvalue(),
        _sferr.getvalue().strip().split("\n")[0][:78])

    # Placement must follow the same route as loading.  If it does not, the
    # file reads fine and then vanishes from `trend` with no error at all.
    _sfdt, _sfsrc, _ = record_start(_sf_odd)
    chk("clock placement follows content dispatch too",
        _sfdt == datetime.datetime(2024, 3, 22, 0, 0, 0),
        "%s via %s" % (_sfdt, _sfsrc))

    # Magic, not text: an EDF under a nonsense name.
    _sf_edf = os.path.join(_sfd, "recording.bin")
    _st_write_edf(_sf_edf, [x[:int(20 * 500.0)] for x in _pwleads], 500.0,
                  ["ECG1", "ECG2", "ECG3"])
    with _ctx.redirect_stderr(_io.StringIO()):
        _sfc3, _, _, _ = load_signals(_sf_edf)
    chk("an EDF under a nonsense extension is recognised by its magic",
        _sfc3.shape[1] == 3, "%d channel(s)" % _sfc3.shape[1])

    # A Ponemah container under a nonsense name must reach read_ponemah -- so
    # the user gets the informative refusal, not "unrecognised extension".
    _sf_pnm = os.path.join(_sfd, "recording.raw")
    _st_write_pnmwav(_sf_pnm, [x[:5000] for x in _pwleads], 0.0005)
    try:
        with _ctx.redirect_stderr(_io.StringIO()):
            load_signals(_sf_pnm)
        _sfwhy = "it returned data"
    except NotImplementedError as e:
        _sfwhy = "NotImplementedError: " + str(e).split("\n")[0][:40]
    except ValueError as e:                              # noqa: BLE001
        _sfwhy = "ValueError: " + str(e).split("\n")[0][:40]
    chk("a Ponemah container under a nonsense extension reaches its own refusal",
        _sfwhy.startswith("NotImplementedError"), _sfwhy)

    # THE LIMIT.  Sniffing must not turn into guessing: an unidentifiable
    # binary has to be refused, because inventing a layout for it is the exact
    # failure this project is built around.
    _sf_bin = os.path.join(_sfd, "mystery.bin")
    with open(_sf_bin, "wb") as _f:
        _f.write(bytes(np.random.default_rng(3).integers(0, 256, 40000,
                                                         dtype=np.uint8)))
    try:
        with _ctx.redirect_stderr(_io.StringIO()):
            load_signals(_sf_bin)
        _sfref = ""
    except ValueError as e:
        _sfref = str(e)
    except Exception as e:                               # noqa: BLE001
        _sfref = "wrong exception: %r" % e
    chk("an unidentifiable binary is still REFUSED, not guessed at",
        "probe" in _sfref and "printable" in _sfref,
        "refused and pointed at probe" if "probe" in _sfref
        else (_sfref[:60] or "it did not refuse"))
    print()

    # ----------------------------------------------------------------- [18]
    print("  [18] 'x' markers: the exporter's own statement of missing data")
    # P21's real export carries a literal 'x' where Ponemah had no valid
    # sample.  The old reader passed it to np.loadtxt, which raised, so ONE
    # marked sample 86 s into a six-hour file aborted the whole recording.
    # These checks cover the parse, the excision it feeds, and -- most
    # importantly -- the two ways this could go silently wrong.
    _mkd = os.path.join(tmp, "marks")
    os.makedirs(_mkd, exist_ok=True)

    def _mk_write(path, n, marked, col=1, token="     x"):
        """An export of `n` rows with `marked` row indices marked in `col`."""
        t0 = datetime.datetime(2024, 3, 22, 0, 0, 0)
        with open(path, "w") as f:
            f.write(_ax_hdr)
            for i in range(n):
                t = t0 + datetime.timedelta(milliseconds=2.0 * i)
                stamp = "%d/%d/%d %d:%02d:%02d.%03d %s" % (
                    t.month, t.day, t.year,
                    12 if t.hour % 12 == 0 else t.hour % 12,
                    t.minute, t.second, t.microsecond // 1000,
                    "AM" if t.hour < 12 else "PM")
                v = list(_ax_rows[i % len(_ax_rows)])
                cells = ["%.4f" % x for x in v]
                if i in marked:
                    cells[col - 1] = token
                f.write(" %s,%s,38.6046,383.6461\n" % (stamp, ",".join(cells)))

    # The exact failure the user hit: a marker partway through the file.
    _mk1 = os.path.join(_mkd, "P21_marked.ascii")
    _mk_marked = set(range(1000, 1500))
    _mk_write(_mk1, 5000, _mk_marked, col=1)
    _mkerr = _io.StringIO()
    with _ctx.redirect_stderr(_mkerr):
        _mkc, _mkfs, _mklab, _ = load_signals(_mk1)
    chk("an export containing 'x' LOADS instead of raising",
        _mkc.shape == (5000, 3), "shape %s" % (_mkc.shape,))
    # The marked cells must be NaN -- not zero, and not the previous value.
    # Zero-filling here would be the quiet failure: the file would read, the
    # dead stretch would look like a flat line, and nothing would excise it.
    _mkn = np.isnan(_mkc[:, 0])
    chk("the marked samples arrive as NaN, exactly where they were written",
        int(_mkn.sum()) == len(_mk_marked)
        and bool(_mkn[sorted(_mk_marked)].all()),
        "%d NaN, expected %d" % (int(_mkn.sum()), len(_mk_marked)))
    chk("and ONLY that channel is affected",
        not bool(np.isnan(_mkc[:, 1]).any() or np.isnan(_mkc[:, 2]).any()),
        "ch2 %d NaN, ch3 %d NaN" % (int(np.isnan(_mkc[:, 1]).sum()),
                                    int(np.isnan(_mkc[:, 2]).sum())))
    chk("the reader SAYS what token it found and how much of it",
        "x" in _mkerr.getvalue() and "missing samples per channel" in _mkerr.getvalue(),
        [l for l in _mkerr.getvalue().split("\n") if "marker" in l][:1])

    # The timestamp column is full of slashes and letters and must survive the
    # cleaner untouched -- if it did not, the rate would come out wrong and
    # every derived number with it.
    _mkfs_ts = ascii_rate_from_timestamps(_mk1, ascii_describe(_mk1)["data_offset"])
    chk("the cleaner does not damage the timestamp column",
        abs(_mkfs_ts - 500.0) < 1e-6 and abs(_mkfs - 500.0) < 1e-6,
        "%.4f Hz from the clock, %g Hz used" % (_mkfs_ts, _mkfs))

    # THE ONE THAT MATTERS MOST.  filtfilt propagates a single NaN across the
    # entire signal in both directions.  Left unhandled, one marked sample
    # returns a whole record of NaN -- no beats, no rate, no error.
    _mkfill, _mkmask = fill_missing(_mkc)
    chk("fill_missing leaves nothing non-finite behind",
        bool(np.isfinite(_mkfill).all()) and int(_mkmask.sum()) == len(_mk_marked),
        "%d filled, mask still records %d" % (int((~np.isfinite(_mkc)).sum()),
                                              int(_mkmask.sum())))
    _mkbp = bp(_mkfill[:, 0], _mkfs, 5.0, 40.0)
    chk("and the filtered trace survives -- one NaN would have erased all of it",
        bool(np.isfinite(_mkbp).all()),
        "%d finite of %d" % (int(np.isfinite(_mkbp).sum()), len(_mkbp)))
    # Interpolation, not zero-fill: a step to zero rings through the bandpass
    # and manufactures beats just OUTSIDE the excised span, where they count.
    _mkedge = np.abs(np.diff(_mkfill[sorted(_mk_marked)[0] - 2:
                                     sorted(_mk_marked)[0] + 2, 0])).max()
    chk("the gap is bridged smoothly rather than stepped to zero",
        _mkedge < 0.05, "largest step at the gap edge %.4f" % _mkedge)

    # The mask must become excised time, and the two halves must move
    # together: beats out of the numerator, seconds out of the denominator.
    _mksp = mask_to_spans(_mkmask[:, 0], _mkfs)
    chk("the NaN run becomes exactly one span of the right length",
        len(_mksp) == 1 and abs(total_span_s(_mksp) - 1.0) < 1e-9,
        "%d span(s), %.4f s (500 marked samples at 500 Hz = 1.0 s)"
        % (len(_mksp), total_span_s(_mksp)))
    # No minimum length, unlike the inferred no-signal spans: the exporter is
    # stating a fact, not clearing a threshold.
    _mk2 = os.path.join(_mkd, "P21_one.ascii")
    _mk_write(_mk2, 2000, {900}, col=1)
    with _ctx.redirect_stderr(_io.StringIO()):
        _mkc2, _mkfs2, _, _ = load_signals(_mk2)
    _mksp2 = mask_to_spans(np.isnan(_mkc2[:, 0]), _mkfs2)
    chk("a SINGLE marked sample still produces a span",
        len(_mksp2) == 1, "%d span(s) from one marked sample" % len(_mksp2))

    # Overlapping span lists must not double-count.  nosig and mark spans
    # overlap almost by definition -- marked time is usually flat -- and
    # adding their durations would over-subtract from the denominator and
    # inflate the reported rate.
    _mg = merge_spans([(0.0, 5.0), (3.0, 8.0), (20.0, 21.0)])
    chk("overlapping spans merge instead of double-counting",
        _mg == [(0.0, 8.0), (20.0, 21.0)] and abs(total_span_s(_mg) - 9.0) < 1e-9,
        "%s = %.1f s (naive sum would be 11.0)" % (_mg, total_span_s(_mg)))

    # An empty field is missing data too, and loadtxt rejects it just as
    # loudly as it rejects 'x'.
    _mk3 = os.path.join(_mkd, "P21_empty.ascii")
    _mk_write(_mk3, 1200, {600, 601}, col=2, token="")
    with _ctx.redirect_stderr(_io.StringIO()):
        _mkc3, _, _, _ = load_signals(_mk3)
    chk("an EMPTY field is treated as missing, not as a parse failure",
        int(np.isnan(_mkc3[:, 1]).sum()) == 2,
        "%d NaN in the emptied channel" % int(np.isnan(_mkc3[:, 1]).sum()))

    # End-to-end: the flag must appear, and it must be advisory at this level
    # rather than quietly disqualifying the file.
    chk("a small marked fraction is advisory, a large one is not",
        is_advisory("MARKED_0.42%") and not is_advisory("MARKED_MAJOR_31.00%"),
        "MARKED_0.42%% advisory=%s, MARKED_MAJOR_31.00%% advisory=%s"
        % (is_advisory("MARKED_0.42%"), is_advisory("MARKED_MAJOR_31.00%")))

    # The sidecar spreadsheet.  An .xlsx is a ZIP of XML, so the standard
    # library reads it -- no new dependency on a machine where the data lives.
    _xl = os.path.join(_mkd, "results.xlsx")
    with zipfile.ZipFile(_xl, "w") as _z:
        _z.writestr("[Content_Types].xml", "<Types/>")
        _z.writestr("xl/workbook.xml",
                    '<workbook><sheets>'
                    '<sheet name="Derived Data" sheetId="1" r:id="rId1"/>'
                    '<sheet name="Attributes" sheetId="2" r:id="rId2"/>'
                    '</sheets></workbook>')
        _z.writestr("xl/worksheets/sheet1.xml", "<worksheetData/>" * 200)
    _xi = zip_describe(_xl)
    chk("an xlsx is recognised and its worksheets named",
        _xi["ok"] and _xi["kind"] == "xlsx"
        and _xi["sheets"] == ["Derived Data", "Attributes"],
        "%s: %s" % (_xi["kind"], _xi["sheets"]))
    # And it must not raise on something that merely starts like one.
    _nz = os.path.join(_mkd, "not_really.xlsx")
    with open(_nz, "wb") as _f:
        _f.write(b"PK\x03\x04" + b"\x00" * 200)
    _ni = zip_describe(_nz)
    chk("a file that only LOOKS like an archive reports rather than raising",
        _ni["ok"] is False and bool(_ni["why"]), _ni["why"][:60])
    print()

    # ---------------------------------------------------------------- [19]
    print("  [19] a MULTIPLEXED container: finding the channel tag by measurement")
    _dxd = os.path.join(tmp, "demux")
    os.makedirs(_dxd, exist_ok=True)
    _dxp = os.path.join(_dxd, "rig.PnmWav")
    # Build a container with the shape P10 actually has: fast channels and slow
    # ones, blocks tagged by channel, plus two DECOYS that a weaker test would
    # fall for.  5010 is unique per block (a sequence number).  7777 changes
    # with the channel but splits the payload into ragged sizes, so only the
    # integer-ratio test rejects it -- group count alone would not.
    _dx_rates = [(2, 100), (3, 100), (4, 2), (5, 1)]     # relative rates
    _dx_unit = 512                                        # bytes per rate unit
    with open(_dxp, "wb") as _f:
        _f.write(PNMWAV_MAGIC)
        def _dxrec(tag, val):
            _f.write(struct.pack("<HI", tag, len(val)))
            _f.write(val)
        # Header: one descriptor per channel, each with its OWN gain, so a
        # reader that takes the last one for everybody is caught.
        for _ci, (_ch, _rt) in enumerate(_dx_rates):
            _dxrec(5045, struct.pack("<Q", _ch))
            _dxrec(5025, struct.pack("<h", -32256))
            _dxrec(5026, struct.pack("<h", 32255))
            _dxrec(5029, struct.pack("<f", -14.0 * (_ci + 1)))
            _dxrec(5030, struct.pack("<f", 14.0 * (_ci + 1)))
        _dx_seq = 0
        for _ch, _rt in _dx_rates:
            _left = _rt * _dx_unit
            while _left > 0:
                _n = min(_left, 4096)
                _dxrec(5045, struct.pack("<Q", _ch))
                _dxrec(5010, struct.pack("<Q", _dx_seq))      # decoy: unique
                # Decoy: changes every third block, so it cuts ACROSS channel
                # boundaries.  Few enough groups to be evaluated, but the
                # groups are ragged -- which is the only thing separating it
                # from a channel id, and the whole point of the ratio test.
                _dxrec(7777, struct.pack("<Q", 900 + _dx_seq // 3))
                _dxrec(5015, bytes(_n))
                _left -= _n
                _dx_seq += 1

    _dxw = pnmwav_describe(_dxp)
    _dxtag, _dxg, _dxtbl = pnmwav_channel_tag(_dxw["records"],
                                              _dxw["bulk_tag"])
    chk("the channel tag is found without being named",
        _dxtag == 5045, "picked tag %s from %d candidate tag(s)"
        % (_dxtag, len(_dxtbl)))
    chk("and the undeclared decoy is rejected however cleanly it splits",
        _dxtag != 7777 and any(d["tag"] == 7777 and "declared" in d["why"]
                               for d in _dxtbl),
        next(("7777: %s" % d["why"] for d in _dxtbl if d["tag"] == 7777),
             "7777 not evaluated"))
    chk("a per-block sequence number is rejected for having too many groups",
        5010 not in (_dxtag,) and any(d["tag"] == 5010 and d["groups"] is None
                                      for d in _dxtbl),
        next(("5010: %s" % d["why"] for d in _dxtbl if d["tag"] == 5010),
             "5010 not evaluated"))
    chk("every channel is recovered",
        sorted(_dxg) == [c for c, _ in _dx_rates],
        "channels %s" % sorted(_dxg))
    _dxsz = {c: sum(L for _o, L in _dxg[c]) for c in sorted(_dxg)}
    chk("and each one holds exactly the bytes it was given",
        all(_dxsz.get(c) == r * _dx_unit for c, r in _dx_rates),
        "sizes %s" % _dxsz)

    # The gains are per channel and must not be smeared by scan order.
    _dxdesc = pnmwav_descriptors(_dxw["records"], _dxtag, _dxw["bulk_tag"])
    _dxgains = [_dxdesc.get(c, {}).get("gain") for c, _ in _dx_rates]
    chk("each channel keeps its OWN gain rather than the last descriptor's",
        all(g is not None for g in _dxgains)
        and len({round(g, 12) for g in _dxgains}) == len(_dx_rates),
        "gains %s" % ["%.3e" % g if g else g for g in _dxgains])
    _dxexp = 28.0 / 64511.0
    chk("and the gain is the stated engineering range over the raw range",
        _dxgains[0] is not None and abs(_dxgains[0] - _dxexp) < 1e-15,
        "%s vs 28.0/64511 = %.6e"
        % ("%.6e" % _dxgains[0] if _dxgains[0] is not None else "none",
           _dxexp))

    # A container that is NOT multiplexed must not be forced into a split.
    _dxs = os.path.join(_dxd, "single.PnmWav")
    with open(_dxs, "wb") as _f:
        _f.write(PNMWAV_MAGIC)
        for _i in range(8):
            _f.write(struct.pack("<HI", 5015, 4096))
            _f.write(bytes(4096))
    _dxw2 = pnmwav_describe(_dxs)
    _dxt2, _dxg2, _ = pnmwav_channel_tag(_dxw2["records"], _dxw2["bulk_tag"])
    chk("a single-channel container reports NO split rather than inventing one",
        _dxt2 is None and not _dxg2, "tag %s, %d group(s)" % (_dxt2, len(_dxg2)))
    print()

    # ----------------------------------------------------------------- [20]
    print("  [20] the SQLite sidecars: read them, and stop guessing at them")
    # Shaped after the real .PnmMarks, whose schema `probe` recovered from raw
    # bytes: a Cycle table indexed on (ChannelContextId, CycleTime) -- very
    # likely Ponemah's own per-beat detections -- and MatchSegments(StartTime,
    # EndTime), which may be the intervals to exclude.
    _sqd = os.path.join(tmp, "sidecar")
    os.makedirs(_sqd, exist_ok=True)
    _sqp = os.path.join(_sqd, "E1 P10.1.P10.PnmMarks")
    _con = sqlite3.connect(_sqp)
    _con.executescript(
        "CREATE TABLE Cycle (ChannelContextId INTEGER NOT NULL,"
        " CycleTime LONG, Value REAL);"
        "CREATE INDEX idx_cci_cycletime ON Cycle(ChannelContextId, CycleTime);"
        "CREATE TABLE MatchSegments (SearchContextId INTEGER NOT NULL,"
        " LogTime LONG, StartTime LONG, EndTime LONG);"
        "CREATE TABLE Empty (a INTEGER);")
    _con.executemany("INSERT INTO Cycle VALUES (?,?,?)",
                     [(1, 1000 + 500 * i, 0.5) for i in range(40)])
    _con.executemany("INSERT INTO MatchSegments VALUES (?,?,?,?)",
                     [(7, 10, 2000, 3000), (7, 11, 9000, 9500)])
    _con.commit()
    _con.close()
    _before = sorted(os.listdir(_sqd))

    _si = sqlite_describe(_sqp)
    chk("a sidecar database opens and lists its tables",
        _si["ok"] and [t["name"] for t in _si["tables"]]
        == ["Cycle", "Empty", "MatchSegments"],
        "%s" % [t["name"] for t in _si["tables"]])
    _cyc = next(t for t in _si["tables"] if t["name"] == "Cycle")
    chk("row counts are real counts, not estimates",
        _cyc["nrow"] == 40, "%s rows" % _cyc["nrow"])
    chk("and the columns are reported with their declared types",
        ("CycleTime", "LONG") in _cyc["cols"], "%s" % _cyc["cols"])
    # The whole point: a min and a max turn an unread LONG into a duration.
    chk("a time-shaped column gets its span measured",
        _cyc["spans"].get("CycleTime") == (1000, 20500),
        "%s" % _cyc["spans"])
    _ms = next(t for t in _si["tables"] if t["name"] == "MatchSegments")
    chk("both ends of an interval column are picked up",
        _ms["spans"].get("StartTime") == (2000, 9000)
        and _ms["spans"].get("EndTime") == (3000, 9500),
        "%s" % _ms["spans"])
    chk("an empty table reports zero rather than failing",
        next(t for t in _si["tables"] if t["name"] == "Empty")["nrow"] == 0)
    chk("no rows are read unless they are asked for",
        _cyc["rows"] == [])
    chk("and --rows N returns exactly N",
        len(next(t for t in sqlite_describe(_sqp, sample=3)["tables"]
                 if t["name"] == "Cycle")["rows"]) == 3)
    # This is the check that protects the user's only copy of an experiment.
    chk("reading the database leaves the directory byte-identical",
        sorted(os.listdir(_sqd)) == _before,
        "before %s, after %s" % (_before, sorted(os.listdir(_sqd))))
    # A file that is not SQLite at all must say so, not raise.
    _notdb = os.path.join(_sqd, "notadb.bin")
    with open(_notdb, "wb") as _f:
        _f.write(os.urandom(4096))
    chk("a non-database is refused with a reason, not an exception",
        sqlite_describe(_notdb)["ok"] is False)

    # ---- probe must no longer issue a waveform verdict on a recognised
    # container.  The real run called a 122 KB SQLite event log "very likely
    # correct" as a biosignal layout.
    class _A:
        input = [_sqp]
        fs_hint = 500.0
        rows = 0
        force = False
    _buf = _io.StringIO()
    with _ctx.redirect_stdout(_buf):
        cmd_probe(_A())
    _out = _buf.getvalue()
    chk("probe names the tables of a sidecar instead of searching it",
        "Cycle" in _out and "MatchSegments" in _out)
    chk("and issues NO layout verdict on it",
        "very likely correct" not in _out and "VERDICT" not in _out,
        _out[-160:].replace("\n", " "))
    chk("it says why the search was skipped rather than skipping silently",
        "No waveform search was run" in _out)
    print()

    # ----------------------------------------------------------------- [21]
    print("  [21] Ponemah's own beat list and bad-data intervals")
    # Built so every printed number has a known correct value.  2 Hz beats
    # (120 bpm) for 600 s on context 2, 1 Hz on context 5, and three bad
    # intervals -- two of which OVERLAP, because 383 real marks written by an
    # operator and an algorithm over 18 hours certainly do.
    _mkd = os.path.join(tmp, "marks")
    os.makedirs(_mkd, exist_ok=True)
    _mkp = os.path.join(_mkd, "E1 P9.1.P9.PnmMarks")
    _T0 = 638269487992540000          # the real P10 first-beat tick
    _TPS = NET_TICKS_PER_S
    _beats2 = [_T0 + i * (_TPS // 2) for i in range(1200)]      # 2 Hz, 600 s
    _beats5 = [_T0 + i * _TPS for i in range(600)]              # 1 Hz, 600 s
    _con = sqlite3.connect(_mkp)
    _con.executescript(
        "CREATE TABLE Cycle (ChannelContextId INTEGER NOT NULL,"
        " CycleTime LONG, Marks BLOB);"
        "CREATE TABLE ChannelContextInfo (ChannelContextId INTEGER,"
        " SubjectChannelId LONG, TicksPerSample LONG);"
        "CREATE TABLE BadDataMark (BadDataMarkId INTEGER,"
        " SubjectChannelId LONG, StartTime LONG, EndTime LONG);"
        "CREATE TABLE MarkDatabaseInfo (SchemaVersion INTEGER,"
        " CreateDate INTEGER);")
    _con.executemany("INSERT INTO Cycle VALUES (?,?,?)",
                     [(2, t, None) for t in _beats2]
                     + [(5, t, None) for t in _beats5])
    _con.executemany("INSERT INTO ChannelContextInfo VALUES (?,?,?)",
                     [(2, 1001, 20000), (5, 1004, 10000000)])
    # 100-110 s and 105-120 s overlap: 20 s raw, 20 s merged (not 25).
    # 300-310 s is separate.  Total merged = 30 s.
    _con.executemany("INSERT INTO BadDataMark VALUES (?,?,?,?)",
                     [(1, 1001, _T0 + 100 * _TPS, _T0 + 110 * _TPS),
                      (2, 1001, _T0 + 105 * _TPS, _T0 + 120 * _TPS),
                      (3, 1001, _T0 + 300 * _TPS, _T0 + 310 * _TPS)])
    _con.execute("INSERT INTO MarkDatabaseInfo VALUES (?,?)",
                 (1, _T0 - 10 * _TPS))
    _con.commit()
    _con.close()

    _m = read_marks(_mkp)
    chk("a .PnmMarks yields its beat table", _m["ok"], _m["why"])
    chk("both contexts are found with the right beat counts",
        [(c["ctx"], c["n"]) for c in _m["contexts"]] == [(2, 1200), (5, 600)],
        "%s" % [(c["ctx"], c["n"]) for c in _m["contexts"]])
    _c2 = _m["contexts"][0]
    # TicksPerSample is the file SAYING what the rate is -- the first time
    # anything in this project has read a rate rather than assumed one.
    chk("TicksPerSample is read as a sampling rate",
        _c2["fs"] == 500.0 and _m["contexts"][1]["fs"] == 1.0,
        "%s, %s" % (_c2["fs"], _m["contexts"][1]["fs"]))
    chk("and the beat rate comes out at the constructed 120 bpm",
        abs(_c2["bpm_modal"] - 120.0) < 1e-6
        and abs(_c2["bpm_mean"] - 120.0) < 1e-6,
        "modal %.4f mean %.4f" % (_c2["bpm_modal"], _c2["bpm_mean"]))
    chk("the span is the constructed 599.5 s",
        abs(_c2["span_s"] - 599.5) < 1e-6, "%.4f s" % _c2["span_s"])
    # The tick decode, against a date computed by hand.
    chk("the tick decode lands on the real P10 start time",
        ticks_to_dt(_T0).isoformat(sep=" ") == "2023-08-06 19:59:59.254000",
        ticks_to_dt(_T0).isoformat(sep=" "))
    chk("ticks_to_s is pure subtraction, so the epoch cannot shift it",
        float(ticks_to_s(_T0 + 7 * _TPS, _T0)) == 7.0)

    # ---- the overlap merge.  Summing raw durations says 35 s; the truth is 30.
    _raw = [(a, b) for _s, a, b in _m["bad"]]
    _mg = merge_tick_spans(_raw)
    chk("overlapping bad-data marks merge instead of double-counting",
        len(_mg) == 2
        and abs(sum(b - a for a, b in _mg) / float(_TPS) - 30.0) < 1e-6,
        "%d span(s), %.1f s (naive sum would be %.1f)"
        % (len(_mg), sum(b - a for a, b in _mg) / float(_TPS),
           sum(b - a for a, b in _raw) / float(_TPS)))

    # ---- beats inside the marks.  2 Hz over 30 s of marks, inclusive of both
    # endpoints: 100-120 s is 41 beats, 300-310 s is 21.  62 in total.
    chk("beats falling inside a bad interval are counted exactly",
        beats_in_spans(_c2["times"], _mg) == 62,
        "%d" % beats_in_spans(_c2["times"], _mg))
    chk("a beat exactly on a boundary counts as inside",
        beats_in_spans(np.array([_T0 + 100 * _TPS], dtype=np.int64), _mg) == 1)
    chk("a beat in the gap BETWEEN two marks does not",
        beats_in_spans(np.array([_T0 + 200 * _TPS], dtype=np.int64), _mg) == 0)
    chk("no marks means no beats excluded",
        beats_in_spans(_c2["times"], []) == 0)

    # ---- the export must be readable by the thing that consumes it.
    _pk = os.path.join(_mkd, "ponemah.peaks.csv")
    _n = write_marks_peaks(_pk, _c2, _m["t0"], _mkp, _mg)
    chk("every beat is written, none silently dropped", _n == 1200)
    _times, _meta, _rows = read_peaks(_pk)
    chk("the export round-trips through the reader `compare` uses",
        len(_rows) == 1200 and len(_times) == 1200 - 62,
        "%d row(s), %d kept" % (len(_rows), len(_times)))
    chk("excluded beats are marked keep=0 rather than deleted",
        sum(1 for r in _rows if r["keep"] == "0") == 62)
    chk("the first kept beat is at t=0 and the clock is the file's own",
        abs(_times[0]) < 1e-9 and _meta.get("fs_hz") == "500.0000",
        "t0 %.6f, fs %s" % (_times[0], _meta.get("fs_hz")))
    chk("the tick origin is recorded so a shifted comparison is detectable",
        _meta.get("t0_ticks") == str(_T0))
    chk("and the rows say who detected them",
        all(r["source"] == "PONEMAH" for r in _rows))

    # ---- a database that is SQLite but not a marks file must decline clearly.
    _nom = os.path.join(_mkd, "empty.PnmMarks")
    _con = sqlite3.connect(_nom)
    _con.execute("CREATE TABLE Other (x INTEGER)")
    _con.commit()
    _con.close()
    _bad = read_marks(_nom)
    chk("a database with no Cycle table says so and names what it has",
        not _bad["ok"] and "Other" in _bad["why"], _bad["why"])
    _nested_pk = os.path.join(_mkd, "does_not_exist_yet", "sub", "peaks.csv")
    chk("write_marks_peaks creates missing parent directories instead of failing",
        write_marks_peaks(_nested_pk, _c2, _m["t0"], _mkp, _mg) == 1200
        and os.path.isfile(_nested_pk))
    _pnm_cols, _pnm_fs, _pnm_lbls, _pnm_dur = read_ponemah(_dxp)
    chk("read_ponemah loads a multiplexed .PnmWav natively",
        _pnm_cols.shape == (25600, 2) and _pnm_fs == 500.0
        and _pnm_lbls == ["ECG_ch2", "ECG_ch3"],
        "shape %s, fs %s, labels %s" % (_pnm_cols.shape, _pnm_fs, _pnm_lbls))
    # ---- verify cmd_marks end-to-end on a 3-lead cardiac database
    _mk3 = os.path.join(_mkd, "three_lead.PnmMarks")
    _con3 = sqlite3.connect(_mk3)
    _con3.execute("CREATE TABLE ChannelContextInfo (ChannelContextId INTEGER,"
                  " SubjectChannelId INTEGER, TicksPerSample LONG)")
    _con3.execute("CREATE TABLE Cycle (ChannelContextId INTEGER, CycleTime LONG)")
    _con3.execute("CREATE TABLE BadDataMark (SubjectId INTEGER, StartTime LONG,"
                  " EndTime LONG)")
    _con3.executemany("INSERT INTO ChannelContextInfo VALUES (?, ?, ?)",
                      [(1, 2, 20000), (2, 3, 20000), (3, 4, 20000),
                       (4, 5, 10000000)])
    _con3.executemany("INSERT INTO Cycle VALUES (?, ?)",
                      [(1, _T0 + i * 5000000) for i in range(100)] +
                      [(2, _T0 + i * 5000000) for i in range(1000)] +
                      [(3, _T0 + i * 5000000) for i in range(1100)] +
                      [(4, _T0 + i * 10000000) for i in range(500)])
    _con3.execute("INSERT INTO BadDataMark VALUES (1, ?, ?)",
                  (_T0 + 10 * NET_TICKS_PER_S, _T0 + 15 * NET_TICKS_PER_S))
    _con3.commit()
    _con3.close()
    import contextlib, io, shutil
    _out_io = io.StringIO()
    with contextlib.redirect_stdout(_out_io):
        _rc3 = cmd_marks(argparse.Namespace(
            input=[_mk3], export_beats=None, export_excl=None, context=None))
    _txt3 = _out_io.getvalue()
    chk("cmd_marks formats 3-lead inter-lead spread without error",
        _rc3 == 0 and "spread between active leads:   100 beats (10.0%" in _txt3,
        "rc=%s" % _rc3)
    # ---- verify read_ponemah marks BadDataMark intervals as NaN when sidecar present
    _dx_sidecar = os.path.join(os.path.dirname(_dxp), "sidecar.PnmMarks")
    shutil.copyfile(_mk3, _dx_sidecar)
    _pnm_bad, _pnm_fs2, _, _ = read_ponemah(_dxp)
    _nan_spans = mask_to_spans(np.isnan(_pnm_bad[:, 0]), _pnm_fs2)
    os.remove(_dx_sidecar)
    chk("read_ponemah masks .PnmMarks BadDataMark intervals as NaN",
        len(_nan_spans) == 1 and abs(total_span_s(_nan_spans) - 5.0) < 0.02,
        "spans=%s" % _nan_spans)

    # ---- THE ORIGIN.  Sample zero is the start of the RECORDING; the
    # sidecar's first beat is later.  On P10 that gap is 0.254 s, and
    # `compare` measured it independently from the beats at 0.2520 s.  If the
    # bad-data intervals are placed against the wrong one of those, all 344
    # of them sit a quarter-second off -- leaking bad samples in at one edge
    # and excising good ones at the other, silently.
    _or_dir = os.path.join(tmp, "origin")
    os.makedirs(_or_dir, exist_ok=True)
    # The recording starts at 19:59:59.000; the first beat is 0.400 s later.
    _or_start_dt = datetime.datetime(2023, 8, 6, 19, 59, 59)
    _or_start_tk = int((_or_start_dt
                        - datetime.datetime(1, 1, 1)).total_seconds()
                       * NET_TICKS_PER_S)
    _or_beat_tk = _or_start_tk + int(0.400 * NET_TICKS_PER_S)
    # Same container bytes as the demux fixture, with a start-time record
    # spliced in and a filename carrying the stamp the record must agree with.
    _or_wav = os.path.join(_or_dir, "rig.P9.20230806195959.PnmWav")
    with open(_dxp, "rb") as _f:
        _or_body = _f.read()[len(PNMWAV_MAGIC):]
    with open(_or_wav, "wb") as _f:
        _f.write(PNMWAV_MAGIC)
        _f.write(struct.pack("<HI", 5012, 8))
        _f.write(struct.pack("<Q", _or_start_tk))
        _f.write(_or_body)
    _or_recs = pnmwav_describe(_or_wav)["records"]
    _or_found = pnmwav_start_ticks(_or_recs, want_dt=_or_start_dt)
    chk("the recording start is read from the container, not assumed",
        _or_found == _or_start_tk,
        "found %s, wrote %s" % (_or_found, _or_start_tk))
    chk("and a start that does NOT agree with the filename is refused",
        pnmwav_start_ticks(_or_recs,
                           want_dt=_or_start_dt
                           + datetime.timedelta(hours=3)) is None)
    # A sidecar whose first beat is 0.400 s after the recording start, with a
    # bad interval running 10.0 .. 15.0 s on the ABSOLUTE clock.
    _or_marks = os.path.join(_or_dir, "rig.PnmMarks")
    _con_o = sqlite3.connect(_or_marks)
    _con_o.execute("CREATE TABLE ChannelContextInfo (ChannelContextId INTEGER,"
                   " SubjectChannelId INTEGER, TicksPerSample LONG)")
    _con_o.execute("CREATE TABLE Cycle (ChannelContextId INTEGER,"
                   " CycleTime LONG)")
    _con_o.execute("CREATE TABLE BadDataMark (SubjectId INTEGER,"
                   " StartTime LONG, EndTime LONG)")
    _con_o.executemany("INSERT INTO ChannelContextInfo VALUES (?, ?, ?)",
                       [(1, 2, 20000), (2, 3, 20000)])
    _con_o.executemany(
        "INSERT INTO Cycle VALUES (?, ?)",
        [(1, _or_beat_tk + int(i * 0.6 * NET_TICKS_PER_S))
         for i in range(200)])
    _con_o.execute("INSERT INTO BadDataMark VALUES (1, ?, ?)",
                   (_or_start_tk + 10 * NET_TICKS_PER_S,
                    _or_start_tk + 15 * NET_TICKS_PER_S))
    _con_o.commit()
    _con_o.close()
    _or_cols, _or_fs, _, _ = read_ponemah(_or_wav)
    _or_spans = mask_to_spans(np.isnan(_or_cols[:, 0]), _or_fs)
    chk("a bad interval lands where the ABSOLUTE clock says, not 0.4 s early",
        len(_or_spans) == 1 and abs(_or_spans[0][0] - 10.0) < 0.01
        and abs(_or_spans[0][1] - 15.0) < 0.01,
        "got %s, want (10.00, 15.00); the first-beat origin would give"
        " (9.60, 14.60)" % ([("%.2f" % a, "%.2f" % b) for a, b in _or_spans],))
    # And the fallback must still work, announcing itself.
    _or_nostamp = os.path.join(_or_dir, "nostamp.PnmWav")
    shutil.copyfile(_dxp, _or_nostamp)
    _or_marks2 = os.path.join(_or_dir, "nostamp.PnmMarks")
    shutil.copyfile(_or_marks, _or_marks2)
    os.remove(_or_marks)
    _or_err = _io.StringIO()
    with _ctx.redirect_stderr(_or_err):
        _ns_cols, _ns_fs, _, _ = read_ponemah(_or_nostamp)
    _ns_spans = mask_to_spans(np.isnan(_ns_cols[:, 0]), _ns_fs)
    chk("with no agreeing start, it falls back to the first beat AND SAYS SO",
        len(_ns_spans) == 1 and abs(_ns_spans[0][0] - 9.6) < 0.01
        and "first beat" in _or_err.getvalue(),
        "spans %s, stderr %r"
        % ([("%.2f" % a, "%.2f" % b) for a, b in _ns_spans],
           _or_err.getvalue().strip()[:60]))

    # ---- floor% must not re-report the excised interval as a detector fault.
    #
    # Wiring BadDataMark excision in raised P10's floor% from 0.67% to 3.15%
    # and with it AMP_FLOOR_3.15%, on a file whose analysable signal had not
    # changed at all: fill_missing bridges the marked samples with a straight
    # line, every detection landing on it is sub-QRS by construction, and the
    # floor was counting our own interpolation as neurokit misbehaving.  These
    # two checks pin both halves -- that the restricted figure is the one
    # reported, and that a file with nothing excised is left exactly as it was.
    _ff_args = argparse.Namespace(
        species="pig", minutes=0.0, lead=0, band=None, refractory=None,
        qc_min=DEFAULTS["qc_min"], clip_k=DEFAULTS["clip_k"],
        chunk=DEFAULTS["chunk_s"], refill=True, refill_gap_mult=3.0,
        refill_rounds=3, nosig=True)
    _ff_clean = os.path.join(_mkd, "P21_floorclean.ascii")
    _mk_write(_ff_clean, 5000, set())
    _ff_err = _io.StringIO()
    with _ctx.redirect_stderr(_ff_err):
        _r_clean = analyse(_ff_clean, _ff_args, SPECIES["pig"])
        _r_mark = analyse(_mk1, _ff_args, SPECIES["pig"])
    chk("with nothing excised, floor% is untouched by the restriction",
        not _r_clean.excised_s
        and _r_clean.floor_removed == _r_clean.floor_removed_all
        and _r_clean.floor_excised == 0,
        "floor %.4f vs all %.4f, excised %d"
        % (_r_clean.floor_removed, _r_clean.floor_removed_all,
           _r_clean.floor_excised))
    chk("floor rejections inside an excised span are counted apart, "
        "never against the detector",
        _r_mark.excised_s > 0
        and _r_mark.floor_removed <= _r_mark.floor_removed_all + 1e-12
        and _r_mark.floor_excised >= 0
        and (_r_mark.floor_removed > AMP_FLOOR_NOTE_FRAC
             or not any(f.startswith("AMP_FLOOR")
                        for f in _r_mark.integrity["flags"])),
        "floor %.4f vs all %.4f, %d rejected inside the excision"
        % (_r_mark.floor_removed, _r_mark.floor_removed_all,
           _r_mark.floor_excised))
    print()

    # ----------------------------------------------------------------- [22]
    print("  [22] comparing against Ponemah: the two clocks, and the window")
    # The failure this section exists to prevent: Ponemah times its beats from
    # ITS FIRST BEAT, a waveform is timed from SAMPLE ZERO, and on P10 those
    # differ by 0.254 s against a 50 ms matching window.  Unmeasured, two
    # lists that agree perfectly score zero.
    _al_true = np.arange(20.0, 260.0, 0.6)            # 100 bpm, 400 beats
    _al_shift = 0.2537
    _al_a = _al_true.copy()
    _al_b = _al_true + _al_shift
    _lag, _lagn, _lagcov = peak_train_lag(_al_a, _al_b)
    chk("a constant offset between two beat trains is MEASURED, not assumed",
        abs(_lag - _al_shift) < 0.002,
        "measured %+.4f s, constructed %+.4f s" % (_lag, _al_shift))
    chk("and the evidence is COVERAGE, which a periodic train cannot fake",
        _lagcov > 0.99 and _lagn >= len(_al_true) - 1,
        "%d of %d beat(s) find a partner (%.1f%%)"
        % (_lagn, len(_al_true), 100.0 * _lagcov))
    _m_no, _fp_no, _fn_no = match_peaks(_al_a, _al_b, 0.05)
    _m_al, _fp_al, _fn_al = match_peaks(_al_a + _lag, _al_b, 0.05)
    chk("unaligned, the 0.25 s shift scores these IDENTICAL trains at zero",
        len(_m_no) == 0,
        "%d matched of %d -- this is the silent failure" % (len(_m_no),
                                                            len(_al_true)))
    chk("aligned, the same two trains score perfectly",
        len(_m_al) == len(_al_true) and not _fp_al and not _fn_al,
        "%d matched, %d FP, %d FN" % (len(_m_al), len(_fp_al), len(_fn_al)))
    # THE BUG THIS SECTION FOUND.  A regular train aligns just as well one
    # whole RR away, so the candidate at +0.854 s covers exactly as much as the
    # one at +0.254 s.  Scoring by histogram height could not tell them apart
    # and returned -0.946 s.  The smallest shift is the only one the evidence
    # supports, and it must be the one chosen.
    chk("a whole-RR alias is NOT preferred over the smallest true shift",
        abs(_lag) <= 0.6 / 2.0 + 1e-9,
        "chose %+.4f s with RR 0.600 s -- an alias would sit near %+.4f"
        % (_lag, _al_shift - 0.6))
    # Jitter must survive: the lag is a CONSTANT, not a per-beat correction.
    _rng_j = np.random.RandomState(7)
    _al_bj = _al_true + _al_shift + _rng_j.normal(0, 0.004, len(_al_true))
    _lagj, _, _covj = peak_train_lag(_al_a, _al_bj)
    chk("per-beat jitter does not move the measured offset",
        abs(_lagj - _al_shift) < 0.003 and _covj > 0.99,
        "measured %+.4f s at %.1f%% coverage under 4 ms jitter"
        % (_lagj, 100.0 * _covj))
    # An unrelated pair must NOT produce a confident lag.
    _al_c = np.sort(_rng_j.uniform(20.0, 260.0, 400))
    _, _, _cov_u = peak_train_lag(_al_a, _al_c)
    chk("two unrelated trains do NOT yield a confident offset",
        _cov_u < 0.5, "coverage %.1f%% (a real one measured %.1f%%)"
        % (100.0 * _cov_u, 100.0 * _lagcov))

    # ---- end to end through cmd_compare, which is where the window is cut.
    _cmpd = os.path.join(tmp, "cmp")
    os.makedirs(_cmpd, exist_ok=True)
    _cmp_ref = os.path.join(_cmpd, "ponemah.peaks.csv")
    with open(_cmp_ref, "w", newline="") as _f:
        _f.write("# %s\n" % VERSION)
        _f.write("# origin: Ponemah Cycle table, ChannelContextId 3\n")
        _f.write("# subject_channel: 4\n")
        _f.write("# fs_hz: 500.0000\n")
        _f.write("# duration_s: %.4f\n" % (_al_true[-1] - _al_true[0]))
        _w = csv.DictWriter(_f, fieldnames=PEAK_FIELDS)
        _w.writeheader()
        for _t in np.arange(20.0, 3600.0, 0.6):       # an hour of beats
            _w.writerow(dict(time_s="%.4f" % _t, sample=int(round(_t * 500)),
                             amp="", rhythm="", cluster=-1, qc=0,
                             source="PONEMAH", keep=1, note=""))
    _cmp_auto = os.path.join(_cmpd, "ours.peaks.csv")
    with open(_cmp_auto, "w", newline="") as _f:
        _f.write("# %s\n" % VERSION)
        _f.write("# fs_hz: 500.0000\n")
        _f.write("# duration_s: 260.0000\n")
        _f.write("# lead_name: ECG_ch3\n")
        _w = csv.DictWriter(_f, fieldnames=PEAK_FIELDS)
        _w.writeheader()
        for _t in _al_true:
            _w.writerow(dict(time_s="%.4f" % _t, sample=int(round(_t * 500)),
                             amp="", rhythm="", cluster=-1, qc=0,
                             source="AUTO", keep=1, note=""))
    _cmp_args = argparse.Namespace(
        species="pig", auto=_cmp_auto, manual=_cmp_ref, input=None,
        match_tol=None, max_windows=5, align=True, align_max=5.0,
        minutes=0.0, lead=None, band=None, refractory=None,
        qc_min=DEFAULTS["qc_min"], clip_k=DEFAULTS["clip_k"],
        chunk=DEFAULTS["chunk_s"], refill=True, refill_gap_mult=3.0,
        refill_rounds=3, nosig=True)
    _cmp_io = _io.StringIO()
    with _ctx.redirect_stdout(_cmp_io):
        cmd_compare(_cmp_args)
    _cmp_txt = _cmp_io.getvalue()
    chk("compare SAYS it is reading Ponemah's own detections, not a review",
        "PONEMAH's own detection" in _cmp_txt
        and "unedited" not in _cmp_txt,
        "the old code called this 'unedited' and voided the run")
    chk("compare reports the measured offset rather than applying it silently",
        "clock offset" in _cmp_txt and "measured, not assumed" in _cmp_txt)
    # --auto omitted is the form the Ponemah workflow needs.
    _cmp_args2 = argparse.Namespace(**vars(_cmp_args))
    _cmp_args2.auto = None
    _cmp_args2.input = None
    _cmp_err = _io.StringIO()
    with _ctx.redirect_stderr(_cmp_err):
        _rc_c = cmd_compare(_cmp_args2)
    chk("compare with neither --auto nor --input refuses with a reason",
        _rc_c == 2 and "--auto" in _cmp_err.getvalue(),
        _cmp_err.getvalue().strip()[:60])
    print()

    # ---------------------------------------------------------------- [23]
    # WHICH CLOCK THE ANSWER IS EXPRESSED IN.
    #
    # compare measures an offset between the two beat trains and removes it.
    # It removed it by shifting (a) -- the RECORDING -- onto (b)'s origin,
    # which scores correctly and then reports every time in a coordinate
    # system nothing else in the tool uses.  Two things went wrong downstream.
    #
    #   * The window clip that follows compares (b) against r.dur, which is
    #     in waveform seconds.  With (b) still on its own clock the cut
    #     landed 254 ms off at both ends.
    #   * The closing hint offered `show --peaks (b)`, and `show` draws a
    #     peak file's raw times.  Every marker would have been drawn a
    #     quarter second from its beat, on the one display whose purpose is
    #     to judge whether markers sit on beats.
    #
    # So the fixture below pins the DIRECTION, not merely the magnitude: the
    # disagreements are written out and their times must match the waveform
    # positions they were built at, not those positions plus the offset.
    print("[23] compare: which clock, the worst window, and a displayable diff")
    _dfd = os.path.join(tmp, "diff")
    os.makedirs(_dfd, exist_ok=True)

    _dx_base = np.arange(20.0, 260.0, 0.6)      # agreed beats, waveform clock
    _dx_shift = 0.25                            # (b) - (a), as on P10
    _dx_fp = [60.5, 180.5, 181.1, 181.7, 182.3, 182.9]   # 1 in w1, 5 in w3
    _dx_fn = [120.5, 121.1]                              # 2 in w2

    _dx_auto_t = np.sort(np.concatenate([_dx_base, np.array(_dx_fp)]))
    _dx_ref_t = np.sort(np.concatenate([_dx_base, np.array(_dx_fn)])) + _dx_shift

    _dx_autop = os.path.join(_dfd, "ours.peaks.csv")
    with open(_dx_autop, "w", newline="") as _f:
        _f.write("# %s\n# fs_hz: 500.0000\n# duration_s: 260.0000\n"
                 "# lead_name: ECG_ch3\n" % VERSION)
        _w = csv.DictWriter(_f, fieldnames=PEAK_FIELDS)
        _w.writeheader()
        for _t in _dx_auto_t:
            _w.writerow(dict(time_s="%.4f" % _t, sample=int(round(_t * 500)),
                             amp="", rhythm="", cluster=-1, qc=0,
                             source="AUTO", keep=1, note=""))
    _dx_refp = os.path.join(_dfd, "ponemah.peaks.csv")
    with open(_dx_refp, "w", newline="") as _f:
        _f.write("# %s\n# fs_hz: 500.0000\n# duration_s: 260.0000\n"
                 "# subject_channel: 3\n" % VERSION)
        _w = csv.DictWriter(_f, fieldnames=PEAK_FIELDS)
        _w.writeheader()
        for _t in _dx_ref_t:
            _w.writerow(dict(time_s="%.4f" % _t, sample=int(round(_t * 500)),
                             amp="", rhythm="", cluster=-1, qc=0,
                             source="PONEMAH", keep=1, note=""))

    _dx_out = os.path.join(_dfd, "sub", "diff.csv")   # 'sub' must be created
    _dx_args = argparse.Namespace(
        species="pig", auto=_dx_autop, manual=_dx_refp, input=None,
        match_tol=None, max_windows=20, align=True, align_max=5.0,
        export_diff=_dx_out,
        minutes=0.0, lead=None, band=None, refractory=None,
        qc_min=DEFAULTS["qc_min"], clip_k=DEFAULTS["clip_k"],
        chunk=DEFAULTS["chunk_s"], refill=True, refill_gap_mult=3.0,
        refill_rounds=3, nosig=True)
    _dx_io = _io.StringIO()
    with _ctx.redirect_stdout(_dx_io):
        cmd_compare(_dx_args)
    _dx_txt = _dx_io.getvalue()

    chk("compare --export-diff creates missing parent directories",
        os.path.isfile(_dx_out), _dx_out)

    _dx_t, _dx_meta, _dx_rows = read_peaks(_dx_out)
    _got_fp = sorted(round(float(d["time_s"]), 4) for d in _dx_rows
                     if d.get("source") == "FP")
    _got_fn = sorted(round(float(d["time_s"]), 4) for d in _dx_rows
                     if d.get("source") == "FN")
    _got_tp = [d for d in _dx_rows if d.get("source") == "TP"]

    chk("the diff file finds exactly the planted false positives",
        _got_fp == sorted(_dx_fp), "got %s" % (_got_fp,))
    # THE DIRECTION CHECK.  The reference beats were written at
    # waveform+0.25; if the offset were removed the other way about these
    # would read 120.75 and 121.35.
    chk("FN times are on the RECORDING's clock, not the reference's",
        _got_fn == sorted(_dx_fn),
        "got %s, want %s -- the wrong direction gives %s"
        % (_got_fn, sorted(_dx_fn),
           [round(v + _dx_shift, 4) for v in _dx_fn]))
    chk("agreed beats are carried in the diff file so `show` can scale to them",
        len(_got_tp) == len(_dx_base),
        "%d TP row(s) for %d agreed beat(s)" % (len(_got_tp), len(_dx_base)))
    chk("every diff row is readable as a peak file",
        len(_dx_t) == len(_dx_rows) == len(_got_fp) + len(_got_fn) + len(_got_tp))
    chk("the diff file states its own composition in its header",
        _dx_meta.get("n_fp") == "6" and _dx_meta.get("n_fn") == "2",
        "header says n_fp=%r n_fn=%r"
        % (_dx_meta.get("n_fp"), _dx_meta.get("n_fn")))

    # The hint must name window 3 (5 FPs), not window 1 (1 FP, and earlier).
    chk("the inspect hint names the WORST window, not the first one",
        "--start 180" in _dx_txt and "window 3, the worst one" in _dx_txt,
        "hint said: %s" % next((_l.strip() for _l in _dx_txt.splitlines()
                                if "--start" in _l), "(no --start line)"))
    chk("the printed command carries --mark-source so the scale stays honest",
        "--mark-source FP,FN" in _dx_txt)
    # Two commands now, and the second one has a job the first cannot do.
    # The overview is a 10 s panel: 100 ms per column against a 14 ms QRS,
    # which is an envelope.  It is the right picture for "where is the
    # trouble" and the wrong one for "is this FP sitting on a QRS".  Until
    # this build the overview was the ONLY thing offered, so the second
    # question had no command at all.
    _dx_secs = [float(_m) for _l in _dx_txt.splitlines()
                for _m in re.findall(r"--seconds\s+([0-9.]+)", _l)]
    chk("--export-diff offers a zoom as well as the window overview",
        len(_dx_secs) >= 2, "printed --seconds %s" % (_dx_secs,))
    _dx_zoom = panel_resolution(min(_dx_secs) if _dx_secs else 10.0, 100,
                                500.0, PIG.qrs_width_ms)
    chk("...and the zoom it prints RESOLVES a QRS when run",
        _dx_zoom["verdict"] == "morphology",
        "--seconds %g -> %.2f col per QRS, verdict %s"
        % (min(_dx_secs) if _dx_secs else -1, _dx_zoom["cols_per_qrs"],
           _dx_zoom["verdict"]))

    # Without --export-diff the tool must NOT offer the reference file to
    # `show`, which is what it used to do.
    _dx_args2 = argparse.Namespace(**vars(_dx_args))
    _dx_args2.export_diff = None
    _dx_io2 = _io.StringIO()
    with _ctx.redirect_stdout(_dx_io2):
        cmd_compare(_dx_args2)
    _dx_txt2 = _dx_io2.getvalue()
    chk("without --export-diff compare does NOT hand the reference to `show`",
        "show --input FILE --peaks" not in _dx_txt2
        and "--export-diff" in _dx_txt2,
        "the old hint drew every marker %.3f s off its beat" % _dx_shift)

    # Paths with spaces: every Ponemah path in this project has one.
    chk("printed paths are shell-quoted",
        _shq("/a b/c.PnmWav") in ("'/a b/c.PnmWav'", '"/a b/c.PnmWav"'),
        _shq("/a b/c.PnmWav"))

    # The companion-file warning must not fire on the normal workflow, and
    # must still fire on the mistake it exists to catch.
    _sib_wav = "/d/08062023 P10/08062023 P10.P10.20230806195959.PnmWav"
    _sib_mrk = "/d/08062023 P10/08062023 P10.1.P10.PnmMarks"
    chk("a PnmWav and its own PnmMarks are recognised as companion files",
        _pnm_siblings(_sib_wav, _sib_mrk),
        "these differ by construction and are the same recording")
    chk("a DIFFERENT animal in the same directory still warns",
        not _pnm_siblings(_sib_wav, "/d/08062023 P10/08062023 P21.1.P21.PnmMarks"),
        "the experiment token differs, so this must stay a warning")
    chk("the same name in a different directory still warns",
        not _pnm_siblings(_sib_wav, "/other/08062023 P10.1.P10.PnmMarks"))
    chk("non-Ponemah files are never called companions",
        not _pnm_siblings("/d/a.edf", "/d/a.peaks.csv"))

    # The row filter must move with the array it is paired with.
    chk("_row_time_in honours the clock shift it is given",
        _row_time_in({"time_s": "10.2"}, 0.0, 10.0, {}, shift_s=-0.25)
        and not _row_time_in({"time_s": "10.2"}, 0.0, 10.0, {}),
        "10.2 s is outside [0,10] until the -0.25 s shift is applied")

    # Ponemah against Ponemah: two electrodes, one heart.  A channel mismatch
    # here is the measurement, not a mistake, and must not be warned about --
    # the warning tells the reader to re-export onto one lead, which would
    # destroy exactly the baseline being sought.
    _il_a = os.path.join(_dfd, "pon_ch3.peaks.csv")
    with open(_il_a, "w", newline="") as _f:
        _f.write("# %s\n# fs_hz: 500.0000\n# duration_s: 260.0000\n"
                 "# origin: Ponemah Cycle table, ChannelContextId 2\n"
                 "# subject_channel: 3\n" % VERSION)
        _w = csv.DictWriter(_f, fieldnames=PEAK_FIELDS)
        _w.writeheader()
        for _t in _dx_base:
            _w.writerow(dict(time_s="%.4f" % _t, sample="", amp="", rhythm="",
                             cluster=-1, qc=0, source="PONEMAH", keep=1,
                             note=""))
    _il_b = os.path.join(_dfd, "pon_ch4.peaks.csv")
    with open(_il_b, "w", newline="") as _f:
        _f.write("# %s\n# fs_hz: 500.0000\n# duration_s: 260.0000\n"
                 "# origin: Ponemah Cycle table, ChannelContextId 3\n"
                 "# subject_channel: 4\n" % VERSION)
        _w = csv.DictWriter(_f, fieldnames=PEAK_FIELDS)
        _w.writeheader()
        for _t in _dx_ref_t:
            _w.writerow(dict(time_s="%.4f" % _t, sample="", amp="", rhythm="",
                             cluster=-1, qc=0, source="PONEMAH", keep=1,
                             note=""))

    _il_args = argparse.Namespace(**vars(_dx_args))
    _il_args.auto = _il_a             # Ponemah channel 3
    _il_args.manual = _il_b           # Ponemah channel 4
    _il_args.export_diff = None
    _il_io = _io.StringIO()
    with _ctx.redirect_stdout(_il_io):
        cmd_compare(_il_args)
    _il_txt = _il_io.getvalue()
    chk("Ponemah against Ponemah is called an INTER-LEAD comparison",
        "INTER-LEAD" in _il_txt
        and "subject channel 3" in _il_txt and "subject channel 4" in _il_txt,
        "both sides are Ponemah on one heart -- this is the baseline, not an "
        "error")
    chk("an inter-lead run is NOT told to re-export onto one lead",
        "Re-export (b) for this lead" not in _il_txt
        and "DIFFERENT LEADS" not in _il_txt,
        "that advice would destroy the baseline being measured")
    chk("(a)'s channel is read from a Ponemah header, which has no lead_name",
        "(a) subject channel 3" in _il_txt,
        "without the subject_channel fall-back this check goes silent")

    # ...but a DETECTION scored against the wrong Ponemah lead still warns.
    _il_args2 = argparse.Namespace(**vars(_dx_args))
    _il_args2.manual = _il_b          # (a) stays our detection on ECG_ch3
    _il_args2.export_diff = None
    _il_io2 = _io.StringIO()
    with _ctx.redirect_stdout(_il_io2):
        cmd_compare(_il_args2)
    _il_txt2 = _il_io2.getvalue()
    chk("a DETECTION scored against the wrong Ponemah lead still warns",
        "DIFFERENT LEADS" in _il_txt2 and "INTER-LEAD" not in _il_txt2,
        "(a) is ECG_ch3, (b) is channel 4 -- that one IS a mistake")

    # show --mark-source: draw a subset, scale to everything.
    _fm = filter_marks_by_source(_dx_rows, {"FP", "FN"})
    chk("--mark-source draws only the requested sources",
        len(_fm) == len(_dx_fp) + len(_dx_fn)
        and sorted(round(float(v), 4) for v in _fm)
        == sorted(_dx_fp + _dx_fn),
        "%d mark(s) from %d row(s)" % (len(_fm), len(_dx_rows)))
    chk("--mark-source leaves the SCALE set untouched",
        len(_dx_t) > len(_fm),
        "scale from %d peak(s), marks %d -- if these were equal the panel "
        "would be scaled to the disputed points alone"
        % (len(_dx_t), len(_fm)))
    chk("--mark-source still honours keep=0",
        len(filter_marks_by_source(
            [{"source": "FP", "keep": "0", "time_s": "1.0"},
             {"source": "FP", "keep": "1", "time_s": "2.0"}], {"FP"})) == 1)
    print()

    # ---------------------------------------------------------------- [24]
    # NUMERATOR AND DENOMINATOR MUST BE EXCISED TOGETHER.
    #
    # `marks --export-beats` writes bad-data beats keep=0, and read_peaks
    # drops them -- so the beat count that reaches `compare` is already
    # cleaned.  `duration_s` is the raw span.  Dividing one by the other
    # understated P10's rate by the marked fraction, 8.41%: Ponemah's two
    # leads printed 53.69 and 60.32 bpm where the honest figures are 58.6 and
    # 65.8.  The ratio survived, so nothing looked wrong.
    print("[24] rate: the denominator must lose the same seconds as the count")
    _rd = os.path.join(tmp, "rate")
    os.makedirs(_rd, exist_ok=True)

    def _wr_pon(p, times, dur_s, an_s=None, n_bad=0, ch="3", ctxid=2):
        with open(p, "w", newline="") as _f:
            _f.write("# %s\n# fs_hz: 500.0000\n" % VERSION)
            _f.write("# origin: Ponemah Cycle table, ChannelContextId %d\n"
                     % ctxid)
            _f.write("# subject_channel: %s\n" % ch)
            _f.write("# duration_s: %.4f\n" % dur_s)
            if an_s is not None:
                _f.write("# analysable_s: %.4f\n" % an_s)
            _f.write("# n_in_bad_data: %d  (written keep=0)\n" % n_bad)
            _w2 = csv.DictWriter(_f, fieldnames=PEAK_FIELDS)
            _w2.writeheader()
            for _t in times:
                _w2.writerow(dict(time_s="%.4f" % _t, sample="", amp="",
                                  rhythm="", cluster=-1, qc=0,
                                  source="PONEMAH", keep=1, note=""))

    # 100 beats survive; the file says 120 s span of which 20 s was excised.
    _rt = np.arange(1.0, 101.0, 1.0)
    _rd_a = os.path.join(_rd, "a.csv")
    _rd_b = os.path.join(_rd, "b.csv")
    _wr_pon(_rd_a, _rt, 120.0, an_s=100.0, n_bad=20, ch="3", ctxid=2)
    _wr_pon(_rd_b, _rt, 120.0, an_s=100.0, n_bad=20, ch="4", ctxid=3)
    _rd_args = argparse.Namespace(**vars(_dx_args))
    _rd_args.auto, _rd_args.manual = _rd_a, _rd_b
    _rd_args.input, _rd_args.export_diff = None, None
    _rd_io = _io.StringIO()
    with _ctx.redirect_stdout(_rd_io):
        cmd_compare(_rd_args)
    _rd_txt = _rd_io.getvalue()
    chk("with analysable_s present the rate divides by the EXCISED span",
        "both over 100.0 s" in _rd_txt and "ANALYSABLE" in _rd_txt,
        "100 beats over 100 s is 60 bpm; over the raw 120 s it reads 50")
    chk("and the resulting rate is the honest one",
        "rate from (a) 60.00 bpm" in _rd_txt,
        next((_l.strip() for _l in _rd_txt.splitlines()
              if "rate from (a)" in _l), "(no rate line)"))

    # An OLD export -- no analysable_s, but beats were still removed.  The
    # tool must not silently divide by the raw span.
    _rd_a2 = os.path.join(_rd, "a_old.csv")
    _rd_b2 = os.path.join(_rd, "b_old.csv")
    _wr_pon(_rd_a2, _rt, 120.0, an_s=None, n_bad=20, ch="3", ctxid=2)
    _wr_pon(_rd_b2, _rt, 120.0, an_s=None, n_bad=20, ch="4", ctxid=3)
    _rd_args2 = argparse.Namespace(**vars(_rd_args))
    _rd_args2.auto, _rd_args2.manual = _rd_a2, _rd_b2
    _rd_io2 = _io.StringIO()
    with _ctx.redirect_stdout(_rd_io2):
        cmd_compare(_rd_args2)
    _rd_txt2 = _rd_io2.getvalue()
    chk("an export predating analysable_s has its bias NAMED, not hidden",
        "BOTH RATES ARE BIASED LOW" in _rd_txt2,
        "the count was cleaned and the span was not -- say so")
    chk("...and the advice is to re-export, not to trust the figure",
        "Re-run `marks --export-beats`" in _rd_txt2)

    # A file with nothing excluded must NOT be warned about.
    _rd_a3 = os.path.join(_rd, "a_clean.csv")
    _rd_b3 = os.path.join(_rd, "b_clean.csv")
    _wr_pon(_rd_a3, _rt, 100.0, an_s=None, n_bad=0, ch="3", ctxid=2)
    _wr_pon(_rd_b3, _rt, 100.0, an_s=None, n_bad=0, ch="4", ctxid=3)
    _rd_args3 = argparse.Namespace(**vars(_rd_args))
    _rd_args3.auto, _rd_args3.manual = _rd_a3, _rd_b3
    _rd_io3 = _io.StringIO()
    with _ctx.redirect_stdout(_rd_io3):
        cmd_compare(_rd_args3)
    chk("a file with nothing excluded raises no bias warning",
        "BIASED LOW" not in _rd_io3.getvalue(),
        "no beats were removed, so the raw span IS the analysable span")

    # marks --export-beats must actually emit the header the above relies on.
    _me_ctx = dict(ctx=2, SubjectChannelId=3, fs=500.0,
                   times=np.array([10 * NET_TICKS_PER_S,
                                   40 * NET_TICKS_PER_S], dtype=np.int64),
                   span_s=30.0)
    _me_p = os.path.join(_rd, "exported.csv")
    write_marks_peaks(_me_p, _me_ctx, 10 * NET_TICKS_PER_S, "/x/y.PnmMarks",
                      bad_spans=[(20 * NET_TICKS_PER_S,
                                  25 * NET_TICKS_PER_S)])
    _, _me_meta, _ = read_peaks(_me_p)
    chk("marks --export-beats records the seconds its exclusion removed",
        _me_meta.get("excluded_s") == "5.0000"
        and _me_meta.get("analysable_s") == "25.0000",
        "excluded_s=%r analysable_s=%r (span 30 s, one 5 s bad interval)"
        % (_me_meta.get("excluded_s"), _me_meta.get("analysable_s")))
    # A bad interval lying outside the context's own span must not be counted.
    write_marks_peaks(_me_p, _me_ctx, 10 * NET_TICKS_PER_S, "/x/y.PnmMarks",
                      bad_spans=[(100 * NET_TICKS_PER_S,
                                  200 * NET_TICKS_PER_S)])
    _, _me_meta2, _ = read_peaks(_me_p)
    chk("a bad interval outside the context's span removes no time from it",
        _me_meta2.get("excluded_s") == "0.0000",
        "got %r" % _me_meta2.get("excluded_s"))

    # ---- the window must cut BOTH trains.
    #
    # (a) is normally this build's detection, which already stops at the read
    # window, so cutting only (b) was invisible.  Give (a) a whole-record peak
    # file -- which is exactly what scoring Ponemah's two leads against each
    # other over a windowed recording does -- and the old code left (a) at
    # full length while (b) was cut, collapsing PPV for no reason but the
    # mismatch.
    _cw_long = os.path.join(_rd, "whole_record.csv")
    with open(_cw_long, "w", newline="") as _f:
        _f.write("# %s\n# fs_hz: 500.0000\n# duration_s: 10000.0000\n"
                 % VERSION)
        _w2 = csv.DictWriter(_f, fieldnames=PEAK_FIELDS)
        _w2.writeheader()
        for _t in np.arange(0.5, 10000.0, 1.0):
            _w2.writerow(dict(time_s="%.4f" % _t, sample="", amp="",
                              rhythm="", cluster=-1, qc=0, source="AUTO",
                              keep=1, note=""))
    _cw_args = argparse.Namespace(**vars(_dx_args))
    _cw_args.input = [good]           # the synthetic recording built in [2]
    _cw_args.auto = _cw_long
    _cw_args.manual = _cw_long
    _cw_args.align = False            # isolate the clip from the offset
    _cw_args.export_diff = None
    _cw_io = _io.StringIO()
    with _ctx.redirect_stdout(_cw_io):
        with _ctx.redirect_stderr(_io.StringIO()):
            cmd_compare(_cw_args)
    _cw_txt = _cw_io.getvalue()
    chk("the read window cuts (a) too, not only (b)",
        "(a) is a peak file covering more than the read window" in _cw_txt,
        "a 10,000 s peak file against a short recording must be cut")
    _cw_kept = re.search(r"it is cut too:\s*\n\s*([\d,]+) of ([\d,]+)", _cw_txt)
    chk("and the cut leaves only the beats inside the window",
        bool(_cw_kept)
        and int(_cw_kept.group(1).replace(",", ""))
        < int(_cw_kept.group(2).replace(",", "")),
        _cw_kept.group(0).replace("\n", " ") if _cw_kept else "(no cut line)")

    # ---- (a)'s own clock, when (a) is a FILE, must be measured too.
    #
    # The window clip, the 60 s window numbers and everything --export-diff
    # writes are in RECORDING seconds.  When (a) is this build's detection
    # that holds by construction.  When (a) is a peak file it was an
    # ASSUMPTION -- and on a Ponemah export it is wrong by the 0.254 s
    # between the sidecar's first beat and sample zero.  Sub-beat on a
    # 30-minute window, but it is the same quarter second that read 0%
    # sensitivity three builds ago, and the recording's own detection is
    # right there to measure against.
    _ra_r = analyse(good, _ff_args, SPECIES["pig"])
    _ra_t = np.asarray(_ra_r.anchors, dtype=float) / float(_ra_r.fs)
    _ra_off = 0.40
    _ra_p = os.path.join(_rd, "offset_by_hand.csv")
    with open(_ra_p, "w", newline="") as _f:
        _f.write("# %s\n# fs_hz: %.4f\n# duration_s: %.4f\n"
                 % (VERSION, _ra_r.fs, _ra_r.dur))
        _w2 = csv.DictWriter(_f, fieldnames=PEAK_FIELDS)
        _w2.writeheader()
        for _t in _ra_t + _ra_off:
            _w2.writerow(dict(time_s="%.4f" % _t, sample="", amp="",
                              rhythm="", cluster=-1, qc=0, source="AUTO",
                              keep=1, note=""))
    _ra_args = argparse.Namespace(**vars(_dx_args))
    _ra_args.input = [good]
    _ra_args.auto = _ra_p
    _ra_args.manual = _ra_p
    _ra_args.align = True
    _ra_args.export_diff = os.path.join(_rd, "ra_diff.csv")
    _ra_io = _io.StringIO()
    with _ctx.redirect_stdout(_ra_io):
        with _ctx.redirect_stderr(_io.StringIO()):
            cmd_compare(_ra_args)
    _ra_txt = _ra_io.getvalue()
    chk("(a)'s clock is CHECKED against the recording, not assumed",
        "its clock was checked against this" in _ra_txt,
        "a peak file need not share the recording's origin")
    _ra_m = re.search(r"recording's own detection:\s*([-+][\d.]+) s", _ra_txt)
    chk("...and the hand-made 0.400 s offset is what it measures",
        bool(_ra_m) and abs(float(_ra_m.group(1)) + _ra_off) < 0.02,
        "measured %s s against a constructed %+.3f s"
        % (_ra_m.group(1) if _ra_m else "(none)", -_ra_off))
    # The payoff: the diff file must land on the recording, not 0.4 s off it.
    if os.path.isfile(_ra_args.export_diff):
        _ra_dt, _, _ra_rows = read_peaks(_ra_args.export_diff)
        _ra_tp = sorted(float(d["time_s"]) for d in _ra_rows
                        if d.get("source") == "TP")
        chk("so --export-diff lands on the recording's beats, not 0.4 s off",
            bool(_ra_tp)
            and min(abs(_ra_tp[0] - v) for v in _ra_t) < 0.02,
            "first TP at %.4f s; nearest real beat %.4f s"
            % (_ra_tp[0], min(_ra_t, key=lambda v: abs(v - _ra_tp[0])))
            if _ra_tp else "(no TP rows)")

    # A detection-vs-file run must NOT print the (a)-clock line: there is no
    # file on the (a) side to have a clock of its own.
    _ra_args2 = argparse.Namespace(**vars(_ra_args))
    _ra_args2.auto = None
    _ra_args2.export_diff = None
    _ra_io2 = _io.StringIO()
    with _ctx.redirect_stdout(_ra_io2):
        with _ctx.redirect_stderr(_io.StringIO()):
            cmd_compare(_ra_args2)
    chk("with (a) detected here, no (a)-clock check is claimed",
        "its clock was checked against this" not in _ra_io2.getvalue(),
        "the detection IS the recording's clock; checking it would be theatre")
    print()

    # ---------------------------------------------------------------- [25]
    # THE THIRD LEAD.
    #
    # Two-way scoring can only report that (a) and (b) disagree.  On P10 that
    # left PPV 92.89% standing as though it measured us, when Ponemah's own
    # two leads disagree with each other by 7,902 beats -- so most of those
    # "false positives" could as easily be (b)'s misses.  A third electrode
    # on the same heart settles it, because every lead sees every beat.
    #
    # The fixture makes the answer known by construction: of 6 beats (a) has
    # and (b) does not, the arbiter is given 4; of 2 beats (b) has and (a)
    # does not, the arbiter is given 1.
    print("[25] the third lead: turning a disagreement into a verdict")
    _ad = os.path.join(tmp, "arb")
    os.makedirs(_ad, exist_ok=True)

    def _wr_lead(p, times, ch, shift=0.0):
        with open(p, "w", newline="") as _f:
            _f.write("# %s\n# fs_hz: 500.0000\n# duration_s: 260.0000\n"
                     "# origin: Ponemah Cycle table\n"
                     "# subject_channel: %s\n" % (VERSION, ch))
            _w2 = csv.DictWriter(_f, fieldnames=PEAK_FIELDS)
            _w2.writeheader()
            for _t in np.sort(np.asarray(times, float)) + shift:
                _w2.writerow(dict(time_s="%.4f" % _t, sample="", amp="",
                                  rhythm="", cluster=-1, qc=0,
                                  source="PONEMAH", keep=1, note=""))

    _ab_fp_seen = _dx_fp[:4]          # 4 of the 6 confirmed
    _ab_fn_seen = _dx_fn[:1]          # 1 of the 2 confirmed
    _ab_p = os.path.join(_ad, "ch4.csv")
    _wr_lead(_ab_p, np.concatenate([_dx_base, _ab_fp_seen, _ab_fn_seen]),
             ch="4", shift=-0.13)     # its own origin, to be measured away

    # ---- the classifier on its own, before any I/O is involved.
    _u_auto = np.array([1.0, 2.0, 3.0])
    _u_man = np.array([1.0, 4.0])
    _u_matched, _u_fp, _u_fn = match_peaks(_u_auto, _u_man, 0.08)
    _u = arbitrate(_u_auto, _u_man, _u_fp, _u_fn, np.array([2.0, 9.0]), 0.08)
    chk("arbitrate splits (a)-only beats by whether the third lead has them",
        [_u_auto[i] for i in _u["fp_yes"]] == [2.0]
        and [_u_auto[i] for i in _u["fp_no"]] == [3.0],
        "confirmed %s, unconfirmed %s"
        % ([_u_auto[i] for i in _u["fp_yes"]],
           [_u_auto[i] for i in _u["fp_no"]]))
    chk("...and splits (b)-only beats the same way",
        _u["fn_yes"] == [] and [_u_man[j] for j in _u["fn_no"]] == [4.0],
        "our misses %s, (b)-alone %s"
        % ([_u_man[j] for j in _u["fn_yes"]],
           [_u_man[j] for j in _u["fn_no"]]))

    # ---- end to end.
    _ab_out = os.path.join(_ad, "diff.csv")
    _ab_args = argparse.Namespace(**vars(_dx_args))
    _ab_args.arbiter = _ab_p
    _ab_args.export_diff = _ab_out
    _ab_io = _io.StringIO()
    with _ctx.redirect_stdout(_ab_io):
        cmd_compare(_ab_args)
    _ab_txt = _ab_io.getvalue()

    # The fixture writes the arbiter at (times - 0.13), so the offset this
    # must report is arbiter-minus-(a) = -0.13.  Pinning the SIGN and not
    # merely the magnitude is the point: a lag applied the wrong way round
    # still lines two trains up, and then everything downstream is off by
    # twice the offset.
    chk("the arbiter's own clock is measured, not assumed",
        re.search(r"clock offset vs \(a\):\s*-0\.13", _ab_txt) is not None,
        next((_l.strip() for _l in _ab_txt.splitlines()
              if "clock offset vs (a)" in _l), "(no line)"))
    chk("4 of the 6 disputed detections are confirmed by the third lead",
        re.search(r"4\s+the arbiter has too\s+->\s+\(b\) MISSED", _ab_txt)
        is not None and
        re.search(r"2\s+in neither other lead\s+->\s+unconfirmed", _ab_txt)
        is not None,
        "planted 4 confirmed and 2 not")
    chk("and 1 of the 2 misses is confirmed as genuinely ours",
        re.search(r"1\s+the arbiter has too\s+->\s+\(a\) really MISSED",
                  _ab_txt) is not None and
        re.search(r"1\s+in neither other lead\s+->\s+\(b\) alone", _ab_txt)
        is not None,
        "planted 1 real miss and 1 (b)-only beat")
    # The re-score, with the arithmetic checked against the construction:
    # 400 agreed + 4 confirmed = 404 found, of a 405-beat majority set,
    # out of 406 detections.
    _ab_sens = 100.0 * 404.0 / 405.0
    _ab_ppv = 100.0 * 404.0 / 406.0
    chk("the majority re-score is the arithmetic of the construction",
        ("%.2f%%" % _ab_sens) in _ab_txt and ("%.2f%%" % _ab_ppv) in _ab_txt,
        "want sens %.2f%% and PPV %.2f%% from 404/405 and 404/406"
        % (_ab_sens, _ab_ppv))
    chk("...and it is an improvement on the two-way PPV, as it must be here",
        _ab_ppv > 100.0 * 400.0 / 406.0,
        "two-way PPV counts all 6 as errors; 4 of them are (b)'s")
    _ab_rows = read_peaks(_ab_out)[2]
    _ab_yes = sorted(round(float(d["time_s"]), 4) for d in _ab_rows
                     if d.get("source") == "FP"
                     and "arb=yes" in (d.get("note") or ""))
    chk("the exported diff records the verdict on every disputed row",
        _ab_yes == sorted(_ab_fp_seen),
        "arb=yes on %s, planted %s" % (_ab_yes, sorted(_ab_fp_seen)))

    # ---- the majority RATE, which is what goal 6 plots.  Sensitivity and PPV
    # are per-beat and can both look fine while the count -- and so the trend
    # -- runs systematically off.  The denominator is read back out of the
    # tool's own output rather than restated here, so this checks the rate
    # against the construction and not against a second copy of the constant.
    _ab_dur = re.search(r"both over ([0-9.]+) s", _ab_txt)
    _ab_rm = 60.0 * 405.0 / float(_ab_dur.group(1)) if _ab_dur else 0.0
    chk("the 2-of-3 majority gets its own rate, over the same denominator",
        _ab_dur is not None
        and ("majority %.2f bpm" % _ab_rm) in _ab_txt,
        "want %.2f bpm from 405 beats over %s s"
        % (_ab_rm, _ab_dur.group(1) if _ab_dur else "?"))
    # 406 detections against a 405-beat majority, and 402 against it: (a) must
    # read high and (b) low.  A sign error here would invert the conclusion
    # that a trend built on (b) alone runs slow.
    _ab_rate_l = next((_l for _l in _ab_txt.splitlines()
                       if "2-of-3 majority" in _l), "")
    chk("...and each side's bias against it is signed the right way",
        ("(a) +%.2f%%" % (100.0 * (406.0 - 405.0) / 405.0)) in _ab_rate_l
        and ("(b) -%.2f%%" % (100.0 * (405.0 - 402.0) / 405.0))
        in _ab_rate_l,
        _ab_rate_l.strip() or "(no majority rate line)")

    # ---- independence.  Both refusals matter, and neither is cosmetic: an
    # arbiter sharing (b)'s wire would confirm (b) by construction, and one
    # sharing (a)'s wire would confirm (a)'s artifacts.  Either would make
    # the numbers above better than the truth, silently.
    _ab_same_b = os.path.join(_ad, "ch3_again.csv")
    _wr_lead(_ab_same_b, _dx_base, ch="3")
    _ab_args_b = argparse.Namespace(**vars(_ab_args))
    _ab_args_b.arbiter, _ab_args_b.export_diff = _ab_same_b, None
    _ab_io_b = _io.StringIO()
    with _ctx.redirect_stdout(_ab_io_b):
        cmd_compare(_ab_args_b)
    chk("an arbiter on (b)'s own electrode is REFUSED",
        "same electrode as (b)" in _ab_io_b.getvalue(),
        "a third opinion from the same wire is not a third opinion")

    # (a) here is a peak file whose lead_name is ECG_ch3, so pointing (b) at
    # channel 4 and the arbiter at 3 puts the arbiter on (a)'s wire.
    _ab_args_a = argparse.Namespace(**vars(_ab_args))
    _ab_args_a.manual = _ab_p            # (b) = channel 4
    _ab_args_a.arbiter = _ab_same_b      # arbiter = channel 3 = (a)'s lead
    _ab_args_a.export_diff = None
    _ab_io_a = _io.StringIO()
    with _ctx.redirect_stdout(_ab_io_a):
        cmd_compare(_ab_args_a)
    chk("an arbiter on (a)'s own electrode is REFUSED too",
        "same electrode as (a)" in _ab_io_a.getvalue(),
        "noise belongs to a wire; two detectors on it confirm each other")

    # ---- and when no arbiter is given, say that one would help.  The
    # observation without the remedy is what left 92.89% standing.
    chk("without --arbiter the run points at the third lead",
        "--arbiter" in _dx_txt and "THIRD ECG lead" in _dx_txt,
        "the two-way run must not stop at 'neither side is ground truth'")
    print()

    # ---------------------------------------------------------------- [26]
    # STATISTICS THAT CANNOT BE SUPPORTED, AND CLOCKS THAT CAN.
    #
    # Both halves of this section are fixes for defects that survived review
    # because the output looked reasonable.
    #
    # The first: a 0.178 s ASCII sample reported p99/A = 1.11 against a fleet
    # range of 0.46-0.48, and that was carried for several sessions as a
    # morphology anomaly worth investigating.  The 99th percentile of 89
    # samples is the maximum.  The ratio was an identity, not a finding.
    #
    # The second: exported beat times were written from the FIRST BEAT while
    # the waveform they get compared against starts 0.254 s earlier.
    print("[26] statistics that cannot be supported, and clocks that can")

    # ---- the policy, on its own.
    _ps_p21 = percentile_support(89, 1)
    chk("p99 of 89 samples is refused -- that is the maximum, not a percentile",
        not _ps_p21["ok"] and abs(_ps_p21["tail_n"] - 0.89) < 1e-9
        and "maximum" in _ps_p21["why"],
        "tail_n %.2f, why %r" % (_ps_p21["tail_n"], _ps_p21["why"]))
    chk("...and a real recording's length is accepted",
        percentile_support(500 * 1800, 1843)["ok"],
        "30 min at 500 Hz must not be caught by a guard aimed at 0.178 s")
    # Both arms, because a guard that only ever fires is as useless as one
    # that never does.
    chk("enough samples but too few beats is ALSO refused",
        not percentile_support(500 * 1800, 3)["ok"]
        and "median over 3 beat" in percentile_support(500 * 1800, 3)["why"],
        "the denominator A is a median over beats; 3 beats cannot support it")
    chk("the boundary is where the arithmetic puts it, not nearby",
        percentile_support(1000, 10)["ok"]
        and not percentile_support(999, 10)["ok"],
        "tail_min=%g at p99 means exactly 1000 samples"
        % PERCENTILE_TAIL_MIN)
    # The trap is_advisory() documents: a flag the classifier does not
    # recognise silently disqualifies.  Here that is the INTENDED outcome, so
    # it is pinned rather than left to chance -- if SHORT_RECORD were ever
    # added to ADVISORY_FLAGS, a 0.178 s file would be called trustworthy.
    chk("a record too short for its statistics does NOT count as trustworthy",
        not is_advisory("SHORT_RECORD_n=89"),
        "SHORT_RECORD must disqualify; 0.178 s has no bpm either")

    # ---- the export clock, end to end.
    _pc_dir = os.path.join(tmp, "pnmclock")
    os.makedirs(_pc_dir, exist_ok=True)
    _pc_dt = datetime.datetime(2023, 8, 6, 19, 59, 59)
    _pc_tk = int((_pc_dt - datetime.datetime(1, 1, 1)).total_seconds()
                 * NET_TICKS_PER_S)
    # P10's own gap, to the tick: the container starts on a whole second and
    # the first beat is 2,540,000 ticks later.
    _pc_gap = 2540000
    _pc_beat0 = _pc_tk + _pc_gap
    _pc_wav = os.path.join(_pc_dir, "ex.A1.20230806195959.PnmWav")
    with open(_dxp, "rb") as _f:
        _pc_body = _f.read()[len(PNMWAV_MAGIC):]
    with open(_pc_wav, "wb") as _f:
        _f.write(PNMWAV_MAGIC)
        # Tag 5013 because that is what the real container uses -- confirmed
        # independently by ep_pipeline.py (0x1395) and by agreeing with the
        # filename stamp.  pnmwav_start_ticks does not look at the number,
        # which is why it survived this file's notes being wrong about it.
        _f.write(struct.pack("<HI", 5013, 8))
        _f.write(struct.pack("<Q", _pc_tk))
        _f.write(_pc_body)
    _pc_marks = os.path.join(_pc_dir, "ex.1.A1.PnmMarks")

    def _pc_build(dbp):
        _c = sqlite3.connect(dbp)
        _c.execute("CREATE TABLE ChannelContextInfo (ChannelContextId INTEGER,"
                   " SubjectChannelId INTEGER, TicksPerSample LONG)")
        _c.execute("CREATE TABLE Cycle (ChannelContextId INTEGER,"
                   " CycleTime LONG)")
        _c.execute("CREATE TABLE BadDataMark (SubjectId INTEGER,"
                   " StartTime LONG, EndTime LONG)")
        _c.execute("INSERT INTO ChannelContextInfo VALUES (1, 3, 20000)")
        _c.executemany("INSERT INTO Cycle VALUES (?, ?)",
                       [(1, _pc_beat0 + int(i * 0.6 * NET_TICKS_PER_S))
                        for i in range(50)])
        _c.execute("INSERT INTO BadDataMark VALUES (1, ?, ?)",
                   (_pc_tk + 20 * NET_TICKS_PER_S,
                    _pc_tk + 25 * NET_TICKS_PER_S))
        _c.commit()
        _c.close()
    _pc_build(_pc_marks)

    _pc_beats = os.path.join(_pc_dir, "beats.csv")
    _pc_excl = os.path.join(_pc_dir, "excl.csv")
    _pc_args = argparse.Namespace(
        input=[_pc_marks], export_beats=_pc_beats, export_excl=_pc_excl,
        context=None, species="pig", traceback=True)
    _pc_io = _io.StringIO()
    with _ctx.redirect_stdout(_pc_io):
        cmd_marks(_pc_args)
    _pc_txt = _pc_io.getvalue()
    _, _pc_meta, _pc_rows = read_peaks(_pc_beats)
    chk("an export beside its .PnmWav uses the RECORDING's clock",
        _pc_meta.get("t0_ticks") == str(_pc_tk),
        "t0_ticks %s, want %s (first beat would be %s)"
        % (_pc_meta.get("t0_ticks"), _pc_tk, _pc_beat0))
    # The number that matters: the first beat must NOT land on zero.
    chk("...so the first beat sits 0.2540 s in, not at zero",
        _pc_rows and abs(float(_pc_rows[0]["time_s"]) - 0.2540) < 1e-4,
        "first beat at %s s, want 0.2540"
        % (_pc_rows[0]["time_s"] if _pc_rows else "(no rows)"))
    _pc_ex = list(csv.DictReader(
        [l for l in open(_pc_excl) if not l.startswith("#")]))
    chk("and a bad-data interval keeps its ABSOLUTE position",
        _pc_ex and abs(float(_pc_ex[0]["start_s"]) - 20.0) < 1e-3,
        "span starts %s s, want 20.000; the first-beat origin gives 19.746"
        % (_pc_ex[0]["start_s"] if _pc_ex else "(none)"))
    chk("the run states which origin it wrote, rather than leaving it implied",
        "recording start, stated by" in _pc_txt and "ex.A1" in _pc_txt,
        next((l.strip() for l in _pc_txt.splitlines()
              if "from the" in l and "recording" in l), "(no origin line)"))

    # ---- and the fallback, which must still work and must announce itself.
    # A sidecar that travels without its waveform is normal, and refusing to
    # export would be worse than exporting on a stated fallback.
    _pc_alone = os.path.join(tmp, "pnmalone")
    os.makedirs(_pc_alone, exist_ok=True)
    _pc_marks2 = os.path.join(_pc_alone, "ex.1.A1.PnmMarks")
    _pc_build(_pc_marks2)
    _pc_beats2 = os.path.join(_pc_alone, "beats.csv")
    _pc_args2 = argparse.Namespace(
        input=[_pc_marks2], export_beats=_pc_beats2, export_excl=None,
        context=None, species="pig", traceback=True)
    _pc_io2 = _io.StringIO()
    with _ctx.redirect_stdout(_pc_io2):
        cmd_marks(_pc_args2)
    _, _pc_meta2, _pc_rows2 = read_peaks(_pc_beats2)
    chk("with no waveform beside it, the first beat IS the origin -- and said",
        _pc_meta2.get("t0_ticks") == str(_pc_beat0)
        and abs(float(_pc_rows2[0]["time_s"])) < 1e-6
        and "first beat" in _pc_io2.getvalue(),
        "t0_ticks %s, first row %s"
        % (_pc_meta2.get("t0_ticks"),
           _pc_rows2[0]["time_s"] if _pc_rows2 else "(none)"))

    # ---- the tag table.  Its value is entirely in what it REFUSES to name.
    chk("only tags with two witnesses are named",
        5013 in PNMWAV_TAG_NAMES and 5045 in PNMWAV_TAG_NAMES
        and 5012 not in PNMWAV_TAG_NAMES
        and 5000 not in PNMWAV_TAG_NAMES and 5044 not in PNMWAV_TAG_NAMES,
        "5012 in particular: this file's own notes called it the start time "
        "for several sessions, and it is an 8-byte per-channel field")
    chk("every named tag records HOW it was established",
        all(isinstance(v, tuple) and len(v) == 2 and v[0] and v[1]
            for v in PNMWAV_TAG_NAMES.values()),
        "a name without provenance is a guess with better manners")

    # ---- trend --exclude: goal 6's excision, on data that has no sidecar.
    #
    # The arithmetic is fixed by construction so a half-done excision cannot
    # pass.  600 s of recording at exactly 60 bpm is 600 beats; cutting
    # 100 s removes 100 of them.  500 beats over 500 s is still 60.00 bpm.
    #
    # That invariance is the whole test.  Cutting the SECONDS alone would
    # read 600/500 = 72.00; cutting the BEATS alone would read 500/600 =
    # 50.00.  Only doing both leaves the rate where it started, which is what
    # "excise from the numerator and the denominator" has to mean.
    # Spans in seconds merge without being rounded.  Both halves matter: the
    # nested pair is the case that defeats the "last span starting at or
    # before this beat" test downstream, and the fractional edges are what
    # merge_tick_spans would have truncated to whole seconds.
    _xm = merge_spans_s([(50.0, 60.0), (0.0, 100.0), (120.25, 130.75)])
    chk("overlapping second-spans merge, and nesting is absorbed",
        _xm == [(0.0, 100.0), (120.25, 130.75)],
        "%s -- (50,60) sits inside (0,100); left separate, a beat at 80 tests"
        " against (50,60), reads outside, and survives a cut that covers it"
        % (_xm,))
    chk("...and the edges keep their fractions instead of being rounded",
        _xm[1] == (120.25, 130.75),
        "the tick merger casts to int; at 500 Hz a truncated edge is up to"
        " 500 samples of misplacement")

    _xt_dir = os.path.join(tmp, "trendex")
    os.makedirs(_xt_dir, exist_ok=True)
    _xt_csv = os.path.join(_xt_dir, "spans.csv")
    _xt_t0 = int((datetime.datetime(2023, 8, 6, 19, 59, 59)
                  - datetime.datetime(1, 1, 1)).total_seconds()
                 * NET_TICKS_PER_S)
    with open(_xt_csv, "w", newline="") as _f:
        _f.write("# %s\n# t0_ticks: %d\n" % (VERSION, _xt_t0))
        _f.write("start_s,end_s,dur_s\n200.0000,300.0000,100.0000\n")
    _xt_read = read_span_file(_xt_csv)
    chk("a span file carries its own origin, so it cannot be mis-placed",
        _xt_read["t0_ticks"] == _xt_t0 and _xt_read["spans"] == [(200.0, 300.0)],
        "t0_ticks %s, spans %s"
        % (_xt_read["t0_ticks"], _xt_read["spans"]))

    # The binning half, exercised directly: one 600 s record at 60 bpm.
    _xt_e0 = 1000000.0
    _xt_beats = _xt_e0 + np.arange(600, dtype=float)      # one per second
    _xt_cut = [(_xt_e0 + 200.0, _xt_e0 + 300.0)]
    _xt_keep = _xt_beats[(_xt_beats < _xt_cut[0][0])
                         | (_xt_beats > _xt_cut[0][1])]
    _xt_acc = {}
    bin_record(_xt_acc, _xt_e0, 600.0, _xt_keep, _xt_cut, 600.0)
    _xt_rows = bins_to_rows(_xt_acc, 600.0, 0.5)
    _xt_live = sum(r["live"] for r in _xt_rows)
    _xt_n = sum(r["beats"] for r in _xt_rows)
    chk("excising 100 s removes 100 s AND the beats inside it",
        abs(_xt_live - 500.0) < 1e-6 and _xt_n == 499,
        "live %.1f s (want 500.0), beats %d (want 499 -- the endpoints at"
        " 200 and 300 are both inside a closed interval)"
        % (_xt_live, _xt_n))
    # The rate must be almost exactly unchanged.  Not bit-identical: the cut
    # is closed at both ends so it takes 101 of the 600 one-per-second beats
    # while removing 100 s, which is an edge effect of the fixture, not of
    # the excision.  A one-sided excision would move it by 20%.
    _xt_bpm = 60.0 * _xt_n / _xt_live
    chk("...so the rate survives the excision instead of jumping",
        abs(_xt_bpm - 60.0) < 0.2,
        "%.2f bpm; seconds-only would read 72.00, beats-only 50.00"
        % _xt_bpm)

    # Dead time from two sources that overlap must be counted once.  A
    # no-signal span found by the detector and an operator-marked span read
    # from the sidecar will overlap whenever the operator marked a dropout --
    # which is the usual reason to mark one.  bin_record sums its spans'
    # overlaps to get dead time and clamps live at zero, so double-counting
    # never raises; it just quietly reports less coverage than there was.
    _xo_acc_bad, _xo_acc_ok = {}, {}
    _xo_nos = [(_xt_e0 + 100.0, _xt_e0 + 200.0)]
    _xo_mrk = [(_xt_e0 + 150.0, _xt_e0 + 250.0)]
    bin_record(_xo_acc_bad, _xt_e0, 600.0, [], _xo_nos + _xo_mrk, 600.0)
    bin_record(_xo_acc_ok, _xt_e0, 600.0, [],
               merge_spans_s(_xo_nos + _xo_mrk), 600.0)
    _xo_bad = sum(r["live"] for r in bins_to_rows(_xo_acc_bad, 600.0, 0.5))
    _xo_ok = sum(r["live"] for r in bins_to_rows(_xo_acc_ok, 600.0, 0.5))
    chk("overlapping dead time is subtracted once, not once per source",
        abs(_xo_ok - 450.0) < 1e-6 and abs(_xo_bad - 400.0) < 1e-6,
        "(100,200) and (150,250) cover 150 s together; merged leaves %.1f s"
        " live (want 450.0), unmerged leaves %.1f s (400.0 -- the shared"
        " 50 s taken twice)" % (_xo_ok, _xo_bad))
    print()






    # ---------------------------------------------------------------- [27]
    print("[27] view: the HTML page carries exactly the beats and leads analysed")
    import json as _json
    import base64 as _b64m
    _va = argparse.Namespace(species="pig", minutes=0.0, lead=None, band=None,
                             refractory=None, qc_min=0.90, traceback=False,
                             nosig=True)
    _vr = analyse(good, _va, PIG)
    _vc, _vfs, _vn, _vd = load_signals(good)
    _vt = "selftest </script> & <b>"
    _vh = build_view_html(_vr, _vc, _vt)
    _tag = '<script type="application/json" id="payload">'
    _vp = None
    try:
        _j0 = _vh.index(_tag) + len(_tag)
        _vp = _json.loads(_vh[_j0:_vh.index("</script>", _j0)])
    except Exception as _e:                                   # noqa: BLE001
        chk("view payload parses as JSON", False, repr(_e))
    if _vp is not None:
        chk("view payload parses as JSON", True, "%d bytes" % len(_vh))
        _pk = np.frombuffer(_b64m.b64decode(_vp["peaks"]), dtype="<i4")
        chk("view carries every detected beat, in sample units",
            len(_pk) == len(_vr.anchors) == _vp["n_peaks"]
            and np.array_equal(_pk, np.sort(_vr.anchors)),
            "%d in page vs %d detected" % (len(_pk), len(_vr.anchors)))
        _best = [k for k, L in enumerate(_vp["leads"]) if L["best"]]
        chk("view draws every lead and marks the detection lead",
            len(_vp["leads"]) == _vc.shape[1] and _best == [_vr.lead],
            "%d leads, best %s, analyse chose %d"
            % (len(_vp["leads"]), _best, _vr.lead))
        _L = _vp["leads"][_vr.lead]
        _y = fill_missing(_vc)[0][:, _vr.lead]
        _yq = (np.frombuffer(_b64m.b64decode(_L["data"]), dtype="<i2")
               * _L["scale"] + _L["centre"])
        _qe = float(np.max(np.abs(_yq - _y))) if len(_yq) == len(_y) else float("inf")
        chk("view int16 trace matches the raw lead",
            len(_yq) == len(_y) and _qe <= 0.51 * _L["scale"],
            "max error %.3g = %.2f LSB over %d samples"
            % (_qe, _qe / _L["scale"], len(_yq)))
    chk("view escapes the title out of HTML and script",
        _vh.count("</script>") == 2 and "<b>" not in _vh.split(_tag)[0]
        and "__DATA__" not in _vh and "__TITLE__" not in _vh,
        "%d closing script tags (want 2: payload, code)"
        % _vh.count("</script>"))
    if _vp is not None:
        chk("view export carries detect's header and one row per beat",
            len(_vp["rows"]) == _vp["n_peaks"]
            and any(h.startswith("# config_sha1: %s" % config_signature(_vr)[1])
                    for h in _vp["csv_head"])
            and _vp["fields"] == PEAK_FIELDS,
            "%d rows for %d beats" % (len(_vp["rows"]), _vp["n_peaks"]))
    # Ponemah placement.  A beat list that starts an hour before this file
    # and is timed from its first beat, 0.254 s after its own origin: the
    # stated origin must place it, and the measured residual must remove the
    # rest.  Then the same list with no origin at all.
    _vs = np.asarray(_vr.anchors, float) / _vr.fs
    _fst = datetime.datetime(2023, 8, 6, 20, 59, 59)
    _org = _fst - datetime.timedelta(seconds=3600)
    _otk = int(to_epoch(_org) - to_epoch(NET_EPOCH)) * NET_TICKS_PER_S
    _pl, _pi = place_ponemah(_vs + 3600.0 + 0.254, {"t0_ticks": str(_otk)},
                             _fst, _vs, _vr.dur)
    _pe = (float(np.max(np.abs(np.sort(_pl) - np.sort(_vs))))
           if len(_pl) == len(_vs) else float("inf"))
    chk("view places Ponemah by origin, then measures the residual",
        _pi["applied"] and abs(_pi["coarse_s"] + 3600.0) < 1e-6
        and abs(_pi["lag_s"] - 0.254) < 0.005 and _pe < 0.005,
        "coarse %+.3f s, residual %+.3f s, cov %.2f, %d/%d inside, max err %.4f s"
        % (_pi["coarse_s"], _pi["lag_s"], _pi["coverage"], len(_pl), len(_vs), _pe))
    _pl2, _pi2 = place_ponemah(_vs + 0.254, {}, _fst, _vs, _vr.dur)
    chk("view with no stated origin still aligns by measurement",
        _pi2["applied"] and abs(_pi2["lag_s"] - 0.254) < 0.005
        and _pi2["coarse_s"] == 0.0,
        "residual %+.3f s, cov %.2f" % (_pi2["lag_s"], _pi2["coverage"]))
    _rng = np.random.default_rng(7)
    _pl3, _pi3 = place_ponemah(np.sort(_rng.uniform(0, _vr.dur, len(_vs))), {},
                               _fst, _vs, _vr.dur)
    chk("view refuses an offset that matches nothing",
        not _pi3["applied"], "cov %.2f on unrelated beats" % _pi3["coverage"])
    # Edits round trip: an export-format file with one rejection and one
    # addition must come back as exactly that.
    _eh, _er = _view_rows(_vr)
    _ef = os.path.join(tmp, "view_edits.csv")
    _add = int(_vr.anchors[5] + _vr.anchors[6]) // 2
    with open(_ef, "w", newline="") as _fh:
        _fh.write("\n".join(_eh) + "\n")
        _w = csv.DictWriter(_fh, fieldnames=PEAK_FIELDS)
        _w.writeheader()
        for _k, _d in enumerate(_er):
            _d = dict(_d)
            if _k == 3:
                _d["keep"] = 0
            _w.writerow(_d)
        _w.writerow(dict(time_s="%.4f" % (_add / _vr.fs), sample=_add, amp="",
                         rhythm="", cluster=-1, qc=0, source="MANUAL", keep=1,
                         note="added in view"))
    _rem, _ad, _en = read_view_edits(_ef, _vr)
    _kt, _km, _ = read_peaks(_ef)
    chk("view edits reload, and read_peaks counts them as compare will",
        _rem == [3] and _ad == [_add] and _en == ""
        and len(_kt) == len(_vr.anchors)
        and _km.get("config_sha1") == config_signature(_vr)[1],
        "rejected %s, added %s, note %r, %d kept rows"
        % (_rem, _ad, _en, len(_kt)))
    _vh2 = build_view_html(_vr, _vc, "p.edf", pon=(_pl, _pi), edits=(_rem, _ad))
    _j2 = _vh2.index(_tag) + len(_tag)
    _vp2 = _json.loads(_vh2[_j2:_vh2.index("</script>", _j2)])
    chk("view page carries the overlay and the edits",
        _vp2["pon"] is not None and _vp2["pon"]["n"] == len(_pl)
        and _vp2["removed"] == [3] and _vp2["added"] == [_add]
        and _vp2["export_name"] == "p.edited.csv",
        "pon %s, removed %s, added %s"
        % (_vp2["pon"] and _vp2["pon"]["n"], _vp2["removed"], _vp2["added"]))
    _vo = os.path.join(tmp, "view_out.html")
    # A Ponemah-style beat list for the end-to-end run: no stated origin,
    # 0.254 s late, as a first-beat-timed export is.
    _vpf = os.path.join(tmp, "view_pon.csv")
    with open(_vpf, "w", newline="") as _fh:
        _fh.write("# origin: Ponemah Cycle table (selftest)\n")
        _w = csv.DictWriter(_fh, fieldnames=PEAK_FIELDS)
        _w.writeheader()
        for _t in _vs + 0.254:
            _w.writerow(dict(time_s="%.4f" % _t, source="PONEMAH", keep=1))
    _vargs = argparse.Namespace(species="pig", minutes=0.0, lead=None,
                                band=None, refractory=None, qc_min=0.90,
                                traceback=False, nosig=True, input=[good],
                                out=_vo, outdir=None, seconds=10,
                                window=False, ponemah=_vpf, edits=_ef)
    _vrc = cmd_view(_vargs)
    chk("view subcommand writes the page", _vrc == 0 and os.path.getsize(_vo) > 1000,
        "rc %s, %d bytes" % (_vrc, os.path.getsize(_vo) if os.path.exists(_vo) else -1))
    # A browser decides the download's name -- Safari has used "Unknown" --
    # so a missing --manual must be answered by what is ON DISK, by content.
    _ud = os.path.join(tmp, "dl")
    os.makedirs(_ud, exist_ok=True)
    with open(os.path.join(_ud, "Unknown"), "w") as _fh:
        _fh.write("# ecg_rpeaks\n# edited_in: x view\ntime_s,keep\n1.0,1\n")
    with open(os.path.join(_ud, "other.csv"), "w") as _fh:
        _fh.write("time_s,keep\n1.0,1\n")
    _fx = find_view_exports([_ud])
    chk("a view export is found by content, whatever the browser named it",
        [os.path.basename(p) for p in _fx] == ["Unknown"],
        "found %s" % [os.path.basename(p) for p in _fx])
    import time as _time
    _t = _time.time()
    _crc = cmd_compare(argparse.Namespace(
        species="pig", minutes=0.0, lead=None, band=None, refractory=None,
        qc_min=0.90, traceback=False, nosig=True, input=[good], auto=None,
        manual=os.path.join(_ud, "missing.edited.csv"), arbiter=None,
        match_tol=None, max_windows=20, export_diff=None, align=True,
        align_max=5.0))
    chk("compare refuses a missing --manual BEFORE detecting",
        _crc == 2 and _time.time() - _t < 2.0,
        "rc %s after %.2f s" % (_crc, _time.time() - _t))
    print()

    # ---------------------------------------------------------------- [28]
    # THE ARBITER CHOSEN BY MEASUREMENT, AND BEATLESS TIME TAKEN OUT.
    #
    # Two defaults changed together.  compare now picks the third lead itself
    # from the Ponemah sidecar's contexts (or --arbiter-candidates), refusing
    # any that shares a wire with (a) or (b) by TIMING, not by label; and every
    # rate now excises beatless gaps longer than refill_gap_mult x baseline RR
    # unless --keep-empty.  Each rule is pinned on data whose answer is known
    # by construction.
    print("[28] automatic arbiter, and empty gaps excised by default")
    _ag = os.path.join(tmp, "autoarb")
    os.makedirs(_ag, exist_ok=True)
    _arng = np.random.default_rng(28)

    # ---- select_arbiter on its own.  (a) and (b) share the 400 base beats;
    # (b) is on its own wire (3 ms jitter).  Candidates, one per rule.
    _sa_base = _dx_base
    _sa_auto = np.sort(np.concatenate([_sa_base, _dx_fp]))
    _sa_man = np.sort(np.concatenate([_sa_base + _arng.normal(0, 0.003, len(_sa_base)),
                                      _dx_fn]))
    _sa_c = [
        dict(label="same_wire_as_a", ch="4", ctx=11, cardiac=True,
             times_s=_sa_base + _arng.normal(0, 0.0002, len(_sa_base)) + 0.05),
        dict(label="good_ch5", ch="5", ctx=12, cardiac=True,
             times_s=_sa_base + _arng.normal(0, 0.003, len(_sa_base)) + 0.07),
        dict(label="weak_ch6", ch="6", ctx=13, cardiac=True,
             times_s=(_sa_base + _arng.normal(0, 0.003, len(_sa_base)))[
                 np.arange(len(_sa_base)) % 5 != 0] - 0.04),
        dict(label="epoch_ctx", ch="7", ctx=14, cardiac=False, fs=1.0,
             times_s=np.arange(0.0, 260.0, 1.0)),
        dict(label="is_b", ch="8", ctx=2, cardiac=True, src="/x/S.PnmMarks",
             times_s=_sa_man.copy()),
        dict(label="b_channel", ch="3", ctx=15, cardiac=True,
             times_s=_sa_base + _arng.normal(0, 0.003, len(_sa_base))),
    ]
    _sa_ch, _sa_rows = select_arbiter(_sa_auto, _sa_man, _sa_c, 0.05,
                                      man_ch="3", man_ctx=2,
                                      man_src="/y/S.PnmMarks")
    _sa_why = {r_["label"]: r_["why"] for r_ in _sa_rows}
    chk("auto arbiter: the independent lead with the best F1 vs (b) is CHOSEN",
        _sa_ch is not None and _sa_ch["label"] == "good_ch5"
        and "CHOSEN" in _sa_ch["why"],
        "; ".join("%s: %s" % kv for kv in sorted(_sa_why.items())))
    chk("auto arbiter: a lead within %.1f ms of (a) is refused as (a)'s wire"
        % ARBITER_SAME_ELECTRODE_MS,
        _sa_why["same_wire_as_a"].startswith("same electrode as (a)"),
        _sa_why["same_wire_as_a"])
    chk("auto arbiter: an epoch context is refused as not cardiac",
        _sa_why["epoch_ctx"].startswith("not cardiac"), _sa_why["epoch_ctx"])
    chk("auto arbiter: (b)'s own context is refused as the same list",
        _sa_why["is_b"].startswith("this IS (b)"), _sa_why["is_b"])
    chk("auto arbiter: (b)'s subject channel is refused",
        _sa_why["b_channel"].startswith("same subject channel as (b)"),
        _sa_why["b_channel"])
    chk("auto arbiter: a weaker independent lead is accepted but not chosen",
        _sa_why["weak_ch6"] == "independent of (a) and (b)", _sa_why["weak_ch6"])
    _sw = next(r_ for r_ in _sa_rows if r_["label"] == "good_ch5")
    chk("auto arbiter: timings are measured after the offset is removed",
        1.0 < _sw["dt_a_ms"] < 4.0 and 1.0 < _sw["dt_b_ms"] < 6.0
        and abs(_sw["lag_a"] - 0.07) < 0.005,
        "|dt| a %.2f ms, b %.2f ms, offset vs (a) %+.4f s"
        % (_sw["dt_a_ms"], _sw["dt_b_ms"], _sw["lag_a"]))
    _sa_ch2, _sa_rows2 = select_arbiter(_sa_auto, _sa_man, [_sa_c[2]], 0.05,
                                        man_ch="3")
    chk("auto arbiter: below F1 %.2f it is still used, and called weak"
        % ARBITER_WARN_F1,
        _sa_ch2 is not None and _sa_ch2["f1_b"] < ARBITER_WARN_F1
        and "weak" in _sa_ch2["why"],
        "%s F1 %.3f" % (_sa_ch2 and _sa_ch2["why"],
                        _sa_ch2["f1_b"] if _sa_ch2 else float("nan")))
    _sa_ch3, _sa_rows3 = select_arbiter(_sa_auto, _sa_man, _sa_c[:1] + _sa_c[3:],
                                        0.05, man_ch="3", man_ctx=2,
                                        man_src="/y/S.PnmMarks")
    chk("auto arbiter: nothing qualifies -> no arbiter, every row says why",
        _sa_ch3 is None and all(r_["why"] and not r_["ok"] for r_ in _sa_rows3),
        "; ".join(r_["why"] for r_ in _sa_rows3))

    # ---- end to end through compare, from --arbiter-candidates.  ch4.csv
    # from [25] is (a)'s own times shifted, so by timing it is one wire with
    # both lists; the jittered ch5 is a real third electrode.
    _jit_p = os.path.join(_ag, "ch5_jit.csv")
    _jit_t = (np.concatenate([_dx_base + _arng.normal(0, 0.003, len(_dx_base)),
                              _ab_fp_seen, _ab_fn_seen]))
    _wr_lead(_jit_p, _jit_t, ch="5", shift=-0.13)

    def _run_cmp(**kw):
        _na = argparse.Namespace(**vars(_dx_args))
        _na.export_diff = None
        _na.arbiter = None
        for _k, _v in kw.items():
            setattr(_na, _k, _v)
        _o = _io.StringIO()
        with _ctx.redirect_stdout(_o):
            _rc = cmd_compare(_na)
        return _rc, _o.getvalue()

    _rc_a, _tx_a = _run_cmp(arbiter_candidates=[_ab_p, _jit_p])
    _row_same = next((_l for _l in _tx_a.splitlines() if "ch4.csv" in _l
                      and "rejected" in _l), "")
    chk("compare prints the candidate table and refuses the same-wire list",
        "chosen automatically" in _tx_a and "same electrode as" in _row_same,
        _row_same.strip() or "(no ch4.csv row)")
    chk("compare CHOOSES the independent lead and arbitrates with it",
        re.search(r"ch5_jit\.csv.*ACCEPTED: CHOSEN", _tx_a) is not None
        and "ARBITER  ch5_jit.csv" in _tx_a
        and re.search(r"4\s+the arbiter has too\s+->\s+\(b\) MISSED", _tx_a)
        is not None
        and re.search(r"1\s+the arbiter has too\s+->\s+\(a\) really MISSED",
                      _tx_a) is not None,
        next((_l.strip() for _l in _tx_a.splitlines() if "CHOSEN" in _l),
             "(no CHOSEN row)"))
    _rc_n, _tx_n = _run_cmp(arbiter="none", arbiter_candidates=[_jit_p])
    chk("--arbiter none disables the automatic choice",
        "disabled (--arbiter none)" in _tx_n and "CHOSEN" not in _tx_n
        and "the arbiter has too" not in _tx_n, "rc %s" % _rc_n)
    _rc_o, _tx_o = _run_cmp(arbiter=_ab_p, arbiter_candidates=[_jit_p])
    chk("--arbiter FILE overrides the automatic choice",
        ("ARBITER  %s" % _ab_p) in _tx_o and "chosen automatically" not in _tx_o,
        "rc %s" % _rc_o)

    # ---- the Ponemah sidecar: contexts become candidates.  Context 9 is a
    # 1 Hz epoch table starting at tick T0 (so the sidecar's t0 is the
    # recording's 0 s); context 3 is (b)'s subject channel; context 4 is the
    # third electrode.
    _amk = os.path.join(_ag, "S1.1.S1.PnmMarks")
    _aT0, _aTPS = 638269487992540000, NET_TICKS_PER_S
    _c4 = np.sort(_jit_t) - 0.13
    _c3 = _dx_ref_t
    _acon = sqlite3.connect(_amk)
    _acon.executescript(
        "CREATE TABLE Cycle (ChannelContextId INTEGER NOT NULL,"
        " CycleTime LONG, Marks BLOB);"
        "CREATE TABLE ChannelContextInfo (ChannelContextId INTEGER,"
        " SubjectChannelId LONG, TicksPerSample LONG);"
        "CREATE TABLE BadDataMark (BadDataMarkId INTEGER,"
        " SubjectChannelId LONG, StartTime LONG, EndTime LONG);"
        "CREATE TABLE MarkDatabaseInfo (SchemaVersion INTEGER,"
        " CreateDate INTEGER);")
    _acon.executemany(
        "INSERT INTO Cycle VALUES (?,?,?)",
        [(9, _aT0 + k * _aTPS, None) for k in range(260)]
        + [(3, _aT0 + int(round(t_ * _aTPS)), None) for t_ in _c3]
        + [(4, _aT0 + int(round(t_ * _aTPS)), None) for t_ in _c4])
    _acon.executemany("INSERT INTO ChannelContextInfo VALUES (?,?,?)",
                      [(9, 9, 10000000), (3, 3, 20000), (4, 4, 20000)])
    _acon.execute("INSERT INTO MarkDatabaseInfo VALUES (?,?)", (1, _aT0))
    _acon.commit()
    _acon.close()
    _mc, _mnote = marks_arbiter_candidates(_amk)
    chk("every sidecar context becomes a candidate; the 1 Hz one is not cardiac",
        sorted((c_["ctx"], c_["cardiac"]) for c_ in _mc)
        == [(3, True), (4, True), (9, False)] and not _mnote,
        "%s %s" % ([(c_["ctx"], c_["ch"], c_["cardiac"]) for c_ in _mc], _mnote))
    # (b) names the sidecar it came from, as `marks --export-beats` writes it,
    # so compare finds it with no --marks and no --input.
    _bsrc = os.path.join(_ag, "b_from_sidecar.csv")
    with open(_dx_refp) as _fi, open(_bsrc, "w") as _fo:
        _hl = _fi.readline()
        _fo.write(_hl + "# source_file: %s\n" % _amk + _fi.read())
    _rc_m, _tx_m = _run_cmp(manual=_bsrc)
    chk("compare discovers the sidecar (b) was exported from",
        "the file (b) was exported from" in _tx_m
        and re.search(r"ctx 4 .*ACCEPTED: CHOSEN", _tx_m) is not None
        and re.search(r"ctx 3 .*rejected: same subject channel as \(b\)", _tx_m)
        is not None
        and re.search(r"ctx 9 .*rejected: not cardiac", _tx_m) is not None,
        next((_l.strip() for _l in _tx_m.splitlines() if "CHOSEN" in _l),
             "(no CHOSEN row)"))
    _rc_x, _tx_x = _run_cmp(marks=_amk)
    chk("--marks FILE names the sidecar explicitly",
        re.search(r"ctx 4 .*ACCEPTED: CHOSEN", _tx_x) is not None,
        "rc %s" % _rc_x)
    # Discovery beside --input and in its parent, and the refusal to guess.
    _dd = os.path.join(_ag, "animal")
    os.makedirs(os.path.join(_dd, "sample EDFs"), exist_ok=True)
    _dmk = os.path.join(_dd, "A.1.A.PnmMarks")
    with open(_dmk, "wb") as _fh:
        _fh.write(b"")
    _fnd, _fhow = find_marks_file([os.path.join(_dd, "sample EDFs", "x.edf")])
    chk("find_marks_file looks in --input's parent folder (the P10 layout)",
        _fnd == _dmk and "parent" in _fhow, "%s (%s)" % (_fnd, _fhow))
    with open(os.path.join(_dd, "B.1.B.PnmMarks"), "wb") as _fh:
        _fh.write(b"")
    _fnd2, _fhow2 = find_marks_file([os.path.join(_dd, "sample EDFs", "x.edf")])
    chk("two sidecars in one folder are ambiguous, not guessed between",
        _fnd2 is None and "ambiguous" in _fhow2, _fhow2)

    # ---- empty_gap_spans, by hand.  Beats every 1.0 s at 0.5..49.5 and
    # 60.5..99.5, record 110 s: M = 1.0, limit 3.0.  The 11 s gap keeps one
    # interval, (50.0, 60.0) goes; the tail keeps M/2, (100.0, 110.0) goes.
    _eg_fs = 500.0
    _eg_t = np.concatenate([np.arange(0.5, 50.0, 1.0), np.arange(60.5, 100.0, 1.0)])
    _eg_a = np.round(_eg_t * _eg_fs).astype(np.int64)
    _eg1, _egM = empty_gap_spans(_eg_a, _eg_fs, 110.0, [], 3.0)
    chk("empty gaps: the interior of a gap and the tail, M/2 kept at each beat",
        abs(_egM - 1.0) < 1e-9 and len(_eg1) == 2
        and all(abs(x_ - y_) < 1e-9 for s_, w_ in zip(_eg1, [(50.0, 60.0), (100.0, 110.0)])
                for x_, y_ in zip(s_, w_)),
        "%s, M %.4f" % (_eg1, _egM))
    _eg2, _ = empty_gap_spans(_eg_a, _eg_fs, 110.0, [(52.0, 55.0)], 3.0)
    chk("empty gaps: disjoint from no-signal/marked spans, never double counted",
        abs(total_span_s(_eg2) - 17.0) < 1e-9
        and all(_overlap(s_, e_, 52.0, 55.0) == 0.0 for s_, e_ in _eg2),
        "%s" % (_eg2,))
    _eg3, _ = empty_gap_spans(_eg_a, _eg_fs, 110.0, [(50.5, 59.0)], 3.0)
    chk("empty gaps: a gap that only bridges an excised span is not excised again",
        len(_eg3) == 1 and abs(_eg3[0][0] - 100.0) < 1e-9,
        "live 2.5 s < 3.0 s limit; got %s" % (_eg3,))
    _eg4, _ = empty_gap_spans(_eg_a[:10], _eg_fs, 110.0, [], 3.0)
    chk("empty gaps: fewer than %d beats -> no baseline, nothing excised"
        % EMPTY_MIN_BEATS, _eg4 == [], "%s" % (_eg4,))

    # ---- analyse on a beatless stretch that is NOT flat: 60 s of noise with
    # no beats, which no-signal excision cannot see.
    _gl, _gpk = _st_build(200.0, 500.0, 960.0, early_every=0, seed=5,
                          blackout=(80.0, 140.0), silent=False)
    _gf = os.path.join(_ag, "gap.edf")
    _st_write_edf(_gf, _gl, 500.0, ["A", "B", "C"])
    # No-signal excision OFF here so the gap is visible ONLY as beatless;
    # the run after it turns it back on and checks the two never overlap.
    _ga = argparse.Namespace(species="pig", minutes=0.0, lead=None, band=None,
                             refractory=None, qc_min=0.90, traceback=False,
                             nosig=False)
    _gr = analyse(_gf, _ga, PIG)
    _ga_k = argparse.Namespace(**vars(_ga))
    _ga_k.keep_empty = True
    _grk = analyse(_gf, _ga_k, PIG)
    _gi, _gik = _gr.integrity, _grk.integrity
    _true_bpm = 60.0 / 0.96
    chk("a noisy beatless minute is excised as EMPTY by default",
        55.0 < _gi["empty_s"] < 61.0 and _gi["empty_applied_s"] == _gi["empty_s"]
        and abs(_gi["analysable_s"]
                - (_gr.dur - _gi["excised_base_s"] - _gi["empty_s"])) < 1e-6,
        "empty %.2f s in %d gap(s), no-signal+marked %.2f s, analysable %.2f s"
        % (_gi["empty_s"], _gi["n_empty"], _gi["excised_base_s"],
           _gi["analysable_s"]))
    chk("...and the rate is the heart's, not diluted by the silence",
        abs(_gi["bpm"] - _true_bpm) / _true_bpm < 0.02
        and _gik["bpm"] < 0.8 * _true_bpm,
        "default %.2f bpm, --keep-empty %.2f bpm, constructed %.2f"
        % (_gi["bpm"], _gik["bpm"], _true_bpm))
    chk("--keep-empty measures the same gap but leaves it in the denominator",
        abs(_gik["empty_s"] - _gi["empty_s"]) < 1e-9
        and _gik["empty_applied_s"] == 0.0 and _gik["keep_empty"]
        and abs(_gik["analysable_s"] - (_grk.dur - _gik["excised_base_s"])) < 1e-6,
        "empty %.2f s measured, %.2f applied, analysable %.2f s"
        % (_gik["empty_s"], _gik["empty_applied_s"], _gik["analysable_s"]))
    chk("no beat lies inside an empty span (the numerator needs no change)",
        not any(beats_in_spans(np.asarray(_gr.anchors, float) / _gr.fs,
                               [(s_ + 1e-9, e_ - 1e-9)]) for s_, e_ in _gr.empty_spans),
        "%d span(s)" % len(_gr.empty_spans))
    chk("excised total = no-signal/marked + empty, exactly",
        abs(total_span_s(_gr.excise_spans)
            - (total_span_s(_gr.excise_base_spans) + _gr.empty_s)) < 1e-6,
        "%.3f vs %.3f + %.3f" % (total_span_s(_gr.excise_spans),
                                 total_span_s(_gr.excise_base_spans), _gr.empty_s))

    _ga_n = argparse.Namespace(**vars(_ga))
    _ga_n.nosig = True
    _grn = analyse(_gf, _ga_n, PIG)
    _gin = _grn.integrity
    chk("with no-signal excision on as well, the categories add up, no overlap",
        55.0 < _gin["excised_base_s"] + _gin["empty_s"] < 61.5
        and abs(total_span_s(_grn.excise_spans)
                - (total_span_s(_grn.excise_base_spans) + _grn.empty_s)) < 1e-6
        and abs(_gin["bpm"] - _true_bpm) / _true_bpm < 0.02,
        "no-signal+marked %.2f s + empty %.2f s, %.2f bpm"
        % (_gin["excised_base_s"], _gin["empty_s"], _gin["bpm"]))

    # ---- the page: toggle present, initial state follows --keep-empty, and
    # the same constants handed to the JS recompute.
    _gc = load_signals(_gf)[0]
    _gh = build_view_html(_gr, _gc, "gap.edf")
    with open(os.path.join(tmp, "gap.view.html"), "w", encoding="utf-8") as _fh:
        _fh.write(_gh)
    # The same file with no-signal excision on, so the page has BASE spans
    # under the empty ones.  Written for an out-of-band check of the JS
    # recompute (the page flags a JS/Python mismatch in its status bar).
    with open(os.path.join(tmp, "gap_nosig.view.html"), "w",
              encoding="utf-8") as _fh:
        _fh.write(build_view_html(_grn, _gc, "gap.edf"))
    _gj0 = _gh.index(_tag) + len(_tag)
    _gp = _json.loads(_gh[_gj0:_gh.index("</script>", _gj0)])
    _ghk = build_view_html(_grk, _gc, "gap.edf")
    _gjk = _ghk.index(_tag) + len(_tag)
    _gpk2 = _json.loads(_ghk[_gjk:_ghk.index("</script>", _gjk)])
    chk("view: a 'Drop empty gaps' toggle whose default follows --keep-empty",
        'id="dropempty"' in _gh and _gp["drop_empty"] is True
        and _gpk2["drop_empty"] is False,
        "drop_empty %s / with --keep-empty %s"
        % (_gp.get("drop_empty"), _gpk2.get("drop_empty")))
    chk("view: the page gets Python's constants and Python's spans to check against",
        _gp["empty_cfg"] == dict(gap_mult=3.0, tol=EMPTY_BASE_TOL,
                                 iters=EMPTY_BASE_ITERS,
                                 min_sel=EMPTY_BASE_MIN_SEL,
                                 min_beats=EMPTY_MIN_BEATS)
        and abs(sum(b_ - a_ for a_, b_ in _gp["empty_py"]) - _gr.empty_s) < 1e-6
        and len(_gp["excised_base"]) == len(_gr.excise_base_spans)
        and abs(_gp["dur_s"] - _gr.dur) < 1e-9,
        "%s, %d empty span(s)" % (_gp.get("empty_cfg"), len(_gp.get("empty_py", []))))
    print()

    # ---------------------------------------------------------------- [29]
    # COMPARE: EMPTY MEANS EMPTY IN BOTH LISTS.
    #
    # The empty gaps analyse() measures come from (a) alone.  Used as the
    # compare denominator, a gap where (b) HAS beats -- our misses -- lost its
    # time while (b)'s beats there stayed counted, so (b) read fast and the
    # misses looked like silence.  compare now re-derives the spans from the
    # union after alignment.  Pinned on the noisy-gap record from [28].
    print("[29] compare: empty gaps from the union of (a) and (b)")
    # ---- the rule on its own, by hand (same layout as the [28] hand case).
    _u_a = _eg_t
    _u_fill = np.arange(50.5, 55.0, 1.0)                  # 5 (b)-only beats
    _u_b = np.sort(np.concatenate([_eg_t, _u_fill]))
    _u_fn = match_peaks(_u_a, _u_b, 0.05)[2]
    _u_sp, _u_M, _u_n = compare_empty_spans(_u_a, _u_b, _u_fn, _eg_fs, 110.0,
                                            [], 3.0)
    chk("union rule: (b)'s beats in (a)'s gap shrink the empty span to the "
        "part neither list covers",
        len(_u_fn) == 5 and len(_u_sp) == 2
        and abs(_u_sp[0][0] - 55.0) < 1e-9 and abs(_u_sp[0][1] - 60.0) < 1e-9
        and abs(total_span_s(_u_sp) - 15.0) < 1e-9 and _u_n == len(_u_b),
        "%s (a alone: [(50,60),(100,110)] = 20 s)" % (_u_sp,))
    chk("union rule: no beat of either list lies inside a union span",
        not _in_spans_mask(_u_b, [(a_ + 1e-9, b_ - 1e-9) for a_, b_ in _u_sp]).any()
        and not _in_spans_mask(_u_a, [(a_ + 1e-9, b_ - 1e-9) for a_, b_ in _u_sp]).any())
    _u_sp2, _, _ = compare_empty_spans(_u_a, _u_a + 0.002,
                                       match_peaks(_u_a, _u_a + 0.002, 0.05)[2],
                                       _eg_fs, 110.0, [], 3.0)
    chk("union rule: a gap empty in both is excised exactly as (a) alone",
        abs(total_span_s(_u_sp2) - 20.0) < 1e-9, "%s" % (_u_sp2,))

    # ---- end to end through compare, recording given (so a denominator).
    _cx = argparse.Namespace(**vars(_dx_args))
    _cx.input, _cx.auto, _cx.nosig = [_gf], None, False
    _cx.export_diff, _cx.arbiter, _cx.keep_empty = None, "none", False
    _cr = analyse(_gf, _cx, PIG)
    _ct = np.asarray(_cr.anchors, float) / _cr.fs
    _cgi = int(np.argmax(np.diff(_ct)))
    _cg0, _cg1 = _ct[_cgi], _ct[_cgi + 1]
    _cfill = np.arange(_cg0 + 0.96, _cg1 - 0.48, 0.96)   # Ponemah hears these
    _cb_same = os.path.join(_ag, "b_same.csv")
    _cb_fill = os.path.join(_ag, "b_fill.csv")
    _wr_lead(_cb_same, _ct, ch="3")
    _wr_lead(_cb_fill, np.concatenate([_ct, _cfill]), ch="3")

    def _cmp_gap(manual, **kw):
        _na = argparse.Namespace(**vars(_cx))
        _na.manual = manual
        for _k, _v in kw.items():
            setattr(_na, _k, _v)
        _o = _io.StringIO()
        with _ctx.redirect_stdout(_o):
            cmd_compare(_na)
        _t = _o.getvalue()
        _d = re.search(r"both over ([0-9.]+) s", _t)
        _f = re.search(r"false negatives \(b only\)\s+(\d+)", _t)
        return (_t, float(_d.group(1)) if _d else float("nan"),
                int(_f.group(1)) if _f else -1)

    _tf, _df, _fnf = _cmp_gap(_cb_fill)
    chk("(b) beats inside (a)'s gap: the gap is NOT excised, and they are FNs",
        _fnf == len(_cfill) and abs(_df - _cr.dur) < 0.051
        and "derived from the UNION of (a) and (b)" in _tf
        and re.search(r"0\.0 s in 0 gap\(s\)", _tf) is not None
        and "CONSISTENCY FAILURE" not in _tf,
        "FN %d of %d planted, denominator %.1f s of %.1f s, (a) alone would "
        "excise %.1f s" % (_fnf, len(_cfill), _df, _cr.dur, _cr.empty_s))
    _ts, _ds, _fns = _cmp_gap(_cb_same)
    chk("a gap empty in both lists is excised for both",
        _fns == 0 and abs(_ds - (_cr.dur - _cr.empty_s)) < 0.051
        and _cr.empty_s > 50.0 and "CONSISTENCY FAILURE" not in _ts,
        "denominator %.1f s, want %.1f - %.1f" % (_ds, _cr.dur, _cr.empty_s))
    _rt = re.search(r"rate from \(a\) ([0-9.]+) bpm\s+rate from \(b\) ([0-9.]+)", _tf)
    chk("...and with (b) filling it, (b)'s rate is over the FULL time, not "
        "inflated",
        _rt is not None and abs(float(_rt.group(2))
                                - 60.0 * (len(_ct) + len(_cfill)) / _cr.dur) < 0.01,
        _rt.group(0) if _rt else "(no rate line)")
    _tfk, _dfk, _ = _cmp_gap(_cb_fill, keep_empty=True)
    _tsk, _dsk, _ = _cmp_gap(_cb_same, keep_empty=True)
    chk("--keep-empty: nothing excised in either case",
        abs(_dfk - _cr.dur) < 0.051 and abs(_dsk - _cr.dur) < 0.051
        and "KEPT as pauses (--keep-empty)" in _tsk,
        "denominators %.1f / %.1f s of %.1f" % (_dfk, _dsk, _cr.dur))
    # An arbiter that DOES have beats inside the excised span: it is only
    # consulted on disagreements, so it must neither crash nor move the time.
    _carb = os.path.join(_ag, "arb_in_gap.csv")
    _wr_lead(_carb, np.concatenate([_ct + _arng.normal(0, 0.003, len(_ct)),
                                    _cfill]), ch="9")
    _ta, _da, _ = _cmp_gap(_cb_same, arbiter=_carb)
    chk("an arbiter beat inside an excised span changes nothing and breaks "
        "nothing",
        "the arbiter has too" in _ta and abs(_da - _ds) < 1e-9
        and "CONSISTENCY FAILURE" not in _ta,
        "denominator %.1f s (without arbiter %.1f s)" % (_da, _ds))
    print()

    # ---------------------------------------------------------------- [30]
    # HTML PAGES FOR trend AND report, AND THE SECONDS LINE.
    #
    # The pages are what lab members will actually open, so they are checked
    # for the three things that would make them silently useless: not
    # written, not self-contained (a CDN script is a blank page offline, and
    # a privacy problem online), or not carrying the numbers the terminal
    # printed.  Two placed files: a clean 200 s record, then the noisy-gap
    # record from [28] -- run with --no-nosig so its 59.52 s gap is EMPTY
    # time -- and a 20 s --exclude span in the first.
    print("[30] HTML pages for trend and report, and the seconds line")
    _hd = os.path.join(tmp, "html")
    os.makedirs(_hd, exist_ok=True)
    _hc, _ = _st_build(200.0, 500.0, 960.0, early_every=0, seed=6)
    _st_write_edf(os.path.join(_hd, "P10_seg01_part001_20230806_195959.edf"),
                  _hc, 500.0, ["A", "B", "C"],
                  start=datetime.datetime(2023, 8, 6, 19, 59, 59))
    _st_write_edf(os.path.join(_hd, "P10_seg01_part002_20230806_200319.edf"),
                  _gl, 500.0, ["A", "B", "C"],
                  start=datetime.datetime(2023, 8, 6, 20, 3, 19))
    _hx = os.path.join(_hd, "excl.csv")
    with open(_hx, "w", newline="") as _f:
        _f.write("# %s\n# t0_ticks: %d\n" % (VERSION, _xt_t0))
        _f.write("start_s,end_s,dur_s\n20.0000,40.0000,20.0000\n")
    _hin = os.path.join(_hd, "*.edf")

    def _run_main(argv):
        _old = sys.argv
        sys.argv = ["ecg_rpeaks.py"] + list(argv)
        _o = _io.StringIO()
        _rc = 0
        try:
            with _ctx.redirect_stdout(_o):
                main()
        except SystemExit as _e:
            _rc = _e.code or 0
        finally:
            sys.argv = _old
        return _rc, _o.getvalue()

    def _page(path):
        with open(path, encoding="utf-8") as _fh:
            _h = _fh.read()
        _j0 = _h.index(_tag) + len(_tag)
        return _h, _json.loads(_h[_j0:_h.index("</script>", _j0)])

    def _selfcontained(h):
        return (re.search(r"""(src|href)\s*=\s*["']?\s*(https?:)?//""", h, re.I)
                is None and "<link" not in h.lower()
                and "@import" not in h and "url(" not in h)

    _ht = os.path.join(_hd, "out", "trend.html")
    _targs = ["trend", "--input", _hin, "--bin", "5", "--no-nosig",
              "--exclude", _hx]
    _rc_p, _tx_p = _run_main(_targs)
    _rc_h, _tx_h = _run_main(_targs + ["--html", _ht])
    chk("trend --html writes the page and says so",
        _rc_h in (0, None) and os.path.isfile(_ht)
        and ("wrote %s" % _ht) in _tx_h, "rc %s" % _rc_h)
    chk("trend text is unchanged by --html apart from the 'wrote' line",
        _tx_h == _tx_p + "wrote %s\n" % _ht,
        "%d vs %d chars" % (len(_tx_h), len(_tx_p)))
    _sm = re.search(r"analysable\s+([0-9.]+) s \(([0-9.]+) h\) with empty gaps "
                    r"DROPPED;\s+([0-9.]+) s \(([0-9.]+) h\) with them KEPT\s+"
                    r"\[(\w+) in use\]", _tx_p)
    # 400 s recorded, 20 s excluded, 59.52 s empty (see [28]).
    chk("trend prints analysable SECONDS with empty gaps dropped and kept",
        _sm is not None and 318.0 < float(_sm.group(1)) < 322.0
        and abs(float(_sm.group(3)) - 380.0) < 0.2 and _sm.group(5) == "DROPPED",
        _sm.group(0) if _sm else "(no seconds line)")
    chk("...and the exclusion's own seconds, with and without it",
        re.search(r"over 32[0-9.]+ s analysable with the exclusion, 34[0-9.]+ s"
                  r" without it", _tx_p) is not None,
        next((_l.strip() for _l in _tx_p.splitlines() if "without it" in _l),
             "(no line)"))
    _hh, _hp = _page(_ht)
    chk("trend page is self-contained (no remote script, link, font or image)",
        _selfcontained(_hh) and "<canvas" in _hh, "%d bytes" % len(_hh))
    chk("trend page carries every bin and the numbers the text printed",
        len(_hp["rows"]) == 3 and _hp["beats"] == sum(r_["beats"] for r_ in _hp["rows"])
        and abs(_hp["analysable_s"] - float(_sm.group(1) if _sm else -1)) < 0.06
        and abs(_hp["analysable_s_alt"] - 380.0) < 0.2
        and abs(_hp["analysable_s"] - (380.0 - _hp["empty_s"])) < 0.01
        and _hp["log"].startswith("=" * 120),
        "%d bins, %d beats, %.2f s / %.2f s"
        % (len(_hp["rows"]), _hp["beats"], _hp["analysable_s"],
           _hp["analysable_s_alt"]))
    chk("trend page states the modes: empty gaps and the exclusion",
        any(m_.startswith("empty gaps  DROPPED") and "59.5 s" in m_
            for m_ in _hp["modes"][:1])
        and any(m_.startswith("excluded    excl.csv") and "20.0 s declared" in m_
                for m_ in _hp["modes"])
        and any("WITHOUT" in c_[1] for c_ in _hp["cards"])
        and any(c_[1] == "analysable seconds" for c_ in _hp["cards"]),
        " | ".join(_hp["modes"]))
    _htk = os.path.join(_hd, "trend_keep.html")
    _rc_k, _tx_k = _run_main(_targs + ["--keep-empty", "--html", _htk])
    _hk, _hpk = _page(_htk)
    chk("trend --keep-empty: the page and the seconds line say KEPT",
        "[KEPT in use]" in _tx_k and _hpk["keep_empty"] is True
        and abs(_hpk["analysable_s"] - 380.0) < 0.2
        and any("KEPT as pauses" in m_ for m_ in _hpk["modes"]),
        "%.2f s" % _hpk["analysable_s"])

    _hr = os.path.join(_hd, "out", "report.html")
    _hv = os.path.join(_hd, "out", "views")
    _rc_r, _tx_r = _run_main(["report", "--input", _hin, "--no-nosig",
                              "--html", _hr, "--view-dir", _hv])
    _rh, _rp = _page(_hr)
    _gap_row = next((d_ for d_ in _rp["files"] if "part002" in d_["file"]), {})
    chk("report --html: one row per file, analysable/empty seconds, totals",
        os.path.isfile(_hr) and ("wrote %s" % _hr) in _tx_r
        and len(_rp["files"]) == 2
        and abs(_gap_row.get("empty_s", 0) - 59.5) < 1.0
        and abs(_gap_row.get("analysable_s", 0)
                - (200.0 - _gap_row.get("empty_s", 0))) < 0.01
        and _rp["totals"]["beats"] == sum(d_["beats"] for d_ in _rp["files"])
        and all(k_ in _gap_row for k_ in ("lead", "nosig_s", "mark_s", "bpm",
                                          "flags")),
        "gap row %s" % {k_: _gap_row.get(k_) for k_ in ("analysable_s",
                                                        "empty_s", "bpm")})
    _vl = [d_.get("view") for d_ in _rp["files"]]
    chk("report --view-dir writes each viewer page and links it RELATIVELY",
        _rp["has_view"] and all(v_ and not os.path.isabs(v_) for v_ in _vl)
        and all(os.path.isfile(os.path.join(os.path.dirname(_hr), v_))
                for v_ in _vl)
        and 'id="dropempty"' in open(os.path.join(os.path.dirname(_hr),
                                                  _vl[0])).read(),
        "%s" % _vl)
    chk("report page is self-contained and states the empty-gap mode",
        _selfcontained(_rh) and any(m_.startswith("empty gaps  DROPPED")
                                    for m_ in _rp["modes"]),
        " | ".join(_rp["modes"]))
    _rc_rp, _tx_rp = _run_main(["report", "--input", _hin, "--no-nosig"])
    chk("report text is unchanged by --html apart from the added lines",
        _tx_r == _tx_rp + "\n  viewer pages: 2 written to %s\n" % _hv
        + "wrote %s\n" % _hr,
        "%d vs %d chars" % (len(_tx_r), len(_tx_rp)))
    print()

    # ---------------------------------------------------------------- [31]
    # LONG RECORDINGS IN SEGMENTS.
    #
    # P10's native .PnmWav is ONE 18.6 h file where its EDF export is 19
    # hourly ones.  `--segment` (default 60 min) makes the long file behave
    # like the hourly ones: each segment analysed as its own file, placed on
    # the wall clock at recording start + offset, one row and one viewer
    # page each.  The fixture is a 7-minute multiplexed .PnmWav cut at
    # --segment 2, so the split rule, the 1-minute tail, three boundaries
    # and a BadDataMark lying ACROSS one of them are all exercised in a few
    # seconds.  What must hold: nothing lost or doubled at a boundary, the
    # parts add up to the whole, each piece on the right clock, and memory
    # bounded by the segment rather than the recording.
    print("[31] long recordings: segments, boundaries, pages and memory")
    import tracemalloc
    _sd = os.path.join(tmp, "segments")
    os.makedirs(_sd, exist_ok=True)
    _L = 60 * 60 * 500
    _b1 = segment_bounds(int(60.02 * 60 * 500), 500.0, 60.0)
    _b2 = segment_bounds(121 * 60 * 500, 500.0, 60.0)
    _n186 = int(18.6 * 3600 * 500)
    _b3 = segment_bounds(_n186, 500.0, 60.0) or []
    chk("split rule: 60.02 min is not split, a 1-min tail is folded in, "
        "18.6 h is 19 segments",
        _b1 is None and _b2 == [(0, _L), (_L, 121 * 60 * 500)]
        and len(_b3) == 19 and _b3[-1] == (18 * _L, _n186)
        and segment_bounds(_n186, 500.0, 0) is None,
        "60.02 min: %s; 121 min: %s; 18.6 h: %d segment(s), last %s"
        % (_b1, _b2, len(_b3), _b3[-1:] or None))

    class _SA:
        segment = SEGMENT_MIN_DEFAULT
        minutes = 0.0
    _e60 = os.path.join(_sd, "P10_seg01_part001_20230806_195959.edf")
    _st_write_edf(_e60, [np.zeros(int(60.02 * 60 * 10)) for _ in range(3)],
                  10.0, ["ECG1", "ECG2", "ECG3"])
    _e130 = os.path.join(_sd, "long130.edf")
    _st_write_edf(_e130, [np.zeros(130 * 60 * 10) for _ in range(3)],
                  10.0, ["ECG1", "ECG2", "ECG3"])
    _pl130 = segment_plan(_e130, _SA) or []
    chk("EDF: a 60.0x-min hourly export stays ONE file; a 130-min one would be "
        "3 segments (header only, no samples read)",
        segment_plan(_e60, _SA) is None and len(_pl130) == 3
        and _pl130[-1] == "long130 seg03 (02:00:00-02:10:00)",
        "%s" % _pl130)

    _sfs = 500.0
    _sl, _struth = _st_build(420.0, _sfs, 960.0, early_every=0, seed=31)
    _sst = datetime.datetime(2023, 8, 6, 19, 59, 59)
    _spd = os.path.join(_sd, "pnm")
    os.makedirs(_spd, exist_ok=True)
    _base = "08062023 P10.P10.20230806195959"
    _spw = os.path.join(_spd, _base + ".PnmWav")
    _st_write_pnmwav_mux(_spw, _sl, _sst)
    _sdl = _sst - datetime.datetime(1, 1, 1)
    _stk = (_sdl.days * 86400 + _sdl.seconds) * int(NET_TICKS_PER_S)
    _smk = os.path.join(_spd, "08062023 P10.1.P10.PnmMarks")
    _con = sqlite3.connect(_smk)
    _con.execute("CREATE TABLE ChannelContextInfo (ChannelContextId INTEGER,"
                 " SubjectChannelId INTEGER, TicksPerSample LONG)")
    _con.execute("CREATE TABLE Cycle (ChannelContextId INTEGER, CycleTime LONG)")
    _con.execute("CREATE TABLE BadDataMark (SubjectId INTEGER, StartTime LONG,"
                 " EndTime LONG)")
    _con.executemany("INSERT INTO ChannelContextInfo VALUES (?, ?, ?)",
                     [(1, 2, 20000), (2, 3, 20000), (3, 4, 20000)])
    _con.executemany("INSERT INTO Cycle VALUES (?, ?)",
                     [(1, _stk + int(p) * 20000) for p in _struth])
    # 230-250 s: straddles the 240 s boundary between seg02 and seg03.
    _con.execute("INSERT INTO BadDataMark VALUES (1, ?, ?)",
                 (_stk + 230 * int(NET_TICKS_PER_S),
                  _stk + 250 * int(NET_TICKS_PER_S)))
    _con.commit()
    _con.close()

    def _sns(**kw):
        a_ = argparse.Namespace(
            minutes=0.0, lead=None, band=None, refractory=None,
            qc_min=DEFAULTS["qc_min"], clip_k=DEFAULTS["clip_k"],
            chunk=DEFAULTS["chunk_s"], refill=True, refill_gap_mult=3.0,
            refill_rounds=3, nosig=True, keep_empty=False, segment=2.0,
            traceback=False)
        for k_, v_ in kw.items():
            setattr(a_, k_, v_)
        return a_
    _items = list(iter_analyses(_spw, _sns(), SPECIES["pig"]))
    _segs = [(r_, i_) for r_, _c, i_, e_ in _items if e_ is None]
    _serr = [e_ for _r, _c, _i, e_ in _items if e_ is not None]
    _snames = [i_["name"] for _r, i_ in _segs]
    _want_names = ["%s seg0%d (00:0%d:00-00:0%d:00)" % (_base, k_ + 1, 2 * k_,
                                                        min(7, 2 * k_ + 2))
                   for k_ in range(4)]
    chk("a 7-min .PnmWav at --segment 2 is 4 segments, named with their stretch",
        not _serr and _snames == _want_names
        and [(i_["a"], i_["b"]) for _r, i_ in _segs]
        == [(0, 60000), (60000, 120000), (120000, 180000), (180000, 210000)],
        "%s %s" % (_snames, _serr[:1]))
    _ru = analyse(_spw, _sns(segment=0), SPECIES["pig"])
    _ua = np.asarray(_ru.anchors, dtype=np.int64)
    _merged = (np.concatenate([np.asarray(r_.anchors, np.int64) + i_["a"]
                               for r_, i_ in _segs]) if _segs
               else np.array([], dtype=np.int64))
    _near = lambda arr, b: sorted(int(x) for x in arr if abs(int(x) - b) <= _sfs)
    _bnd = [int(i_["a"]) for _r, i_ in _segs[1:]]
    _tr_ok = _struth[(_struth < 229.9 * _sfs) | (_struth > 250.1 * _sfs)]
    _hit = (int(sum(1 for p in _tr_ok
                    if len(_merged) and np.min(np.abs(_merged - p)) <= 5))
            if len(_tr_ok) else 0)
    _ndup = int(np.sum(np.diff(np.sort(_merged)) < int(0.2 * _sfs)))
    chk("beats at segment boundaries are neither lost nor counted twice",
        _ndup == 0 and len(_merged) == len(_ua) and _hit == len(_tr_ok)
        and all(_near(_merged, b) == _near(_ua, b) for b in _bnd),
        "segments %d beats vs whole file %d; %d/%d true beats found; %d doubled;"
        " at the boundaries %s vs %s"
        % (len(_merged), len(_ua), _hit, len(_tr_ok), _ndup,
           [_near(_merged, b) for b in _bnd], [_near(_ua, b) for b in _bnd]))
    _smark = {i_["tag"]: float(r_.mark_s) for r_, i_ in _segs}
    chk("a BadDataMark across a boundary is split 10 s + 10 s, and adds up",
        abs(_smark.get("seg02", 0) - 10.0) < 0.01
        and abs(_smark.get("seg03", 0) - 10.0) < 0.01
        and _smark.get("seg01") == 0 and _smark.get("seg04") == 0
        and abs(sum(_smark.values()) - float(_ru.mark_s)) < 0.01,
        "%s, whole file %.3f s" % (_smark, float(_ru.mark_s)))
    _rd = _SegReader(_spw)
    _full = read_ponemah(_spw)[0]
    _blk = _rd.block(110000, 130000)
    _dd = (_blk - _full[110000:130000])[:, 1]
    _fin = np.isfinite(_dd)
    _ix = np.arange(len(_dd), dtype=float)
    _res = (np.max(np.abs(_dd[_fin] - np.polyval(np.polyfit(_ix[_fin], _dd[_fin], 1),
                                                  _ix[_fin]))) if _fin.sum() > 2
            else float("inf"))
    chk("the segment reader decodes the whole-file reader's samples (up to its "
        "own detrend) and the same bad-data NaNs",
        _rd.n == _full.shape[0] == 210000
        and np.array_equal(np.isnan(_blk), np.isnan(_full[110000:130000]))
        and np.isnan(_blk).any() and not np.isnan(_blk).all() and _res < 1e-6,
        "n %d/%d, NaN rows %d, residual %.2e" % (_rd.n, _full.shape[0],
                                                 int(np.isnan(_blk[:, 0]).sum()), _res))

    _sro = os.path.join(_sd, "out")
    _srh = os.path.join(_sro, "report.html")
    _svd = os.path.join(_sro, "views")
    _rc_s, _tx_s = _run_main(["report", "--input", _spw, "--segment", "2",
                              "--html", _srh, "--view-dir", _svd])
    _srhh, _srp = _page(_srh)
    _srows = _srp["files"]
    _stot = re.search(r"= %s TOTAL: 4 segment\(s\), 7\.0 min, (\d+) beats"
                      % re.escape(_base + ".PnmWav"), _tx_s)
    chk("report: a row per segment (full names), a TOTAL line, totals = sum of rows",
        [d_["file"] for d_ in _srows] == _want_names
        and all(n_ in _tx_s for n_ in _want_names)
        and _stot is not None and int(_stot.group(1)) == len(_merged)
        and _srp["totals"]["beats"] == sum(d_["beats"] for d_ in _srows) == len(_merged)
        and abs(_srp["totals"]["analysable_s"]
                - sum(float(r_.analysable_s) for r_, _i in _segs)) < 0.01,
        "%s | %s" % ([d_.get("file") for d_ in _srows],
                     _stot.group(0) if _stot else "(no TOTAL line)"))
    _sidx = os.path.join(_svd, _base + ".index.html")
    _sih = open(_sidx, encoding="utf-8").read() if os.path.isfile(_sidx) else ""
    chk("report --view-dir: <base>.segNN.view.html per segment, rows link them, "
        "<base>.index.html links every one",
        all(os.path.isfile(os.path.join(_svd, "%s.seg0%d.view.html" % (_base, k_)))
            for k_ in range(1, 5))
        and [d_.get("view") for d_ in _srows]
        == ["views/%s.seg0%d.view.html" % (_base, k_) for k_ in range(1, 5)]
        and all(('href="%s.seg0%d.view.html"' % (_base, k_)) in _sih
                for k_ in range(1, 5))
        and "20:01:59" in _sih and _selfcontained(_sih)
        and "segment index pages: %s.index.html" % _base in _tx_s,
        "%s" % [d_.get("view") for d_ in _srows])
    _sth = os.path.join(_sro, "trend.html")
    _rc_t, _tx_t = _run_main(["trend", "--input", _spw, "--segment", "2",
                              "--bin", "1", "--html", _sth])
    _sthh, _stp = _page(_sth)
    chk("trend: each segment at recording start + offset; beats reconcile with report",
        [f_[1] for f_ in _stp["files"]]
        == ["2023-08-06 19:59:59", "2023-08-06 20:01:59",
            "2023-08-06 20:03:59", "2023-08-06 20:05:59"]
        and "1 file(s) placed as 4 segment(s)" in _tx_t
        and _stp["beats"] == _srp["totals"]["beats"],
        "%s; %d vs %d beats" % ([f_[1] for f_ in _stp["files"]], _stp["beats"],
                                _srp["totals"]["beats"]))
    _svo = os.path.join(_sd, "view")
    _rc_v, _tx_v = _run_main(["view", "--input", _spw, "--segment", "2",
                              "--outdir", _svo])
    _p2f = os.path.join(_svo, _base + ".seg02.view.html")
    _p2 = _page(_p2f)[1] if os.path.isfile(_p2f) else {}
    chk("view: a page per segment on the recording's clock, plus the index",
        os.path.isfile(os.path.join(_svo, _base + ".index.html"))
        and all(os.path.isfile(os.path.join(_svo, "%s.seg0%d.view.html" % (_base, k_)))
                for k_ in range(1, 5))
        and _p2.get("t_offset_s") == 120.0 and _p2.get("n") == 60000
        and _p2.get("title") == _want_names[1]
        and _p2.get("n_peaks") == len(_segs[1][0].anchors)
        and "# segment_offset_s: 120.0000" in _p2.get("csv_head", []),
        "offset %s, n %s, peaks %s" % (_p2.get("t_offset_s"), _p2.get("n"),
                                       _p2.get("n_peaks")))
    _rc_w, _tx_w = _run_main(["view", "--input", _spw, "--start", "00:03:00",
                              "--minutes", "1.5", "--outdir", _svo])
    _pwf = os.path.join(_svo, _base + ".000300-000430.view.html")
    _pwp = _page(_pwf)[1] if os.path.isfile(_pwf) else {}
    _exp = _ua[(_ua >= 180 * _sfs) & (_ua < 270 * _sfs)]
    chk("view --start 00:03:00 --minutes 1.5 writes ONE page for that stretch",
        _pwp.get("n") == 45000 and _pwp.get("t_offset_s") == 180.0
        and abs(_pwp.get("n_peaks", -9) - len(_exp)) <= 1
        and parse_clock_s("180") == parse_clock_s("3:00")
        == parse_clock_s("00:03:00") == 180.0
        and "index" not in _tx_w,
        "n %s, offset %s, %s beats vs %d in the whole-file run"
        % (_pwp.get("n"), _pwp.get("t_offset_s"), _pwp.get("n_peaks"), len(_exp)))
    tracemalloc.start()
    _mw = analyse(_spw, _sns(segment=0), SPECIES["pig"])
    _pk_whole = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    _mw = None
    tracemalloc.start()
    for _it in iter_analyses(_spw, _sns(), SPECIES["pig"]):
        _it = None
    _pk_seg = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    # Extrapolation to P10: the segmented peak scales with the SEGMENT
    # (60 min + 2 x 15 s lead, vs 2 min + 30 s here), the whole-file peak
    # with the RECORDING (18.6 h vs 7 min).
    _est_seg = _pk_seg * (3630.0 / 150.0)
    _est_whole = _pk_whole * (18.6 * 3600.0 / 420.0)
    chk("memory: segmenting bounds the peak by the segment, not the recording",
        _pk_seg < 0.6 * _pk_whole,
        "measured peak %.1f MB whole 7-min file vs %.1f MB in 2-min segments; "
        "extrapolated to P10 (18.6 h, 3 x 500 Hz): ~%.0f MB at --segment 60 vs "
        "~%.1f GB unsegmented"
        % (_pk_whole / 1e6, _pk_seg / 1e6, _est_seg / 1e6, _est_whole / 1e9))
    print("      peak traced memory: whole 7-min file %.1f MB, 2-min segments "
          "%.1f MB -> P10 estimate ~%.0f MB at --segment 60 (vs ~%.1f GB whole)"
          % (_pk_whole / 1e6, _pk_seg / 1e6, _est_seg / 1e6, _est_whole / 1e9))
    _rc_e0, _tx_e0 = _run_main(["report", "--input", _hin, "--no-nosig",
                                "--segment", "0"])
    chk("EDF folders are untouched: hourly-sized files give the same report "
        "with --segment 0 as with the default",
        _tx_e0 == _tx_rp, "%d vs %d chars" % (len(_tx_e0), len(_tx_rp)))
    print()

    # ---------------------------------------------------------------- [32]
    # COMPARE ON ONE STRETCH.  A segment page exports its edits timed from
    # the segment start, with # segment_offset_s saying where that is; a
    # Ponemah list is timed from the recording start.  compare must score
    # either against the SAME stretch of detection, and say which it did.
    print("[32] compare on a segment page: header start, --start, mismatch")
    _cd = os.path.join(_sd, "cmp")
    os.makedirs(_cd, exist_ok=True)
    _ctr = _tr_ok / _sfs                      # truth, recording clock, no bad data
    _cseg = os.path.join(_cd, _base + ".seg02.edited.csv")
    with open(_cseg, "w", newline="") as _f:
        _f.write("# %s\n# fs_hz: 500.0000\n# duration_s: 120.0000\n"
                 "# segment: %s\n# segment_offset_s: 120.0000\n"
                 % (VERSION, _want_names[1]))
        _f.write("time_s,sample,amp,rhythm,cluster,qc,source,keep,note\n")
        for _t in _ctr[(_ctr >= 120.0) & (_ctr < 240.0)] - 120.0:
            _f.write("%.4f,,,,,,MANUAL,1,\n" % _t)
    _sens = lambda tx: (float(re.search(r"sensitivity\s+([0-9.]+)%", tx).group(1))
                        if re.search(r"sensitivity\s+([0-9.]+)%", tx) else -1.0)
    _apk = lambda tx: (int(re.search(r"\(a\) .*?(\d+) peaks", tx).group(1))
                       if re.search(r"\(a\) .*?(\d+) peaks", tx) else -1)
    _rc_c1, _tx_c1 = _run_main(["compare", "--input", _spw, "--manual", _cseg,
                                "--arbiter", "none"])
    chk("compare: a segment page's export is scored on ITS stretch, read from "
        "# segment_offset_s",
        _rc_c1 in (0, None)
        and "stretch   00:02:00-00:04:00 of the recording (120.0 s): start from"
            " (b)'s # segment_offset_s header, length from (b)'s # duration_s"
        in _tx_c1
        and "(b) is this stretch's segment page" in _tx_c1
        and _apk(_tx_c1) == len(_segs[1][0].anchors) and _sens(_tx_c1) >= 99.0,
        "rc %s, (a) %d peaks vs seg02 %d, sensitivity %.2f%%"
        % (_rc_c1, _apk(_tx_c1), len(_segs[1][0].anchors), _sens(_tx_c1)))
    _crec = os.path.join(_cd, "ponemah_like.csv")
    _cdrop = float(_ctr[np.argmin(np.abs(_ctr - 200.0))])
    with open(_crec, "w", newline="") as _f:
        _f.write("# %s\n# fs_hz: 500.0000\n# duration_s: 420.0000\n" % VERSION)
        _f.write("time_s,sample,amp,rhythm,cluster,qc,source,keep,note\n")
        for _t in _ctr:
            if _t != _cdrop:
                _f.write("%.4f,,,,,,PONEMAH,1,\n" % _t)
    _cdf = os.path.join(_cd, "diff.csv")
    _rc_c2, _tx_c2 = _run_main(["compare", "--input", _spw, "--manual", _crec,
                                "--start", "00:03:00", "--minutes", "1.5",
                                "--export-diff", _cdf])
    _dt2, _dm2, _dr2 = (read_peaks(_cdf) if os.path.isfile(_cdf)
                        else (np.array([]), {}, []))
    # (b) lacks one beat (a) has: an FP of (a), written at recording time.
    _dfn = [float(d_["time_s"]) for d_ in _dr2 if d_.get("source") == "FP"]
    _ctx1 = next((_l for _l in _tx_c2.splitlines()
                  if "PnmMarks ctx 1" in _l), "")
    chk("compare --start: a recording-clock (b) is cut to the stretch and "
        "shifted to its start",
        _rc_c2 in (0, None)
        and "start from --start, length from --minutes" in _tx_c2
        and "(b) is on the RECORDING's clock (no # segment_offset_s header):"
            " cut to 00:03:00-00:04:30 and shifted by -180.0 s" in _tx_c2
        and _sens(_tx_c2) >= 98.0,
        "rc %s, sensitivity %.2f%%" % (_rc_c2, _sens(_tx_c2)))
    chk("...the .PnmMarks arbiter candidates are cut and shifted the same way",
        "recording clock: cut to 00:03:00-00:04:30, shifted by -180.0 s" in _tx_c2
        and "same electrode as (b)" in _ctx1,
        _ctx1.strip() or "(no ctx 1 row)")
    chk("...and --export-diff and the show hint are back on the RECORDING clock",
        any(abs(x_ - _cdrop) < 0.05 for x_ in _dfn)
        and len(_dt2) and 179.9 <= float(np.min(_dt2))
        and float(np.max(_dt2)) <= 270.1
        and re.search(r"--start (180|240) --seconds 10", _tx_c2) is not None,
        "FP at %s (dropped from (b) %.3f), diff span %s-%s"
        % (_dfn, _cdrop, float(np.min(_dt2)) if len(_dt2) else None,
           float(np.max(_dt2)) if len(_dt2) else None))
    _rc_c3, _tx_c3 = _run_main(["compare", "--input", _spw, "--manual", _cseg,
                                "--start", "00:03:00", "--arbiter", "none"])
    chk("compare --start that disagrees with (b)'s header warns, and says what "
        "it did",
        _rc_c3 in (0, None)
        and "** WARNING: --start 00:03:00 (180.0 s) but (b) says"
            " # segment_offset_s 120.0 s (00:02:00) -- -60.0 s apart." in _tx_c3
        and "counts from ITS # segment_offset_s 120.0 s (00:02:00): moved"
            " -60.0 s onto this stretch" in _tx_c3
        and "WARNING: --start" not in _tx_c1,
        next((_l.strip() for _l in _tx_c3.splitlines() if "WARNING" in _l),
             "(no warning)"))
    chk("view: segment pages export <base>.<tag>.edited.csv, one name per page",
        _p2.get("export_name") == _base + ".seg02.edited.csv"
        and _pwp.get("export_name") == _base + ".000300-000430.edited.csv"
        and ("--manual '%s.seg01.edited.csv'" % _base) in _tx_v,
        "%s | %s" % (_p2.get("export_name"), _pwp.get("export_name")))
    print()

    nfail = sum(1 for okk, _, _ in results if not okk)
    nkver = str(getattr(nk, "__version__", "?"))
    stubbed = "stub" in nkver.lower()
    print("=" * 100)
    if nfail == 0:
        print("SELFTEST PASSED -- %d checks.  This install reproduces known answers." % len(results))
        if stubbed:
            print("  BUT neurokit2 is STUBBED here (version %r), so section [2] did NOT" % nkver)
            print("  exercise the real detector.  This run proves the harness works; it")
            print("  says nothing about detection accuracy.  Re-run where neurokit is real.")
        else:
            print("  The detector path here is the REAL neurokit2 call (%s), so this" % nkver)
            print("  covers what the development tests could not.")
    else:
        print("SELFTEST: %d of %d CHECKS FAILED" % (nfail, len(results)))
        for okk, name, detail in results:
            if not okk:
                print("   FAIL  %s   %s" % (name, detail))
        print()
        print("  neurokit2 in use: %s" % nkver)
        print("  A failure in [2] or the phantom-beat check in [6] is the DETECTOR:")
        print("  this neurokit build reached a different answer on input whose correct")
        print("  answer is known by construction.  A failure elsewhere is this tool.")
        print("  Send the output either way.")
    print("=" * 100)
    return 0 if nfail == 0 else 1


# ======================================================================== main

def add_segment(ap):
    ap.add_argument("--segment", type=float, default=SEGMENT_MIN_DEFAULT,
                    metavar="MIN",
                    help="analyse a recording longer than MIN minutes (by "
                         "more than %d%%%% of MIN) as consecutive MIN-minute "
                         "segments, each exactly as if it were its own file "
                         "(own lead, detection, excision, wall-clock start), "
                         "reading only one segment into memory at a time.  "
                         "Default %g = hourly, like the EDF exports; 0 = never "
                         "split.  Hourly EDFs are shorter than that and are "
                         "unaffected." % (int(round(100 * SEGMENT_TOL_FRAC)),
                                         SEGMENT_MIN_DEFAULT))


def add_common(ap):
    ap.add_argument("--species", choices=sorted(SPECIES), default="pig")
    ap.add_argument("--minutes", type=float, default=0.0, help="0 = whole file")
    ap.add_argument("--lead", type=int, default=None,
                    help="force a lead; default is per-file selection by tmplQ")
    ap.add_argument("--band", type=float, nargs=2, default=None)
    ap.add_argument("--refractory", type=float, default=None)
    ap.add_argument("--qc-min", type=float, default=DEFAULTS["qc_min"])
    ap.add_argument("--clip-k", type=float, default=DEFAULTS["clip_k"],
                    help="clip the detection signal at k x p99(|x|).  Must be "
                         "below ~4 to stop neurokit's 0.25*SPKI floor rising "
                         "above a real beat; see clip_artifacts().")
    ap.add_argument("--chunk", type=float, default=DEFAULTS["chunk_s"],
                    help="detection chunk in seconds; bounds how long a "
                         "poisoned threshold can suppress beats")
    # --no-refill exists so the refill can be A/B'd on ONE build.  Comparing
    # against an older binary would confound the change with everything else
    # that moved, which has already caused one wrong conclusion here.
    ap.add_argument("--no-refill", dest="refill", action="store_false",
                    help="disable artifact-anchored gap refilling")
    ap.add_argument("--refill-gap-mult", type=float, default=3.0,
                    dest="refill_gap_mult",
                    help="re-detect inside any gap longer than this many "
                         "median RR intervals")
    ap.add_argument("--refill-rounds", type=int, default=3,
                    dest="refill_rounds",
                    help="how many times to re-scan; each round can only "
                         "shorten the remaining gaps")
    # Same reasoning as --no-refill: a behaviour change that removes beats has
    # to be comparable against itself on ONE build.  Comparing against an older
    # binary confounds the change with everything else that moved, which has
    # already produced one wrong conclusion in this project.
    ap.add_argument("--no-nosig", dest="nosig", action="store_false",
                    help="do not detect or excise no-signal spans; the rate "
                         "then runs over the full file duration as before, "
                         "less any empty gaps unless --keep-empty is given")
    # The default drops beatless gaps from the denominator; this is the
    # one-flag way back to counting them, on the same build, for the same
    # A/B reason as --no-refill and --no-nosig above.
    ap.add_argument("--keep-empty", dest="keep_empty", action="store_true",
                    default=False,
                    help="keep beatless gaps as real pauses.  By default any "
                         "inter-beat gap still longer than --refill-gap-mult "
                         "x the baseline RR after the refill, and not already "
                         "no-signal or marked, is excised as EMPTY: its "
                         "interior (one normal interval kept) leaves the "
                         "rate's denominator.")
    ap.add_argument("--traceback", action="store_true")


def main():
    ap = argparse.ArgumentParser(
        description="R peak detection, review and accuracy comparison.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__.split("Usage\n-----")[-1])
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("detect", help="detect R peaks and write peak files -- this is (a)")
    p.add_argument("--input", required=True, nargs="+")
    p.add_argument("--outdir", default=None)
    add_common(p); p.set_defaults(fn=cmd_detect)

    p = sub.add_parser("show", help="ASCII display of the signal with peaks marked")
    p.add_argument("--input", required=True, nargs="+")
    p.add_argument("--peaks", default=None)
    p.add_argument("--start", type=float, default=0.0)
    p.add_argument("--seconds", type=float, default=6.0)
    p.add_argument("--panels", type=int, default=3)
    p.add_argument("--width", type=int, default=100,
                   help="columns per panel (clamped to 40-400).  Time "
                        "resolution is --seconds / --width, and `show` prints "
                        "what that buys against the species QRS width before "
                        "it draws anything.  Widening is how to keep a long "
                        "span AND resolve beats, terminal permitting.")
    p.add_argument("--mark-source", default=None, dest="mark_source",
                   help="draw ONLY peak-file rows whose source column is in "
                        "this comma-separated list (e.g. FP,FN on a file "
                        "written by `compare --export-diff`).  The display "
                        "scale is still built from every kept row, so the "
                        "trace stays beat-referenced while only the rows of "
                        "interest are marked.")
    add_common(p); p.set_defaults(fn=cmd_show)

    p = sub.add_parser("spans", help="MEASURE the windowed-range distribution "
                                     "(no threshold applied, changes nothing)")
    p.add_argument("--input", required=True, nargs="+")
    p.add_argument("--win", type=float, default=2.0,
                   help="sliding window in seconds; must exceed the longest "
                        "plausible RR or diastole reads as a dropout")
    p.add_argument("--step", type=float, default=0.25)
    p.add_argument("--min-span", type=float, default=2.0, dest="min_span",
                   help="ignore runs shorter than this; an isolated window "
                        "over threshold is noise, not an event")
    p.add_argument("--hist", action="store_true",
                   help="also print the full range/A distribution and every "
                        "trial cut per file; verbose over many files")
    add_common(p); p.set_defaults(fn=cmd_spans)

    p = sub.add_parser("review", help="write an editable peak file with suggestions -- for (b)")
    p.add_argument("--input", required=True, nargs="+")
    p.add_argument("--out", required=True)
    add_common(p); p.set_defaults(fn=cmd_review)

    p = sub.add_parser("compare", help="score an edited file against detection -- (a) vs (b)")
    p.add_argument("--auto", default=None,
                   help="peak file for (a).  If omitted, --input is detected "
                        "now and that detection becomes (a) -- which is the "
                        "form to use when (b) is a Ponemah beat list.")
    p.add_argument("--manual", required=True)
    p.add_argument("--input", default=None, nargs="+")
    p.add_argument("--match-tol", type=float, default=None, help="ms")
    p.add_argument("--max-windows", type=int, default=20)
    p.add_argument("--arbiter", default=None,
                   help="a THIRD peak file, from another simultaneous lead on "
                        "the same animal, OVERRIDING the automatic choice; or "
                        "'none' to switch arbitration off.  Every lead sees "
                        "every beat, so a disagreement between (a) and (b) "
                        "can be put to a vote instead of left open: a beat "
                        "(a) found, (b) rejected and the arbiter has is (b)'s "
                        "miss, not (a)'s error.  Refused if the arbiter "
                        "shares an electrode with (a) or (b), since then it "
                        "is not an independent witness.  Default: chosen "
                        "automatically from --marks / --arbiter-candidates.")
    p.add_argument("--marks", default=None,
                   help="a .PnmMarks sidecar whose every channel context is "
                        "a candidate arbiter.  Default: the file (b) was "
                        "exported from, else the ONE .PnmMarks beside --input "
                        "or in its parent folder.  Candidates on (a)'s or "
                        "(b)'s electrode (median |dt| < %.1f ms) are "
                        "rejected; the rest are ranked by F1 against (b)."
                        % ARBITER_SAME_ELECTRODE_MS)
    p.add_argument("--arbiter-candidates", nargs="+", default=None,
                   dest="arbiter_candidates",
                   help="extra candidate arbiter peak files (e.g. `marks "
                        "--export-beats` output), judged by the same rule")
    p.add_argument("--export-diff", default=None, dest="export_diff",
                   help="write the disagreements to a peak file, on the "
                        "RECORDING's clock, and print a ready-made `show` "
                        "command for the worst window.  The measured offset "
                        "is already removed, so unlike (b) itself this file "
                        "can be displayed against the waveform directly.")
    p.add_argument("--no-align", dest="align", action="store_false",
                   help="do NOT measure the clock offset between the two peak "
                        "trains.  The offset is real -- a Ponemah export is "
                        "timed from its first beat, a waveform from sample "
                        "zero -- so this is for showing what the score would "
                        "have been without the correction, not for normal use.")
    p.add_argument("--align-max", type=float, default=5.0, dest="align_max",
                   help="widest offset to search for, in seconds")
    p.add_argument("--start", default=None, metavar="S",
                   help="score only the stretch starting S into the recording "
                        "(seconds, or HH:MM:SS); --minutes gives its length "
                        "(default: (b)'s # duration_s, else %d min).  Without "
                        "--start, a (b) exported from a segment page is scored "
                        "on that page's stretch, read from its "
                        "# segment_offset_s header.  A (b) on the recording's "
                        "clock is cut to the stretch and shifted to its start, "
                        "and so are the arbiter candidates." % SEGMENT_MIN_DEFAULT)
    add_common(p); p.set_defaults(fn=cmd_compare, align=True)

    p = sub.add_parser("report", help="QC and rate summary over many files")
    p.add_argument("--input", required=True, nargs="+")
    p.add_argument("--html", default=None, metavar="OUT.html",
                   help="also write the table as ONE self-contained HTML page "
                        "(opens in any browser, no internet needed)")
    p.add_argument("--view-dir", default=None, dest="view_dir", metavar="DIR",
                   help="also write each file's `view` page into DIR; with "
                        "--html the table links to them.  A segmented "
                        "recording gets one <base>.segNN.view.html per "
                        "segment plus <base>.index.html")
    add_segment(p)
    add_common(p); p.set_defaults(fn=cmd_report)

    p = sub.add_parser("trend",
                       help="N-minute average bpm over wall-clock time, "
                            "across many files")
    p.add_argument("--input", required=True, nargs="+")
    p.add_argument("--bin", type=float, default=5.0,
                   help="bin width in MINUTES (5, 10, 30, 60 ...); bins are "
                        "aligned to the wall clock, not to file starts")
    p.add_argument("--min-coverage", type=float, default=0.5,
                   dest="min_coverage",
                   help="a bin with less analysable time than this fraction "
                        "is drawn as '?' and left out of the summary.  This "
                        "is a REPORTING choice, not a measurement: the bin's "
                        "bpm is still computed and still written to --csv.")
    p.add_argument("--width", type=int, default=108,
                   help="bins per plot panel")
    p.add_argument("--table", action="store_true",
                   help="also print every bin as a row")
    p.add_argument("--csv", default=None,
                   help="write the bins to CSV, including thin and empty "
                        "ones, for plotting elsewhere")
    p.add_argument("--exclude", nargs="+", default=None,
                   help="span file(s) of start_s,end_s to cut from BOTH the "
                        "beat count and the seconds -- what "
                        "`marks --export-excl` writes.  An EDF export carries "
                        "no bad-data sidecar, so without this a trend over "
                        "EDF parts runs straight through Ponemah's marked "
                        "intervals (8.41%% of P10) as though they were clean.")
    p.add_argument("--html", default=None, metavar="OUT.html",
                   help="also write an interactive trend chart, summary and "
                        "bin table as ONE self-contained HTML page (opens in "
                        "any browser, no internet needed)")
    add_segment(p)
    add_common(p); p.set_defaults(fn=cmd_trend)

    p = sub.add_parser("clipsweep",
                       help="test whether long gaps are the detector's SPKI "
                            "ratchet or a real dropout")
    p.add_argument("--input", required=True, nargs="+")
    p.add_argument("--clip-ks", type=float, nargs="+", default=[8.0, 4.0, 3.0, 2.0],
                   dest="clip_ks",
                   help="clip levels to try, first one is the baseline")
    add_common(p); p.set_defaults(fn=cmd_clipsweep)

    p = sub.add_parser("probe",
                       help="report what an unreadable file actually is, with "
                            "evidence, so a reader can be written from it")
    p.add_argument("--input", required=True, nargs="+")
    p.add_argument("--fs-hint", type=float, default=500.0, dest="fs_hint",
                   help="sampling rate to ASSUME when converting a detected "
                        "period into bpm.  Nothing is read from the file to "
                        "confirm it, so the reported bpm scales directly with "
                        "this number; it is a sanity check, not a measurement.")
    p.add_argument("--rows", type=int, default=0,
                   help="for a SQLite sidecar, also print the first N rows of "
                        "every table.  Off by default: a table listing is safe "
                        "to run on anything, 26 MB of beat times is not.")
    p.add_argument("--force", action="store_true",
                   help="run the waveform search even on a container the magic "
                        "has already identified as something else.  The search "
                        "always returns a candidate, so on a PNG or a database "
                        "that candidate is noise -- this exists for the case "
                        "where the magic is wrong.")
    p.set_defaults(fn=cmd_probe, species="pig")

    p = sub.add_parser(
        "marks",
        help="read Ponemah's OWN beat list and bad-data intervals from a "
             ".PnmMarks sidecar, and export them")
    p.add_argument("--input", required=True, nargs="+",
                   help="one or more .PnmMarks files")
    p.add_argument("--export-beats", dest="export_beats", default=None,
                   help="write Ponemah's beats as a peak file that "
                        "`compare --manual` reads.  Beats inside a bad-data "
                        "interval are written keep=0 rather than dropped, so "
                        "the exclusion is visible and reversible.")
    p.add_argument("--export-excl", dest="export_excl", default=None,
                   help="write the merged bad-data intervals as "
                        "start_s,end_s,dur_s")
    p.add_argument("--context", type=int, default=None,
                   help="ChannelContextId to export.  Default is the context "
                        "with the most cycles, which on a multi-channel "
                        "recording is the ECG one -- chosen by measurement "
                        "rather than by a hardcoded id.")
    p.set_defaults(fn=cmd_marks, species="pig")

    p = sub.add_parser(
        "verify",
        help="settle a binary layout by checking it against an export of the "
             "same recording")
    p.add_argument("--raw", required=True,
                   help="the binary file whose layout is unknown")
    p.add_argument("--against", required=True, nargs="+",
                   help="export(s) of the SAME recording with a known reader "
                        "(EDF, WAV or ASCII).  Pass several -- the extra ones "
                        "test that the payload stays contiguous further in.")
    p.add_argument("--seconds", type=float, default=10.0,
                   help="window length to match, in seconds")
    p.add_argument("--max-channels", type=int, default=8, dest="max_channels",
                   help="largest interleaved channel count to try")
    p.add_argument("--offsets", type=int, nargs="+", default=None,
                   help="extra byte offsets to try as the start of the payload")
    p.set_defaults(fn=cmd_verify, species="pig")

    p = sub.add_parser("view",
                       help="write an HTML viewer: every lead stacked, the "
                            "detection lead in gold, this tool's R peaks marked")
    p.add_argument("--input", required=True, nargs="+")
    p.add_argument("--out", default=None,
                   help="output HTML for a single input; default is "
                        "<input name>.view.html in --outdir")
    p.add_argument("--outdir", default=None,
                   help="directory for the HTML files (default: current)")
    p.add_argument("--seconds", type=int, default=20,
                   choices=list(VIEW_WINDOWS_S),
                   help="initial window width in seconds")
    p.add_argument("--ponemah", default=None,
                   help="overlay Ponemah's beats: a peak file from `marks "
                        "--export-beats`.  Placed on each file's clock by its "
                        "stated origin, then the residual offset is measured "
                        "against this tool's beats before it is applied.")
    p.add_argument("--edits", default=None,
                   help="start from a file previously saved with Export CSV, "
                        "to carry on editing (single input only)")
    p.add_argument("--window", action="store_true",
                   help="also open the page(s) in a desktop window; needs "
                        "`pip install pywebview`, else the HTML still works "
                        "in any browser")
    p.add_argument("--start", default=None, metavar="S",
                   help="write ONE page for an arbitrary stretch: S seconds or "
                        "HH:MM:SS from the recording start, --minutes long "
                        "(default one --segment).  Named "
                        "<base>.HHMMSS-HHMMSS.view.html unless --out is given")
    add_segment(p)
    add_common(p); p.set_defaults(fn=cmd_view)

    p = sub.add_parser("selftest",
                       help="verify this install against data with a known answer")
    p.set_defaults(fn=cmd_selftest, species="pig")

    args = ap.parse_args()
    if not hasattr(args, "qc_min"):
        args.qc_min = DEFAULTS["qc_min"]
    if not SPECIES[args.species].validated:
        print("  WARNING: the %s profile has never been validated against real data.\n"
              "           Its numbers are scaled guesses.  Check them against\n"
              "           hand-marked beats before relying on any output."
              % args.species, file=sys.stderr)
    rc = args.fn(args)
    if rc:
        sys.exit(rc)


if __name__ == "__main__":
    main()
