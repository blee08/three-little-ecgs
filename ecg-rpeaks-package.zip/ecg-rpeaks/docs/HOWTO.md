# ecg-rpeaks how-to guide

Step-by-step recipes for installing the tool and for the jobs the lab does
most often. For what the tool does and why, see [OVERVIEW.md](OVERVIEW.md).
For a short reference of commands and options, see the
[README](../README.md).

Every recipe is a list of commands to copy into a terminal. If you get stuck,
paste this page and the error message into an AI assistant and ask for help
with the step you are on.

**Contents**

1. [Install on a Mac](#1-install-on-a-mac)
2. [Install on Windows](#2-install-on-windows)
3. [Terminal basics you will need](#3-terminal-basics-you-will-need)
4. [How the tool handles one long .PnmWav file](#4-how-the-tool-handles-one-long-pnmwav-file)
5. [Recipe: heart-rate trend for a whole recording](#5-recipe-heart-rate-trend-for-a-whole-recording)
6. [Recipe: hour-by-hour summary with links to the viewer](#6-recipe-hour-by-hour-summary-with-links-to-the-viewer)
7. [Recipe: check and correct the beats](#7-recipe-check-and-correct-the-beats)
8. [Recipe: measure accuracy against Ponemah or your corrections](#8-recipe-measure-accuracy-against-ponemah-or-your-corrections)
9. [Recipe: decide how to treat bad and empty stretches](#9-recipe-decide-how-to-treat-bad-and-empty-stretches)
10. [If you have EDF files instead](#10-if-you-have-edf-files-instead)
11. [Update, uninstall, start over, and share results](#11-update-uninstall-start-over-and-share-results)
12. [When something goes wrong](#12-when-something-goes-wrong)

---

## 1. Install on a Mac

You need the `ecg-rpeaks` folder (unzip `ecg-rpeaks-package.zip` if that is
what you received). The example assumes it is in your Downloads folder.

If an earlier install attempt did not work, first remove it as described in
[section 11](#11-update-uninstall-start-over-and-share-results) ("Start over
from a clean slate"), then follow these steps.

1. Open **Terminal** (press Cmd+Space, type "Terminal", press Return).
2. Install `uv`, a free tool that installs Python programs and a suitable
   Python for them:

   ```bash
   curl -LsSf https://astral.sh/uv/install.sh | sh
   ```

3. **Close the Terminal window and open a new one**, so the new command is
   found.
4. Install the tool:

   ```bash
   cd ~/Downloads
   uv tool install --python 3.12 "./ecg-rpeaks[window]"
   ```

   This downloads Python 3.12 and the scientific libraries the first time,
   which can take a few minutes. The tool needs Python 3.10 or newer; a Mac's
   built-in `python3` is often 3.9, which does not work, so `--python 3.12`
   tells `uv` to use its own copy. If you see the warning "failed to patch the
   install name of the dynamic library", ignore it; it is harmless for this
   tool.
5. Check which Python the tool got:

   ```bash
   "$(uv tool dir)/ecg-rpeaks/bin/python" --version
   ```

   It must say `Python 3.12.x`. If it says 3.9, start over (section 11) and
   repeat step 4.
6. Check the install:

   ```bash
   ecg-rpeaks selftest
   ```

   The very first run can sit for a few minutes before anything appears
   (macOS checks the new libraries and matplotlib builds a font cache). Let it
   finish. It runs the built-in checks on made-up data and should end with
   `SELFTEST PASSED`. The first line of the output shows the build, for
   example `ecg_rpeaks/1.1 build 65d12b64`.

If step 6 says `command not found`, run `uv tool update-shell`, open a new
Terminal window, and try again.

## 2. Install on Windows

1. Open **PowerShell** (press the Windows key, type "PowerShell", press
   Enter).
2. Install `uv`:

   ```powershell
   powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
   ```

3. **Close PowerShell and open a new window.**
4. Install the tool (adjust the folder if you unzipped it elsewhere):

   ```powershell
   cd $HOME\Downloads
   uv tool install --python 3.12 ".\ecg-rpeaks[window]"
   ```

5. Check which Python the tool got; it must say `Python 3.12.x`:

   ```powershell
   & "$(uv tool dir)\ecg-rpeaks\Scripts\python.exe" --version
   ```

6. Check the install (the first run can take a few minutes to start):

   ```powershell
   ecg-rpeaks selftest
   ```

If `ecg-rpeaks` is not found, run `uv tool update-shell`, open a new
PowerShell window, and try again.

## 3. Terminal basics you will need

- **Go to a folder:** `cd` followed by the folder path. Use a folder where you
  want the output files to go, for example `cd ~/Desktop/P10-results` (Mac) or
  `cd $HOME\Desktop\P10-results` (Windows). Create it first in Finder or
  Explorer if needed.
- **Paths with spaces need quotes.** Mac: `'...'`. Windows: `"..."`.
- **Easy paths:** drag a file or folder from Finder or Explorer into the
  terminal window and its full path is pasted for you.
- **Long commands.** The examples split long commands with `\` at the end of
  a line (Mac). In PowerShell, use a backtick `` ` `` instead, or put the
  whole command on one line.
- **Open a result file:** `open FILE.html` (Mac) or `start FILE.html`
  (Windows), or double-click it in Finder or Explorer.
- **Help for any command:** `ecg-rpeaks trend --help`.

The examples below use this recording folder. Replace the paths with yours.

```
/Users/me/pig-data/08062023 P10/
    08062023 P10.P10.20230806195959.PnmWav     <- raw recording, 18.6 h
    08062023 P10.1.P10.PnmMarks                <- Ponemah's beats and bad intervals
```

Keep the `.PnmMarks` file next to the `.PnmWav`. The tool finds it there on
its own and uses Ponemah's bad intervals and beat lists from it.

To keep the commands short, first store the two paths in variables:

```bash
# Mac
DATA='/Users/me/pig-data/08062023 P10'
P="$DATA/08062023 P10.P10.20230806195959.PnmWav"
M="$DATA/08062023 P10.1.P10.PnmMarks"
```

```powershell
# Windows PowerShell
$DATA = "C:\Users\me\pig-data\08062023 P10"
$P = "$DATA\08062023 P10.P10.20230806195959.PnmWav"
$M = "$DATA\08062023 P10.1.P10.PnmMarks"
```

Then write `"$P"` and `"$M"` in the commands, with the quotes.

---

## 4. How the tool handles one long .PnmWav file

A `.PnmWav` holds the whole recording in one file (18.6 hours for P10). The
tool does not analyse it in one piece. It cuts it into **segments of 60
minutes** and treats each segment like its own file:

- Each segment gets its own lead choice, its own beat detection, its own
  share of Ponemah's bad intervals, and its own beatless gaps.
- Each segment starts with 15 seconds borrowed from the one before, so no
  beat is lost or counted twice at a boundary.
- Only one segment is in memory at a time.
- A short tail is not left on its own: if the last piece is 3 minutes or
  less, it joins the segment before. P10 gives 19 segments: 18 of 60 minutes
  and one of 36 minutes.

Segments are named after the file and their place in it, for example
`08062023 P10.P10.20230806195959 seg03 (02:00:00-03:00:00)`. The times are
hours:minutes:seconds from the start of the recording.

You can change the length with `--segment MINUTES` (for example
`--segment 30`), or turn it off with `--segment 0`. Turning it off needs
much more memory: several GB for an 18-hour file.

---

## 5. Recipe: heart-rate trend for a whole recording

**Goal:** the heart rate in 5-minute steps across the whole recording, as a
web page.

1. Go to your results folder.
2. Run:

   ```bash
   ecg-rpeaks trend --bin 5 --input "$P" --html P10_trend.html
   ```

   It works through the 19 segments one after another, so expect it to take
   a while. Each segment is placed at its own time in the recording, so the
   trend is one continuous line from start to end.
3. Open `P10_trend.html`.

What the page shows:

- The heart rate in each 5-minute step. Hover over a point for its time,
  rate, beat count and usable seconds.
- Hollow points are steps where less than half the time was usable.
- Shaded gaps are times with no recording; the line is never joined across
  them.
- The totals: beats, usable time (in hours and seconds), and the overall rate.

Ponemah's bad intervals are already left out, because the tool reads them
from the `.PnmMarks` file. You do not need `--exclude`.

The terminal prints the same summary as text. The `analysable` line gives
the usable seconds with beatless gaps removed and with them kept.

## 6. Recipe: hour-by-hour summary with links to the viewer

**Goal:** one table with a row per hour of the recording, each row linked to
a viewer page for that hour.

```bash
ecg-rpeaks report --input "$P" --html P10_report.html --view-dir views
```

This takes longer than `trend`, because it also writes one viewer page per
segment into the `views` folder.

Open `P10_report.html`. There is one row per segment (19 for P10). Each row
lists the lead used, beats, usable seconds, the seconds removed for each
reason (no signal, Ponemah's bad intervals, beatless gaps), the rate, and any
warnings. Click a row's name to open its viewer page.

Below the segment rows is a **TOTAL** line for the whole recording. Its rate
is all the beats divided by all the usable time, not an average of the
hourly rates.

A segment whose warnings column is not empty deserves a look in the viewer
before its rate is used. The [implementation notes](IMPLEMENTATION.md#5-rate-and-flags)
list what each warning means.

## 7. Recipe: check and correct the beats

**Goal:** look at the detected beats, fix mistakes, and save a corrected list.

### 7a. Pages for the whole recording

```bash
ecg-rpeaks view --input "$P" --outdir views
```

This writes one page per segment, such as
`views/08062023 P10.P10.20230806195959.seg03.view.html`, and an index page
that lists them all:

```bash
open "views/08062023 P10.P10.20230806195959.index.html"
```

The index shows each hour with its beats and rate. Click one to open it.
If you already ran recipe 6, the same pages are in `views` and you can skip
this step.

### 7b. A page for one stretch you choose

If you already know where to look, make a page for just that stretch:

```bash
ecg-rpeaks view --input "$P" --start 02:15:00 --minutes 30 --outdir views
```

`--start` is the time from the start of the recording, as `HH:MM:SS`,
`MM:SS` or seconds. This page is named
`views/08062023 P10.P10.20230806195959.021500-024500.view.html`. Without
`--minutes`, the page is 60 minutes long.

To open a page in its own window with a normal Save dialog, add `--window`
to either command.

### 7c. Using the page

- All three leads are stacked. The lead the tool used is **gold**, with a
  marker on every detected beat.
- Change the window width (2 s to 5 min) and step through the stretch.
- **Red** shading: no signal, missing data, or Ponemah's bad intervals, left
  out of the rate. **Violet** shading: stretches with no beats, left out by
  default.
- The chips at the top show the beat count, the rate, and the usable hours.
- The time axis counts from the start of the page. The page title gives the
  page's place in the recording.

To correct beats:

1. Turn on **Edit R**.
2. Click on a beat marker to remove a wrong detection.
3. Click on the trace where a beat was missed to add one. It snaps to the
   nearest peak.
4. The count, rate and shading update after each click. Undo is available.
5. Click **Export CSV**. In a browser, the file (named like
   `08062023 P10.P10.20230806195959.seg03.edited.csv`) goes to your
   Downloads folder; with `--window` you choose where to save it.

The times in this file count from the start of the page, not the start of
the recording. The file records the page's starting point on a line
`# segment_offset_s`, so the tool can put the beats back in place later.

### 7d. Continue editing later

Reopen the same stretch with your saved file. Give `--start` (and
`--minutes` if the page was not 60 minutes), so the tool knows which
stretch the edits belong to:

```bash
# a segment page: seg03 starts at 02:00:00
ecg-rpeaks view --input "$P" --start 02:00:00 --outdir views \
  --edits ~/Downloads/"08062023 P10.P10.20230806195959.seg03.edited.csv"

# a stretch page from 7b
ecg-rpeaks view --input "$P" --start 02:15:00 --minutes 30 --outdir views \
  --edits ~/Downloads/"08062023 P10.P10.20230806195959.021500-024500.edited.csv"
```

### 7e. Show Ponemah's beats on top

Export Ponemah's beats once (recipe 8, step 1), then add
`--ponemah P10_ch3.csv` to any `view` command. The tool lines them up with
each page on its own.

## 8. Recipe: measure accuracy against Ponemah or your corrections

**Goal:** recall and precision of the tool's beats against another beat list.

1. See what Ponemah recorded, then export its beats for the lead you want:

   ```bash
   ecg-rpeaks marks --input "$M"
   ```

   The table lists each channel ("context") with its beat count. Contexts
   running at 1-10 Hz are timing ticks, not beats. Pick a cardiac context,
   then export it (for P10, context 2 is subject channel 3):

   ```bash
   ecg-rpeaks marks --input "$M" --context 2 --export-beats P10_ch3.csv
   ```

   The times in this file count from the start of the recording.

2. Compare the tool's beats with Ponemah's over the first 30 minutes:

   ```bash
   ecg-rpeaks compare --minutes 30 --input "$P" --manual P10_ch3.csv
   ```

   Or over any other stretch, with `--start`:

   ```bash
   ecg-rpeaks compare --start 02:00:00 --minutes 30 --input "$P" --manual P10_ch3.csv
   ```

   `compare` does not split the file into segments. Always give `--minutes`
   with a `.PnmWav`; the whole 18-hour file at once needs several GB of
   memory.

3. Read the output from the top:
   - **clock offset:** how far apart the two clocks were, measured.
   - **true positives / false positives / false negatives:** beats both
     found / only the tool found / only Ponemah found.
   - **sensitivity** (recall) and **positive predictive value** (precision).
   - **ARBITER:** the tool picks Ponemah's list from a different electrode as
     a tie-breaker, shows why it chose it, sorts each disagreement, and
     reports accuracy against the beats at least two of the three lists
     contain.
   - **WHERE THEY DISAGREE:** disagreements per minute, to know where to look.

4. To look at the disputed beats, add `--export-diff P10_diff.csv` to the
   `compare` command. It then prints a ready-made `show` command that draws
   those beats in the terminal. Or open the same stretch in the viewer
   (recipe 7b).

**Against your own corrections:** use the file you exported in recipe 7 as
`--manual`. The tool reads the page's starting point from the file and
scores that same stretch, so you do not need `--start`:

```bash
ecg-rpeaks compare --input "$P" \
  --manual ~/Downloads/"08062023 P10.P10.20230806195959.seg03.edited.csv"
```

Options: `--arbiter FILE` chooses the tie-breaker yourself; `--arbiter none`
skips it. If the `.PnmMarks` file is not next to the `.PnmWav`, add
`--marks "$M"`.

## 9. Recipe: decide how to treat bad and empty stretches

Three kinds of stretch can be left out of the rate. With a `.PnmWav`, all
three are on by default:

- **No signal or missing data:** always left out.
- **Ponemah's bad intervals:** left out automatically, read from the
  `.PnmMarks` file next to the `.PnmWav`.
- **Beatless gaps** (no beats for more than three normal beat intervals, even
  after a second search): left out by default. If the heart may truly pause,
  add `--keep-empty` to count them as pauses.

To see how much the beatless-gap choice matters, run the trend both ways and
compare the overall rates:

```bash
# Default: beatless gaps left out
ecg-rpeaks trend --bin 5 --input "$P" --html P10_trend.html
# Keep beatless gaps as pauses
ecg-rpeaks trend --bin 5 --input "$P" --keep-empty --html P10_trend_keep.html
```

In the viewer, the **Drop empty gaps** checkbox makes the same choice for one
page, live.

On P10, Ponemah's bad intervals changed the overall rate by 0.8%, and
beatless gaps covered only 28 seconds, so these choices mattered little
there. That may not hold for other animals.

## 10. If you have EDF files instead

Everything above also works on EDF files exported from Ponemah. The
differences:

- Give a folder, and the tool reads every `.edf` in it, in time order:

  ```bash
  ecg-rpeaks trend --bin 5 --input "$DATA/sample EDFs" --html P10_trend.html
  ecg-rpeaks report --input "$DATA/sample EDFs" --html P10_report.html --view-dir views
  ecg-rpeaks view --input "$DATA/sample EDFs/P10_seg01_part001_20230806_195959.edf" --outdir views
  ```

- Hourly EDF files are already short, so they are not split, and each file
  gets one page and one report row.
- EDF files do not carry Ponemah's bad intervals. To leave them out, export
  them from the `.PnmMarks` file and pass them to `trend`:

  ```bash
  ecg-rpeaks marks --input "$M" --export-excl P10_badspans.csv
  ecg-rpeaks trend --bin 5 --input "$DATA/sample EDFs" --exclude P10_badspans.csv --html P10_trend_excl.html
  ```

  The output then shows the rate with and without them side by side.

## 11. Update, uninstall, start over, and share results

**Update** to a new version: uninstall the old one, replace the `ecg-rpeaks`
folder with the new one, then from the folder that contains it:

```bash
uv tool uninstall ecg-rpeaks
uv tool install --python 3.12 "./ecg-rpeaks[window]"
ecg-rpeaks selftest
```

Check that the build tag on the first line changed. Uninstalling first,
rather than using `--reinstall`, makes sure the old Python environment is not
kept.

**Uninstall:**

```bash
uv tool uninstall ecg-rpeaks
hash -r        # Mac only: make the terminal forget the old command
```

**Start over from a clean slate.** Use this if an install went wrong, for
example if every `ecg-rpeaks` command fails with a `TypeError` or seems to
hang:

```bash
# 1. remove the tool
uv tool uninstall ecg-rpeaks
# 2. remove any copy installed with pip (harmless if there is none)
python3 -m pip uninstall -y ecg-rpeaks        # Windows: py -m pip uninstall -y ecg-rpeaks
# 3. remove the Python that uv downloaded, and uv's download cache
uv python uninstall 3.12
uv cache clean
# 4. make the terminal forget the old command (Mac)
hash -r
```

Then follow section 1 (Mac) or section 2 (Windows) again from the top,
including the Python version check.

**Remove `uv` itself** too, only if you no longer need it (Mac):

```bash
uv cache clean
rm -r "$(uv python dir)" "$(uv tool dir)"
rm ~/.local/bin/uv ~/.local/bin/uvx
```

**Share results:** the `.html` pages are self-contained. Email them or put
them on a shared drive, and they open offline in any browser. A report page
and an index page link to viewer pages in the `views` folder, so share the
folder with them. When reporting numbers, include the build tag printed at
the top of the output, so anyone can tell which version produced them.

## 12. When something goes wrong

| Symptom | What to do |
|---|---|
| `command not found: ecg-rpeaks` | Run `uv tool update-shell`, open a new terminal. |
| `No such file or directory` for a path that exists | The path has spaces; put it in quotes. Or drag the file into the terminal. |
| A command finds no input files | For a folder, `--input` reads only `.edf` files. Give a `.PnmWav` file by its full name. |
| The computer slows down or the tool stops with a memory error | Keep segmenting on (do not use `--segment 0`), or use a shorter `--segment 30`. For `compare`, always give `--minutes`. |
| `--edits belongs to ONE page` | The file was split into segments. Add `--start` (and `--minutes`) for the page the edits came from (recipe 7d). |
| Bad intervals are not left out | The `.PnmMarks` file must sit in the same folder as the `.PnmWav`. |
| `TypeError: unsupported operand type(s) for \|` in `neurokit2` | The tool was installed on Python 3.9 or older. Start over from a clean slate (section 11), reinstall, and check the Python version (section 1, step 5). |
| "failed to patch the install name of the dynamic library" during install | Harmless for this tool; ignore it. It means Apple's command line tools are not installed. Only if the tool then fails to start, run `xcode-select --install` and start over (section 11). |
| The first command after installing seems to hang | Wait a few minutes once: macOS checks the new libraries and matplotlib builds a font cache. Later runs are fast. |
| Install fails on `neurokit2` or `scipy` | Make sure you installed with `uv` (it picks a Python with ready-made packages), then retry. |
| `view --window` does not open a window | The `[window]` part was left out when installing. Open the `.html` file in a browser, or reinstall with `[window]`. |
| `compare` says it cannot find the `.PnmMarks` file | Add `--marks "$M"`. |
| A rate looks wrong | Run `ecg-rpeaks selftest`. If it passes, open that hour in the viewer and check the chosen lead, the shaded stretches, and the warnings column in `report`. |

When asking for help, send the full command, the first ten lines of its
output (they include the build tag), and the error message.
