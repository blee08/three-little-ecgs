# ecg-rpeaks: code and implementation notes

This is the next level down from [OVERVIEW.md](OVERVIEW.md). It is for people
who will read, change, or check the code. Line numbers are approximate and
refer to build `65d12b64`; search for the function names instead of relying
on them.

## 1. Shape of the code

Everything lives in one file, `ecg_rpeaks.py` (about 14,000 lines). That is
deliberate: the lab can copy one file to a laptop and run it, and the build
tag identifies exactly which code produced any output.

The file is split into sections marked by `# ===== name` banners:

| Section | What it holds | Key names |
|---|---|---|
| Version and profiles | Build tag, per-species settings, defaults | `VERSION`, `_self_hash`, `Species`, `PIG`, `RAT`, `DEFAULTS` |
| Readers | EDF, WAV, text, PnmWav, file-type sniffing, channel choice | `load_signals`, `MiniEDF`, `read_ascii`, `read_ponemah`, `_sniff_format` |
| Unknown-format probe | Tools for reverse-engineering a file | `probe_layouts`, `sqlite_describe`, `read_marks` |
| Layout verification | Proving a binary layout against an export | `verify_layouts`, `verify_fit` |
| Signal / detection | Filters, Pan-Tompkins wrapper, chunking, refill | `bp`, `clip_artifacts`, `detect_nk`, `detect_chunked`, `refill_gaps` |
| Morphology | Beat shapes, clustering, lead score | `extract_beats`, `cluster_beats`, `template_quality` |
| Rhythm, rate, integrity | Spans, excision, rate, flags, trend bins | `rate_and_integrity`, `empty_gap_spans`, `bin_record` |
| Analysis | The per-file pipeline | `analyse`, `Result` |
| Peak files | CSV beat lists | `write_peaks`, `read_peaks`, `PEAK_FIELDS` |
| Display | Text waveforms | `ascii_wave`, `cmd_show` |
| Compare | Clock alignment, matching, tie-breaker | `peak_train_lag`, `match_peaks`, `select_arbiter`, `arbitrate`, `cmd_compare` |
| Commands | `marks`, `probe`, `verify`, `detect`, `review` | `cmd_marks`, `write_marks_peaks`, `read_span_file` |
| HTML reports | `trend --html`, `report --html` | `_trend_body`, `_report_body` |
| Selftest | Synthetic data builders and checks | `_st_build`, `_st_write_edf`, `_st_write_pnmwav`, `cmd_selftest` |
| View | The interactive viewer page | `build_view_html`, `VIEW_HTML`, `place_ponemah`, `cmd_view` |
| Main | Argument parsing | `add_common`, `main` |

### Build tag

`_self_hash()` hashes the file's own bytes after normalising line endings
(`\r\n` and `\r` to `\n`) and stripping trailing newlines, and keeps the first
8 hex digits of the SHA-1. `VERSION` is `ecg_rpeaks/1.1 build <tag>`, and it is
printed at the top of every command's output and written into every peak
file. Normalising means copying the file between Linux, Mac and Windows does
not change the tag.

### Species profiles

Every animal-specific number lives in a `Species` object, so nothing else
hardcodes one. The pig profile is measured; the rat profile is a starting
point and is marked `validated=False`, which makes `main()` print a warning.

| Field | Pig | Meaning |
|---|---|---|
| `fs_expected` | 500 Hz | Expected sample rate (a mismatch prints a note) |
| `hr_plausible` | 40-200 bpm | Outside this, the file gets `RATE_IMPLAUSIBLE` |
| `refractory_ms` | 350 | Two beats closer than this are merged |
| `band` | 20-45 Hz | Detection band |
| `snap_ms` | 80 | Search half-window when moving a beat to its peak |
| `match_tol_ms` | 80 | Pairing window in `compare` |
| `beat_half_ms` | 100 | Half-width of the beat window used for templates |
| `amp_floor_frac` | 0.25 | Beats below this fraction of the median height are dropped |
| `no_signal_frac` | 0.15 | Window range below this fraction of a typical beat = no signal |
| `saturated_frac` | 7.0 | Window range above this multiple = saturated (reported only) |

`DEFAULTS` holds the rest: `chunk_s=60`, `lead_in_s=15`, `clip_k=3.0`,
`window_s=60` (QC windows), `corr=0.85` and `kmax=8` (clustering),
`qc_min=0.90`, and the no-signal window `nosig_win_s=2.0`,
`nosig_step_s=0.25`, `nosig_min_s=2.0`.

## 2. Reading files

`load_signals(path, minutes)` is the single entry point. It sniffs the
format from the first bytes (`_sniff_format`), dispatches to a reader, picks
the ECG channels, detrends them, and returns `(cols, fs, ch_names, dur)`,
where `cols` is an `(N, C)` float array.

- **Channel choice.** Channels whose label contains "ecg" are used; otherwise
  the first three valid channels, skipping labels in `SKIP_LABELS`
  (annotation, battery, temperature, activity, accelerometer, gyro, status,
  impedance).
- **Missing samples** arrive as NaN (for example, `x` markers in text exports,
  or Ponemah bad intervals, below). `fill_missing` bridges them by straight
  lines and returns a mask, so filters never see a NaN (one NaN would spread
  through `filtfilt` over the whole record). The mask later becomes excised
  "marked" spans.
- **Start time.** `record_start` takes the recording's wall-clock start from
  the EDF header, the PnmWav container, or a `YYYYMMDD_HHMMSS` stamp in the
  file name. `trend` needs it to place files on one clock.

### EDF and text

`MiniEDF` is a small EDF reader (header offsets, int16 records, scaling to
physical units). `read_ascii` handles text exports with extensions
`.txt .csv .asc .ascii .tsv .dat`; it finds where the numeric data starts and
takes the sample rate from the header or from the timestamps.

### PnmWav (Ponemah native)

The format is undocumented. What the code relies on:

- **Framing.** After a 4-byte magic (`AF 55 55 AA`), the file is a chain of
  records: a uint16 tag, a uint32 length, then that many bytes, little-endian.
  `_pnmwav_chain` walks it and stops at the first malformed record.
- **Named tags.** Only tags with two independent confirmations are named, in
  `PNMWAV_TAG_NAMES`, each with a note saying how it was confirmed. For
  example, 5015 is the sample block (99% of the file's bytes) and 5045 is the
  channel id. Other tags are left unnamed on purpose.
- **Decoding** (`read_ponemah`). Sample blocks are 16-bit signed integers,
  split into channels by tag 5045 (`pnmwav_channel_tag`). Counts are scaled to
  mV from each channel's raw and engineering range (`pnmwav_descriptors`). The
  full-rate channels (the ones with the most samples) are the ECG leads.
- **Sample rate and bad intervals** come from the `.PnmMarks` file next to the
  recording: `TicksPerSample` for the rate (500 Hz is assumed if there is no
  such file), and `BadDataMark` intervals, which are written in as NaN.

> [!NOTE]
> Because of that last point, analysing a `.PnmWav` directly removes
> Ponemah's bad intervals by default, as "marked" time. An EDF export carries
> no such information, so for EDF input Ponemah's intervals are removed only
> with `trend --exclude`.

The decode was checked sample by sample against simultaneous EDF exports
(correlation 1.000 on all three leads); `verify` is the command that does
this check.

### PnmMarks (Ponemah database)

`read_marks` opens the `.PnmMarks` file as SQLite and treats every table and
column as optional.

- `Cycle` holds one row per detected beat: `CycleTime` and a channel context.
  Times are .NET ticks (100 ns units since year 1; `NET_TICKS_PER_S`).
- `ChannelContextInfo` gives each context's subject channel and sample rate.
  Contexts at 1-10 Hz are "epoch" ticks, not beats, and are labelled as such.
- `BadDataMark(StartTime, EndTime)` holds the bad intervals. Overlapping
  intervals are merged before use (`merge_tick_spans`).
- `Cycle.Marks` is a binary field with an unknown layout and is not read.

`marks --export-beats` writes one context as a peak file. Beats inside bad
intervals are kept but written with `keep=0`, so the exclusion is visible and
reversible. The times are seconds from the recording start stated by the
PnmWav container, and the file records `# source_file`, which `compare` uses
to find the `.PnmMarks` again. `marks --export-excl` writes the merged
intervals as `start_s,end_s,dur_s` with a `# t0_ticks` origin line, read back
by `read_span_file`.

## 3. The per-file pipeline: `analyse()`

`analyse(path, args, profile)` runs the steps below and returns a `Result`
with the beats, spans, rates and flags. Every command that computes a rate
goes through it.

1. **Load and fill.** `load_signals`, then `fill_missing`. The missing-sample
   fraction per lead is kept for the lead score.
2. **Choose a lead** (skipped if `--lead` is given). For each lead, run the
   whole detection chain quickly (steps 3-5 below, without refill), then score
   it with `template_quality`:
   - build a template as the median shape of the taller half of the beats;
   - score = fraction of beats whose correlation with the template exceeds
     0.8;
   - subtract the lead's missing-sample fraction.

   The highest score wins. False detections rarely match the template, so a
   lead with many of them scores low. Leads with fewer than 50 beats score -1.
3. **Two filtered copies.** `wide` is band-passed 0.7 Hz to min(240 Hz,
   0.45 fs), is never clipped, and is used for everything about shape and
   height. `det` is band-passed to the profile band (20-45 Hz) and clipped by
   `clip_artifacts` at `clip_k` times the 99th percentile of |det|. It is used
   only for detection.
4. **Detect in chunks.** `detect_chunked` cuts `det` into 60 s pieces, each
   with 15 s of lead-in, and calls `detect_nk` on each. `detect_nk` calls
   `neurokit2.ecg_peaks(method="pantompkins")` and then `enforce_refractory`
   (350 ms, keep the taller). Only peaks in each chunk's core are kept.
   - *Why chunks:* neurokit's adaptive threshold is raised by every accepted
     peak and never lowered by a rejection, so one tall artifact can block
     detection until the threshold is reset. Chunking limits the damage to
     one chunk.
   - *Why clip:* the clip caps how high that threshold can climb. `clip_k=3`
     was chosen from measurements: high enough to stay above the tallest real
     beat, low enough to stop the long gaps seen at `clip_k=4`.
5. **Find no-signal time.** On `wide`, a 2 s window slides in 0.25 s steps.
   Where the window's range is below 15% of the median beat height
   (`median_qrs_amp`) for at least 2 s, that time is **no-signal**. Above 7
   times, it is **saturated** (reported, not removed). No-signal spans and
   marked (missing-sample) spans are merged into the base excision list.
6. **Refill gaps** (`refill_gaps`). Any gap longer than 3 median beat
   intervals is detected again, restarting just after the artifact that
   started it (found with `_first_artifact_end`), up to 3 rounds. No beat may
   be placed inside an excised span. If a gap refills, the threshold was the
   cause; if it stays empty after a clean restart, there was nothing to find.
7. **Snap** each beat to the largest deflection within ±80 ms on `wide`
   (`snap_to_extremum`), so the filter's delay does not shift beat times.
8. **Height floor** (`amplitude_floor`). Beats smaller than 25% of the median
   beat height are dropped. The fraction removed is reported, and above 5% it
   becomes a `AMP_FLOOR_MAJOR` flag.
9. **Drop beats in excised spans**, so beats and seconds leave together.
10. **Empty gaps** (`empty_gap_spans`), explained in section 4.
11. **Shape and rhythm** for QC and flags: `cluster_beats` groups beat shapes
    (correlation 0.85, up to 8 clusters), `classify_rhythm` labels short
    intervals as SPLIT, RESET or COMPENS against a robust baseline interval,
    and `qc_windows` scores each 60 s window.
12. **Rate and flags** (`rate_and_integrity`), explained in section 5.

### Long recordings: segments (`iter_analyses`)

`report`, `trend` and `view` do not call `analyse()` on a long file
directly. They loop over `iter_analyses(path, args, profile, stretch=None)`,
which yields one `(result, signals, info, error)` per piece:

- **Plan** (`segment_plan`, from headers only). A file is split into
  `--segment` minute pieces (default `SEGMENT_MIN_DEFAULT` = 60; 0 turns it
  off) only if it is longer than one segment by more than 5% of a segment. A
  last piece of 5% or less is folded into the one before. P10 (18.6 h) gives
  18 × 60 min + 1 × 36 min.
- **Each piece is a file.** It gets its own lead choice, detection, no-signal
  and empty-gap spans, flags and rate. For a `.PnmWav`, only that piece is
  decoded, with 15 s of lead-in from the previous piece so detection near the
  boundary is not cut short. Beats in the lead-in are dropped, so each beat
  belongs to exactly one piece. Ponemah's bad intervals are sliced to the
  piece. Peak memory is set by one segment, not the file (the selftest
  extrapolates about 290 MB for P10 at 60 min vs about 3.6 GB whole; an
  estimate, not a measurement).
- **`info`** (`_seg_info`) holds the piece's name, tag (`seg01`..`seg19`, or
  `HHMMSS-HHMMSS` for a chosen stretch), and `t0_s`, its start in seconds
  from the recording start. Unsegmented files yield one item with
  `info=None`, so EDF folders behave exactly as before.
- **Stretches.** `view --start S --minutes N` (and `compare --start`) pass
  `stretch=(S, N×60)` and get one piece for exactly that range.
- **Placement.** `trend` puts each piece at recording start + `t0_s`, so the
  pieces of a `.PnmWav` land where the hourly EDFs of the same recording
  would. `report` prints one row per piece and a TOTAL line per recording
  (`segment_totals_line`: all beats over all analysable seconds). `view` and
  `report --view-dir` write `<base>.<tag>.view.html` per piece and an index
  page `<base>.index.html` (`write_segment_index`).
- **Clocks in files.** Times on a segment page, and in its exported CSV,
  count from the piece start. The CSV header says so with
  `# segment_offset_s`, which `compare` uses to score the same stretch.

## 4. Excision: which time is left out

A rate is beats divided by seconds, so any stretch left out must lose both.
There are three kinds of span, all kept separately so reports can say how
much each removed:

| Kind | Source | Applied |
|---|---|---|
| `nosig_spans` | Step 5 (flat trace) | Always, unless `--no-nosig` |
| `mark_spans` | Missing samples, including Ponemah bad intervals read from a PnmWav | Always |
| `empty_spans` | Step 10 | By default; `--keep-empty` turns it off |

`empty_gap_spans(anchors, fs, dur, excluded, gap_mult)`:

- `M` is a robust baseline beat interval (`robust_baseline_rr`: iterated
  median of intervals within 15% of the current estimate; needs at least 25
  beats).
- A gap counts if its length, minus any part already excised, is more than
  `gap_mult × M` (3 by default, shared with the refill).
- The removed piece is the gap's inside, from `t_i + M/2` to
  `t_{i+1} - M/2`, so one normal interval is still counted. Parts already
  excised are subtracted, so nothing is counted twice.

The rate's denominator is `dur` minus the merged spans in use
(`analysable_s`). Interval statistics skip intervals that bridge an excised
span (`rr_bridges_span`), so a removed stretch does not show up as a long gap.

## 5. Rate and flags

`rate_and_integrity` computes `bpm = 60 × beats / analysable_s`, the modal
rate, the share of short intervals, the longest gap (in baseline intervals),
and the share of time in long gaps. `analyse()` adds more flags. The main
ones:

| Flag | Meaning |
|---|---|
| `TOO_FEW_BEATS` | Fewer than 25 beats |
| `RATE_IMPLAUSIBLE` | Rate outside the profile's plausible range |
| `DROPOUT_SUSPECTED` | Mean rate more than 2% below the modal rate: likely missed beats |
| `GAP_TIME_>2%`, `LONG_GAP` | Too much time in long gaps, or one gap over 10 intervals |
| `GAP_ENDS_ON_CHUNK_EDGE` | A long gap ends at a chunk boundary: the threshold problem in step 4 |
| `AMP_FLOOR_x%` / `AMP_FLOOR_MAJOR_x%` | Share of beats removed by the height floor |
| `NO_SIGNAL` / `NO_SIGNAL_MAJOR` | No-signal time present / over 10% of the file |
| `MARKED_x%` / `MARKED_MAJOR_x%` | Missing-sample time |
| `SATURATED` | Saturated stretches found |
| `CLIP_BELOW_KMIN`, `CLIP_DESTROYS_QRS` | `clip_k` is at risk of cutting real beats |

`trustworthy` is false if any flag is present that is not in
`ADVISORY_FLAGS` (`CLIP_BELOW_KMIN`, `SATURATED`, `NO_SIGNAL`) or a
measured-value advisory such as `AMP_FLOOR_0.99%`.

## 6. Commands

| Command | Function | What it does |
|---|---|---|
| `detect` | `cmd_detect` | Run `analyse` and write a peak file |
| `review` | `cmd_review` | Same, plus suggested insertions in long gaps, for hand editing |
| `report` | `cmd_report` → `_report_body` | One row per file: lead, beats, removed time by kind, rate, flags; `--html`, `--view-dir` |
| `trend` | `cmd_trend` → `_trend_body` | Rate in fixed clock-time bins across many files; `--exclude`, `--html` |
| `compare` | `cmd_compare` | Score one beat list against another, with a tie-breaker |
| `view` | `cmd_view` | Write the interactive viewer page(s) |
| `show` | `cmd_show` | Text waveform with beats marked, for a terminal |
| `marks` | `cmd_marks` | Read a `.PnmMarks` file; export beats or bad intervals |
| `spans` | `cmd_spans` | Show the no-signal measurement without applying it |
| `clipsweep` | `cmd_clipsweep` | Try several `clip_k` values on the same files |
| `probe`, `verify` | `cmd_probe`, `cmd_verify` | Investigate an unknown file / prove a binary layout against an export |
| `selftest` | `cmd_selftest` | Built-in checks on synthetic data |

`add_common` adds the options shared by the analysis commands (`--lead`,
`--minutes`, `--species`, `--band`, `--refractory`, `--clip-k`, `--chunk`,
`--keep-empty`, and others). `expand_inputs` accepts files, quoted globs, or
a directory (which means every `.edf` in it), so shell globbing is not needed
on Windows.

## 7. Trend

`bin_record` places each file's beats and time into bins aligned to the wall
clock (for example, 03:00-03:05), not to the file start, so files of
different lengths line up. Each bin keeps three sums: `beats` (after
excision), `live` (analysable seconds), and `span` (recorded seconds). The bin
rate is `beats / live`, the same estimator as the file rate, and
`live / span` is the coverage; bins under 50% coverage are marked thin.
Unrecorded time is drawn as a gap and never joined across.

`--exclude FILE` adds Ponemah's bad intervals from `marks --export-excl`,
placed on each file's clock using the file's stated origin (`t0_ticks`). Beats
inside them and their seconds are removed together, and the text reports the
rate with and without the exclusion. The text output also prints the
analysable seconds with empty gaps dropped and kept.

## 8. Compare

`cmd_compare` scores list (a) (detected now from `--input`, or `--auto`
CSV) against list (b) (`--manual` CSV).

1. **Clock alignment** (`peak_train_lag`). Candidate offsets come from a
   histogram (10 ms bins, ±5 s by default, `--align-max`) of the differences
   between nearby beats. Each candidate is scored by **coverage**: the share
   of (a)'s beats with a partner within the matching window. Ties go to the
   smallest shift, since shifts one beat interval apart line up almost as
   well on a regular rhythm. An offset is applied only if coverage is at least
   50%.
2. **Window cut.** (b) is cut to the part of the recording (a) covers
   (`--minutes`), so beats outside it do not count as misses.
   - `--start S` analyses only `[S, S + len]` of `--input` through
     `iter_analyses(stretch=...)`. The length is `--minutes`, else (b)'s
     `# duration_s`, else 60 min.
   - If (b) has `# segment_offset_s` (a segment page export) and no
     `--start` is given, the stretch is taken from the header. A `--start`
     more than 1 s away from the header prints a warning and moves (b) onto
     the requested stretch.
   - A (b) on the recording's clock (no segment header, beats past the
     stretch) is cut to the stretch plus the alignment margin and shifted by
     `-S`. The same applies to `--auto`, `--arbiter` and arbiter candidates;
     `.PnmMarks` candidates are always cut and shifted.
   - `--export-diff` adds `S` back, so its times stay on the recording clock
     (with a `# stretch_start_s` header line).
3. **Matching** (`match_peaks`). One-to-one greedy pairing by smallest time
   difference within ±80 ms. This is safe because 80 ms is far below a beat
   interval. The result is TP, FP (only in a), FN (only in b), recall,
   precision and F1, plus the timing spread of matched pairs.
4. **Empty gaps** (`compare_empty_spans`). Computed after alignment from
   (a)'s beats plus (b)'s unmatched beats, so a stretch is empty only if
   neither list has a beat there. The same spans are removed from both lists'
   rate denominators.
5. **Tie-breaker** (`select_arbiter`, `arbitrate`). Candidates are every
   context in the `.PnmMarks` file (found from `--marks`, from (b)'s
   `# source_file`, or beside the input) plus any `--arbiter-candidates`.
   Candidates are rejected if they are not cardiac (under 100 Hz), are the
   same list as (b), pair with fewer than 50% of beats
   (`ARBITER_MIN_COVERAGE`), share (b)'s channel, or have a median timing
   difference under 1.0 ms against (a) or (b), which means the same electrode
   (`ARBITER_SAME_ELECTRODE_MS`). Of the rest, the highest F1 against (b) is
   chosen, with a warning below 0.90 (`ARBITER_WARN_F1`). `arbitrate` then
   sorts each FP and FN by whether the tie-breaker has it, and rescores
   against the beats at least two of the three lists contain. `--arbiter
   FILE` overrides the choice; `--arbiter none` turns it off.
6. **Outputs.** Per-minute disagreement counts, rates from each list and the
   majority, and with `--export-diff` a CSV of the disputed beats on the
   recording's clock plus a ready-made `show` command.

## 9. Viewer

`build_view_html(r, cols, title, ...)` returns one HTML string built from
the `VIEW_HTML` template and a JSON payload. The page needs no network.

- **Data.** Each lead is centred, scaled to int16, and base64-encoded, which
  keeps an hour at 500 Hz × 3 leads to a manageable size. Beats are int32
  sample indices. The payload also carries the excised spans, Python's empty
  spans (`empty_py`), and the empty-gap settings (`empty_cfg`).
- **Drawing.** All leads are stacked; the chosen lead is gold. The display
  filter and the window width (`VIEW_WINDOWS_S`, 2 s to 5 min) can be
  changed.
- **Editing.** In Edit R mode, a click within 80 ms of a beat removes it;
  elsewhere it adds a beat snapped to the largest deflection within 40 ms.
  After each edit the JavaScript recomputes empty gaps with the same rule and
  constants as Python, and updates the shading, beat count, bpm and hours. On
  an unedited page it checks its own result against `empty_py` and shows a
  mismatch warning if they differ.
- **Export CSV** writes the peak-file format below with removed beats as
  `keep=0` and added beats as `source=MANUAL`, so `compare --manual` and
  `view --edits` read it directly.
- **Ponemah overlay** (`--ponemah`). `place_ponemah` places Ponemah's beats
  on the file's clock by the stated origin, measures the remaining offset
  against our beats, and applies it only if enough beats match.
- **Desktop window** (`--window`). Opens the same page with pywebview; the
  `_ViewAPI` class supplies a native Save dialog for Export CSV.

## 10. Peak file format

Comment lines start with `#` and carry `key: value` metadata:

```
# ecg_rpeaks/1.1 build 65d12b64
# source_file: /path/to/recording.edf
# species: pig
# fs_hz: 500.0000
# duration_s: 3600.0000
# lead: 1
# config: ...
# config_sha1: ...
# n_auto: 4012
# n_suggested: 0
time_s,sample,amp,rhythm,cluster,qc,source,keep,note
0.8420,421,0.51234,normal,0,1,AUTO,1,
```

- `keep=1` counts the beat; `keep=0` does not.
- `source` is `AUTO` (detected), `SUGGEST` (proposed insertion from
  `review`), `MANUAL` (added by a person in the viewer), `PONEMAH` (from
  `marks --export-beats`), or `TP` / `FP` / `FN` (in a `compare
  --export-diff` file).
- `read_peaks` returns only kept rows, taking `time_s` or, if blank,
  `sample / fs_hz`.
- `config_sha1` lets `compare` check that an edited file is scored against
  the same detection settings.

## 11. Testing and release

### Selftest

`cmd_selftest` builds synthetic recordings in a temporary folder
(`_st_build` makes beat trains with known timing, early beats, noise,
flat holes and artifacts; `_st_write_edf` and `_st_write_pnmwav` write them
as files) and checks the pipeline against the known answers. Checks are
grouped into numbered sections, for example the rate invariant, excision
without double counting, clock alignment with a known offset, the tie-breaker
rules, the empty-gap rule by hand, and the HTML pages. Build `65d12b64` has
365 checks. `ecg-rpeaks selftest` needs no data files.

### Harnesses in google3

The BUILD file next to the code defines:

- `:selftest_runner` runs `selftest` with a **stubbed** `neurokit2` (a simple
  threshold detector), because neurokit2 is not available in that build
  environment. It proves the checks run and pass; the real detector is only
  exercised where neurokit2 is installed (for example, the lab's Mac).
- `:report_runner` runs `report` and related commands on fixed test files and
  is compared against the previous build's output.

```bash
/google/bin/releases/arca9-local-blaze-cli/blaze-for-agents run //experimental/users/seungjoon/ecg_tool_test:selftest_runner
/google/bin/releases/arca9-local-blaze-cli/blaze-for-agents run //experimental/users/seungjoon/ecg_tool_test:report_runner
```

### Release steps

1. Change the code; add selftest checks for the change.
2. Run both harnesses; both must exit 0.
3. The new tag is printed by any command (it is the hash described in
   section 1).
4. Copy the file to `released/`, the `package/` folder, and the shared
   folder, and add a section to `released/RELEASED_TAG.txt` describing the
   change.
5. Rebuild the package zip.

## 12. Known limitations and loose ends

- **One animal.** Every threshold was tuned on one pig recording (P10). The
  rat profile has never seen real data.
- **Stubbed detector in CI.** The google3 harness does not run the real
  neurokit2, so a change in neurokit2's behaviour would only show up on a
  machine with it installed. Run `ecg-rpeaks selftest` there after upgrades.
- **Ponemah's bad intervals depend on the input type.** They are applied by
  default for `.PnmWav` input (as marked time) but only with `--exclude` for
  EDF input. Reports say which was used, but the difference is easy to miss.
- **Segmenting is untested on the real file.** Segments, index pages,
  `view --start` and `compare --start` were checked on synthetic `.PnmWav`
  files only. The memory figures above are estimates.
- **Size.** One 15,000-line file is easy to ship and hard to navigate. If it
  keeps growing, the natural split is readers / pipeline / compare / viewer,
  with the single-file build generated from them.
