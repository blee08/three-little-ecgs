# How ecg-rpeaks works: a plain-language overview

This page explains what the tool does, why it does it that way, and how far
its numbers can be trusted. For installation and commands, see the
[README](../README.md). For code-level details, see
[IMPLEMENTATION.md](IMPLEMENTATION.md).

## The problem

The lab tests a device meant to help defective hearts keep a steady rate. To
judge the device, we need the heart rate of each animal over many hours, which
means finding every heartbeat in long ECG recordings.

On an ECG, each heartbeat shows up as a sharp spike called the **R peak**. The
time between two R peaks is the **beat interval**, and the heart rate in beats
per minute (**bpm**) comes from how many beats fall in a stretch of time.

Finding R peaks is routine for healthy hearts, but these recordings are harder:

- The hearts are defective, so beats do not always look alike or come at a
  regular pace. Rules that assume a normal rhythm can mislabel real beats as
  noise, or noise as beats.
- The animals move, electrodes lose contact, and the signal sometimes goes flat
  or saturates.
- The recording system (Ponemah) has its own beat detector, but on our test
  recording its leads disagree with each other by about 12%, and one lead
  missed most beats. The lab often corrected its output by hand.

## The pipeline at a glance

```mermaid
flowchart LR
    A["Read the recording<br>(PnmWav, EDF, text)"] --> B["Pick the best lead"]
    B --> C["Find beats<br>(Pan-Tompkins)"]
    C --> D["Clean up the beat list"]
    D --> E["Mark stretches to leave out"]
    E --> F["Heart rate and trend"]
    D --> G["Viewer: check and correct"]
    G --> H["Compare against another list"]
```

### 1. Read the recording

The tool reads Ponemah's raw `.PnmWav` format directly, as well as EDF and
plain text exports. We worked out the `.PnmWav` layout ourselves and confirmed
it sample by sample against the exports. It also reads Ponemah's `.PnmMarks`
file, which holds Ponemah's own beats for each lead and the intervals Ponemah
marked as bad.

A `.PnmWav` holds the whole recording in one file (18.6 hours for the test
animal). The tool cuts it into one-hour segments and treats each one as a
separate file for every step below, with a short overlap so no beat is lost
at the joins. This keeps memory use low and gives one row, and one viewer
page, per hour. Hourly EDF exports are already that size and are not cut.

### 2. Pick the best lead

Each recording has three electrodes, or **leads**, and they do not all record
equally well. The tool runs a quick detection on each lead and checks how much
the detected beats look alike. On a clean lead nearly every detection has the
shape of a heartbeat. On a noisy lead many detections are noise, which does not
look like a heartbeat, so that lead scores lower even if it reports more beats.
Leads with missing samples are marked down. The best lead is used for the whole
file or segment.

We tried two other ideas and dropped them: blending the leads into one signal
was worse than the best single lead in 18 of 19 files, and picking the lead
with the least background noise chose a worse lead in 17 of 19.

### 3. Find beats

The core detector is the standard Pan-Tompkins method (Pan and Tompkins, 1985),
run through the NeuroKit2 library. It highlights the steep upstroke of each
beat and marks a beat wherever that signal crosses a threshold that adapts as
the recording goes on. We use it unchanged.

What we added is work before and after it:

- **Before:** filter the signal to keep the sharp spike of each beat, clip rare
  huge spikes, and process the recording in one-minute pieces so that a single
  artifact cannot push the adaptive threshold so high that real beats are
  missed for a long time.
- **After:** merge two detections that are too close together to be separate
  beats, move each beat to the exact top of its spike, drop detections that are
  far too small to be a beat, and search again inside any unusually long gap.

### 4. Mark stretches to leave out

A heart rate is beats divided by time, so any stretch left out must lose both
its beats and its seconds. Removing only one would push the rate up or down.
Stretches come out for three reasons:

| Reason | Default | Why |
|---|---|---|
| The trace is nearly flat, or samples are missing | Removed | Usually an electrode lost contact; nothing can be measured. |
| No beats even after a second search, for longer than three normal beat intervals | Removed | Treated as unusable. Turn off with `--keep-empty` (or the viewer checkbox) to count these as real pauses. |
| Ponemah marked the interval as bad | Removed when reading a `.PnmWav` directly; for EDF exports, only if you pass `--exclude` | These intervals still contain real beats. On the test recording they ran 8% to 12% faster than the rest, probably because the animal was moving. |

Whether to drop beatless gaps deserves thought. If the heart can truly pause,
dropping those gaps makes the rate look higher than it was. Run once each way
if in doubt; the tool reports how much time each rule removed.

### 5. Heart rate and trend

The tool reports the rate for each file or hour, and a trend across the whole recording
in fixed steps (for example, 5 minutes). Each step's rate is its beats divided
by its usable seconds. Gaps in the recording are drawn as gaps, never joined
across.

## Checking the result

There is no hand-checked answer key for these recordings yet, so accuracy is
measured against a **reference**: a stand-in for the true beats.

1. **Line up the clocks.** Two beat lists can start their clocks at slightly
   different moments. The tool tries small shifts and keeps the one that pairs
   the most beats.
2. **Pair the beats.** Two beats within 80 milliseconds count as the same beat.
   A beat with no partner is a disagreement.
3. **Break ties with another lead.** A disagreement alone does not say which
   list is wrong. The tool adds Ponemah's beat list from a different electrode,
   chosen automatically, and counts a beat as real if at least two of the three
   lists contain it.

Two measures summarize the result:

- **Recall:** of the reference beats, how many we found.
- **Precision:** of the beats we reported, how many are in the reference.

On the first 30 minutes of the test recording:

| | Reference 1: Ponemah, same lead | Reference 2: two-of-three vote |
|---|---:|---:|
| Recall | 98.9% (1,712 / 1,731) | 99.6% (1,818 / 1,826) |
| Precision | 92.9% (1,712 / 1,843) | 98.6% (1,818 / 1,843) |

Most of our apparent false alarms against Reference 1 (106 of 131) were beats
that Ponemah missed on that lead but found on another electrode. Reference 2
includes our own list as one of the three votes, which flatters us somewhat.

## The viewer

The viewer is a web page, one per hour of recording (or per stretch you
choose), with an index page that lists them. It shows all leads stacked,
the chosen lead in gold, every detected beat, and the stretches left out of the
rate. You can add or remove beats by clicking, and the beat count and rate
update as you go. Ponemah's beats can be drawn on top for comparison. A
corrected list can be exported and then scored with `compare`, which is how a
hand-checked answer key can be built.

## How far to trust it

- Every setting was tuned on **one recording from one animal**. Check a new
  animal, implant, or gain setting in the viewer before relying on the numbers.
- Accuracy so far is agreement with Ponemah, not truth. Hand-marking even 10
  minutes would give a true accuracy figure.
- A profile for rats exists but has never been checked against real data; the
  tool warns when it is used.
- Each file's report lists flags (such as a suspected dropout) and how much
  time was removed for each reason. Read those alongside the rate.

## Glossary

| Term | Meaning |
|---|---|
| Lead | One electrode's view of the heart's electrical signal. |
| R peak | The sharp spike of each heartbeat on the ECG. |
| Beat interval | Time between two consecutive R peaks. |
| bpm | Beats per minute. |
| PnmWav / PnmMarks | Ponemah's raw recording file / its database of beats and bad intervals. |
| Reference | The beat list accuracy is measured against, standing in for the truth. |
| Recall / precision | Share of reference beats we found / share of our beats that are in the reference. |

## References

- Pan, J., and Tompkins, W. J. (1985). A real-time QRS detection algorithm.
  *IEEE Transactions on Biomedical Engineering*, BME-32(3), 230-236.
  https://doi.org/10.1109/TBME.1985.325532
- Makowski, D., et al. (2021). NeuroKit2: A Python toolbox for
  neurophysiological signal processing. *Behavior Research Methods*, 53(4),
  1689-1696. https://doi.org/10.3758/s13428-020-01516-y
