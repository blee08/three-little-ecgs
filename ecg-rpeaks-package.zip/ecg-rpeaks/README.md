# ecg-rpeaks

Finds heartbeats (R peaks) in long ECG recordings from implanted telemetry
(Ponemah `.PnmWav`, EDF exports, and plain text exports), and turns them into
heart-rate trends and an interactive viewer for checking and correcting beats.

It was built and tuned on pig recordings. For step-by-step recipes, see
[docs/HOWTO.md](docs/HOWTO.md). For a plain-language explanation of how it
works and how far to trust it, read [docs/OVERVIEW.md](docs/OVERVIEW.md).
Code-level details are in [docs/IMPLEMENTATION.md](docs/IMPLEMENTATION.md).

> **Setting this up with an AI assistant?** Paste this whole file into the
> assistant and say: "Help me install and run this tool on my computer. I am on
> macOS" (or "Windows"). Every step below is a command you can copy.

---

## 1. What you need

- A Mac or a Windows PC.
- About 500 MB of free disk space (mostly for the scientific Python libraries).
- The folder that contains this README (the "package folder"). Below it is
  called `ecg-rpeaks`. If you received a zip file, unzip it first.

You do **not** need to install Python yourself if you use `uv` (step 2). `uv`
downloads a suitable Python (3.12) for you, separate from any Python already on
the computer.

## 2. Install (one time)

If you tried to install an earlier copy and it did not work, first remove it
as described in [2d](#2d-uninstall-or-start-again-from-a-clean-slate), then
follow these steps from the top.

### 2a. Install `uv`

`uv` is a small, free installer for Python tools. It works the same way on Mac
and Windows.

**macOS** (open the Terminal app):

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

**Windows** (open PowerShell):

```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

Close the terminal window and open a new one so the `uv` command is found.

### 2b. Install the tool

In the terminal, go to the folder that **contains** the `ecg-rpeaks` folder,
then run:

```bash
uv tool install --python 3.12 "./ecg-rpeaks[window]"
```

`--python 3.12` makes `uv` download its own Python 3.12 and leave the
computer's Python alone. The tool needs Python 3.10 or newer, and a Mac's
built-in `python3` is often 3.9, which does not work.

On a Mac you may see the warning "failed to patch the install name of the
dynamic library". It is harmless for this tool (all its libraries come
ready-built), so you can ignore it.

The `[window]` part is optional. It adds the desktop-window mode for the viewer
(`view --window`). Without it, the viewer still opens in any web browser.

Check which Python the tool got:

```bash
"$(uv tool dir)/ecg-rpeaks/bin/python" --version
```

It must print `Python 3.12.x` (anything from 3.10 up is fine). If it prints
3.9 or older, uninstall ([2d](#2d-uninstall-or-start-again-from-a-clean-slate))
and run the install command again. On Windows, use
`& "$(uv tool dir)\ecg-rpeaks\Scripts\python.exe" --version`.

If the terminal later says `ecg-rpeaks: command not found`, run
`uv tool update-shell`, then open a new terminal window.

### 2c. Check that it works

```bash
ecg-rpeaks selftest
```

This runs the built-in checks on synthetic data and should end with
`SELFTEST PASSED`. The first line shows the build tag.

The **first run** after installing can sit for a few minutes before printing
anything, while macOS checks the new libraries and matplotlib builds its font
cache ("Matplotlib is building the font cache"). Let it finish. Later runs
start in a few seconds.

### 2d. Uninstall, or start again from a clean slate

**Remove the tool:**

```bash
uv tool uninstall ecg-rpeaks
hash -r        # macOS: make the terminal forget the old command (skip on Windows)
```

**If the tool was ever installed with `pip`** (outside `uv`), remove that copy
too. It is harmless to run if there is none:

```bash
python3 -m pip uninstall -y ecg-rpeaks     # Windows: py -m pip uninstall -y ecg-rpeaks
```

**For a completely clean start**, also remove the Python that `uv` downloaded
and its download cache, so everything is fetched fresh:

```bash
uv python uninstall 3.12
uv cache clean
```

Then install again from [2b](#2b-install-the-tool).

**To remove `uv` itself** as well (only if you no longer need it), on macOS:

```bash
uv cache clean
rm -r "$(uv python dir)" "$(uv tool dir)"
rm ~/.local/bin/uv ~/.local/bin/uvx
```

### Updating to a new version

Uninstall the old version, replace the package folder with the new one, and
install again:

```bash
uv tool uninstall ecg-rpeaks
uv tool install --python 3.12 "./ecg-rpeaks[window]"
ecg-rpeaks selftest
```

Check that the build tag on the first line of the selftest output changed.
Uninstalling first, rather than using `--reinstall`, makes sure the old Python
environment is not kept.

### Other ways to install

If you already use Python 3.10 or newer and prefer not to use `uv`:

```bash
pipx install "./ecg-rpeaks[window]"          # with pipx
# or, inside a virtual environment:
python3 -m pip install "./ecg-rpeaks[window]"
```

You can also skip installing and run the single file directly, after installing
its libraries (`numpy`, `scipy`, `neurokit2`) on Python 3.10 or newer:

```bash
python3 ecg_rpeaks.py selftest
```

Every command below works the same way with `python3 ecg_rpeaks.py` in place
of `ecg-rpeaks`.

---

## 3. Everyday use

The examples use a recording folder like this one. Use your own paths.

```
08062023 P10/
    08062023 P10.P10.20230806195959.PnmWav     <- the raw recording (18.6 h)
    08062023 P10.1.P10.PnmMarks                <- Ponemah's beats and bad intervals
```

Keep the `.PnmMarks` file in the same folder as the `.PnmWav`. The tool finds
it there and uses Ponemah's bad intervals from it automatically.

> **Paths with spaces must be in quotes.** On macOS use single quotes
> `'...'`; on Windows use double quotes `"..."`. You can drag a file or folder
> from Finder or Explorer into the terminal to paste its path.

Output files are written to the folder you run the command from, unless you
give a different path.

**Long recordings are cut into 1-hour segments.** Each segment is analysed on
its own (lead choice, beats, bad intervals, beatless gaps), with a 15 s
overlap so no beat is lost at a boundary, and only one segment is in memory
at a time. P10 gives 19 segments. Change the length with `--segment MINUTES`,
or turn it off with `--segment 0` (needs several GB of memory).

### 3a. Heart-rate trend over a whole recording

```bash
ecg-rpeaks trend --bin 5 --input 'P10/08062023 P10.P10.20230806195959.PnmWav' --html P10_trend.html
```

Open `P10_trend.html` in a web browser. It shows the heart rate in 5-minute
steps across the recording, the total beats, the usable time, and the average
rate. Hover over the chart for the numbers in each step. Ponemah's bad
intervals are already left out.

### 3b. Hour-by-hour summary

```bash
ecg-rpeaks report --input 'P10/08062023 P10.P10.20230806195959.PnmWav' --html P10_report.html --view-dir views
```

This writes a table with one row per segment (which lead was used, beats,
usable time, removed time, rate, warnings) and a TOTAL line for the whole
recording. With `--view-dir`, it also writes a viewer page for every segment
into the `views` folder, plus an index page, and links each row to its page.

### 3c. Look at the beats and correct them

```bash
# one page per hour, plus an index page
ecg-rpeaks view --outdir views --input 'P10/08062023 P10.P10.20230806195959.PnmWav'

# or one page for a stretch you choose
ecg-rpeaks view --outdir views --input 'P10/08062023 P10.P10.20230806195959.PnmWav' --start 02:15:00 --minutes 30
```

Then open `views/08062023 P10.P10.20230806195959.index.html` (on macOS:
`open "views/..."`; on Windows: `start "views\..."`). Add `--window` to open
pages in a desktop window instead.

In the viewer:

- All leads are drawn stacked. The lead the tool chose is gold, with a marker
  on every detected beat.
- Shaded stretches are left out of the rate: red for no signal, missing data
  or Ponemah's bad intervals, violet for beatless gaps. The **Drop empty
  gaps** checkbox switches the beatless-gap rule off or on, and the beat count
  and rate update at once.
- **Edit R** lets you click to add a missed beat or remove a wrong one.
  **Export CSV** saves your corrected list. Its times count from the start of
  the page, and the file records where the page starts.
- To keep editing later, reopen the same stretch with `--start` (and
  `--minutes`) plus `--edits <your exported file>.csv`.
- To draw Ponemah's beats on top for comparison, add
  `--ponemah P10_ch3.csv` (from step 3d).

### 3d. Get Ponemah's own beats and bad intervals

The `.PnmMarks` file sits next to the recording. It holds Ponemah's detected
beats for each lead and its list of bad intervals.

```bash
ecg-rpeaks marks --input 'P10/08062023 P10.1.P10.PnmMarks'
```

This prints a table of the channels (called contexts) in the file, with beat
counts. Then export Ponemah's beats for one lead (pick the context number
from the table):

```bash
ecg-rpeaks marks --input 'P10/08062023 P10.1.P10.PnmMarks' --context 2 --export-beats P10_ch3.csv
```

### 3e. Measure accuracy against another beat list

Compare the tool's beats with Ponemah's beats over a stretch of the
recording:

```bash
ecg-rpeaks compare --minutes 30 \
  --input 'P10/08062023 P10.P10.20230806195959.PnmWav' \
  --manual P10_ch3.csv
```

Add `--start HH:MM:SS` to score a stretch other than the first one. Always
give `--minutes` with a `.PnmWav`: `compare` is not segmented, and the whole
file at once needs several GB of memory. To score a list you corrected in
the viewer, give it as `--manual`; the tool reads from the file which
stretch it belongs to.

It lines up the two clocks, pairs the beats, and prints recall, precision,
and where the two lists disagree. It also picks a third lead from the
`.PnmMarks` file as a tie-breaker, and prints the accuracy against the
two-of-three vote. Use `--arbiter FILE` to choose the tie-breaker yourself, or
`--arbiter none` to skip it.

On Windows PowerShell, put the command on one line, or end each line with a
backtick `` ` `` instead of a backslash `\`.

### 3f. EDF files

The same commands work on EDF exports. Give a folder and the tool reads every
`.edf` in it. EDF files do not carry Ponemah's bad intervals; to remove them,
export them with `marks --export-excl P10_badspans.csv` and add
`--exclude P10_badspans.csv` to `trend`. See
[docs/HOWTO.md](docs/HOWTO.md#10-if-you-have-edf-files-instead).

---

## 4. Useful options

| Option | Commands | What it does |
|---|---|---|
| `--segment MIN` | `trend`, `report`, `view` | Length of the pieces a long recording is cut into (default 60; 0 = do not cut). |
| `--start T` | `view`, `compare` | Where the stretch starts, as `HH:MM:SS`, `MM:SS` or seconds from the recording start. |
| `--minutes N` | `view`, `compare` | Length of the stretch (from `--start`, or from the beginning). |
| `--keep-empty` | all that compute a rate | Count beatless gaps as real pauses instead of removing them. Use this if the heart may truly skip beats. |
| `--exclude FILE.csv` | `trend` | For EDF input: also remove Ponemah's bad intervals (from `marks --export-excl`). A `.PnmWav` does this already. |
| `--marks FILE` | `compare` | Where the `.PnmMarks` file is, if it is not next to the recording. |
| `--lead N` | all that detect | Force a lead instead of letting the tool choose. |
| `--html FILE.html` | `trend`, `report` | Write a web page as well as the text summary. |
| `--window` | `view` | Open the viewer in a desktop window (needs the `[window]` extra). |

Every command has built-in help: `ecg-rpeaks --help`, `ecg-rpeaks trend --help`.

## 5. Files it reads and writes

| File | What it is |
|---|---|
| `.PnmWav` | Ponemah's raw recording. Read directly. |
| `.edf` | EDF export of the recording (for example, hourly files). |
| `.txt` / `.asc` | Plain text export. |
| `.PnmMarks` | Ponemah's database next to the recording: its beats per lead and its bad intervals. |
| `*.csv` peak files | Beat lists: written by `detect`, `marks --export-beats`, and the viewer's Export CSV; read by `compare` and `view --edits`. |
| `*.html` | Viewer pages, trend and report pages. Self-contained: open offline, email, or share. |

## 6. Troubleshooting

- **`command not found: ecg-rpeaks`**: run `uv tool update-shell` and open a
  new terminal.
- **A path "does not exist" but it does**: the path probably has spaces and
  needs quotes.
- **`TypeError: unsupported operand type(s) for |` from `neurokit2`**: the tool
  was installed on Python 3.9 or older. Uninstall it (step 2d) and install
  again (step 2b), then check the Python version as shown in 2b.
- **"failed to patch the install name of the dynamic library" during install**:
  harmless for this tool; ignore it. It means Apple's command line tools are
  not installed. Only if the tool then fails to start, install them with
  `xcode-select --install`, run `uv python uninstall 3.12`, and install again.
- **The first command seems to hang**: the first run after installing can take
  a few minutes (macOS checks new libraries; matplotlib builds a font cache).
  Wait once; later runs are fast.
- **`neurokit2` or `scipy` fails to install**: make sure you are using `uv` (it
  picks a Python version that has ready-made packages), then retry step 2b.
- **The viewer's desktop window does not open**: the `[window]` extra is
  missing. Open the `.html` file in a browser instead, or reinstall with
  `[window]`.
- **The computer runs out of memory**: keep segmenting on (no `--segment 0`),
  and give `compare` a `--minutes`.
- **Unexpected numbers**: run `ecg-rpeaks selftest` first. If it passes, open
  the file in the viewer and look at the shaded stretches and the chosen lead.

When asking for help, include the full command you ran and the first lines of
its output, which show the tool's build tag.
